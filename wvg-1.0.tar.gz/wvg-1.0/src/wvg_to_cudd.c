/*
 * wvg_to_cudd.c
 *
 *  Copyright (C) 2009,2010,2011 Stefan Bolus, University of Kiel, Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "wvg_to_cudd.h"

struct threshold_cache_ent_t
{
	int lb,ub; /*(lb,ub] or (lb,ub) if ub=infty. */
	DdNode * f;
};

/* Used to insert entries. */
static gint _threshold_cache_key_compare (const struct threshold_cache_ent_t * a,
		const struct threshold_cache_ent_t * b)
{
	return a->ub - b->ub;
}

/* Used to lookup entries. */
static gint _threshold_cache_lookup_compare (const struct threshold_cache_ent_t * e, gint q)
{
	// lb < q <= ub ?
	if (q <= e->lb) return -1;
	else if (q > e->ub) return 1;
	else return 0;
}


/*!
 * Recursive step to build the ROBDD for a weighted voting game.
 *
 * \param a Weights in the remaining game. a[0] is the next weight.
 * \param b Remaining quota.
 * \param n Number of players in the original game.
 * \param i Current player. [0-indexed]
 * \param lb Will contain the maximum weight of all losing coalitions.
 * \param ub Will contain the minimum weight of all winning coalitions.
 * \param left Cumulative of the remaining players.
 * \return Returns the ROBDD representing the game [b;a] with n-i+1 players.
 */
static DdNode * _create_threshold_bdd_aux (DdManager * manager, GTree * cache[],
			const gint * a, gint b, gint n, gint i,
			gint left, gint * /*out*/ lb, gint * /*out*/ ub)
{
	if (i == n) {
		if (b <= 0) /* winning */ {
			*lb = G_MININT;
			*ub = 0;
			return Cudd_ReadOne(manager);
		}
		else {
			*lb = 0;
			*ub = G_MAXINT;
			return Cudd_Not(Cudd_ReadOne(manager));
		}
	}
	else {
		struct threshold_cache_ent_t * ent;

		ent = g_tree_search (cache[i],
				(GCompareFunc)_threshold_cache_lookup_compare, (gpointer)b);
		if (ent) {
			*lb = ent->lb;
			*ub = ent->ub;
			return ent->f;
		}
		else {
			DdNode *r,*t,*e;
			int lbT,lbE,ubT,ubE;

			t = _create_threshold_bdd_aux (manager,cache,a+1,b-a[0],n,i+1,left-a[0],&lbT,&ubT);
			Cudd_Ref (t);
			e = _create_threshold_bdd_aux (manager,cache,a+1,b,     n,i+1,left-a[0],&lbE,&ubE);
			Cudd_Ref (e);

			*lb = MAX(lbT+a[0],lbE); /* max loosing */
			*ub = MIN((ubT<G_MAXINT)?ubT+a[0]:ubT,ubE); /* min winning */

			if (Cudd_IsComplement(t)) {
				r = Cudd_bddIte(manager,Cudd_bddIthVar(manager,i),
						Cudd_Not(t),Cudd_Not(e));
				r = Cudd_Not(r);
			}
			else r = Cudd_bddIte(manager,Cudd_bddIthVar(manager,i),t,e);

			Cudd_Deref (t);
			Cudd_Deref (e);

			/* It is not necessary to reference the DdNodes in the the cache
			 * because they are referenced either by the nodes created so far,
			 * or by the this function. */
			ent = g_new (struct threshold_cache_ent_t, 1);
			ent->lb = *lb;
			ent->ub = *ub;
			ent->f = r;
			g_tree_insert (cache[i], ent, ent);

			return r;
		}
	}
}


static DdNode * _create_threshold_bdd (DdManager * manager, const gint * a, gint b, gint n)
{
	GTree ** cache = g_new(GTree*,n);
	int ub,lb,left;
	DdNode * r;
	int i;

	for (i = 0, left = 0 ; i < n ; i ++) {
		cache[i] = g_tree_new ((GCompareFunc) _threshold_cache_key_compare);
		left += a[i];
	}
	r = _create_threshold_bdd_aux(manager,cache,a,b,n,0,left,&lb,&ub);

	for (i = 0 ; i < n ; i ++) {
		g_tree_foreach (cache[i], (GTraverseFunc) g_free, NULL);
		g_tree_destroy (cache[i]);
	}
	g_free (cache);

	return r;
}


DdNode * wvg_to_cudd (DdManager * manager, gint n, gint q, const gint * w)
{
	return _create_threshold_bdd (manager,w,q,n);
}
