/*
 * main.c
 *
 *  Copyright (C) 2011 Stefan Bolus, University of Kiel, Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "wvg_to_cudd.h"
#include "relview/plugin.h"
#include <gtk/gtk.h>
#include <errno.h>
#include <ctype.h> // isdigit
#include <string.h> // strtok
#include "ui_xml.c" // UI Specification. ./Makefile.am

#define NDEBUG 1

/*!
 * Callback for the availability of a menu entry. Always returns TRUE
 * indicating that the menu entry is always available.
 */
static gboolean _always_enabled (gpointer user_data, MenuEntry * entry, gpointer obj) {
	return TRUE;
}


/*!
 * A weighted voting game. Use \ref _wvg_destroy to destroy it. The weights
 * field has to be initialized using \ref g_new or \ref g_new0. The quota has
 * to be strictly positive while for the weights positive values including 0
 * are okay.
 */
typedef struct WVG
{
	gint quota;
	gint n;
	gint * weights;
} WVG;


#ifndef NDEBUG
static gchar * _wvg_to_string (const WVG * self)
{
	GString * s = g_string_new ("");
	int i;
	g_string_append_c (s, '[');
	g_string_append_printf (s, "%d;", self->quota);
	for (i = 0 ; i < self->n ; ++i) {
		if (i>0) g_string_append_c (s, ',');
		g_string_append_printf (s, "%d", self->weights[i]);
	}
	g_string_append_c (s, ']');
	return g_string_free (s, FALSE);
}
#endif


/*!
 * Destroys a \ref WVG object representing a weighted voting game.
 */
static void _wvg_destroy (WVG * self)
{
	if (self) {
		if (self->weights) g_free (self->weights);
		g_free (self);
	}
}


/*!
 * Parses the game as follows:
 *    1. Replace all non-digits characters by spaces.
 *    2. Convert all subsequent digits into integers.
 *    3. The first integer becomes the quota the remaining become the weights.
 *
 * \return Returns a WVG or NULL.
 */
static WVG * _parse_input (const gchar * input)
{
	gchar * copy = g_strdup (input), *ptr;
	int len, val;
	GList/*<gint*>*/ * l = NULL;
	uint valCount = 0;
	WVG * game = g_new0 (WVG,1);

	/* Replace all non-digits by spaces. */
	for ( ptr = copy ; *ptr ; ++ptr) {
		if ( !isdigit(*ptr)) *ptr = ' ';
	}

    ptr = copy;
    while (sscanf(ptr, " %d%n", &val, &len) > 0) {
    		gint * ent = g_new(gint, 1);
    		*ent = val;
            ptr += len;
            l = g_list_prepend (l, ent);
    }

    l = g_list_reverse (l);
    game->n = g_list_length (l) - 1;
    if (game->n > 0) {
    	GList/*<gint*>*/ * wptr = l->next;
    	int i;

    	game->quota = *(gint*)l->data;
    	game->weights = g_new (gint, game->n);
    	for ( i=0 ; i<game->n ; ++i, wptr = wptr->next)

    		game->weights[i] = *(gint*)wptr->data;
    }
    else {
    	g_free (game);
    	game = NULL;
    }

    g_list_foreach (l,(GFunc)g_free,NULL);
    g_list_free (l);
    return game;
}


/*!
 * Opens a dialog and asks the user for a weigted voting game. Returns TRUE
 * in case the use pressed okay and FALSE otherwise. The input is returned
 * in s that has to be initialized. The input is not check for validity.
 */
static gboolean _ask_wvg (GtkWidget * parent, GString * name, GString * /*inout*/ input)
{
	GError * err = NULL;
	gboolean success = FALSE;

	GtkBuilder * builder = gtk_builder_new ();
	if ( !gtk_builder_add_from_string (builder, _ui_xml_str, _ui_xml_str_size, &err)) {
		g_warning ("wvg-to-vector: Unable to load UI specification.");
	}
	else {
		GtkWidget * dialog = GTK_WIDGET(gtk_builder_get_object (builder, "dialogInputGame"));
		GtkEntry * entryName = GTK_ENTRY(gtk_builder_get_object (builder, "entryName"));
		GtkEntry * entry = GTK_ENTRY(gtk_builder_get_object (builder, "entryGame"));
		gint resp;

		assert (dialog != NULL);
		assert (entry != NULL);
		assert (entryName != NULL);

		gtk_window_set_transient_for (GTK_WINDOW(dialog), GTK_WINDOW(parent));

		resp = gtk_dialog_run (GTK_DIALOG(dialog));
		if (resp == 1) /* Create */ {
			g_string_assign (name, gtk_entry_get_text (entryName));
			g_string_assign (input, gtk_entry_get_text (entry));
			success = TRUE;
		}
		else { /* Abort */ }

		gtk_widget_destroy (GTK_WIDGET(dialog));
		g_object_unref (G_OBJECT(builder));
	}

	g_object_unref (G_OBJECT(builder));
	return success;
}


/*!
 * Called when the user selected and entry in the popup menu.
 *
 * \param user_data Pointer to the function which is to be called.
 * \param entry The menu entry.
 * \param obj The RelationWindow object.
 */
static void _on_activate (gpointer user_data, MenuEntry * entry, gpointer obj)
{
	Relview * rv = rv_get_instance ();
	RelationWindow * window = (RelationWindow*) obj;
	RelManager * rel_manager = rv_get_rel_manager(rv);

	GString * input = g_string_new (""), * name = g_string_new ("");
	gboolean success;

	success = _ask_wvg (relation_window_get_window(window), name, input);
	if (success) {
		gchar * name_str = g_strstrip(g_strdup(name->str));

		/* Use $ if no name is given. */
		if (*name_str == '\0') {
			g_free (name_str);
			name_str = g_strdup ("$");
		}

		if ( !rel_is_valid_name (name_str, rel_manager)) {
			rv_user_error ("Invalid relation name", "Name \"%s\" is invalid.", name_str);
		}
		else {
			WVG * game = _parse_input (input->str);
			if (game) {
				KureContext * context = rv_get_context(rv);
				DdManager * dd_manager = kure_context_get_manager (context);
				RelManager * rel_manager = rv_get_rel_manager(rv);
				KureRel * impl = NULL;
				Rel * rel = NULL;
				DdNode * bdd = NULL;
				mpz_t rows, cols;

#ifndef NDEBUG
				{
					gchar * game_str = _wvg_to_string (game);
					printf ("wvg-to-vector: Game is %s\n", game_str);
					g_free (game_str);
				}
#endif

				mpz_init (rows);
				mpz_ui_pow_ui (rows, 2, game->n);
				mpz_init_set_si (cols, 1);

				bdd = wvg_to_cudd (dd_manager, game->n, game->quota, game->weights);
				if (bdd) {
					Cudd_Ref (bdd);
					impl = kure_rel_new_from_bdd (context, bdd, rows, cols);
					if (impl) {
						Cudd_Deref (bdd);

						rel = rel_new_from_impl (name_str, impl);
						if (rel) {
							gboolean inserted = rv_user_rename_or_not(rv, rel);

							if (inserted)
								relation_window_set_relation(window, rel);
							else /* user canceled */
								rel_destroy(rel);
						}
						else kure_rel_destroy (impl);
					}
					else {
						Cudd_RecursiveDeref (dd_manager, bdd);
					}
				}
				_wvg_destroy (game);
			}
		}

		g_free (name_str);
	}
	else { /* User canceled. */ }

	g_string_free (input, TRUE);
	g_string_free (name, TRUE);
}



G_MODULE_EXPORT static gboolean onInit (int * version, rvp_plugin_id_t id)
{
    return TRUE; /* don't ignore module. */
}


static const char _menu_path [] = "/relation-window";
static MenuEntry * _menu_entry = NULL;


G_MODULE_EXPORT static void onEnable (const gchar * message)
{
	Relview * rv = rv_get_instance();
	MenuManager * manager = rv_get_menu_manager(rv);
	MenuDomain * domain = menu_manager_get_domain(manager, _menu_path);

	if ( NULL == domain) {
		g_warning ("wvg-to-vector: Unknown menu domain: %s", _menu_path);
	}
	else {
		gboolean success;

		_menu_entry = menu_entry_new ("WVG->Vector", _always_enabled,
				_on_activate, NULL);
		if (_menu_entry) {
			success = menu_domain_add (domain, "actions" /*subpath*/, _menu_entry);
			if ( !success) {
				g_warning ("wvg-to-vector: Unable to add menu entry to %s/actions",	_menu_path);
				menu_entry_destroy (_menu_entry);
			}
		}
	}
}


G_MODULE_EXPORT static void onDisable ()
{
	if (_menu_entry) {
		Relview * rv = rv_get_instance();
		MenuManager * manager = rv_get_menu_manager(rv);
		MenuDomain * domain = menu_manager_get_domain(manager, _menu_path);
		if (menu_domain_steal (domain, _menu_entry)) {
			menu_entry_destroy (_menu_entry);
			_menu_entry = NULL;
		}
	}
}


RvPlugInInfo PLUG_IN_INFO = {
		onInit, NULL, onEnable, onDisable,
		(gchar*) "WVG-to-Vector",
		(gchar*) "Creates a relational vector from a weighted voting game."
};


RV_PLUGIN_MAIN()

