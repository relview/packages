/*
 * main.c
 *
 *  Copyright (C) 2011 Stefan Bolus, University of Kiel, Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


#include "relview/plugin.h"
#include <gtk/gtk.h>
#include <errno.h>
#include <ctype.h> // isdigit
#include <string.h> // strtok
#include "ui_xml.c" // UI Specification. ./Makefile.am

#define PLUGIN_MSG_DOMAIN "cudd-info"

#define NDEBUG 1

/*!
 * Shows the relation's ROBDD information in a dialog window.
 */
static void _showRelInfoDialog (RelationWindow * rw, Rel * rel)
{
	Relview * rv = rv_get_instance ();
	GError * err = NULL;
	GtkBuilder * builder = gtk_builder_new ();
	if ( !gtk_builder_add_from_string (builder, _ui_xml_str, _ui_xml_str_size, &err)) {
		g_warning (PLUGIN_MSG_DOMAIN": Unable to load UI specification. Reason: %s", err->message);
		g_error_free(err);
	}
	else {
		GtkWidget * dialog = GTK_WIDGET(gtk_builder_get_object (builder, "dialogRelInfo"));
		GtkWidget * treeview = GTK_WIDGET(gtk_builder_get_object (builder, "treeviewRelInfo"));
		GtkListStore * model = NULL;
		GtkTreeIter iter;
		gchar buf [4096];
		KureRel * impl = rel_get_impl (rel);
		DdManager * manager = kure_context_get_manager (kure_rel_get_context(impl));
		DdNode * bdd = kure_rel_get_bdd (impl);
		gint vars_rows = kure_rel_get_vars_rows (impl);
		gint vars_cols = kure_rel_get_vars_cols (impl);

		g_assert(dialog != NULL);
		g_assert(treeview != NULL);

		model = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(treeview)));

		/* Relation Name */
		gtk_list_store_append(model, &iter);
		gtk_list_store_set (model, &iter, 0, "Name", 1, rel_get_name(rel), -1);

		/* Number of variables */
		{
			sprintf (buf, "%d", vars_rows + vars_cols);

			gtk_list_store_append(model, &iter);
			gtk_list_store_set(model, &iter, 0, "Var. Count", 1, buf,
					2, "Number of variables used.", -1);
		}

		/* DAG size */
			sprintf(buf, "%d", Cudd_DagSize(bdd));
			gtk_list_store_append(model, &iter);
			gtk_list_store_set(model, &iter, 0, "DAG Size", 1, buf,
					2, "Number of nodes.", -1);

		/* Minterm count */
		{
			mpz_t entries;
			mpz_init (entries);

			kure_get_entries (impl, entries);
			gmp_sprintf (buf, "%Zd", entries);

			gtk_list_store_append(model, &iter);
			gtk_list_store_set(model, &iter, 0, "Minterm Count", 1, buf,
					2, "Number of bits set.", -1);

			mpz_clear (entries);
		}

		/* Path count */
			sprintf(buf, "~%.0lf", Cudd_CountPath(bdd));
			gtk_list_store_append(model, &iter);
			gtk_list_store_set(model, &iter, 0, "Path Count", 1, buf,
					2, "Number of paths to a terminal node.", -1);

		/* Density */
			sprintf(buf, "%.3lf", Cudd_Density (manager, bdd, vars_rows + vars_cols));
			gtk_list_store_append(model, &iter);
			gtk_list_store_set(model, &iter, 0, "Density", 1, buf,
					2, "Ratio of the number of minterms to the number of nodes.", -1);

		/* Number of Leaves */
			sprintf(buf, "%d", Cudd_CountLeaves(bdd));
			gtk_list_store_append(model, &iter);
			gtk_list_store_set(model, &iter, 0, "Leaves", 1, buf,
					2, "Number of leaves.", -1);

			gtk_window_set_transient_for (GTK_WINDOW(dialog),
					GTK_WINDOW(relation_window_get_window(rw)));

			gtk_dialog_run (GTK_DIALOG(dialog));
			gtk_widget_destroy (dialog);
	}

	g_object_unref (G_OBJECT(builder));
	return;
}


/*!
 * Called when the user selected an entry in the popup menu.
 *
 * \param user_data Pointer to the function which is to be called.
 * \param entry The menu entry.
 * \param obj The GraphWindow object.
 */
static void _on_show_rel_info_activate (gpointer user_data, MenuEntry * entry, gpointer obj)
{
	RelationWindow * rw = relation_window_get_instance();
	Rel * rel = relation_window_get_relation(rw);
	if (rel)
		_showRelInfoDialog (rw, rel);
}


/*!
 * Callback for the availability of a menu entry. Always returns TRUE
 * indicating that the menu entry is always available.
 */
static gboolean _always_enabled (gpointer user_data, MenuEntry * entry, gpointer obj) {
	return TRUE;
}


G_MODULE_EXPORT static gboolean onInit (int * version, rvp_plugin_id_t id)
{
    return TRUE; /* don't ignore module. */
}


static const char _menu_path [] = "/relation-window";
/* Stores our menu entries so we can remove them when the plugin is
 * disabled. */
static GList/*<MenuEntry*>*/ * _menu_entries = NULL;


G_MODULE_EXPORT static void onEnable (const gchar * message)
{
	Relview * rv = rv_get_instance();
	MenuManager * manager = rv_get_menu_manager(rv);
	MenuDomain * domain = menu_manager_get_domain(manager, _menu_path);

	if ( NULL == domain) {
		g_warning (PLUGIN_MSG_DOMAIN": Unknown menu domain: %s", _menu_path);
	}
	else {
#define MENU_ENTRY_ADD(name, is_enabled_func, on_activate_func, user_data) { \
	MenuEntry * e = menu_entry_new (name, is_enabled_func, on_activate_func, (gpointer) user_data); \
	if (e) { \
		_menu_entries = g_list_prepend (_menu_entries, (gpointer)e); \
		menu_domain_add (domain, "actions"/*subpath*/, e); } }

		MENU_ENTRY_ADD("Show BDD Info", _always_enabled, _on_show_rel_info_activate, NULL);
	}
}


G_MODULE_EXPORT static void onDisable ()
{
	if (_menu_entries != NULL) {
		Relview * rv = rv_get_instance();
		MenuManager * manager = rv_get_menu_manager(rv);
		MenuDomain * domain = menu_manager_get_domain (manager, _menu_path);

		if (domain != NULL) {
			GList/*<MenuEntry*>*/ * iter = _menu_entries;
			for ( ; iter ; iter = iter->next) {
				MenuEntry * cur = (MenuEntry*) iter->data;
				menu_domain_steal (domain, cur);
				menu_entry_destroy (cur);
			}
		}

		g_list_free (_menu_entries);
		_menu_entries = NULL;
	}
}


RvPlugInInfo PLUG_IN_INFO = {
		onInit, NULL, onEnable, onDisable,
		(gchar*) "ROBDD Info",
		(gchar*) "Shows information about a relation's ROBDD."
};


RV_PLUGIN_MAIN()

