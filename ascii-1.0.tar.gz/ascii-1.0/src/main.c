/*
 * main.c
 *
 *  Copyright (C) 2010 Stefan Bolus, University of Kiel, Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

// Ask the user graphs/relations should be exported.
// Ask the user which graphs/rels should be imported.

// get names of graphs/files in the ascii file.
// don't save/load relations, which have more than GINT_MAX rows/cols

#include "relview/plugin.h"
#include <errno.h>
#include <ctype.h>

typedef IOHandler AsciiHandler;

static AsciiHandler * _handler = NULL;

GQuark _error_domain ()
{
	static GQuark domain = 0;
	if (0 == domain)
		domain = g_quark_from_string ("ASCII File Handler");
	return domain;
}

static gboolean _write_rel_to_stream (Rel * rel, FILE * fp, GError ** perr)
{
	KureRel * impl = rel_get_impl (rel);

	if ( ! kure_rel_prod_fits_si(impl)) {
		g_set_error (perr, _error_domain(), 0, "Unable write file. Relation is too big.");
		return FALSE;
	}
	else {
		int rows = kure_rel_get_rows_si(impl),
				cols = kure_rel_get_cols_si(impl);
		int i,j;
		int vars_rows = kure_rel_get_vars_rows(impl),
				vars_cols = kure_rel_get_vars_cols(impl);

		fprintf (fp, "%s (%d, %d)\n", rel_get_name(rel), rows, cols);
		for (i = 0 ; i < rows ; i ++) {
			gboolean first_in_row = TRUE;

			for (j = 0 ; j < cols ; j ++) {
				Kure_bool bit = kure_get_bit_fast_si(impl, i, j,vars_rows, vars_cols);
				if (bit) {
					if (first_in_row) {
						fprintf (fp, "%d : %d", i+1, j+1);
						first_in_row = FALSE;
					}
					else {
						fprintf (fp, " %d", j+1);
					}
				}
			}

			if ( !first_in_row)
				fputc ('\n', fp);
		}

		return TRUE;
	}
}


static gboolean _is_empty_line (const char * s, int len)
{
  const char * p;

  for (p = s ; *p ; ++p)
    if ( !isspace(*p)) return FALSE;
  return TRUE;
}


static gboolean _read_rel_from_stream (FILE * fp, KureContext * context, int * pline_no,
		gchar ** /*out*/ pfname, KureRel ** /*out*/ prel, GError ** /*out*/ perr)
{
	gboolean success = TRUE;
	char * line = NULL;
	size_t size = 0;
	ssize_t len;
#define NAME_BUF_SIZE 128
	gchar name_buf[NAME_BUF_SIZE+1];
	int rows, cols;

	*pfname = NULL;
	*prel = NULL;

	len = getline (&line, &size, fp);
	if (len < 0) {
		g_set_error (perr, _error_domain(), 0, "Error reading from stream. "
				"Reason: %s", g_strerror (errno));
		return FALSE;
	}

#define _xstr(s) #s
#define xstr(s) _xstr(s)
	if (3 != sscanf (line, "%"xstr(NAME_BUF_SIZE)"s ( %d, %d )", name_buf, &rows, &cols)) {
		g_set_error (perr, _error_domain(), 0, "Unable to read relation in "
				"line %d. Format \"%%s (%%d, %%d)\" expected. Got \"%s\".",
				*pline_no-1, line);
		success = FALSE;
	}
	else {

		*pfname = g_strdup (name_buf);
		*prel = kure_rel_new_with_size_si(context, rows, cols);
		if (!*prel) {
			KureError * err = kure_context_get_error (context);
			g_set_error (perr, _error_domain(), 0, "Unable to create relation. "
					"Reason: %s", err ? err->message : "Unknown");
			success = FALSE;
		}

		/* Read lines until we find an empty line. That is a line containing
		 * only whitespaces, or an error occures or EOF is reached. */
		while (success && !feof (fp)) {
			int i,j;

			len = getline (&line, &size, fp);
			if (len < 0 && !feof(fp)) {
				g_set_error (perr, _error_domain(), 0, "Error reading from stream. "
						"Reason: %s", g_strerror (errno));
				success = FALSE;
				break;
			}
			else if (len < 0) /* EOF */ {
				break;
			}
			else {
				(*pline_no) ++;
				if (_is_empty_line(line,len)) break;
				else {
					int off = 0;

					if (1 != sscanf (line, "%d : %n", &i, &off)) {
						g_set_error (perr, _error_domain(), 0, "Error in line %d. "
								"Expected format: \"%%d : \". "
								"Got \"%s\".\n", *pline_no-1, line);
						success = FALSE;
					}
					else {
						char * ptr = line + off;
						while (1 == sscanf (ptr, " %d%n", &j, &off)) {
							kure_set_bit_si(*prel, TRUE, i-1, j-1);
							ptr += off;
						}
					}
				}
			}
		} /*while*/


		if (line) free (line);
	}

	if (!success) {
		if (*pfname) g_free (*pfname);
		if (*prel) kure_rel_destroy(*prel);
	}

	return success;
}

/*!
 * Implements IOHandler::saveSingleRel. See \ref _get_handler.
 */
static gboolean _handler_save_rel (AsciiHandler * self,
		const gchar * filename,	Rel * rel, GError ** perr)
{
	FILE * fp = fopen (filename, "w+");
	if ( !fp) {
		g_set_error (perr, _error_domain(), 0, "Unable to create file '%s'. "
				"Reason: %s", filename, g_strerror(errno));
		return FALSE;
	}
	else {
		gboolean ret = _write_rel_to_stream(rel, fp, perr);
		fclose (fp);
		return ret;
	}
}

/*!
 * Implements IOHandler::load. See \ref _get_handler.
 */
static gboolean _handler_load_rels (AsciiHandler * self,
		const gchar * filename,
		IOHandler_ReplaceCallback replace,
		gpointer replace_user_data, GError ** perr)
{
	gboolean success = TRUE;
	Relview * rv = rv_get_instance();

	FILE * fp = fopen (filename, "r");
	if ( !fp) {
		g_set_error (perr, _error_domain(), 0, "Unable to open file '%s' "
				"for reading. Reason: %s", filename, g_strerror(errno));
		return FALSE;
	}
	else {
		KureContext * context = rv_get_context(rv);
		KureRel * impl = NULL;
		gchar * name = NULL;
		GQueue/*<Rel*>*/ * list = g_queue_new();
		int line_no = 1;

		/* Set the first relation from the file which has been inserted
		 * successfully as the active relation. */
		Rel * first_inserted = NULL;

		DefaultReplacePolicyHandler * policy_handler
			= default_replace_policy_handler_new (rv);
		default_replace_policy_handler_set_parent_callback (policy_handler,
				replace, replace_user_data);

		/* Read all relations from the given file. */
		while (success && !feof(fp)) {
			/* Seek the first non-whitespace character in the stream. */
			while (success && !feof(fp)) {
				int ch = fgetc (fp);
				if (ch < 0 && !feof(fp)) {
					g_set_error (perr, _error_domain(), 0, "22Error reading from stream. "
							"Reason: %s", g_strerror (errno));
					success = FALSE;
				}
				else if (feof(fp)) break;
				else {
					if ('\n' == ch)
						line_no ++;
					else if ( !isspace(ch)) {
						ungetc(ch, fp);
						break;
					}
				}
			}

			/* The next character (if there is on) is not a whitespace. */
			if (success && !feof(fp)) {
				success = _read_rel_from_stream(fp, context, &line_no, &name, &impl, perr);
				if (success) {
					Rel * rel = rel_new_from_impl(name, impl);
					if (rel)
						g_queue_push_tail(list, rel);
					else {
						g_set_error (perr, _error_domain(), 0, "Unable to create "
								"relation with name '%s'.",	name);
						success = FALSE;
					}
				}
			}
		}

		/* Now add the relations to the global state and replace existing
		 * objects if necessary. */
		if (success) {
			Namespace * ns = rv_get_namespace (rv);
			IOHandler_ReplaceCallback clbk
				= default_replace_policy_handler_get_callback(policy_handler);
			RelManager * manager = rv_get_rel_manager(rv);

			GList/*<Rel*>*/ * iter = list->head;
			for ( ; iter ; iter = iter->next) {
				Rel * rel = (Rel*) iter->data;
				RvObject * conflict = RV_OBJECT(namespace_get_by_name(ns, rel_get_name(rel)));
				gboolean really_insert = TRUE;

				if (conflict) {
					RvReplaceAction action;
					IOHandlerReplaceInfo info = {0};
					info.obj = RV_OBJECT(rel);

					action = clbk (policy_handler, &info);

					switch (action) {
					case RV_REPLACE_ACTION_REPLACE:
						rv_object_destroy(conflict); break;
					case RV_REPLACE_ACTION_KEEP:
						really_insert = FALSE;
						rel_destroy(rel);
						break;
					default:
						g_warning ("Unknown RV_REPLACE_ACTION: %d", action);
					}
				}

				if (really_insert) {
					if ( !rel_manager_insert(manager, rel)) {
						rv_user_error("Unable to add relation", "Relation "
								"'%s' from file '%s' could not be added. "
								"Skipped", rel_get_name(rel));
						rel_destroy(rel);
					}
					else {
						if (NULL == first_inserted)
							first_inserted = rel;
					}
				}
			}
		}

		default_replace_policy_handler_destroy (policy_handler);

		fclose (fp);

		if(first_inserted)
			rvp_relation_window_set_relation(first_inserted);

		return success;
	}
}

static void _handler_destroy (AsciiHandler * self)
{
	if (self) {
		if (self != _handler) {
			g_warning ("ascii-plugin: Got wrong handler %p. My handler is %p.", self, _handler);
		}
		else {
			_handler = NULL;
			g_free (self);
		}
	}
}

static IOHandler * _get_handler ()
{
	if (NULL == _handler) {
		static IOHandlerClass * c = NULL;
		_handler = g_new0 (IOHandler,1);
		c = g_new0 (IOHandlerClass,1);

		c->saveSingleRel = _handler_save_rel;
		c->loadRels = _handler_load_rels;
		c->destroy = _handler_destroy;

		c->name = g_strdup ("ASCII");
		c->extensions = g_strdup ("ascii");
		c->description = g_strdup ("Can write relations in ASCII format.");

		_handler->c =c ;
		return _handler;
	}

	return _handler;
}

static gboolean onInit (int * version, rvp_plugin_id_t id)
{
    return TRUE; /* don't ignore module. */
}

static void onEnable (const gchar * message)
{
   	rv_register_io_handler (rv_get_instance(), IO_HANDLER(_get_handler()));
}

static void onDisable ()
{
	rv_unregister_io_handler (rv_get_instance(), IO_HANDLER(_get_handler()));
}


RvPlugInInfo PLUG_IN_INFO = {
		onInit, NULL, onEnable, onDisable,
		(gchar*) "ASCII File Reader/Writer for Relations",
		(gchar*) "Reads and Writes relations from/to a human readable ASCII format."
};


RV_PLUGIN_MAIN()

#if 0
int export_ascii_file (const char * file_name, rellistptr r_root,
		       graphlistptr g_root) {
  int status = TRUE;
  int lines;
  int columns;
  int vars_zeile;
  int vars_spalte;
  int i;
  int j;
  int first_flag;
  int start_node;
  FILE * fp;
  rellistptr rl;
  graphlistptr gl;
  nodelistptr nl;
  edgelistptr el;
  Rel * rel;
  Node * node;
  Edge * edge;
  Kure_MINT * ZWEI;
  Kure_MINT * MAX;

  MAX  = Kure_mp_itom (0);
  ZWEI = Kure_mp_itom (2);

  Kure_mp_rpow (ZWEI, 31, MAX);
  Kure_mp_decr (MAX);
  Kure_mp_mfree (ZWEI);

  if ((fp = fopen (file_name, "w")) == NULL) {
    printf ("ERROR create_file\n");
    status = FALSE;
  } else {
    for (rl = r_root; rl != (rellistptr) NULL; rl = rl->next) {
      rel = & (rl->rel);
      if ((strcmp (rel->name, "$") != 0) && (rel->state != HIDDEN)) {
	/* alle ausser $-Relation und mit Status HIDDEN */

        /* Abbruch, falls Dimension zu gross zum speichern */
        if (Kure_mp_mcmp (rel->breite, MAX) > 0 || Kure_mp_mcmp (rel->hoehe, MAX) > 0) {
          status = 2;
          /* fclose (fp); */
          Kure_mp_mfree (MAX);
          break;
        }
	lines = Kure_mp_mint2int (rel->hoehe);
	columns = Kure_mp_mint2int (rel->breite);
	fprintf (fp, "\n%s (%d, %d)", rel->name, lines, columns);
	i = 0;
	j = 0;
	first_flag = FALSE;
	while (i < lines) {
	  j = 0;
          vars_zeile  = Kure_mp_number_of_vars (rel->hoehe);
          vars_spalte = Kure_mp_number_of_vars (rel->breite);
	  while (j < columns) {
	    if (get_rel_bit (rel, j, i, vars_zeile, vars_spalte) != 0) {
	      if (first_flag == FALSE) {
		/* wenn erster Eintrag gefunden */
		first_flag = TRUE;
		fprintf (fp, "\n%d : %d", i + 1 ,j + 1);
	      } else {
		fprintf (fp, ", %d", j + 1);
	      }
	    }
	    j ++;
	  }
	  first_flag = FALSE;
	  i ++;
	}
	fprintf (fp, "\n");
      }
    }

    for (gl = g_root; gl; gl = gl->next) {
      if (strcmp (gl->graph.name, "$") != 0) {
        if (get_last_node (& (gl->graph))) {
          correct_graph (& (gl->graph));
          fprintf (fp, "\n%s (%d)\n", gl->graph.name,
                   get_last_node (& (gl->graph)));
          nl = gl->graph.node_root;
          while (nl != (nodelistptr) NULL) {
            node = & (nl->node);
            start_node = node->number;
            if (node->state != HELP) {
              /* keine HILFSKNOTEN (LAYER) abspeichern */
              fprintf (fp, "{%d,%d}", node->x_pos, node->y_pos);
              el = gl->graph.edge_root;
              while (el != (edgelistptr) NULL) {
                edge = & (el->edge);
                if (start_node == edge->from) {
                  fprintf (fp, ",%d", edge->to);
                }
                el = el->next;
              }
              fprintf (fp, "\n");
            }
            nl = nl->next;
          }
          fprintf (fp, "\n");
        }
      }
    }
    fclose (fp);
  }

  Kure_mp_mfree (MAX);

  return (status);
}
#endif
