#ifndef _RV_GLOBAL_H
#define _RV_GLOBAL_H

#warning TODO: global.h is obsolete and should not be included in newly written code.

#define MAXNAMELENGTH 64
#define MAXTERMLENGTH 500

#endif
