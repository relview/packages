/*
 * Graph.h
 *
 *  Copyright (C) 2009,2010 Stefan Bolus, University of Kiel, Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef XGRAPH_H_
#define XGRAPH_H_

#include <glib.h>

/* Forward declarations. */
typedef struct _XGraphManager 			XGraphManager;
typedef struct _XGraphManagerObserver 	XGraphManagerObserver;
typedef struct _XGraph 					XGraph;
typedef struct _XGraphLayout			XGraphLayout;
typedef struct _XGraphObserver			XGraphObserver;
typedef struct _XGraphIterator			XGraphIterator;
typedef struct _XGraphNode 				XGraphNode;
typedef struct _XGraphNodeIterator		XGraphNodeIterator;
typedef struct _XGraphNodeLayout		XGraphNodeLayout;
typedef struct _XGraphEdge 				XGraphEdge;
typedef struct _XGraphEdgePath			XGraphEdgePath;
typedef struct _XGraphEdgeShared		XGraphEdgeShared;
typedef struct _XGraphEdgeIterator		XGraphEdgeIterator;
typedef struct _XGraphEdgeLayout		XGraphEdgeLayout;
typedef enum _XGraphState				XGraphState;

#include "Relation.h"
#include "Kure.h"
#include "GraphBuilder.h"


#define DEFAULT_GRAPH_RADIUS  150
#define DEFAULT_DIM  24

typedef struct _LayoutPoint
{
  gfloat x,y;
} LayoutPoint, GraphLayoutPoint;

LayoutPoint * layout_point_new (gfloat x, gfloat y);
LayoutPoint * layout_point_copy (const LayoutPoint * orig);


typedef struct _LayoutRect
{
	gint left, top, right, bottom;
} LayoutRect;

typedef struct _LayoutRectf
{
	gfloat left, top, right, bottom;
} LayoutRectf;

typedef struct _FloatPoint {
	float x,y;
} FloatPoint;

LayoutPoint layout_point_distance_vec (const LayoutPoint * a, const LayoutPoint * b);
gdouble layout_point_distance (const LayoutPoint * a, const LayoutPoint * b);
gboolean layout_point_equal (LayoutPoint a, LayoutPoint b);



typedef void (*GraphLayoutService_layoutNodeFunc) (gpointer,XGraphNode*);
typedef void (*GraphLayoutService_layoutEdgeFunc) (gpointer,XGraphEdge*);
typedef void (*GraphLayoutService_destroyFunc) (gpointer);

// Note: Must not emit anything.
typedef struct _GraphLayoutService GraphLayoutService;
/* interface */ struct _GraphLayoutService
{
	GraphLayoutService_layoutNodeFunc layoutNode;
	GraphLayoutService_layoutEdgeFunc layoutEdge;
	GraphLayoutService_destroyFunc destroy;

	gpointer owner;
};

GraphLayoutService * default_graph_layout_service_new (XGraph * gr, gint radius);


/*enum _XGraphState
{
	GRAPH_NORMAL = 0, GRAPH_HIDDEN = 1, GRAPH_MODIFIED = 4, GRAPH_CORRESPONDENCE = 8
};*/

typedef void (*XGraphManagerObserver_changedFunc) (gpointer, XGraphManager*);
typedef void (*XGraphManagerObserver_onDeleteFunc) (gpointer, XGraphManager*);

/*interface*/ struct _XGraphManagerObserver
{
	/*!
	 * Is called, if graphs are added or removed. It wouldn't make sense
	 * to explicitly name the change, because multiple changes could have
	 * take place at once. */
	XGraphManagerObserver_changedFunc changed;

	/*! Is called, if the manager is deleted. */
	XGraphManagerObserver_onDeleteFunc onDelete;

	gpointer object;
};

typedef void (*XGraphObserver_onDeleteNodeFunc) (gpointer, XGraph*, XGraphNode*);
typedef void (*XGraphObserver_onDeleteEdgeFunc) (gpointer, XGraph*, XGraphEdge*);
typedef void (*XGraphObserver_renamedFunc) (gpointer, XGraph*,const gchar * old_name);
typedef void (*XGraphObserver_changedFunc) (gpointer, XGraph*);
typedef void (*XGraphObserver_layoutChangedFunc) (gpointer, XGraph*);
typedef void (*XGraphObserver_onDeleteFunc) (gpointer, XGraph*);

/*interface*/ struct _XGraphObserver
{
  XGraphObserver_onDeleteNodeFunc onDeleteNode;
  XGraphObserver_onDeleteEdgeFunc onDeleteEdge;
  XGraphObserver_changedFunc changed;
  XGraphObserver_layoutChangedFunc layoutChanged;
  XGraphObserver_renamedFunc renamed;
  XGraphObserver_onDeleteFunc onDelete;

  gpointer * object;
};

// Namespace for out functions.
#define _NS(name) xgraph_##name

XGraphManager * _NS(manager_get_instance) ();
XGraphManager * _NS(manager_new) ();
void 			_NS(manager_destroy) (XGraphManager * self);
void 			_NS(manager_steal_all_from) (XGraphManager * self, XGraphManager * victim);
void 			_NS(manager_steal_all_from_and_overwrite) (XGraphManager * self, XGraphManager * victim);
XGraph * 		_NS(manager_get_by_name) (XGraphManager * self, const gchar * name);
gboolean 		_NS(manager_exists) (XGraphManager * self, const gchar * name);
// Also works with graphs not associated to a manager so far. See
// xgraph_manager_insert for information.
gboolean		_NS(manager_transfer) (XGraphManager * self, XGraph * graph);
gboolean 		_NS(manager_insert) (XGraphManager * self, XGraph * graph);
XGraphIterator* _NS(manager_iterator) (XGraphManager * self);
XGraph *		_NS(manager_create_graph) (XGraphManager * self, const gchar * name);
XGraph *		_NS(manager_create_graph_with_state) (XGraphManager * self, const gchar * name, XGraphState state);
void 			_NS(manager_steal) (XGraphManager * self, XGraph * graph);
void 			_NS(manager_register_observer) (XGraphManager * self, XGraphManagerObserver * o);
void 			_NS(manager_unregister_observer) (XGraphManager * self, const XGraphManagerObserver * o);
void			_NS(manager_delete_by_name) (XGraphManager * self, const gchar * name);
void 			_NS(manager_changed) (XGraphManager * self);
void 			xgraph_manager_block_notify (XGraphManager * self);
void 			xgraph_manager_unblock_notify (XGraphManager * self);
gboolean		_NS(manager_is_empty) (XGraphManager * self);
gint			_NS(manager_get_graph_count) (XGraphManager * self);
GList/*<const gchar*>*/ * _NS(manager_get_names) (XGraphManager * self);

void 			_NS(iterator_next) (XGraphIterator * self);
gboolean 		_NS(iterator_is_valid) (XGraphIterator * self);
XGraph * 		_NS(iterator_get) (XGraphIterator * self);
void 			_NS(iterator_destroy) (XGraphIterator * self);


XGraph *		xgraph_new (const gchar * name);
void 			_NS(destroy) (XGraph * self);
gboolean 		_NS(rename) (XGraph * self, const gchar * new_name);
XGraph * 		_NS(copy) (XGraph * self, const gchar * copy_name);
//XGraphState * 	_NS(get_state) (XGraph * self);
void 			_NS(get_display_extent) (XGraph * self, gint * pleft, gint * ptop, gint * pright, gint * pbottom);
GdkRectangle 	_NS(get_display_rect) (XGraph * self);
gint 			_NS(get_display_left) (XGraph * self);
gint 			_NS(get_display_top) (XGraph * self);
gint 			_NS(get_display_right) (XGraph * self);
gint 			_NS(get_display_bottom) (XGraph * self);
void 			_NS(clear) (XGraph * self);
void 			_NS(clear_s) (XGraph * self);
void 			_NS(clear_edges) (XGraph * self);
void 			_NS(clear_edges_s) (XGraph * self);
gint			_NS(get_node_count) (XGraph * self);
gint            _NS(get_node_count_no_helper) (XGraph * self);
XGraphManager * _NS(get_manager) (XGraph * self);
//rellistptr 		_NS(to_rel) (XGraph * self);
void 			_NS(from_rel) (XGraph * self);
void 			_NS(highlight_nodes_from_rel) (XGraph * self, int level);
void 			_NS(highlight_edges_from_rel) (XGraph * self, int level);
void 			_NS(unhighlight_nodes) (XGraph * self, int level);
void 			_NS(unhighlight_edges) (XGraph * self, int level);
//void 			_NS(normalize) (XGraph * self);
gchar * 		_NS(get_info) (XGraph * self);
const gchar * 	_NS(get_name) (XGraph * self);
void 			_NS(flip_display_vert) (XGraph * self);
void 			_NS(flip_display_horz) (XGraph * self);
void 			_NS(apply_layout) (XGraph * self, const XGraphLayout * layout);
void 			_NS(changed) (XGraph * self);
void 			_NS(layout_changed) (XGraph * self);
void			_NS(reset_layout) (XGraph * self);
void 			_NS(register_observer) (XGraph * self, XGraphObserver * o);
void 			_NS(unregister_observer) (XGraph * self, const XGraphObserver * o);
XGraphEdge *	_NS(create_edge) (XGraph * self, XGraphNode * from, XGraphNode * to);
XGraphEdge *	_NS(create_edge_s) (XGraph * self, XGraphNode * from, XGraphNode * to);
XGraphNode *	_NS(create_node_s) (XGraph * self);
XGraphNode *	_NS(create_node) (XGraph * self);
XGraphNode *    _NS(create_node_gui) (XGraph * self);
XGraphNode *    _NS(create_node_helper) (XGraph * self);


void 			_NS(delete_node) (XGraph * self, XGraphNode * node);
void 			_NS(delete_node_s) (XGraph * self, XGraphNode * node);
XGraphNode *	_NS(get_node_by_id) (XGraph * self, gint nodeId);
gboolean		_NS(delete_edge) (XGraph * self, XGraphEdge * edge);
gboolean		_NS(delete_edge_s) (XGraph * self, XGraphEdge * edge);
void			_NS(delete_incident_edges) (XGraph * self, XGraphNode * node);
void			_NS(delete_incident_edges_s) (XGraph * self, XGraphNode * node);
// Used in e.g. menuitemMarkEdgesGW_activate
void 			_NS(mark_nodes_by_rel) (XGraph * self, const gchar * relName, gint level);
void 			_NS(mark_edges_by_rel) (XGraph * self, const gchar * relName, gint level);
void 			xgraph_mark_edges_by_impl (XGraph * self, const KureRel * impl, gint level);
// Used in e.g. menuitemUnmarkGraphGW_activate
void			_NS(unmark_nodes) (XGraph * self);
void			_NS(unmark_edges) (XGraph * self);
gboolean		_NS(is_empty) (XGraph * self); // any nodes?
XGraphEdge *	_NS(get_edge_by_id) (XGraph * self, gint fromId, gint toId);
XGraphEdge * 	_NS(get_edge) (XGraph * self, const XGraphNode * from, const XGraphNode * to);
gboolean 		_NS(has_edge_by_id) (XGraph * self, gint fromId, gint toId);
gboolean 		_NS(has_edge) (XGraph * self, const XGraphNode * from, const XGraphNode * to);
XGraphEdgeIterator * _NS(edge_iterator) (XGraph * self);
XGraphNodeIterator * _NS(node_iterator) (XGraph * self);
void 			_NS(apply_layout_service) (XGraph * self, GraphLayoutService * service);
void 			_NS(build) (XGraph * self, GraphBuilder * builder);
GraphBuilder * 	_NS(get_builder) (XGraph * self);
GHashTable/*<XGraphNode*,XGraphNode*>*/ * _NS(mapping) (XGraph * from, XGraph * to);
gboolean		_NS(is_hidden) (XGraph * self);
void			_NS(set_hidden) (XGraph * self, gboolean yesno);

void 			_NS(block_notify) (XGraph * self);
void			_NS(unblock_notify) (XGraph * self);

// See the details on nodes ID's and names below.
XGraphNode * 	_NS(get_node_by_name) (XGraph * self, gint name);

// All changing operations have a '..._s' variant, which doesn't
// notifies the observers. The user have to call xgraph_changed
// (or whatever) on its own.

void			_NS(fill_area) (XGraph * self, gint width, gint height);

void 			xgraph_default_layout (XGraph * self, gint radius);

gboolean		_NS(is_correspondence) (XGraph * self);

/**
 * Names have ID's and names which are both numbers. While the first number is
 * used for identifying labels during their life time, the second is used for
 * the user to identify it. Thus, if a node is deleted from the screen, renumbing
 * occurs and names of nodes may change to obtain a consecutive sequence of
 * numbers.
 */
XGraphNodeLayout* 	_NS(node_get_layout) (XGraphNode * self);
void			 	_NS(node_apply_layout) (XGraphNode * self, const XGraphNodeLayout * layout);
void			 	_NS(node_apply_layout_s) (XGraphNode * self, const XGraphNodeLayout * layout);
gboolean			_NS(node_is_selected) (XGraphNode * self);
// true, if the user has selected this node, to create edges from it.
gboolean 			_NS(node_is_selected_for_edge) (XGraphNode * self);
gboolean			_NS(node_is_helper) (XGraphNode * self);
void 				_NS(node_set_selected) (XGraphNode * self, gboolean yesno);
void 				_NS(node_set_selected_for_edge) (XGraphNode * self, gboolean yesno);
const gchar * 		_NS(node_get_name) (XGraphNode * self);
// Should be used with care:
void		 		_NS(node_set_name) (XGraphNode * self, const gchar * name);
gint				_NS(node_get_id) (XGraphNode * self);
XGraph * 			_NS(node_get_graph) (XGraphNode * self);
void				_NS(node_destroy_s) (XGraphNode * self);
void				_NS(node_destroy) (XGraphNode * self);
gdouble				_NS(node_get_distance_to_node) (const XGraphNode * self, const XGraphNode * other);
gdouble				_NS(node_get_distance_to) (const XGraphNode * self, const LayoutPoint * pt);
// Doesn't return the screen name, but internal node number!


void 				_NS(node_iterator_next) (XGraphNodeIterator * self);
gboolean 			_NS(node_iterator_is_valid) (XGraphNodeIterator * self);
XGraphNode *		_NS(node_iterator_get) (XGraphNodeIterator * self);
void 				_NS(node_iterator_destroy) (XGraphNodeIterator * self);

XGraphEdgeLayout* 	_NS(edge_get_layout) (XGraphEdge * self);
void 				_NS(edge_apply_layout) (XGraphEdge * self, const XGraphEdgeLayout * layout);
void 				_NS(edge_apply_layout_s) (XGraphEdge * self, const XGraphEdgeLayout * layout);
gboolean			_NS(edge_is_selected) (XGraphEdge * self);
void 				_NS(edge_set_selected) (XGraphEdge * self, gboolean yesno);
void 				_NS(edge_set_selected_s) (XGraphEdge * self, gboolean yesno);
gint				_NS(edge_get_from_id) (XGraphEdge * self);
gint				_NS(edge_get_to_id) (XGraphEdge * self);
XGraphNode *		_NS(edge_get_from_node) (XGraphEdge * self);
XGraphNode *		_NS(edge_get_to_node) (XGraphEdge * self);
XGraph * 			_NS(edge_get_graph) (XGraphEdge * self);
void				_NS(edge_destroy) (XGraphEdge * self);
void				_NS(edge_destroy_s) (XGraphEdge * self);
void 				_NS(edge_iterator_next) (XGraphEdgeIterator * self);
gboolean 			_NS(edge_iterator_is_valid) (XGraphEdgeIterator * self);
XGraphEdge *		_NS(edge_iterator_get) (XGraphEdgeIterator * self);
void 				_NS(edge_iterator_destroy) (XGraphEdgeIterator * self);
gboolean			_NS(edge_has_inverse) (XGraphEdge * self);
XGraphEdge*			_NS(edge_get_inverse) (XGraphEdge * self);

XGraphLayout * 		_NS(layout_new) ();
void				_NS(layout_destroy) (XGraphLayout * self);
XGraphNodeLayout * 	_NS(layout_add_node) (XGraphLayout * self, int nodeId, float x, float y);
XGraphEdgeLayout *  _NS(layout_add_edge_segments) (XGraphLayout * self, int fromId, int toId,
												   int ptsCount, float * pts);
XGraphEdgeLayout * 	_NS(layout_add_edge_segments_with_list) (XGraphLayout * self,
															 int fromId, int toId,
															 GList/*<FloatPoint*>*/ * pts);

gboolean 		_NS(node_layout_is_visible) (XGraphNodeLayout * self);
void 			_NS(node_layout_set_visibility) (XGraphNodeLayout * self, gboolean visible);
void 			_NS(node_layout_set_visibility_s) (XGraphNodeLayout * self, gboolean visible);
//gint32 			_NS(node_layout_get_color) (XGraphNodeLayout * self);
//void 			_NS(node_layout_set_color) (XGraphNodeLayout * self, gint32 color);
gfloat 			_NS(node_layout_get_x) (XGraphNodeLayout * self);
gfloat 			_NS(node_layout_get_y) (XGraphNodeLayout * self);
void 			_NS(node_layout_set_x) (XGraphNodeLayout * self, gfloat x);
void 			_NS(node_layout_set_y) (XGraphNodeLayout * self, gfloat y);
void 			_NS(node_layout_set_x_s) (XGraphNodeLayout * self, gfloat x);
void 			_NS(node_layout_set_y_s) (XGraphNodeLayout * self, gfloat y);
void 			_NS(node_layout_set_highlighted) (XGraphNodeLayout * self, gboolean yes_no);
void 			_NS(node_layout_set_highlighted_s) (XGraphNodeLayout * self, gboolean yes_no);
gboolean 		_NS(node_layout_is_highlighted) (XGraphNodeLayout * self);
void 			_NS(node_layout_set_marked_first) (XGraphNodeLayout * self, gboolean yes_no);
void 			_NS(node_layout_set_marked_first_s) (XGraphNodeLayout * self, gboolean yes_no);
void 			_NS(node_layout_set_marked_second) (XGraphNodeLayout * self, gboolean yes_no);
void 			_NS(node_layout_set_marked_second_s) (XGraphNodeLayout * self, gboolean yes_no);
//int 			_NS(node_layout_get_marked) (XGraphNodeLayout * self);
gboolean		_NS(node_layout_is_marked_first) (XGraphNodeLayout * self);
gboolean		_NS(node_layout_is_marked_second) (XGraphNodeLayout * self);
gboolean		_NS(node_layout_is_marked_third) (XGraphNodeLayout * self);
LayoutPoint		_NS(node_layout_get_pos) (const XGraphNodeLayout * self);
void 			_NS(node_layout_set_pos) (XGraphNodeLayout * self, gfloat x, gfloat y);
void 			_NS(node_layout_set_pos_s) (XGraphNodeLayout * self, gfloat x, gfloat y);
gint			_NS(node_layout_get_radius) (XGraphNodeLayout * self);
void			_NS(node_layout_set_radius) (XGraphNodeLayout * self, gint radius);
void			_NS(node_layout_reset_s) (XGraphNodeLayout * self);
void			_NS(node_layout_reset) (XGraphNodeLayout * self);

void			_NS(edge_layout_destroy) (gpointer self);
gboolean 		_NS(edge_layout_is_visible) (gconstpointer self);
gboolean 		_NS(edge_layout_is_simple) (gconstpointer self);
gboolean 		_NS(edge_layout_is_highlighted) (gconstpointer self);
gboolean		_NS(edge_layout_is_marked_first) (gconstpointer self);
gboolean		_NS(edge_layout_is_marked_second) (gconstpointer self);
void			_NS(edge_layout_set_marked_first) (gpointer self, gboolean);
void			_NS(edge_layout_set_marked_second) (gpointer self, gboolean);
//gboolean		_NS(edge_layout_is_marked_third) (gconstpointer self);
const XGraphEdgePath * _NS(edge_layout_get_path) (gconstpointer self);
void 			_NS(edge_layout_set_highlighted) (gpointer self, gboolean yesno);
void 			_NS(edge_layout_set_highlighted_s) (gpointer self, gboolean yesno);
void			_NS(edge_layout_reset_s) (gpointer self);
void			_NS(edge_layout_reset) (gpointer self);
void 			_NS(edge_layout_set_path) (gpointer self, const XGraphEdgePath * path);
void 			_NS(edge_layout_set_path_s) (gpointer self, const XGraphEdgePath * path);
LayoutRect		_NS(edge_layout_get_bounding_box) (const XGraphEdgeLayout * self);

gboolean 			xgraph_edge_path_is_simple (const XGraphEdgePath * self);
XGraphEdgePath * 	xgraph_edge_path_ctor (XGraphEdgePath * self);
XGraphEdgePath * 	xgraph_edge_path_new ();
void 				xgraph_edge_path_dtor (XGraphEdgePath * self);
GQueue/*<LayoutPoint*>*/ * xgraph_edge_path_get_points (XGraphEdgePath * self);
void 				xgraph_edge_path_destroy (XGraphEdgePath * self);
void 				xgraph_edge_path_reset (XGraphEdgePath * self);
void 				xgraph_edge_path_assign (XGraphEdgePath * self, const XGraphEdgePath * from);
gboolean 			xgraph_edge_path_is_simple (const XGraphEdgePath * self);
XGraphEdgePath *	xgraph_edge_path_clone (const XGraphEdgePath * self);
void 				xgraph_edge_path_reverse (XGraphEdgePath * self);
gint xgraph_edge_path_get_from (XGraphEdgePath * self);
gint xgraph_edge_path_get_to (XGraphEdgePath * self);
void xgraph_edge_path_set_to (XGraphEdgePath * self, gint nodeName);
void xgraph_edge_path_set_from (XGraphEdgePath * self, gint nodeName);



XGraphEdgeLayout * 	xgraph_indep_edge_layout_new ();

#undef _NS

/*!
 * \example
 *    XGRAPH_FOREACH_NODE(self,node,iter,{
 *       printf ("name: %s\n", xgraph_node_get_name(node));
 *    });
 */
#define XGRAPH_FOREACH_NODE(gr,var,iter,code) {\
	XGraphNodeIterator * (iter) = xgraph_node_iterator(gr);\
	for ( ; xgraph_node_iterator_is_valid(iter) ; xgraph_node_iterator_next(iter)) {\
		XGraphNode * (var) = xgraph_node_iterator_get(iter);\
		code\
	}\
	xgraph_node_iterator_destroy(iter);\
}

#define XGRAPH_FOREACH_EDGE(gr,var,iter,code) {\
	XGraphEdgeIterator * (iter) = xgraph_edge_iterator(gr);\
	for ( ; xgraph_edge_iterator_is_valid(iter) ; xgraph_edge_iterator_next(iter)) {\
		XGraphEdge * (var) = xgraph_edge_iterator_get(iter);\
		code\
	}\
	xgraph_edge_iterator_destroy(iter);\
}

#define XGRAPH_MANAGER_FOREACH_GRAPH(manager,var,iter,code) {\
	XGraphIterator * (iter) = xgraph_manager_iterator(manager);\
	for ( ; xgraph_iterator_is_valid(iter) ; xgraph_iterator_next(iter)) {\
		XGraph * (var) = xgraph_iterator_get(iter);\
		code\
	}\
	xgraph_iterator_destroy(iter);\
}

#endif /* XGRAPH_H_ */
