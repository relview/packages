#ifndef _SME_DRAW_GRAPH_H
#define _SME_DRAW_GRAPH_H

#define KOMPONENTENABSTAND 1
#define MIND_X_ABSTAND 50
#define MIND_Y_ABSTAND 70
#define WEISS 0
#define GRAU 1

#include "global-sme.h"

extern void rank (int *, int *, int *, int *, EDGE *, NODE *,int, int, 
                  int *, int *);                      /* aus rank.c */
extern void position (int *, int *, int *, int *, NODE **, EDGE *,
                      int, int,INT_POINTER *, int *, int);
/* aus position.c */

extern void ordering (int **, int **, int **, int **, EDGE **, NODE **,
                      int *, int *, INT_POINTER **, int **, int *);
/* aus ordering.c */

extern void zerlegen_dag (int, int, EDGE *, GRAPH **, int *);

/* eigene Funktionen */


static void draw_graph ();
static void mk_graph_list ();
static void max_find (int *);
static void find_width ();
static int uebertragen (int, int);
static void abs_coord (int, int);
static int make_acyc ();
static void DFS (int *, int *);
static void DFS_visit (int *, int *, int *, int *, int);
static int piv (int, int);
static int part (int, int, int);
static void quicksort (int, int);
static void Komponenten_sort ();
static graphlistptr dag_to_graph (KureRel*);

/* nach aussen bekannt gegebene */

graphlistptr dag (KureRel*, int, int);

#endif
