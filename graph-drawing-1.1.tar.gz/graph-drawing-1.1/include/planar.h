#ifndef _SUL_planar_h_
#define _SUL_planar_h_

#include "helpfunc.h"
#include "relview/plugin.h"

int isPlanar (KureRel * relName, int alp);

void freePlanarMemory(void);
p_intList* GetBiconnectedComponents (int* anz, p_adjList adj);

#ifdef PLANAR_DATA

#ifndef PLANAR_FILE
extern
#endif /* PLANAR_FILE */
struct planarData {
	/* Berechnung in planar.c */
	struct {
		p_intList singletons;
		p_reorder preorder;
	} connect;

	/* Berechnung in planar.c */
	struct {
		p_reorder preorder;
		p_adjList adj; /* Bezieht sich auf DFS-Nummern */
		int* parent;   /* Bezieht sich auf DFS-Nummern */
		char** alpha;  /* ACHTUNG: Alpha bezieht sich auf DFS-Nummern (stehen in preorder) */
	} planar;

	/* Berechnung in embedding.c */
	struct {
		p_adjList embedding; /* Bezieht sich auf DFS-Nummern */
		p_intList canonical; /* kanonische Ordnung, bezieht sich auf DFS-Nummern (fuer einfachen Triangulierungsalgorithmus) */

		p_ordpartition ordpart; /* geordnete Partition, bezieht sich auf DFS-Nummern (fuer konvexe Zeichnung) */
		int* ranking;           /* Ranking der Knoten in der geordneten Partition */
	} embedding;

	/* Extradaten fuer Mixed-Model */
	struct {
		p_genList edgelevels;
	} mixedmodel;

} planarData 
#ifdef PLANAR_FILE
= {{NULL, NULL}, {NULL, NULL, NULL, NULL}, {NULL, NULL, NULL, NULL}, {NULL}}
#endif /* PLANAR_FILE */
;

#endif /* PLANAR_DATA */


#endif /* _planar_h_ */
