#ifndef _UMI_ORTHOGONAL_H
#define _UMI_ORTHOGONAL_H

# include "relview/plugin.h"

#include "graph.h"
#include "ort_helpfun.h"

/* Komponenten-Zeiger : Zeiger auf eine Zusammenhangskomponente             */

typedef struct komponente * komponentenptr;

/* Zusammenhangskomponenten: teilRelation enthaelt den Teil der Relation,   */
/* der eine Zusammenhangskomponente bildet, original_node_numbers enthaelt  */
/* die Umsetzungs-Tabelle fuer die Knoten-Nummern aus der Gesamt-Relation,  */
/* teilGraph ist der fuer diese Zusammenhangskomponente berechnete Graph,   */
/* next ist selbsterklaerend.                                               */

typedef struct komponente {
  KureRel * teilRelation;
  p_intList original_node_numbers;
  graphlistptr teilGraph;
  komponentenptr next;
} komponente;

/* Komponenten-Liste : Liste aller Zusammenhangskomponenten                 */

typedef struct komponentenlist * komponentenlistptr;

/* Zusammenhangskomponenten: original_edges und number_of_original_nodes    */
/* sind selbsterklaerend, zusammenhangskomponenten enthaelt eine Liste der  */
/* Zusammenhangskomponenten, aus denen eine Relation besteht.               */

typedef struct komponentenlist {
  edgelistptr original_edges;
  unsigned int number_of_original_nodes;
  komponente * zusammenhangskomponenten;
} komponentenlist;


/* ab hier die nach aussen bekanntgegebenen Funktionen des Moduls           */

komponentenlistptr new_component_list (void);
komponentenlistptr splitRelationIntoComponents (KureRel *);
komponentenptr new_component (void);
void delKomponentenListe (komponentenlistptr);
void print_componentlist (komponentenlistptr);
void del_component  (komponentenptr);
void print_component (komponentenptr);

facelistptr faces_of_embedding (p_adjList, int, int, p_intList);

p_intList st_numbering (p_adjList);
p_intList st_numbering_with_source (p_adjList , int, p_intList);

int rel_orthogonal (KureRel *);
KureRel * planar_subrelation (KureRel *);

visibilityrepptr visibility_representation (p_adjList);
orthogonalrepptr orthogonal_embedding (visibilityrepptr, p_adjList);
p_adjList visibility_adjlist (visibilityrepptr);

void transform_orthogonal_representation (orthogonalrepptr);
void insert_nonplanar_edges_into_orthogonal (orthogonalrepptr, p_adjList,
                                             KureRel *);

graphlistptr graph_create_orthogonal (orthogonalrepptr, unsigned int,
				      unsigned int, char *);
graphlistptr small_orthogonal_graph (KureRel*, unsigned int,
				     unsigned int, char *);
graphlistptr MergeGraphsFromComponents (KureRel *, komponentenlistptr);
graphlistptr graph_orthogonal (KureRel *);

KureRel * planar_greedy_subrelation (KureRel *);
graphlistptr graph_orthogonal_fast (KureRel *);

#endif
