#ifndef _SME_ZERLEGEN_H
#define _SME_ZERLEGEN_H

#include "global-sme.h"

/* eigene Funktionen */

void zerlegen_spring (int, int, S_EDGE *, S_GRAPH **, int *);
void zerlegen_dag (int, int, EDGE *, GRAPH **, int *);
void Vereinige (int, int);
int Finde (int);

#endif
