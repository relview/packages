#ifndef _SME_SPRING_LANGSAM_H
#define _SME_SPRING_LANGSAM_H

#define RAND 50
#define MAX_INT 2147483647
#define epsilon 1
#define MIN_KANTENLAENGE 100
#define Min(a,b) ((a) < (b) ? (a) : (b))
#define Max(a,b) ((a) > (b) ? (a) : (b))
#define KOMPONENTENABSTAND 50
#define INIT_TEMP 300
#define PHASE_1 20
#define PHASE_2 35
#define LOW_TEMP 5
#define MID_TEMP 20
#define ITERATIONS 50
#define AREA 1000000

#include "global-sme.h"

extern float k;              /* aus spring.c */

/* Datenstrukturen */

typedef int ** Matrix;
typedef float ** Fl_Matrix;

int make_graph_langsam (KureRel*, S_EDGE **, int *, int *);
extern void zerlegen_spring (int, int, S_EDGE *, S_GRAPH **, int *);

extern void repulsive (S_NODE *, int, int);
extern void attraktive (S_NODE *, S_EDGE *, int);
extern float f_rep (float);
extern float f_attr (float);
extern float laenge (float, float);
//extern graphlistptr draw_tree (char *);

/* eigene Funktionen */

static void alloc_nodes ();
static int find_path (Fl_Matrix);
static void enlarge ();
static void spring_komp (int);
static float find_max (int *);
static float part_min (int);
static float partd (int, char);
static float partd_2 (int, char);
static float partd_xy (int);
static void abs_coord (int, int);
static void set_glob_var ();
static int cool (float, int);
static void spring (int);
static void initial_positions (S_NODE *, int);
static void move (int);
static void Komponenten_sort ();
static void alloc_max_array ();
static void limit (float, S_NODE *, int);
static void drehen_x (float, float, float *, float *);
static void drehen (float, float);
static void turn ();
static void free_glob ();
graphlistptr spring_langsam_to_graph (KureRel*);

/* nach aussen bekannt gegebene Funktionen */

graphlistptr spring_langsam (KureRel*, int, int);

#endif
