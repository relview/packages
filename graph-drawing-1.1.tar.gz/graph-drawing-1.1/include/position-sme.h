#ifndef _SME_POSITION_H
#define _SME_POSITION_H

#define SCANNED 0
#define UNSCANNED 1
#define WEIGHT_1 1
#define WEIGHT_2 2
#define WEIGHT_3 8
#define MIN_SEP 1
#define MIN_SEP_1 1
#define MIN_SEP_2 1
#define MIN_SEP_3 1

extern void rank (int *, int *, int *, int *, EDGE *, NODE *,
                  int, int,  int *, int *);           /* aus rank.c */
extern int slack (int);                            /* aus rank.c */


/* eigene Funktionen */

static void mk_aux_graph (NODE *, EDGE *, int, int);
static void feasible_tree (NODE *, int);
static void set_list (int *, int *, int *, int *, INT_POINTER *, int *,int);
static void mk_graph_list ();

/* nach aussen bekannt gegebene Funktionen */

void position (int *, int *, int *, int *, NODE **, EDGE *, int, int,
               INT_POINTER *, int *, int);

#endif
