#ifndef _SME_GLOBAL_H
#define _SME_GLOBAL_H

#include "relview/plugin.h"
#include "graph.h"

#include <stdlib.h>
#include <stdio.h>

// Must not exceed a very limited amount of characters.
#define UNKNOWN_GRAPH_NAME "SomeGraph"

#define VERY_BIG 10000
#define VIRTUAL 1
#define VIRT_HEAD 2
#define VIRT_TAIL 3
#define ORIGINAL 0

#ifndef FALSE
#define FALSE 0 
#endif
#ifndef TRUE
#define TRUE !FALSE
#endif

typedef int * INT_POINTER;

/* Datenstrukturen fuer DAG-Algorithmus */

typedef struct {
  int rank;
  int status;
  int position;
  int Schleife;
} NODE;

typedef struct {
  int head;
  int tail;
  int weight;
  int delta;
  int status;
  int gedreht;
  int back_and_forth;
} EDGE;


typedef struct {
  int node_count;
  int edge_count;
  int alt_n;
  int x_max;
  int y_max;
  NODE * nodes;
  EDGE * edges;
  int * inj;
} GRAPH;

/* Datenstrukturen fuer die Spring-Embedder */

typedef struct {
  int head;
  int tail;
  int back_and_forth;
} S_EDGE;

typedef struct {
  float x_pos;
  float y_pos;
  float displ_x;
  float displ_y;
} S_NODE;

typedef struct {
  int node_count;
  int edge_count;
  int x_max;
  int y_max;
  S_NODE * nodes;
  S_EDGE * edges;
  int * inj;
} S_GRAPH;

#endif
