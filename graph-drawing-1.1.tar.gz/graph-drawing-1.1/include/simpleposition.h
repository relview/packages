#ifndef _SUL_simpleposition_h_
#define _SUL_simpleposition_h_

#include "relview/plugin.h"
#include "helpfunc.h"

#define PLANAR_GRID_X 	24
#define PLANAR_GRID_Y 	48

p_pair 		computeSimplePositions(void);
p_adjList 	getEmbeddingInOrigNumbering(void);
void 		stripEmbedding (KureRel*);

#endif   /* simpleposition_h */
