#ifndef _SUL_createdrawing_h_
#define _SUL_createdrawing_h_

#include "helpfunc.h" // p_boundingBox
#include "graph.h"
#include "relview/plugin.h"

graphlistptr DrawTriangulatedGraph (KureRel*);
graphlistptr DrawTriangulatedGraphUnsplitted (KureRel*);
graphlistptr DrawMixedModelGraph (KureRel*);
graphlistptr DrawMixedModelGraphUnsplitted (KureRel*);
graphlistptr DrawTriangluarMixedModelGraph (KureRel*);
graphlistptr DrawTriangluarMixedModelGraphUnsplitted (KureRel*);
void swapXYinGraph (Graph * gr);
void scaleGraph (Graph * gr, double xfac, double yfac);

/* private Funktionen */
graphlistptr createMixedDrawing (p_boundingBox *boxes, int gridx, int gridy, 
                                 int xoff, int yoff, KureRel*);
graphlistptr createTriangularDrawing (p_pair, int, int, int, int, KureRel *);

#endif /* drawing_h_ */
