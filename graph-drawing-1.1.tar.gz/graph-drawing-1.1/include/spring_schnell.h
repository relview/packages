#ifndef _SME_SPRING_SCHNELL_H
#define _SME_SPRING_SCHNELL_H

#define INIT_TEMP 300
#define ITERATIONS 50
#define MAX_INT 2147483647
#define RAND 50
#define PHASE_1 20
#define PHASE_2 35
#define MID_TEMP 20
#define LOW_TEMP 5
#define AREA 1000000
#define fakt 200
#define gew_Kantenlaenge 100
#ifndef Min
#  define Min(a,b) (a) < (b) ? (a) : (b)
#endif

#ifndef Max
#  define Max(a,b) (a) > (b) ? (a) : (b)
#endif

#include "global-sme.h"

extern float k;  /* aus spring.c */

/* Datenstrukturen */

typedef int ** Matrix;
typedef float ** Fl_Matrix;

extern void zerlegen_spring (int, int, S_EDGE *, S_GRAPH **, int *, int ***);

/* eigene Funktionen */

static int cool (float, int);
static void initial_positions (S_NODE *, int);
static void alloc_glob ();
static void enlarge (int, int);
static void limit (float, S_NODE *, int);
graphlistptr spring_schnell_to_graph (char*);

/* nach aussen bekannt gegebene Funktionen */

void repulsive (S_NODE *, int, int);
void attraktive (S_NODE *, S_EDGE *, int);
float f_rep (float);
float f_attr (float);
float laenge (float, float);

graphlistptr spring_schnell (KureRel *, int, int);

#endif
