#ifndef _SME_RANK_H
#define _SME_RANK_H

#define SCANNED 0
#define UNSCANNED 1
#define DOWN 1
#define UP 0
#define REIN 0
#define RAUS 1
#define WEDER_NOCH -1
#define FERTIG -1
#define IN_TREE 1
#define NOT_IN_TREE 0
#define MK_INIT_RANKING 1
#define NO_INIT_RANKING 0

#include "global-sme.h"

/* eigene Funktionen */

static int slack (int);
static void enqueue ();
static void dequeue ();
static void einfuegen (int *, int *, int, int);
static void tree_init ();
static int inc_edge ();
static void tight_tree ();
static void mk_treelist ();
static int postorder (int, int);
static int pos (int, int);
static int neg (int, int);
static void cutvalue (int, int);
static void init_cutvalues ();
static void feasible_tree (int *, int *);
static int leave_edge ();
static int enter_edge (int);
static int find_top (int, int);
static int upd_tree (int, int);
static void adjust_rank (int);
static void part_cut (int, int);
static void exchange (int, int);
static void normalize ();
static void best_rank (int, int *);
static void balance ();
static void set_list (int *, int *, int*, int *, EDGE *, NODE *, int, int);
static void free_temp_list ();

/* nach aussen bekannt gegebene Funktionen */

void rank (int *, int *, int *, int *, EDGE *, NODE *, int, int, int *, int *);

#endif
