#ifndef _SME_BAUM_H
#define _SME_BAUM_H

#include "global-sme.h"

#define KOMPONENTENABSTAND 1
#define MIND_X_ABSTAND 40
#define MIND_Y_ABSTAND 70
#define Max(a,b) (a) > (b) ? (a) : (b)
#define Min(a,b) ((a) < (b) ? (a) : (b))

/* eigene Funktionen */

static int ** make_feld (S_GRAPH);
static void uebertragen (int);
static void abs_coord (int, int);
static void find_max (int);
static void free_glob ();
static void baum ();
static void setup_tree (int, int, int *);
static void pos_tree (int );
static void Komponenten_sort ();
static graphlistptr baum_to_graph (KureRel * );
int make_graph_baum (KureRel*, S_EDGE **, int *, int *);
static int baum_test (int, int);

/* nach aussen bekannt gegebene Funktionen */

graphlistptr tree (KureRel*, int, int);

extern graphlistptr dag (KureRel*, int, int);

#endif
