#ifndef _SUL_position_h_
#define _SUL_position_h_

#include "helpfunc.h"

#define SMALL_GRAPH 6  /* ab Graphen mit mehr als SMALL_GRAPH Knoten nicht orthogonal zeichnen */
#define MIXEDPLANAR_GRID_X 30 /* Gridkonstanten fuer Mixed Model und Trimix-Algorithmus */
#define MIXEDPLANAR_GRID_Y 30
#define PLANAR_OFFSET_X 24    /* Gridkonstanten fuer Triangular-Algorithmus */
#define PLANAR_OFFSET_Y 24

p_boundingBox *computeBoundingBoxes (void);	/* result is an array */
void computeLevels (void);
void computeMixModPositions (p_boundingBox *);
void computeVisibilityMixModPositions (p_boundingBox *);

#endif /* position_h */
