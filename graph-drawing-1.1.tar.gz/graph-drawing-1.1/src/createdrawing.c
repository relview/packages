#define _createdrawing_c_

#define PLANAR_DATA

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <malloc.h>

#include "graph.h"
#include "position.h"
#include "simpleposition.h"
#include "embedding.h"
#include "planar.h"
#include "createdrawing.h"
#include "orthogonal.h"


#define DEFAULT_GRAPH_RADIUS  150
#ifndef RAND_MAX
#define RAND_MAX 32767.0
#endif

/* NAME : DrawTriangulatedGraphUnsplitted
 * FUNKTION : erzeugt einen triangulierten Graphen aus einem planaren Graphen
 * UEBERGABEPARAMETER : Zeiger auf eine Relation
 * RUECKGABEWERT : Zeiger auf einen Graphen (NULL, wenn Graph nicht planar)
 * ERSTELLT VON : Sascha Ulbrand (10.02.1999)
 * LETZTE AENDERUNG AM : 10.02.1999
 */
graphlistptr DrawTriangulatedGraphUnsplitted (KureRel * impl)
{
	p_pair pos;
	graphlistptr gl;

	if ( !isPlanar (impl, true))
		return (graphlistptr) NULL;

	if (planarData.planar.adj != NULL && planarData.planar.adj->size <= 4) {
		pos = computeSimplePositions ();
		gl = createTriangularDrawing (pos, PLANAR_GRID_X, PLANAR_GRID_Y,
				PLANAR_OFFSET_X, PLANAR_OFFSET_Y, impl);
		free (pos);
	} else if (planarData.planar.adj != NULL) {
		computeEmbedding ();
		computeSimpleTriangulation ();
		pos = computeSimplePositions ();
		gl = createTriangularDrawing (pos, PLANAR_GRID_X, PLANAR_GRID_Y,
				PLANAR_OFFSET_X, PLANAR_OFFSET_Y, impl);
		free (pos);
	} else {
		gl = graph_create_default (impl, DEFAULT_GRAPH_RADIUS, UNKNOWN_GRAPH_NAME);
	}

	return gl;
}

/* NAME : DrawTriangulatedGraph
 * FUNKTION : erzeugt einen triangulierten Graphen aus einem planaren Graphen
 * UEBERGABEPARAMETER : Zeiger auf eine Relation
 * RUECKGABEWERT : Zeiger auf einen Graphen (NULL, wenn Graph nicht planar)
 * ERSTELLT VON : Sascha Ulbrand (10.02.1999)
 * LETZTE AENDERUNG AM : 10.02.1999
 */
graphlistptr DrawTriangulatedGraph (KureRel * impl)
{
	komponentenlistptr klp;

	klp = splitRelationIntoComponents (impl);
	if (klp) {
		komponentenptr kp = klp->zusammenhangskomponenten;
		graphlistptr gl = NULL;

		while (kp) {
			kp->teilGraph = DrawTriangulatedGraphUnsplitted (kp->teilRelation);
			if ( !kp->teilGraph)
				fprintf (stderr, "DrawTriangulatedGraph: kp->teilGraph is NULL\n");
			kp = kp->next;
		}
		gl = MergeGraphsFromComponents (impl, klp);
		delKomponentenListe (klp);

		return gl;
	}
	else return NULL;
}

/* NAME : DrawTriangluarMixedModelGraphUnsplitted
 * FUNKTION : erzeugt einen triangulierten Graphen aus einem planaren Graphen
 * UEBERGABEPARAMETER : Zeiger auf eine Relation
 * RUECKGABEWERT : Zeiger auf einen Graphen (NULL, wenn Graph nicht planar)
 * ERSTELLT VON : Sascha Ulbrand (10.02.1999)
 * LETZTE AENDERUNG AM : 10.02.1999
 */
graphlistptr DrawTriangluarMixedModelGraphUnsplitted (KureRel * impl)
{
	graphlistptr gl;

	if ( !isPlanar (impl, true))
		return (graphlistptr) NULL;

	if (planarData.planar.adj != NULL && planarData.planar.adj->size <= 4) {
		p_pair pos;

		pos = computeSimplePositions ();
		gl = createTriangularDrawing (pos, PLANAR_GRID_X, PLANAR_GRID_Y,
				PLANAR_OFFSET_X, PLANAR_OFFSET_Y, impl);
		free (pos);
	} else if (planarData.planar.adj) {
		p_boundingBox *boxes;

		computeEmbedding ();
		computeSimpleTriangulation ();
		ConvertTriangularOrdering2EnhacedOrdering ();

		boxes = computeBoundingBoxes ();
		computeLevels ();
		computeMixModPositions (boxes);
		gl = createMixedDrawing (boxes, MIXEDPLANAR_GRID_X, MIXEDPLANAR_GRID_Y,
				PLANAR_OFFSET_X, 2 * PLANAR_OFFSET_Y, impl);
	} else {
		gl = graph_create_default (impl, DEFAULT_GRAPH_RADIUS, UNKNOWN_GRAPH_NAME);
	}
	return gl;
}

/* NAME : DrawTriangluarMixedModelGraph
 * FUNKTION : erzeugt einen triangulierten Graphen aus einem planaren Graphen
 * UEBERGABEPARAMETER : Zeiger auf eine Relation
 * RUECKGABEWERT : Zeiger auf einen Graphen (NULL, wenn Graph nicht planar)
 * ERSTELLT VON : Sascha Ulbrand (10.02.1999)
 * LETZTE AENDERUNG AM : 10.02.1999      
 * Umstellung auf grosse Zahlen: 15.05.2000
 */
graphlistptr DrawTriangluarMixedModelGraph (KureRel * impl)
{
	graphlistptr gl = NULL;
	komponentenlistptr klp;
	komponentenptr kp;
	//Rel *              copyOfRel;
	p_adjList          planarEmbedding;
	visibilityrepptr   visibilityRepresentation;
	orthogonalrepptr   orthogonalRepresentation;

	klp = splitRelationIntoComponents (impl);
	assert (klp);
	if (klp) {
		kp = klp->zusammenhangskomponenten;
		while (kp) {
			KureRel * copy = kp->teilRelation;
			//copyOfRel = get_rel (kp->teilRelation, relData->name);
			/* kleine Graphen werden ggf. orthogonal gezeichnet */
			if (kure_rel_get_cols_si(copy) > SMALL_GRAPH || !rel_orthogonal(copy)) {
				//if ((Kure_mp_mcmp(copyOfRel->breite, Kure_mp_SMALL_GRAPH) > 0) || !rel_orthogonal(copyOfRel)) {
				kp->teilGraph = DrawTriangluarMixedModelGraphUnsplitted (copy);
			}
			else {
				if (kure_rel_get_cols_si(copy) <= 4) {
					//if (Kure_mp_mcmp(copyOfRel->breite, Kure_mp_vier) <= 0) {
					/* Zeichenalgorithmus per Hand aufrufen */
					kp->teilGraph =
							small_orthogonal_graph (kp->teilRelation, MIXEDPLANAR_GRID_X,
									MIXEDPLANAR_GRID_Y, UNKNOWN_GRAPH_NAME);
				}

				else {
					isPlanar (copy, true);
					computeEmbedding ();
					stripEmbedding (copy);
					planarEmbedding = getEmbeddingInOrigNumbering ();

					/* Hier folgt der Algorithmus von Ulf Milanese zum planaren       */
					/* Testen und Berechnen der Einbettung                            */
					visibilityRepresentation = visibility_representation (planarEmbedding);

					orthogonalRepresentation = orthogonal_embedding (visibilityRepresentation, planarEmbedding);
					del_visibility_representation (visibilityRepresentation);

					transform_orthogonal_representation (orthogonalRepresentation);
					delAdjList (planarEmbedding);
					kp->teilGraph = graph_create_orthogonal (orthogonalRepresentation,
							MIXEDPLANAR_GRID_X,
							MIXEDPLANAR_GRID_Y, UNKNOWN_GRAPH_NAME);
					del_orthogonal_representation (orthogonalRepresentation);
					/* Ende des Algorithmuses von Ulf Milanese */
				}

			}
			assert (kp->teilGraph);
			kp = kp->next;
		}
	}
	gl = MergeGraphsFromComponents (impl, klp);
	delKomponentenListe (klp);

	return gl;
}

/* NAME : DrawMixedModelGraphUnsplitted
 * FUNKTION : erzeugt einen MIXMOD-Graphen aus einem planaren Graphen
 * UEBERGABEPARAMETER : Zeiger auf eine Relation
 * RUECKGABEWERT : Zeiger auf einen Graphen (NULL, wenn Graph nicht planar)
 * ERSTELLT VON : Sascha Ulbrand (10.02.1999)
 * LETZTE AENDERUNG AM :10.02.1999
 */
graphlistptr DrawMixedModelGraphUnsplitted (KureRel * impl)
{
	graphlistptr gl;

	if (!isPlanar (impl, true))
		return (graphlistptr) NULL;

	if (planarData.planar.adj != NULL && planarData.planar.adj->size <= 4) {
		p_pair pos;

		pos = computeSimplePositions ();
		gl = createTriangularDrawing (pos, PLANAR_GRID_X, PLANAR_GRID_Y,
				PLANAR_OFFSET_X, PLANAR_OFFSET_Y, impl);
		free (pos);
	} else if (planarData.planar.adj) {
		p_boundingBox *boxes;

		computeEmbedding ();
		computeEnhacedOrdering ();
		if (planarData.embedding.ordpart == NULL) {
			freePlanarMemory();
			return (graphlistptr) NULL;
		}

		boxes = computeBoundingBoxes ();
		computeLevels ();
		computeMixModPositions (boxes);
		gl = createMixedDrawing (boxes, MIXEDPLANAR_GRID_X, MIXEDPLANAR_GRID_Y,
				PLANAR_OFFSET_X, 2 * PLANAR_OFFSET_Y, impl);
	} else {
		gl = graph_create_default (impl, DEFAULT_GRAPH_RADIUS, UNKNOWN_GRAPH_NAME);
	}
	return gl;
}

/* NAME : DrawMixedModelGraph
 * FUNKTION : erzeugt einen MIXMOD-Graphen aus einem planaren Graphen
 * UEBERGABEPARAMETER : Zeiger auf eine Relation
 * RUECKGABEWERT : Zeiger auf einen Graphen (NULL, wenn Graph nicht planar)
 * ERSTELLT VON : Sascha Ulbrand (10.02.1999)
 * LETZTE AENDERUNG AM :10.02.1999
 * Umstellung auf grosse Zahlen: 15.05.2000
 */
graphlistptr DrawMixedModelGraph (KureRel * impl)
{
	graphlistptr gl = NULL;
	komponentenlistptr klp;
	komponentenptr kp;
	p_adjList          planarEmbedding;
	visibilityrepptr   visibilityRepresentation;
	orthogonalrepptr   orthogonalRepresentation;

	klp = splitRelationIntoComponents (impl);
	assert (klp);
	if (klp) {
		kp = klp->zusammenhangskomponenten;
		while (kp) {
			KureRel * copy = kp->teilRelation;
			//get_rel (kp->teilRelation, relData->name);
			/* kleine Graphen werden ggf. orthogonal gezeichnet */
			if (kure_rel_get_cols_si(copy) > SMALL_GRAPH || !rel_orthogonal(copy)) {
				//if ((Kure_mp_mcmp(copyOfRel->breite, Kure_mp_SMALL_GRAPH) > 0 ) || !rel_orthogonal(copyOfRel)) {
				kp->teilGraph = DrawMixedModelGraphUnsplitted (copy);
			} else {
				if (kure_rel_get_cols_si(copy) <= 4) {
					//if (Kure_mp_mcmp(copyOfRel->breite, Kure_mp_vier) <= 0) {
					/* Zeichenalgorithmus per Hand aufrufen */
					kp->teilGraph = small_orthogonal_graph (kp->teilRelation, MIXEDPLANAR_GRID_X,
							MIXEDPLANAR_GRID_Y, UNKNOWN_GRAPH_NAME);
				}

				else {
					isPlanar (copy, true);
					computeEmbedding ();
					stripEmbedding (copy);
					planarEmbedding = getEmbeddingInOrigNumbering ();

					/* Hier folgt der Algorithmus von Ulf Milanese zum planaren       */
					/* Testen und Berechnen der Einbettung                            */
					visibilityRepresentation = visibility_representation (planarEmbedding);

					orthogonalRepresentation = orthogonal_embedding (visibilityRepresentation, planarEmbedding);
					del_visibility_representation (visibilityRepresentation);

					transform_orthogonal_representation (orthogonalRepresentation);
					delAdjList (planarEmbedding);
					kp->teilGraph = graph_create_orthogonal (orthogonalRepresentation,
							MIXEDPLANAR_GRID_X,
							MIXEDPLANAR_GRID_Y, UNKNOWN_GRAPH_NAME);
					del_orthogonal_representation (orthogonalRepresentation);
					/* Ende des Algorithmuses von Ulf Milanese */
				}

			}
			assert (kp->teilGraph);
			kp = kp->next;
		}
	}
	gl = MergeGraphsFromComponents (impl, klp);

	delKomponentenListe (klp);

	return gl;
}

/* NAME : createTriangularDrawing 
 * FUNKTION : Erzeugt einen Graphen 
 * UEBERGABEPARAMETER : Positionsarray (pos) und Gridabstand (gridx,gridy) , Offsets (xoff, yoff) und Relation (relData)
 * VORAUSSETZUNG: globale Struktur planarData ist richtig gefuellt
 * RUECKGABEWERT : Zeiger auf Stuktur Graph
 * ERSTELLT VON : Sascha Ulbrand (09.11.1998)
 * LETZTE AENDERUNG AM : 09.11.1998         
 * Umstellung auf grosse Zahlen 15.05.2000
 */
graphlistptr createTriangularDrawing (p_pair pos, int gridx, int gridy,
		int xoff, int yoff, KureRel * impl)
{
	Graph *gr = NULL;
	graphlistptr gl = NULL;
	nodelistptr p_node;
	edgelistptr p_edge;
	char label[MAXNAMELENGTH + 1];
	int nexty = 1;
	int i, j;
	int breite = kure_rel_get_cols_si (impl);
	int vars_zeilen = kure_rel_get_vars_rows(impl);
	int vars_spalten = kure_rel_get_vars_cols(impl);
	//Kure_MINT * Kure_mp_fuenf;

	//Kure_mp_fuenf = Kure_mp_itom (5);

	assert (kure_is_hom(impl, NULL));
	//assert (Kure_mp_mcmp (relData->breite, relData->hoehe) == 0);

	//breite = Kure_mp_mint2int (relData->breite);
	//vars_zeilen = Kure_mp_number_of_vars (relData->hoehe);
	//vars_spalten = Kure_mp_number_of_vars (relData->breite);

	if (!planarData.connect.preorder) {
		/* Graph ohne Kanten  und kleine Graphen */
		if (breite < 5 && pos) {
			//if ((Kure_mp_mcmp (relData->breite, Kure_mp_fuenf) < 0) && pos) {
			gl = mk_graph (UNKNOWN_GRAPH_NAME, NORMAL);
			if (gl != NULL) {
				gr = &gl->graph;
				for (j = 0; j < breite; j++) {
					sprintf (label, "%i", j + 1);
					p_node = make_node (label,
							pos[j].y * gridy + yoff,
							pos[j].x * gridx + xoff,
							DEFAULT_DIM, VISIBLE);
					if (p_node) {
						append_node (gr, p_node);
					} else {
						printf ("make_node failed\n");
						assert (false);
					}
				}
				for (i = 0; i < breite; i++)
					for (j = 0; j < breite; j++)
						if (kure_get_bit_fast_si(impl, i,j,vars_zeilen, vars_spalten)) {
							//if (get_rel_bit (relData, j, i, vars_zeilen, vars_spalten)) {
							p_edge = make_edge ("", i + 1, j + 1, VISIBLE);

							if (p_edge == (edgelistptr) NULL) {
								printf ("make_edge failed");
								assert (false);
							} else
								append_edge (gr, p_edge);
						}
			} else {
				printf ("making of graph failed!\n");
				assert (false);
			}
		} else {
			gl = graph_create_default (impl, DEFAULT_GRAPH_RADIUS, UNKNOWN_GRAPH_NAME);
		}
	}
	else {
		gl = mk_graph (UNKNOWN_GRAPH_NAME, NORMAL);
		if (gl != (graphlistptr) NULL) {
			gr = &gl->graph;
			for (j = 0; j < breite; j++) {
				sprintf (label, "%i", j + 1);
				if (inList (planarData.connect.singletons, j)) {
					printf ("adding singleton %i\n", j),
							p_node = make_node (label,
									nexty++ * gridy + yoff,
									xoff,
									DEFAULT_DIM, VISIBLE);
				} else {
					i = planarData.connect.preorder->phi[j];
					i = planarData.planar.preorder->phi[i];
					p_node = make_node (label,
							pos[i].y * gridy + yoff,
							pos[i].x * gridx + xoff,
							DEFAULT_DIM, VISIBLE);
				}
				if (p_node == (nodelistptr) NULL) {
					printf ("make_node failed\n");
					assert (false);
				} else
					append_node (gr, p_node);

			}
			for (i = 0; i < breite; i++)
				for (j = 0; j < breite; j++)
					if (kure_get_bit_fast_si (impl, i,j,vars_zeilen,vars_spalten)) {
					//if (get_rel_bit (relData, j, i, vars_zeilen, vars_spalten)) {
						p_edge = make_edge ("", i + 1, j + 1, VISIBLE);

						if (p_edge == (edgelistptr) NULL) {
							printf ("make_edge failed");
							assert (false);
						} else
							append_edge (gr, p_edge);
					}
		}
	}

	freePlanarMemory ();
	//Kure_mp_mfree(Kure_mp_fuenf);
	return gl;
}

/* NAME : PostProcessingY
 * FUNKTION : entfernt leere Zeilen aus einem enhacedDrawing
 * UEBERGABEPARAMETER : Zeiger auf Stuktur Graph (gl), Gridabstand (gridx,gridy) , 
 *                      Offsets (xoff, yoff)
 * RUECKGABEWERT :  Anzahl der freigewordenen Zeilen
 * ERSTELLT VON : Sascha Ulbrand (18.02.1999)
 * LETZTE AENDERUNG AM : 18.02.1999
 */
int PostProcessingY (Graph * gr, int gridx, int gridy, int xoff, int yoff)
{
	nodelistptr p_node;
	int max = 0;
	int i;
	int y;
	p_intSet yPos;
	p_intList freeRows = getNewIntList ();
	int result;

	assert (gr);

	p_node = gr->node_root;
	while (p_node) {
		max = MAXIMUM (max, (p_node->node.y_pos - xoff) / gridx);
		p_node = p_node->next;
	}

	yPos = getNewIntSet (max + 1);

	p_node = gr->node_root;
	while (p_node) {
		intSetIncl (yPos, (p_node->node.y_pos - xoff) / gridx);
		p_node = p_node->next;
	}

	for (i = 0; i <= max; i++)
		if (!isInIntSet (yPos, i))
			addLast (freeRows, i);

	result = freeRows->size;

	while (freeRows->size) {
		y = popLast (freeRows) * gridx + xoff;
		p_node = gr->node_root;
		while (p_node) {
			if (p_node->node.y_pos > y)
				p_node->node.y_pos -= gridx;
			p_node = p_node->next;
		}

	}

	delIntList (freeRows);
	delIntSet (yPos);

	gridy = yoff = 0;		/* dummy statement to supress compiler warning */

	return result;
}

/* NAME : PostProcessingX
 * FUNKTION : entfernt leere Zeilen aus einem enhacedDrawing
 * UEBERGABEPARAMETER : Zeiger auf Stuktur Graph (gr), Gridabstand (gridx,gridy) , 
 *                      Offsets (xoff, yoff)
 * RUECKGABEWERT :  Anzahl der freigewordenen Spalten
 * ERSTELLT VON : Sascha Ulbrand (18.02.1999)
 * LETZTE AENDERUNG AM : 18.02.1999
 */
int PostProcessingX (Graph * gr, int gridx, int gridy, int xoff, int yoff)
{
	nodelistptr p_node;
	int max = 0;
	int i;
	int x;
	p_intSet xPos;
	p_intList freeRows = getNewIntList ();
	int result;

	assert (gr);

	p_node = gr->node_root;
	while (p_node) {
		max = MAXIMUM (max, (p_node->node.x_pos - yoff) / gridy);
		p_node = p_node->next;
	}

	xPos = getNewIntSet (max + 1);

	p_node = gr->node_root;
	while (p_node) {
		intSetIncl (xPos, (p_node->node.x_pos - yoff) / gridy);
		p_node = p_node->next;
	}

	for (i = 0; i <= max; i++)
		if (!isInIntSet (xPos, i))
			addLast (freeRows, i);

	result = freeRows->size;

	while (freeRows->size) {
		x = popLast (freeRows) * gridy + yoff;
		p_node = gr->node_root;
		while (p_node) {
			if (p_node->node.x_pos > x)
				p_node->node.x_pos -= gridy;
			p_node = p_node->next;
		}
	}

	delIntList (freeRows);
	delIntSet (xPos);

	gridx = xoff = 0;		/* dummy statement to supress compiler warning */


	return result;
}

/* NAME : PostProcessingDeg1
 * FUNKTION : Sonderbehandlung von Knoten mit Grad 1
 * UEBERGABEPARAMETER : Zeiger auf Grafen und Gridkonstanten
 * RUECKGABEWERT : Anzahl der behandelten Knoten
 * ERSTELLT VON : Sascha Ulbrand (25.02.1999)
 * LETZTE AENDERUNG AM : 25.02.1999
 */
int PostProcessingDeg1 (Graph * gr, int gridx, int gridy)
{
	p_adjList adj;
	int adjsize = 0;
	int result = 0;
	int i;
	nodelistptr pNode;
	edgelistptr pEdge;

	pNode = gr->node_root;
	while (pNode) {
		if (pNode->node.state == VISIBLE) {
			adjsize++;
		}
		pNode = pNode->next;
	}

	adj = getNewAdjList (adjsize + 1);

	pEdge = gr->edge_root;
	while (pEdge) {
		if (!areNeighbours (adj, pEdge->edge.from, pEdge->edge.to)) {
			addNewEdge (adj, pEdge->edge.from, pEdge->edge.to);
			addNewEdge (adj, pEdge->edge.to, pEdge->edge.from);
		}
		pEdge = pEdge->next;
	}

	for (i = 1; i < adj->size; i++) {
		if (adj->aList[i]->size == 1 && adj->aList[adj->aList[i]->first->val]->size != 1) {
			/* Sonderbehandlung */
			int from = i;
			int to = adj->aList[i]->first->val;
			intlistptr helpiter;
			intlistptr helpiter2;
			Edge *fromEdge = (Edge *) NULL;
			Edge *toEdge = (Edge *) NULL;
			Node *pFrom = (Node *) NULL;
			Node *pTo = (Node *) NULL;
			nodelistptr pHelp = (nodelistptr) NULL;

			pNode = gr->node_root;
			while (pNode) {
				if (pNode->node.number == from && pNode->node.state == VISIBLE) {
					pFrom = &pNode->node;
				} else if (pNode->node.number == to && pNode->node.state == VISIBLE) {
					pTo = &pNode->node;
				}
				pNode = pNode->next;
			}

			assert (pTo && pFrom);	/* Eine Kante hat immer from UND to */

			pEdge = gr->edge_root;
			while (pEdge) {
				if (pEdge->edge.from == from && pEdge->edge.to == to) {
					fromEdge = &pEdge->edge;
				} else if (pEdge->edge.from == to && pEdge->edge.to == from) {
					toEdge = &pEdge->edge;
				}
				pEdge = pEdge->next;
			}

			assert (fromEdge != NULL || toEdge != NULL);	/* mindestens eine muss gefunden werden */

			if ((fromEdge && fromEdge->path == NULL) || (toEdge && toEdge->path == NULL)) {
				if (pFrom->x_pos == pTo->x_pos && adj->aList[to]->size < 8) { /* Beschraenkung auf 8 sieht besser aus */
					result++;
					while (abs (pFrom->y_pos - pTo->y_pos) != gridy) {
						pFrom->y_pos += (((pFrom->y_pos - pTo->y_pos) < 0) ? gridy : -gridy);
					}
				}
				if (pFrom->y_pos == pTo->y_pos && adj->aList[to]->size < 8) { /* Beschraenkung auf 8 sieht besser aus */
					result++;
					while (abs (pFrom->x_pos - pTo->x_pos) != gridx) {
						pFrom->x_pos += (((pFrom->x_pos - pTo->x_pos) < 0) ? gridx : -gridx);
					}
				}
				continue;		/* keine Hilfsknoten auf dem Pfad */
			}
			/* neue Position ermitteln und Knoten 'from' umsetzen */
			if (fromEdge) {
				helpiter = fromEdge->path;
				assert (helpiter);
				while (helpiter->next) {
					helpiter = helpiter->next;
				}
			} else {
				assert (toEdge);
				helpiter = toEdge->path;
			}

			/* printf ("Hilfsknoten mit Nummer %i\n", helpiter->number); */
			pHelp = gr->node_root;
			while (pHelp) {
				if (pHelp->node.number == helpiter->number)
					break;
				pHelp = pHelp->next;
			}

			assert (pHelp);		/* muss was gefunden haben */

			pFrom->x_pos = pHelp->node.x_pos;
			pFrom->y_pos = pHelp->node.y_pos;

			/* Die Hilfsknoten aus den Pfaden loeschen */

			if (fromEdge) {
				helpiter = fromEdge->path;
				while (helpiter) {
					helpiter2 = helpiter;
					helpiter = helpiter->next;
					del_single_node(gr,helpiter2->number);
					free (helpiter2);
				}
				fromEdge->path = NULL;
			}
			if (toEdge) {
				helpiter = toEdge->path;
				while (helpiter) {
					helpiter2 = helpiter;
					helpiter = helpiter->next;
					del_single_node(gr,helpiter2->number);
					free (helpiter2);
				}
				toEdge->path = NULL;
			}
			result++;
		}
	}

	delAdjList (adj);
	return result;
}

/* NAME : createMixedDrawing 
 * FUNKTION : Erstellt aus den boundingBoxes eine RELVIEW-Zeichnung (fuer Mixed-Model)
 * UEBERGABEPARAMETER : Zeiger auf Array von Boundingboxes (boxes), Gridabstand (gridx,gridy) , 
 *                      Offsets (xoff, yoff) und Relation (relData) 
 * NEBENWIRKUNG : loescht Speicher von (boxes)
 * RUECKGABEWERT : Zeiger auf Stuktur Graph
 * ERSTELLT VON : Sascha Ulbrand (18.01.1999)
 * LETZTE AENDERUNG AM : 23.02.1999      
 * Umstellung auf grosse Zahlen: 15.05.2000
 */
graphlistptr createMixedDrawing (p_boundingBox *boxes, int gridx, int gridy,
		int xoff, int yoff, KureRel * impl)
{
	int *rank = planarData.embedding.ranking;
	Graph *gr = NULL;
	graphlistptr gl = NULL;
	nodelistptr p_node;
	nodelistptr p_helpNode[4];
	int oldcount, helpnodecount, firsthelpnode;
	int nextFreeHelpNode;
	edgelistptr p_edge;
	char label[MAXNAMELENGTH + 1];
	int node, nodeNew;

	int singletonCount = 0;
	int from, to, fromNew, toNew;	/* new-Variablen fuer KnotenNummern nach Umnummerierung */
	int fromNewAbsX, toNewAbsX;
	int fromNewAbsY, toNewAbsY;
	int fromNewRelX, toNewRelX;
	int fromNewRelY, toNewRelY;
	int helpx[5], helpy[5];
	int i;
	int obsolete1, obsolete2, obsolete3;
	int drawaddededges;
	int breite = kure_rel_get_cols_si (impl);
	int vars_zeilen = kure_rel_get_vars_rows (impl);
	int vars_spalten = kure_rel_get_vars_cols (impl);

#ifdef DRAW_ADDED_EDGES
	drawaddededges = true;
#else
	drawaddededges = false;
#endif

	//Kure_mp_vier = Kure_mp_itom(4);
	//breite = Kure_mp_mint2int(relData->breite);

	assert (kure_is_hom(impl, NULL) && breite > 4);
	//assert ((Kure_mp_mcmp(relData->breite, relData->hoehe) == 0) && (Kure_mp_mcmp(relData->hoehe, Kure_mp_vier) > 0));
	//Kure_mp_mfree(Kure_mp_vier);

	assert (boxes);
	/* keine Sonderfaelle fuer kleine Graphen, sollten schon abgefangen sein */

	gl = mk_graph (UNKNOWN_GRAPH_NAME, NORMAL);
	if (gl != NULL) {
		gr = &gl->graph;

		/* zunaechst Knoten einzeichnen */
		for (node = 0; node < breite; node++) {
			sprintf (label, "%i", node + 1);
			if (inList (planarData.connect.singletons, node)) {
				singletonCount++;
				p_node = make_node (label,
						15,
						(singletonCount + 1) * gridy + yoff,
						DEFAULT_DIM, VISIBLE);
			} else {
				nodeNew = planarData.connect.preorder->phi[node];
				nodeNew = planarData.planar.preorder->phi[nodeNew];
				p_node = make_node (label,
						boxes[nodeNew]->y * gridy + yoff,
						boxes[nodeNew]->x * gridx + xoff,
						DEFAULT_DIM, VISIBLE);

			}
			if (p_node) {
				append_node (gr, p_node);
			} else {
				printf ("make_node failed\n");
				assert (false);
			}
		}

		nextFreeHelpNode = breite;

		/* nun Kanten einzeichnen */

		//vars_zeilen = Kure_mp_number_of_vars (relData->hoehe);
		//vars_spalten = Kure_mp_number_of_vars (relData->breite);

		for (from = 0; from < breite; from++)
			for (to = 0; to < breite; to++)
				if (from <= to) {
					/* Nummerierung umrechnen */
					toNew = planarData.connect.preorder->phi[to];
					toNew = planarData.planar.preorder->phi[toNew];
					fromNew = planarData.connect.preorder->phi[from];
					fromNew = planarData.planar.preorder->phi[fromNew];

					if (from == to && kure_get_bit_fast_si (impl, from, to, vars_zeilen, vars_spalten)) {
					//if (from == to && get_rel_bit (relData, to, from, vars_zeilen, vars_spalten)) {
						/* Identitaet (Schleife) */
						p_edge = make_edge ("", from + 1, to + 1, VISIBLE);

						if (p_edge == (edgelistptr) NULL) {
							printf ("make_edge failed");
							assert (false);
						} else {
							append_edge (gr, p_edge);
						}
					}
					else if (kure_get_bit_fast_si (impl, to, from, vars_zeilen, vars_spalten)
						|| kure_get_bit_fast_si (impl, from, to, vars_zeilen, vars_spalten)
					//else if (get_rel_bit (relData, from, to, vars_zeilen, vars_spalten) ||
					//		get_rel_bit (relData, to, from, vars_zeilen, vars_spalten)
						||	(drawaddededges && from != to && areNeighbours(planarData.embedding.embedding,fromNew,toNew))) {
						/* relative Positionen der Hilfspunkte holen */
						fromNewRelX = relPointPosition (boxes[fromNew], toNew)->xrel;
						fromNewRelY = relPointPosition (boxes[fromNew], toNew)->yrel;
						toNewRelX = relPointPosition (boxes[toNew], fromNew)->xrel;
						toNewRelY = relPointPosition (boxes[toNew], fromNew)->yrel;

						/* absolute Positionen der Hilfspunkte berechnen */
						fromNewAbsX = boxes[fromNew]->x + fromNewRelX;
						fromNewAbsY = boxes[fromNew]->y + fromNewRelY;
						toNewAbsX = boxes[toNew]->x + toNewRelX;
						toNewAbsY = boxes[toNew]->y + toNewRelY;

						/* Hilfsknoten erzeugen, jeden moeglichen Fall unterscheiden */
						p_helpNode[0] = p_helpNode[1] = p_helpNode[2] = p_helpNode[3] = NULL;
						firsthelpnode = nextFreeHelpNode;
						if (boxes[toNew]->y == boxes[fromNew]->y &&
								relPointPosition (boxes[fromNew], toNew)->yrel == 0 &&
								relPointPosition (boxes[toNew], fromNew)->yrel == 0) {

							/* beide Knoten liegen auf einer Ebene und koennen direkt verbunden werden */
							helpnodecount = 0;

						} else if (boxes[toNew]->x == boxes[fromNew]->x &&
								relPointPosition (boxes[fromNew], toNew)->xrel == 0 &&
								relPointPosition (boxes[toNew], fromNew)->xrel == 0) {
							/* beide Knoten liegen direkt uebereinander und koennen direkt verbunden werden */
							helpnodecount = 0;

						} else if (boxes[toNew]->y == boxes[fromNew]->y) {

							/* Sonderfall fuer Ergebnis der Umbettung von Kanten zwischen Knoten desselben Grades
							 * muss beachtet werden !!!
							 * hier koennen dann bis zu 4 Hilfsknoten benoetigt werden, minimal aber 2 */
							int level;

							helpnodecount = 0;

							/* abfangen, ob auch wirklich dieser Sonderfall vorliegt */
							assert (boxes[fromNew]->in > 2 && boxes[toNew]->in > 2);
							assert (rank[fromNew] == rank[toNew]);

							level = getEdgeWeight (planarData.mixedmodel.edgelevels, fromNew, toNew);

							if (fromNewRelX == 0) {
								/* inpoint liegt direkt unter dem Knoten */
								sprintf (label, "%i", ++nextFreeHelpNode);
								p_helpNode[helpnodecount++] = make_node (label,
										(boxes[fromNew]->y - level) * gridy + yoff,
										boxes[fromNew]->x * gridx + xoff,
										DEFAULT_DIM, HELP);
							} else {
								sprintf (label, "%i", ++nextFreeHelpNode);
								p_helpNode[helpnodecount++] = make_node (label,
										fromNewAbsY * gridy + yoff,
										fromNewAbsX * gridx + xoff,
										DEFAULT_DIM, HELP);

								sprintf (label, "%i", ++nextFreeHelpNode);
								p_helpNode[helpnodecount++] = make_node (label,
										(boxes[fromNew]->y - level) * gridy + yoff,
										fromNewAbsX * gridx + xoff,
										DEFAULT_DIM, HELP);
							}

							if (toNewRelX == 0) {
								/* inpoint liegt direkt unter dem Knoten */
								sprintf (label, "%i", ++nextFreeHelpNode);
								p_helpNode[helpnodecount++] = make_node (label,
										(boxes[toNew]->y - level) * gridy + yoff,
										boxes[toNew]->x * gridx + xoff,
										DEFAULT_DIM, HELP);
							} else {
								sprintf (label, "%i", ++nextFreeHelpNode);
								p_helpNode[helpnodecount++] = make_node (label,
										(boxes[toNew]->y - level) * gridy + yoff,
										toNewAbsX * gridx + xoff,
										DEFAULT_DIM, HELP);

								sprintf (label, "%i", ++nextFreeHelpNode);
								p_helpNode[helpnodecount++] = make_node (label,
										toNewAbsY * gridy + yoff,
										toNewAbsX * gridx + xoff,
										DEFAULT_DIM, HELP);
							}

							/* printf ("Specialcase needed %i helpnodes\n", helpnodecount); */
							assert (helpnodecount >= 2 && helpnodecount <= 4);

						} else if (fromNewAbsX == toNewAbsX && fromNewAbsY == toNewAbsY) {

							/* maximal ein Hilfsknoten benoetigt, da die Hilfsknoten direkt aufeinander liegen */
							if ((fromNewRelX == 0 && fromNewRelY == 0) || (toNewRelX == 0 && toNewRelY == 0)) {
								helpnodecount = 0;
							} else {
								helpnodecount = 1;
								sprintf (label, "%i", ++nextFreeHelpNode);
								p_helpNode[0] = make_node (label,
										fromNewAbsY * gridy + yoff,
										fromNewAbsX * gridx + xoff,
										DEFAULT_DIM, HELP);
							}

						} else if (fromNewAbsX == toNewAbsX || fromNewAbsY == toNewAbsY) {

							/* maximal zwei Hilfsknoten werden benoetigt */
							helpnodecount = 0;
							if (fromNewRelX != 0 || fromNewRelY != 0) {
								helpx[1 + helpnodecount] = fromNewAbsY;
								helpy[1 + helpnodecount] = fromNewAbsX;
								helpnodecount++;
							}
							if (toNewRelX != 0 || toNewRelY != 0) {
								helpx[1 + helpnodecount] = toNewAbsY;
								helpy[1 + helpnodecount] = toNewAbsX;
								helpnodecount++;
							}
							obsolete1 = obsolete2 = false;
							helpx[0] = boxes[fromNew]->y;
							helpy[0] = boxes[fromNew]->x;

							if (helpnodecount == 2) {
								/* evtl ueberfluessige Knoten streichen */
								helpx[3] = boxes[toNew]->y;
								helpy[3] = boxes[toNew]->x;
								if (helpy[0] == helpy[2] || helpx[0] == helpx[2]) {
									assert (helpy[1] == helpy[2] || helpx[1] == helpx[2]);
									obsolete1 = true;
								}
								if (helpy[1] == helpy[3] || helpx[1] == helpx[3]) {
									assert (helpy[2] == helpy[3] || helpx[2] == helpx[3]);
									obsolete2 = true;
								}
							}
							oldcount = helpnodecount;
							helpnodecount = 0;
							for (i = 1; i <= oldcount; i++) {
								if (!(i == 1 && obsolete1) && !(i == 2 && obsolete2)) {
									sprintf (label, "%i", ++nextFreeHelpNode);
									p_helpNode[helpnodecount] = make_node (label,
											helpx[i] * gridy + yoff,
											helpy[i] * gridx + xoff,
											DEFAULT_DIM, HELP);
									helpnodecount++;
								}
							}
						} else {
							/* maximal drei (mindestens ein) Hilfsknoten werden benoetigt */
							if (rank[toNew] == rank[fromNew]) {
								/* wenn drei Hilfsknoten benoetigt werden, haben die Knoten verschiedenen Rang */
								p_adjList erradj;

								printf ("internal error of drawing algorithm: MIXEDMODEL\n"
										"please send bug report including the following data.\n"
										"Adjazenz (orignum) of graph causing bug:\n");
								stripEmbedding (impl);
								erradj = getEmbeddingInOrigNumbering ();
								printAdjList (erradj);
								printf ("****************************** end of bugreprot ***\n");
								delAdjList (erradj);

								del_graph(gl, UNKNOWN_GRAPH_NAME);
								gl = NULL;
								goto exit;	/* extraordinary error, should not happen */
							}

							helpnodecount = 0;
							if (fromNewRelX != 0 || fromNewRelY != 0) {
								helpx[1 + helpnodecount] = fromNewAbsY;
								helpy[1 + helpnodecount] = fromNewAbsX;
								helpnodecount++;
							}
							if (rank[toNew] > rank[fromNew]) {
								helpx[1 + helpnodecount] = toNewAbsY;
								helpy[1 + helpnodecount] = fromNewAbsX;
								helpnodecount++;
							} else if (rank[toNew] < rank[fromNew]) {
								helpx[1 + helpnodecount] = fromNewAbsY;
								helpy[1 + helpnodecount] = toNewAbsX;
								helpnodecount++;
							} else
								assert (false);	/* Der Fall wurde oben schon abgefangen */

							if ((toNewRelX != 0 || toNewRelY != 0)) {
								helpx[1 + helpnodecount] = toNewAbsY;
								helpy[1 + helpnodecount] = toNewAbsX;
								helpnodecount++;
							}
							obsolete1 = obsolete2 = obsolete3 = false;

							helpx[0] = boxes[fromNew]->y;
							helpy[0] = boxes[fromNew]->x;

							if (helpnodecount == 3) {
								/* evtl ueberfluessige Knoten streichen */
								helpx[4] = boxes[toNew]->y;
								helpy[4] = boxes[toNew]->x;
								if (helpy[0] == helpy[2] || helpx[0] == helpx[2]) {
									assert (helpy[1] == helpy[2] || helpx[1] == helpx[2]);
									obsolete1 = true;
								}
								if (helpy[2] == helpy[4] || helpx[2] == helpx[4]) {
									assert (helpy[3] == helpy[4] || helpx[3] == helpx[4]);
									obsolete3 = true;
								}
							} else if (helpnodecount == 2) {
								/* evtl ueberfluessige Knoten streichen */
								helpx[3] = boxes[toNew]->y;
								helpy[3] = boxes[toNew]->x;
								if (helpy[0] == helpy[2] || helpx[0] == helpx[2]) {
									assert (helpy[1] == helpy[2] || helpx[1] == helpx[2]);
									obsolete1 = true;
								}
								if (helpy[1] == helpy[3] || helpx[1] == helpx[3]) {
									assert (helpy[2] == helpy[3] || helpx[2] == helpx[3]);
									obsolete2 = true;
								}
							}
							oldcount = helpnodecount;
							helpnodecount = 0;
							for (i = 1; i <= oldcount; i++) {
								if (!(i == 1 && obsolete1) && !(i == 2 && obsolete2) && !(i == 3 && obsolete3)) {
									sprintf (label, "%i", ++nextFreeHelpNode);
									p_helpNode[helpnodecount] = make_node (label,
											helpx[i] * gridy + yoff,
											helpy[i] * gridx + xoff,
											DEFAULT_DIM, HELP);
									helpnodecount++;
								}
							}

						}

						for (i = 0; i < helpnodecount; i++)
							if (p_helpNode[i]) {
								append_node (gr, p_helpNode[i]);
							} else {
								printf ("make_node failed for edge (%i,%i) (n%i,n%i), helpnodecount = %i\n", from, to, fromNew, toNew, helpnodecount);
								assert (false);
							}

						/* Hinrichtung (from,to), falls erforderlich */
						if (kure_get_bit_fast_si(impl, from, to, vars_zeilen, vars_spalten)) {
						//if (get_rel_bit (relData, to, from, vars_zeilen, vars_spalten)) {
							p_edge = make_edge ("", from + 1, to + 1, VISIBLE);

							if (p_edge == (edgelistptr) NULL) {
								printf ("make_edge failed");
								assert (false);
							} else {
								for (i = 0; i < helpnodecount; i++) {
									append_edge_pathnode (&p_edge->edge, p_helpNode[i]->node.number);
								}
								append_edge (gr, p_edge);
							}
						}
						/* Rueckrichtung (to,from), falls erforderlich */
						if (kure_get_bit_fast_si(impl, to, from, vars_zeilen, vars_spalten)) {
						//if (get_rel_bit (relData, from, to, vars_zeilen, vars_spalten)) {
							p_edge = make_edge ("", to + 1, from + 1, VISIBLE);

							if (p_edge == (edgelistptr) NULL) {
								printf ("make_edge failed");
								assert (false);
							} else {
								for (i = helpnodecount - 1; i >= 0; i--) {
									append_edge_pathnode (&p_edge->edge, p_helpNode[i]->node.number);
								}
								append_edge (gr, p_edge);
							}
						}
#ifdef DRAW_ADDED_EDGES
# error NOT IMPLEMENTED
						if ( !(get_rel_bit (relData, to, from, vars_zeilen, vars_spalten) || get_rel_bit (relData, from, to, vars_zeilen, vars_spalten)) ) {
							p_edge = make_edge ("", from + 1, to + 1, SELECTED);

							if (p_edge == (edgelistptr) NULL) {
								printf ("make_edge failed");
								assert (false);
							} else {
								for (i = 0; i < helpnodecount; i++) {
									append_edge_pathnode (&p_edge->edge, p_helpNode[i]->node.number);
								}
								append_edge (gr, p_edge);
							}
							p_edge = make_edge ("", to + 1, from + 1, SELECTED);

							if (p_edge == (edgelistptr) NULL) {
								printf ("make_edge failed");
								assert (false);
							} else {
								for (i = helpnodecount - 1; i >= 0; i--) {
									append_edge_pathnode (&p_edge->edge, p_helpNode[i]->node.number);
								}
								append_edge (gr, p_edge);
							}
						}
#endif /* DRAW_ADDED_EDGES */
					}
				}
	} else {
		printf ("making of graph failed!\n");
		assert (false);
	}

	exit:

	for (i = 0; i < planarData.planar.preorder->size; i++)
		if (boxes[i])
			delBoundingBox (boxes[i]);
	free (boxes);

	freePlanarMemory ();

	PostProcessingDeg1 (gr, gridx, gridy);
	PostProcessingDeg1 (gr, gridx, gridy);
	PostProcessingY (gr, gridx, gridy, xoff, yoff);
	PostProcessingX (gr, gridx, gridy, xoff, yoff);

	return gl;
}

/* NAME : swapXYinGraph  
 * FUNKTION : tauscht Koordinaten eines Graphen (bewirkt Drehung des Graphen)
 * UEBERGABEPARAMETER : graphlistptr
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (16.02.1999)
 * LETZTE AENDERUNG AM : 16.02.1999
 */
void swapXYinGraph (Graph * gr)
{
	nodelistptr pNode;
	int t;

	assert (gr);

	pNode = gr->node_root;
	while (pNode) {
		t = pNode->node.x_pos;
		pNode->node.x_pos = pNode->node.y_pos;
		pNode->node.y_pos = t;
		pNode = pNode->next;
	}
}

/* NAME : scaleGraph
 * FUNKTION : multipliziert alle Positionen in Knoten mit einer Konstante
 * UEBERGABEPARAMETER : graphptr, Faktor
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (25.02.1999)
 * LETZTE AENDERUNG AM : 25.02.1999
 */
void scaleGraph (Graph * gr, double xfac, double yfac)
{
	nodelistptr pNode;

	assert (gr);

	pNode = gr->node_root;
	while (pNode) {
		pNode->node.x_pos = (int) (pNode->node.x_pos * xfac);
		pNode->node.y_pos = (int) (pNode->node.y_pos * yfac);
		pNode = pNode->next;
	}
}
