/****************************************************************************/
/* Dateiname: orthogonal_fast.c                                             */
/* Inhalt: Eine Greedy-Heuriustik zur Berechnung eines planaren Subgraphen  */
/* Autor: Ulf Milanese                                                      */
/* erstellt am: 27.02.2001                                                  */
/* zuletzt geaendert am 27.02.2001                                          */
/****************************************************************************/

#include <stdio.h>
#include <malloc.h>

#include "orthogonal.h"
#include "embedding.h"
#include "simpleposition.h"

/****************************************************************************/
/* NAME: planar_greedy_subrelation                                          */
/* FUNKTION: Greedy-Heuristik zur Erzeugung einer planaren Sub-Relation     */
/* UEBERGABEPARAMETER: Zeiger auf eine Relation (relData)                   */
/* VORAUSSETZUNG: KEINE                                                     */
/* RUECKGABEWERT: Zeiger auf eine Relation                                  */
/* ERSTELLT VON: Ulf Milanese (27.02.2001)                                  */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/
KureRel * planar_greedy_subrelation (KureRel * impl)
{
	KureRel * res;
	//Rel * resultatData;
	//rellistptr resultat;
	edgelistptr edges;
	edgelistptr tmp_edges;
	int node_1;
	int node_2;
	int i;
	int breite = kure_rel_get_cols_si (impl);
	int hoehe  = kure_rel_get_rows_si (impl);
	int vars_zeilen = kure_rel_get_vars_rows(impl);
	int vars_spalten = kure_rel_get_vars_cols(impl);
	unsigned int degrees [breite];

	res = kure_rel_new_copy (impl);
	/* Die Eingabe wird in das Resultat kopiert. */
	//resultat = copy_rel (relData, relData->name);
	//resultatData = get_rel (resultat, relData->name);
	/* Falls die Relation bereits planar ist, sind wir fertig. */

	if (isPlanar (impl, 0))
		return res;

	/* In degrees werden die Grade der Knoten des reduzierten Graphens */
	/* gespeichert. */
	for (node_1 = 0; node_1 < breite; node_1 ++)
		degrees [node_1] = 0;

	edges = make_edge ("", 0, 0, VISIBLE);
	tmp_edges = edges;

	/* Die Relation wird geleert, dabei werden gleichzeitig eine Liste */
	/* aller Kanten die Grade aller Knoten gespeichert. */
	for (i = 1; i < breite; i ++)
		for (node_1 = 0; node_1 < hoehe - i; node_1 ++) {
			node_2 = node_1 + i;
			if (kure_get_bit_fast_si (impl, node_2, node_1, vars_zeilen, vars_spalten)
					|| kure_get_bit_fast_si(impl, node_1, node_2, vars_zeilen, vars_spalten)) {
					//get_rel_bit (relData, node_1, node_2, vars_zeilen, vars_spalten) ||
					//get_rel_bit (relData, node_2, node_1, vars_zeilen, vars_spalten))) {
				kure_set_bit_si (res, FALSE, node_2, node_1);
				kure_set_bit_si (res, FALSE, node_1, node_2);
				//clear_rel_bit (resultatData, node_1, node_2, breite, hoehe);
				//clear_rel_bit (resultatData, node_2, node_1, breite, hoehe);
				tmp_edges->next = make_edge ("", node_1, node_2, VISIBLE);
				tmp_edges = tmp_edges->next;
				degrees [node_1] ++;
				degrees [node_2] ++;
			}
		}

	/* Die erste Kante (ein Dummy) wird entfernt. */
	tmp_edges = edges;
	edges = edges->next;
	free (tmp_edges);

	/* edges enthaelt jetzt eine Liste aller Kanten (x,y) aus relData mit */
	/* x < y, degrees enthaelt die Grade aller Knoten. */

	/* In einem Greedy-Verfahren werden die Kanten wieder in die Relation */
	/* eingefuegt, falls dadurch nicht die Planaritaet zerstoert wird. */
	/* Dabei bleibt die Relation symmetrisch. */
	tmp_edges = edges;
	while (edges) {
		node_1 = edges->edge.from;
		node_2 = edges->edge.to;

		kure_set_bit_si (res, TRUE, node_2, node_1);
		//set_rel_bit (resultatData, node_1, node_2, breite, hoehe);
		/* Bei Kanten zu Blaettern wird kein Planaritaetstest benoetigt. */
		if ((degrees [node_1] != 1) && (degrees [node_2] != 1))
			if (!isPlanar (res, 0))
				kure_set_bit_si(res, FALSE, node_2, node_1);
				//clear_rel_bit (resultatData, node_1, node_2, breite, hoehe);
			else
				kure_set_bit_si (res, TRUE, node_1, node_2);
				//set_rel_bit (resultatData, node_2, node_1, breite, hoehe);
		else
			kure_set_bit_si (res, TRUE, node_1, node_2);
			//set_rel_bit (resultatData, node_2, node_1, breite, hoehe);
		edges = edges->next;
	}
	del_edgelistptr (tmp_edges);

	return res;
}





/****************************************************************************/
/* NAME : graph_orthogonal_fast                                             */
/* FUNKTION : Zeichnet einen Graphen orthogonal                             */
/* UEBERGABEPARAMETER : Zeiger auf eine Relation                            */
/* VORAUSSETZUNG : Relation laesst sich orthogonal darstellen (wird nicht   */
/*                 geprueft)                                                */
/* RUECKGABEWERT : Zeiger auf eine Liste von Graphen                        */
/* ERSTELLT VON : Ulf Milanese (27.02.2001)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/
graphlistptr graph_orthogonal_fast (KureRel * impl)
{
	graphlistptr       resultat;
	komponentenlistptr klp;
	komponentenptr     kp;
	//Rel *              copyOfRel;
	unsigned int       gridx = 48;
	unsigned int       gridy = 48;
	p_adjList          planarEmbedding;
	visibilityrepptr   visibilityRepresentation;
	orthogonalrepptr   orthogonalRepresentation;
	int breite;

	klp = splitRelationIntoComponents (impl);
	if (klp) {

		kp = klp->zusammenhangskomponenten;
		while (kp) {
			KureRel * copy = kp->teilRelation;
			breite = kure_rel_get_cols_si (copy);
			//copyOfRel = get_rel (kp->teilRelation, rel->name);
			//breite = Kure_mp_mint2int (copyOfRel->breite);
			if (breite <= 4)
				/* Zeichenalgorithmus per Hand aufrufen */
				kp->teilGraph =	small_orthogonal_graph (kp->teilRelation, gridx, gridy, UNKNOWN_GRAPH_NAME);

			else {
				KureRel * planarRel = planar_greedy_subrelation (copy);

				/* Hier folgt der Algorithmus von Sascha Ulbrand zum planaren       */
				/* Testen und Berechnen der Einbettung                              */
				isPlanar (planarRel, 1);
				computeEmbedding ();
				stripEmbedding (copy);
				planarEmbedding = getEmbeddingInOrigNumbering ();
				/* Ende des Algorithmuses von Sascha Ulbrand */

				visibilityRepresentation = visibility_representation (planarEmbedding);
				orthogonalRepresentation = orthogonal_embedding (visibilityRepresentation, planarEmbedding);
				del_visibility_representation (visibilityRepresentation);

				transform_orthogonal_representation (orthogonalRepresentation);
				insert_nonplanar_edges_into_orthogonal (orthogonalRepresentation, planarEmbedding, copy);
				delAdjList (planarEmbedding);
				kp->teilGraph =	graph_create_orthogonal (orthogonalRepresentation, gridx, gridy,
						UNKNOWN_GRAPH_NAME);
				del_orthogonal_representation (orthogonalRepresentation);
			}
			kp = kp->next;
		}
	}
	resultat = MergeGraphsFromComponents (impl, klp);
	delKomponentenListe (klp);
	return (resultat);
}
