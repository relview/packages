#include <stdio.h>
#include <stdlib.h>

#include "global-sme.h"
#include "rank.h"

/* modulglobale Variablen */

static int * lim;
static int * low;
static int * mil;
static int * next;
static int * parent;
static int * vater;
static int * queue;
static int * tree;
static int anfang;
static int * son_count;
static int * nachf_anf;
static int * akt_nachf;
static int * soehne;
static int * cutv;
static int * In;
static int * Out;
static int * A_in;
static int * A_out;
static int Kantenzahl;
static int n  /* n = Knotenzahl */;
static int treesize;
static NODE * nodes;
static EDGE * edges;

/****************************************************************************/
/*  Zu Testzwecken                                                          */
/****************************************************************************/

void rank_ausdrucke ()
{
  int i;

  for (i = 0; i < n; i ++)
    printf ("Knoten %d hat rank %d\n", i, nodes [i].rank);
}

void baumausgabe ()
{
  int i;

  for (i = 0; i < n; i ++)
    printf ("%d<-%d  ", i, vater [i]);
  printf ("\n");
}

void graph_ausgabe ()
{
  int i;

  for (i = 0; i < Kantenzahl; i ++)
    printf ("Kante %d von %d nach %d\n", i, edges [i].tail, edges [i].head);
}

/* {
   int i;
   int j;
   for (i = 0; i < n; i ++) {
   printf ("In-Nachbarn von %d sind: \n", i);
   for (j = A_in [i]; j < A_in [i + 1]; j ++)
   printf ("%d  ", edges [In [j]].tail);
   printf ("\nOut-Nachbarn von %d sind: \n", i);
   for (j = A_out [i]; j < A_out [i + 1]; j ++)
   printf ("%d  ", edges [Out [j]].head);
   }
   } */

/****************************************************************************/
/* NAME: slack                                                              */
/* FUNKTION: berechnet Diff. zw. Laenge und Mindestlaenge einer Kante       */
/* UEBERGABEPARAMETER: e Kante                                              */
/* RUECKGABEWERT: die ber. Differenz                                        */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static int slack (int e)
{
  return (nodes [edges [e].head].rank - nodes [edges [e].tail].rank -
          edges [e].delta );
}



/****************************************************************************/
/* NAME: enqueue                                                            */
/* FUNKTION: ordnet alle Knoten in ein FIFO-Puffer                          */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static void enqueue ()
{
  int i;
  int flag;
  int zaehler = 0;
  int laeufer = 0;

  for (i = 0; i < n; i ++)
    nodes [i].status = 0;
  for (i = 0; i < Kantenzahl; i ++)
    edges [i].status = 0;
  queue = (int *) calloc (n, sizeof (int));
  if (queue == (int *) NULL)
    printf ("Zu wenig Speicherplatz\n");
  while (zaehler< n) {
    flag = 1;
    for (i = A_in [laeufer]; i < A_in [laeufer + 1]; i ++) {
      if (edges [In [i]].status == 0) {
        flag = 0;
        break;
      }
    }
    if (flag != 0) {
      queue [zaehler] = laeufer;
      nodes [laeufer].status = 1;
      for (i = A_out [laeufer]; i < A_out [laeufer + 1]; i ++)
        edges [Out [i]].status = 1;
      zaehler ++;
    }
    do
      laeufer = ++ laeufer % n;
    while (nodes [laeufer].status != 0 && zaehler < n);
  }
}

/****************************************************************************/
/* NAME: dequeue                                                            */
/* FUNKTION: ordnet den Knoten nach der Reihenf. in queue einen Rang zu     */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static void dequeue ()
{
  int i;
  int j;
  int max;

  for (i = 0; i < n; i ++) {
    max = 0;
    for (j = A_in [queue [i]]; j < A_in [queue [i] + 1]; j ++) {
      int temp;

      temp = nodes [edges [In [j]].tail].rank + edges [In [j]].delta;
      max = max > temp? max: temp;
    }
    nodes [queue [i]].rank = max;
  }
  free (queue);
}


/****************************************************************************/
/* NAME: einfuegen                                                          */
/* FUNKTION: fuegt die neu zu untersuchenden Kanten in die next-Liste ein   */
/* UEBERGABEPARAMETER: Anf Anfangsliste, Nachb Nachbarliste, status gibt    */
/*                     Richtung neuer Kante an, v_nontree neuer Knoten      */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 21.3.95                                             */
/****************************************************************************/
static void einfuegen (int * Anf, int * Nachb, int status, int v_nontree)
{
  int i;
  int tmp;

  for (i = Anf [v_nontree]; i < Anf [v_nontree + 1]; i ++) {
    if (edges [Nachb [i]].status == WEDER_NOCH) {
      tmp = next [anfang];
      next [anfang] = Nachb [i];
      edges [Nachb [i]].status = status;
      anfang = Nachb [i];
      next [anfang] = tmp;
    }
    else
      edges [Nachb [i]].status = WEDER_NOCH;
  }
}


/****************************************************************************/
/* NAME: tree_init                                                          */
/* FUNKTION: macht Baum mit einem Knoten                                    */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static void tree_init ()
{
  int i;

  for (i = 0; i < Kantenzahl; i ++)
    edges [i].status = WEDER_NOCH;
  for (i = 0; i < n; i ++)
    nodes [i].status = NOT_IN_TREE;
  tree [0] = 0;
  treesize = 1;
  nodes [0].status = IN_TREE;
  vater [0] = -1;
  parent [0] = -1;
  if (A_in [1] != 0)
    anfang = In [0];
  else
    anfang = Out [0];
  next [anfang] = anfang;
  edges [anfang].status = RAUS; /* egal ob REIN oder RAUS */
  einfuegen (A_in, In, REIN, 0);
  einfuegen (A_out, Out, RAUS, 0);
  if (A_in [1] != 0)
    edges [In [0]].status = REIN;
  else
    edges [Out [0]].status = RAUS;
}


/****************************************************************************/
/* NAME: inc_edge                                                           */
/* FUNKTION: findet Kante zwischen Baum und Rest mit min. slack             */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: Kante mit min. slack                                      */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 21.3.95                                             */
/****************************************************************************/
static int inc_edge ()
{
  int e;
  int res;
  int min;

  while (edges [anfang].status == WEDER_NOCH)
    anfang = next [anfang];
  e = anfang;
  res = anfang;
  min = slack (e);
  while (next [e] != anfang) {
    while (edges [next [e]].status == WEDER_NOCH)
      next [e] = next [next [e]];
    e = next [e];
    if (slack (e) < min) {
      res = e;
      min = slack (e);
    }
  }
  return (res);
}


/****************************************************************************/
/* NAME: tight_tree                                                         */
/* FUNKTION: findet Baum, so dass alle seine Kanten tight sind und der      */
/*           Baum feasible ranking induziert. Erstellt Listen parent        */
/*           und vater                                                      */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static void tight_tree ()
{
  int v;
  int delta;
  int e;
  int v_nontree;

  next = (int *) calloc (Kantenzahl, sizeof (int));
  if (next == (int *) NULL) {
    printf ("Zu wenig Speicherplatz\n");
    exit (0);
  }
  tree_init ();
  while (treesize < n) {
    e = inc_edge (treesize);
    delta = slack (e);
    delta = edges [e].status == RAUS? delta: -delta;
    for (v = 0; v < treesize; v ++)
      nodes [tree [v]].rank += delta;
    v_nontree = edges [e].status == RAUS? edges [e].head: edges [e].tail;
    nodes [v_nontree].status = IN_TREE;
    tree [treesize ++] = v_nontree;
    parent [v_nontree] = e;
    vater [v_nontree] =
      edges [e].status == RAUS? edges [e].tail: edges [e].head;
    if (treesize < n) {
      einfuegen (A_in, In, REIN, v_nontree);
      einfuegen (A_out, Out, RAUS, v_nontree);
    }
  }
  free (next);
}



/****************************************************************************/
/* NAME: mk_treelist                                                        */
/* FUNKTION: stellt den Baum in Form von Nachbarlisten dar                  */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static void mk_treelist ()
{
  int i;

  son_count = (int *) calloc (n + 1, sizeof (int));
  akt_nachf = (int *) calloc (n + 1, sizeof (int));
  if (son_count == (int *) NULL || akt_nachf == (int *) NULL) {
    printf ("Zu wenig Speicherplatz\n");
    exit (0);
  }
  for (i = 1; i < n; i ++)
    son_count [vater [i]] ++;
  nachf_anf [0] = 0;
  for (i = 1; i <= n; i ++) {
    nachf_anf [i] = nachf_anf [i - 1] + son_count [i - 1];
    akt_nachf [i] = nachf_anf [i];
  }
  for (i = 0; i < n; i ++)
    if (vater [i] != -1)
      soehne [akt_nachf [vater [i]] ++] = i;
  free (son_count);
  free (akt_nachf);
}

/****************************************************************************/
/* NAME: postorder                                                          */
/* FUNKTION: erstellt Listen lim,low; lim ist Numerierung der Knoten        */
/*           low gibt die kleinste Nummer eines Nachf. an                   */
/* UEBERGABEPARAMETER: root Knoten der numeriert werden soll                */
/*                     i naechste zu vergebende Nummer                      */
/* RUECKGABEWERT: naechste zu vergebende Nummer                             */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static int postorder (int root, int i)
{
  int j;
  int blatt = 1;

  for (j = nachf_anf [root]; j < nachf_anf [root + 1]; j ++) {
    i = postorder (soehne [j], i);
    blatt = 0;
  }
  lim [root] = i;
  mil [i] = root;
  if (blatt)
    low [root] = i;
  else
    low [root] = low [soehne [nachf_anf [root]]];
  return (i + 1);
}

/****************************************************************************/
/* NAME: pos                                                                */
/* FUNKTION: ber. Summe der Gewichte der Kanten, die von v in die v nicht   */
/*           enthaltende Zsh.komp.(beim Loeschen von e) geht                */
/* UEBERGABEPARAMETER: e Kante, v Knoten auf e                              */
/* RUECKGABEWERT: die berechnete Summe                                      */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static int pos (int e, int v)
{
  int res;
  int u;
  int dir;
  int i;
  int w;

  res = 0;
  u = edges [e].head == v? edges [e].tail: edges [e].head;
  dir = lim [u] > lim [v]? 1: 0;
  for (i = A_out [v]; i < A_out [v + 1]; i ++) {
    w = edges [Out [i]].head;
    if ((dir && (lim [w] < low [v] || lim [w] > lim [v]) && w !=u) ||
        (!dir && lim [w] >= low [u] && lim [w] < lim [u]))
      res += edges [Out [i]].weight;
  }
  return (res);
}

/****************************************************************************/
/* NAME: neg                                                                */
/* FUNKTION: Summe der Gew. der Kanten, die von der v nicht enthaltenden    */
/*           Zsh.komp nach v gehen (bei Loeschung von e)                    */
/* UEBERGABEPARAMETER: e Kante, v Knoten auf e                              */
/* RUECKGABEWERT: die berechnete Summe                                      */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static int neg (int e, int v)
{
  int res;
  int u;
  int dir;
  int i;
  int w;

  res = 0;
  u = edges [e].head == v? edges [e].tail: edges [e].head;
  dir = lim [u] > lim [v]? 1: 0;
  for (i = A_in [v]; i < A_in [v + 1]; i ++) {
    w = edges [In [i]].tail;
    if ((dir && (lim [w] < low [v] || lim [w] > lim [v]) && w !=u) ||
        (!dir && lim [w] >= low [u] && lim [w] < lim [u]))
      res += edges [In [i]].weight;
  }
  return (res);
}

/****************************************************************************/
/* NAME: cutvalue                                                           */
/* FUNKTION: berechnet Schnittwert einer Kante e, wenn von einem ihrer      */
/*           Knoten v die Schnittwerte aller anderen Kanten, die ihn        */
/*           enthalten, bekannt sind                                        */
/* UEBERGABEPARAMETER: e Kante, v Knoten wie unter FUNKTION                 */
/* RUECKGABEWERT: Schnittwert von e                                         */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static void cutvalue (int e, int v)
{
  int dir;
  int i;
  int e_i;
  int dir_i;

  dir = edges [e].tail == v? 1: -1;
  cutv [e] = pos (e, v) - neg (e, v);
  for (i = nachf_anf [v]; i < nachf_anf [v + 1]; i ++) {
    e_i = parent [soehne [i]];
    dir_i = edges [e_i].head == v? 1: -1;
    cutv [e] +=
      pos (e_i, v) - neg (e_i, v) + dir_i * (cutv [e_i] - edges [e_i].weight);
  }
  cutv [e] = edges [e].weight + dir * cutv [e];
}

/****************************************************************************/
/* NAME: init_cutvalues                                                     */
/* FUNKTION: berechnet die Schnittwerte des ersten Baumes                   */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.2.95                                                              */
/* LETZTE AENDERUNG AM: 27.2.95                                             */
/****************************************************************************/
static void init_cutvalues ()
{
  int i;

  for (i = 0; i < n - 1; i ++)
    cutvalue (parent [mil [i]], mil [i]);
}


/****************************************************************************/
/* NAME: feasible_tree                                                      */
/* FUNKTION: findet spannenden Baum, der feasible ranking induziert         */
/* UEBERGABEPARAMETER: vater1 Liste mit Vater des Knoten,                   */
/*                     parent1 Kante zwischen Knoten und seinem Vater       */
/*                     (steht nur was drin, wenn rank von position          */
/*                     aufgerufen wird)                                     */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.4.95                                                              */
/* LETZTE AENDERUNG AM: 24.4.95                                             */
/****************************************************************************/
static void feasible_tree (int * vater1, int * parent1)
{
  int i;
  int flag;
  int e;

  if (vater1 == (int *) NULL) {
    enqueue ();
    dequeue ();
    tight_tree ();
    flag = NO_INIT_RANKING; /* in tight_tree wird automatisch initiales */
  }                       /* ranking geliefert                       */
  else {
    free (vater);
    free (parent);
    vater = vater1;
    parent = parent1;
    flag = MK_INIT_RANKING;
  }
  mk_treelist ();
  (void) postorder (0, 0);
  if (flag == MK_INIT_RANKING) {
    nodes [0].rank = 0;
    for (i = n - 2; i >= 0; i --)
      nodes [mil [i]].rank = edges [parent [mil [i]]].head == mil [i]?
        nodes [vater [mil [i]]].rank + edges [parent [mil [i]]].delta:
      nodes [vater [mil [i]]].rank - edges [parent [mil [i]]].delta;
  }
  for (e = 0; e < Kantenzahl; e ++)
    if (slack (e) < 0) {
      printf ("Baum nicht feasible\n");
      exit (0);
    }

  init_cutvalues ();
}


/****************************************************************************/
/* NAME: leave_edge                                                         */
/* FUNKTION: findet Kante mit negativem Schnittwert                         */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 10.3.95                                                              */
/* LETZTE AENDERUNG AM: 10.3.95                                             */
/****************************************************************************/
static int leave_edge ()
{
  int laeufer;

  laeufer = (anfang + 1) % (n - 1);
  while (laeufer != anfang && cutv [parent [laeufer + 1]] >= 0)
    laeufer = ++ laeufer % (n - 1);
  anfang = laeufer;
  if (cutv [parent [laeufer + 1]] < 0)
    return (parent [laeufer + 1]);
  else
    return (FERTIG);
}


/****************************************************************************/
/* NAME: enter_edge                                                         */
/* FUNKTION: findet Kante mit min. slack, die von head-Komponente           */
/*           zu tail-Komponente von e geht                                  */
/* UEBERGABEPARAMETER: e die zu ersetzende Kante                            */
/* RUECKGABEWERT: die neue Kante                                            */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 10.3.95                                                              */
/* LETZTE AENDERUNG AM: 10.3.95                                             */
/****************************************************************************/
static int enter_edge (int e)
{
  int u, dir, min, res, i;
  dir = lim [edges [e].head] < lim [edges [e].tail]? DOWN: UP;
  u = dir == DOWN? edges [e].head: edges [e].tail;
  min = 1000;
  res = -1;
  if (dir == DOWN)
    for (i = 0; i < Kantenzahl; i ++)
      if (low [u] <= lim [edges [i].tail] &&
          lim [edges [i].tail] <= lim [u] &&
          !(low [u] <= lim [edges [i].head] &&
            lim [edges [i].head] <= lim [u]))
        if (slack (i) < min) {
          min = slack (i);
          res = i;
        }
  if (dir == UP)
    for (i = 0; i < Kantenzahl; i ++)
      if (low [u] <= lim [edges [i].head] &&
          lim [edges [i].head] <= lim [u] &&
          !(low [u] <= lim [edges [i].tail] &&
            lim [edges [i].tail] <= lim [u]))
        if (slack (i) < min) {
          min = slack (i);
          res = i;
        }
  return (res);
}



/****************************************************************************/
/* NAME: find_top                                                           */
/* FUNKTION: findet ersten gemeinsamen Vorgaenger von u und v im Baum       */
/* UEBERGABEPARAMETER: u, v Knoten                                          */
/* RUECKGABEWERT: der erste gemeinsame Vorgaenger von u und v               */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 21.3.95                                                              */
/* LETZTE AENDERUNG AM: 21.3.95                                             */
/****************************************************************************/
static int find_top (int u, int v)
{
  int top;
  int temp;

  if (lim [u] > lim [v]) {
    temp = u;
    u = v;
    v = temp;
  }
  top = u;
  while (lim [top] < lim [v])
    top = vater [top];
  return (top);
}


/****************************************************************************/
/* NAME: upd_tree                                                           */
/* FUNKTION: korrigiert Felder vater und parent                             */
/* UEBERGABEPARAMETER: e alte Kante, f neue Kante                           */
/* RUECKGABEWERT: der Knoten von f, der in der bot-Komponente               */
/*                von e liegt                                               */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 15.3.95                                                              */
/* LETZTE AENDERUNG AM: 21.3.95                                             */
/****************************************************************************/
static int upd_tree (int e, int f)
{
  int top;
  int bot;
  int u;
  int v;
  int node1;
  int node2;
  int node3;
  int edge1;
  int edge2;

  if (lim [edges [e].head] < lim [edges [e].tail]) {
    top = edges [e].tail;
    bot = edges [e].head;
  }
  else {
    top = edges [e].head;
    bot = edges [e].tail;
  }
  if (low [bot] <= lim [edges [f].tail] && lim [edges [f].tail] <= lim [bot]) {
    v = edges [f].tail;
    u = edges [f].head;
  }
  else {
    v = edges [f].head;
    u = edges [f].tail;
  }
  /* v liegt in der Zsh.-komp. in der auch bot liegt */
  node1 = u;
  edge1 = f;
  node2 = v;
  edge2 = parent [v];
  node3 = vater [v];
  while (node2 != top) {
    parent [node2] = edge1;
    vater [node2] = node1;
    node1 = node2;
    edge1 = edge2;
    node2 = node3;
    edge2 = parent [node2];
    node3 = vater [node2];
  }
  return (v);
}


/****************************************************************************/
/* NAME: part_list                                                          */
/* FUNKTION: erstellt Nachbarlisten fuer den Teilbaum mit Wurzel v          */
/* UEBERGABEPARAMETER: v Wurzel des Teilbaums                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.3.95                                                              */
/* LETZTE AENDERUNG AM: 20.3.95                                             */
/****************************************************************************/
/*
  static void part_list (int v)
  {
  int i;
  int m;

  m = lim [v] - low [v];
  son_count = (int *) calloc (m + 1, sizeof (int));
  akt_nachf = (int *) calloc (m + 2, sizeof (int));
  if (son_count == (int *) NULL || akt_nachf == (int *) NULL) {
  printf ("Fehler part_list\n");
  exit (0);
  }
  for (i = 0; i < m; i ++)
  son_count [lim [vater [mil [low [v] + i]]] - low [v]] ++;
  nachf_anf [0] = 0;
  for (i = 1; i <= m + 1; i ++) {
  nachf_anf [i] = nachf_anf [i - 1] + son_count [i - 1];
  akt_nachf [i - 1] = nachf_anf [i - 1];
  }
  for (i = 0; i < m; i ++)
  soehne [akt_nachf [lim [vater [mil [low [v] + i]]] - low [v]] ++] =
  mil [low [v] + i];
  free (son_count);
  free (akt_nachf);
  }
  */

/****************************************************************************/
/* NAME: part_postorder                                                     */
/* FUNKTION: korrigiert Listen lim, low im Teilbaum mit Wurzel root         */
/* UEBERGABEPARAMETER:root Wurzel des Teilbaumes, i naechste zu             */
/*                    vergebende Nummer, top Wurzel des Teilbaumes, in      */
/*                    dem ueberhaupt korr. werden muss                      */
/* RUECKGABEWERT: naechste zu vegebende Nummer                              */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.3.95                                                              */
/* LETZTE AENDERUNG AM: 20.3.95                                             */
/****************************************************************************/
/*
  static int part_postorder (int root, int i, int top)
  {
  int j, blatt;
  blatt = 1;
  for (j = nachf_anf [lim [root] - low [top]];
  j < nachf_anf [lim [root] - low [top] + 1];
  j ++)
  {
  i = part_postorder (soehne [j], i, top);
  blatt = 0;
  }
  lim [root] = i;
  mil [i] = root;
  if (blatt != 0)
  low [root] = i;
  else
  low [root] = low [soehne [nachf_anf [lim [root] - low [top]]]];
  return i + 1;
  }
  */

/****************************************************************************/
/* NAME: adjust_rank                                                        */
/* FUNKTION: korrigiert ranks der Knoten unterhalb u                        */
/* UEBERGABEPARAMETER: u Knoten                                             */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.3.95                                                              */
/* LETZTE AENDERUNG AM: 24.3.95                                             */
/****************************************************************************/
static void adjust_rank (int u)
{
  int i;
  int delta;

  for (i = lim [u]; i >= low [u]; i --) {
    delta = edges [parent [mil [i]]].head == mil [i]?
      edges [parent [mil [i]]].delta: -edges [parent [mil [i]]].delta;
    nodes [mil [i]].rank = nodes [vater [mil [i]]].rank + delta;
  }
}


/****************************************************************************/
/* NAME: cutv_p                                                             */
/* FUNKTION: berechnet Schnittwert von Kante e, wenn Schnittwerte aller     */
/*           anderen Kanten, die Knoten v auf e enthalten, bekannt sind     */
/* UEBERGABEPARAMETER: e Kante, v Knoten, top Wurzel des Teilbaumes         */
/*                     in dem die postorder-Parameter geaendert wurden      */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 21.3.95                                                              */
/* LETZTE AENDERUNG AM: 21.3.95                                             */
/****************************************************************************/
/*
  static void cutv_p (int e, int v, int top)
  {
  int dir, i, e_i,dir_i;
  dir = edges [e].tail == v? 1: -1;
  cutv [e] = pos (e, v) - neg (e, v);
  for (i = nachf_anf [lim [v] - low [top]];
  i < nachf_anf [lim [v] - low [top] + 1]; i ++)
  {
  e_i = parent [soehne [i]];
  dir_i = edges [e_i].head == v? 1: -1;
  cutv [e] += pos (e_i, v) - neg (e_i, v) + dir_i * (cutv [e_i] -
  edges [e_i].weight);
  }
  cutv [e] = edges [e].weight + dir * cutv [e];
  }
  */

/****************************************************************************/
/* NAME: part_cutvalues                                                     */
/* FUNKTION: korrigiert Schnittwerte auf dem Pfad der die beiden Knoten     */
/*           der neuen Kante in dem alten Baum verbindet und den            */
/*           Schnittwert der neuen Kante selbst                             */
/* UEBERGABEPARAMETER: e alte Kante, top erster geneinsamer Vorfahre        */
/*                     der beiden Knoten der neuen Kante                    */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 21.3.95                                                              */
/* LETZTE AENDERUNG AM: 21.3.95                                             */
/****************************************************************************/
/*
  static void part_cutvalues (int e, int top)
  {
  int v;
  v = lim [edges [e].tail] > lim [edges [e].head]? edges [e].head
  : edges [e].tail;
  while (v != top)
  {
  cutv_p (parent [v], v, top);
  v = vater [v];
  }
  v = lim [edges [e].tail] < lim [edges [e].head]? edges [e].head
  : edges [e].tail;
  while (v != top)
  {
  cutv_p (parent [v], v, top);
  v = vater [v];
  }
  }
  */

/****************************************************************************/
/* NAME: part_cut                                                           */
/* FUNKTION: korrigiert Schnittwerte auf dem Pfad der die beiden Knoten     */
/*           der neuen Kante in dem alten Baum verbindet und den            */
/*           Schnittwert der neuen Kante selbst                             */
/* UEBERGABEPARAMETER: e alte Kante, top erster geneinsamer Vorfahre        */
/*                     der beiden Knoten der neuen Kante                    */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.5.95                                                              */
/* LETZTE AENDERUNG AM: 17.5.95                                             */
/****************************************************************************/
static void part_cut (int e, int top)
{
  int v;

  v = edges [e].head;
  while (v != top) {
    cutvalue (parent [v], v);
    v = vater [v];
  }
  v = edges [e].tail;
  while (v != top) {
    cutvalue (parent [v], v);
    v = vater [v];
  }
}


/****************************************************************************/
/* NAME: exchange                                                           */
/* FUNKTION: tauscht alte Kante gegen neue aus und passt Werte wie          */
/*           lim, low, cutv ... an                                          */
/* UEBERGABEPARAMETER: e alte Kante, f neue Kante                           */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 21.3.95                                                              */
/* LETZTE AENDERUNG AM: 21.3.95                                             */
/****************************************************************************/
static void exchange (int e, int f)
{
  int top;
  int u;
  /* int i,j, v, t; */
  /* static int c = 0; */

  top = find_top (edges [f].tail, edges [f].head);
  u = upd_tree (e, f);  /* bei Nachf. von u muss rank geaendert werden */
  /*
    c++;
    part_list (top);
    (void) part_postorder (top,low [top], top);
    */
  /* Baumtest */
  /*
    for (i = 0; i < n; i ++)
    {
    v=i;
    t = 0;
    while (vater [v] >= 0 && t< n + 1)
    {
    v=vater [v];
    t ++;
    }
    if (v != 0)
    {
    printf ("Baum Scheisse bei Durchlauf %d\n",c);
    exit (0);
    }
    }
    adjust_rank (u);
    part_list (top);
    for (i = lim [top]; i >= low [top]; i --)
    {
    printf ("soehne von %d:\n", mil [i]);
    for (j = nachf_anf [i - low [top]]; j < nachf_anf [i - low [top] + 1];
    j ++)
    printf ("%d  ", soehne [j]);
    printf ("\n");
    }
    part_cutvalues (e, top);
    */
  /* noch eine Version */

  mk_treelist ();
  (void) postorder (0, 0);
  adjust_rank (u);
  part_cut (e, top);
}

/****************************************************************************/
/* NAME: normalize                                                          */
/* FUNKTION: setzt kleinsten rank auf Null                                  */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: .23.3.95                                                             */
/* LETZTE AENDERUNG AM: 23.3.95                                             */
/****************************************************************************/
static void normalize ()
{
  int min_rank;
  int i;

  min_rank = 1000;
  for (i = 0; i < n; i ++)
    if (nodes [i].rank < min_rank)
      min_rank = nodes [i].rank;
  if (min_rank != 0)
    for (i = 0; i < n; i ++)
      nodes [i].rank -= min_rank;
}


/****************************************************************************/
/* NAME: best_rank                                                          */
/* FUNKTION: hat ein Knoten verschiedene moegliche ranks, so wird           */
/*           er auf den level mit den wenigsten Knoten gesetzt              */
/* UEBERGABEPARAMETER: i Knoten, rank_count Liste in der steht wie          */
/*                     viele Knoten auf jedem level liegen                  */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.3.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static void best_rank (int i, int * rank_count)
{
  int j;
  int temp;
  int up_slack;
  int down_slack;
  int rank;

  up_slack = VERY_BIG;
  for (j = A_in [i]; j < A_in [i + 1]; j ++)
    if ((temp = slack (In [j])) < up_slack)
      up_slack = temp;
  if (up_slack == VERY_BIG)
    up_slack = 0;
  down_slack = VERY_BIG;
  for (j = A_out [i]; j < A_out [i + 1]; j ++)
    if ((temp = slack (Out [j])) < down_slack)
      down_slack = temp;
  if (down_slack == VERY_BIG)
    down_slack = 0;
  rank = nodes [i].rank;
  for (j = rank - up_slack; j <= rank + down_slack; j ++)
    if (rank_count [j] < rank_count [nodes [i].rank]) {
      rank_count [nodes [i].rank] --;
      rank_count [j] ++;
      nodes [i].rank = j;
    }
}


/****************************************************************************/
/* NAME: balance                                                            */
/* FUNKTION: verteilt die Knoten gleichmaessiger auf die level              */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 23.3.95                                                              */
/* LETZTE AENDERUNG AM: 23.3.95                                             */
/****************************************************************************/
static void balance ()
{
  int i;
  int j;
  int in_sum;
  int out_sum;
  int * rank_count;

  rank_count = (int *) calloc (n, sizeof (int));
  if (rank_count == (int *) NULL) {
    printf ("Zu wenig Speicherplatz\n");
    exit (0);
  }
  for (i = 0; i < n; i ++)
    rank_count [nodes [i].rank] ++;
  for (i = 1; i < n; i ++) {
    in_sum = 0;
    out_sum = 0;
    for (j = A_in [i]; j < A_in [i + 1]; j ++)
      in_sum += edges [In [j]].weight;
    for (j = A_out [i]; j < A_out [i + 1]; j ++)
      out_sum += edges [Out [j]].weight;
    if (in_sum == out_sum)
      best_rank (i, rank_count);
  }
  free (rank_count);
}

/****************************************************************************/
/* NAME: set_list                                                           */
/* FUNKTION: belegt/reserviert Speicherplatz fuer die modulglobalen         */
/*           Felder                                                         */
/* UEBERGABEPARAMETER: die Listen, die den Graphen darstellen und die       */
/*                     Anzahl der Kanten und Knoten                         */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.3.95                                                              */
/* LETZTE AENDERUNG AM: 11.7.95                                             */
/****************************************************************************/
static void set_list (int * A_in1, int * A_out1, int * In1, int * Out1,
                      EDGE * Kanten, NODE * Knoten, int Kanz, int Knoz)
{
  A_in = A_in1;
  A_out = A_out1;
  In = In1;
  Out = Out1;
  n = Knoz;
  Kantenzahl = Kanz;
  edges = Kanten;
  nodes = Knoten;
  lim = (int *) calloc (n, sizeof (int));
  low = (int *) calloc (n, sizeof (int));
  mil = (int *) calloc (n, sizeof (int));
  vater = (int *) calloc (n, sizeof (int));
  parent = (int *) calloc (n, sizeof (int));
  tree = (int *) calloc (n, sizeof (int));
  soehne = (int *) calloc (n, sizeof (int));
  cutv = (int *) calloc (Kantenzahl, sizeof (int));
  nachf_anf = (int *) calloc (n + 1, sizeof (int));

  if (lim == (int *) NULL || low == (int *) NULL || mil == (int *) NULL ||
      parent == (int *) NULL || vater == NULL || tree == (int *) NULL ||
      soehne == (int *) NULL || cutv == (int *) NULL ||
      nachf_anf == (int *) NULL) {
    printf ("Zu wenig Speicherplatz\n");
    exit (0);
  }
}

/****************************************************************************/
/* NAME: free_temp_list                                                     */
/* FUNKTION: gibt den fuer die Hilfslisten reservierten Speicherplatz       */
/*           wieder frei                                                    */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.3.95                                                              */
/* LETZTE AENDERUNG AM: 11.7.95                                             */
/****************************************************************************/
static void free_temp_list ()
{
  free (lim);
  free (low);
  free (mil);
  free (vater);
  free (parent);
  free (tree);
  free (soehne);
  free (cutv);
  free (nachf_anf);
}


/****************************************************************************/
/* NAME: rank                                                               */
/* FUNKTION: findet optimales ranking                                       */
/* UEBERGABEPARAMETER: die Listen, die den Graphen darstellen und die       */
/*                     Anzahl der Kanten und Knoten, vater1 der vater       */
/*                     jedes Knoten, parent die Kante zwischen Knoten       */
/*                     und seinem vater                                     */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 10.3.95                                                              */
/* LETZTE AENDERUNG AM: 10.3.95                                             */
/****************************************************************************/
void rank (int * A_in1, int * A_out1, int * In1, int * Out1, EDGE * Kanten,
           NODE * Knoten, int Kanz, int Knoz, int * vater1, int * parent1)
{
  int e;
  int f;

  set_list (A_in1, A_out1, In1, Out1, Kanten, Knoten, Kanz, Knoz);
  feasible_tree (vater1, parent1);
  anfang = 0;
  while ((e = leave_edge ()) != FERTIG) {
    f = enter_edge (e);
    exchange (e, f);
  }
  normalize ();
  balance ();
  free_temp_list ();
}
