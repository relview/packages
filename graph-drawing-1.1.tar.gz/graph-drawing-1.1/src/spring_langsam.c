#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global-sme.h"
#include "spring_langsam.h"
#include "zerlegen.h"

/* modulglobale Variablen */

static S_EDGE * edges;
static S_NODE * nodes;
static S_GRAPH * Komponenten;
static Fl_Matrix spring_constant;
static Fl_Matrix distance;
static int width;
static int height;
static int min_x;
static int max_x;
static int min_y;
static int max_y;
static int n;
static int Kantenzahl;
static int alt_n;
static int alt_Kanz; /* n Knotenzahl */
static int * x_max_Knoten;
static int * y_max_Knoten;
static int total_width;
static int total_height;
static int double_count;
static int Komponentenabstand;
static int Komponentenzahl;
static float * Kantenlaenge;
static int gew_Kantenlaenge;
static int temperatur;



/****************************************************************************/
/* NAME: make_graph_langsam                                                 */
/* FUNKTION: liest Relation und erstellt daraus Kantenliste                 */
/* UEBERGABEPARAMETER: name Name der Relation                               */
/*                      edges Kantenliste (wird hier initialisiert)         */
/*                      n Knotenzahl, Kanz Kantenzahl                       */
/* RUECKGABEWERT: Anzahl der Kanten, die hin und her gehen                  */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 05.05.95                                                             */
/* LETZTE AENDERUNG AM:05.05.95                                             */
/****************************************************************************/
int make_graph_langsam (KureRel * impl, S_EDGE ** edges, int * n, int * Kanz)
{
	int lines = kure_rel_get_rows_si (impl);
	int columns = kure_rel_get_cols_si (impl);
	int i;
	int j;
	int aktuell;
	int double_count = 0;
	int vars_zeilen = kure_rel_get_vars_rows (impl);
	int vars_spalten = kure_rel_get_vars_cols (impl);

	g_assert (kure_is_hom (impl, NULL));

	* n = lines;
	* Kanz = 0;
	for (i = 0; i < lines; i ++)
		for (j = 0; j <= i; j ++)
			if (kure_get_bit_fast_si(impl, i,j, vars_zeilen, vars_spalten)
					|| kure_get_bit_fast_si (impl, j,i, vars_zeilen, vars_spalten))
			//if (get_rel_bit (rel, j, i, vars_zeilen, vars_spalten) != 0
			//		|| get_rel_bit (rel, i, j, vars_zeilen, vars_spalten)  != 0)
				(* Kanz) ++;

	* edges = (S_EDGE *) calloc (* Kanz, sizeof (S_EDGE));

	aktuell = 0;
	for (i = 0; i < lines; i ++)
		for (j = 0; j < i; j ++)
			if (kure_get_bit_fast_si (impl, i,j, vars_zeilen, vars_spalten)) {
			//if (get_rel_bit (rel, j, i, vars_zeilen, vars_spalten) != 0) {
				(* edges) [aktuell].tail = i;
				(* edges) [aktuell].head = j;
				if (kure_get_bit_fast_si (impl, j,i, vars_zeilen, vars_spalten)) {
				//if (get_rel_bit (rel, i, j, vars_zeilen, vars_spalten) != 0) {
					(* edges) [aktuell ++].back_and_forth = TRUE;
					double_count ++;
				} else
					(* edges) [aktuell ++].back_and_forth = FALSE;
			} else
				if (kure_get_bit_fast_si (impl, j,i, vars_zeilen, vars_spalten)) {
				//if (get_rel_bit (rel, i, j, vars_zeilen, vars_spalten) != 0) {
				(* edges) [aktuell].back_and_forth = FALSE;
				(* edges) [aktuell].tail = j;
				(* edges) [aktuell ++].head = i;
			}

	for (i = 0; i < lines; i ++)
		if (kure_get_bit_fast_si (impl, i,i, vars_zeilen, vars_spalten)) {
		//if (get_rel_bit (rel, i, i, vars_zeilen, vars_spalten) != 0) {
			(* edges) [aktuell].tail = i;
			(* edges) [aktuell].head = i;
			(* edges) [aktuell ++].back_and_forth = FALSE;
		}
	/* return double_count; */

	return (double_count);
}

/****************************************************************************/
/* NAME: spring_langsam                                                     */
/* FUNKTION: berechnet Koordinaten fuer die Knoten                          */
/* UEBERGABEPARAMETER: rel Name der Relation, breite und hoehe des Fensters */
/* RUECKGABEWERT: Zeiger auf Graphen                                        */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 4.7.95                                                               */
/* LETZTE AENDERUNG AM: 4.7.95                                              */
/****************************************************************************/
graphlistptr spring_langsam (KureRel * impl, int breite, int hoehe)
{
	int i;
	graphlistptr gl;

	set_glob_var ();
	double_count = make_graph_langsam (impl, & edges, & n, & Kantenzahl);
	alt_n = n;
	/* urspruengliche Knotenzahl und */
	alt_Kanz = Kantenzahl;
	/* Kantenzahl aufbewahren */
	zerlegen_spring (n, Kantenzahl, edges, & Komponenten, & Komponentenzahl);
	alloc_max_array ();
	free (edges);
	for (i = 0; i < Komponentenzahl; i ++) {
		n = Komponenten [i].node_count;
		Kantenzahl = Komponenten [i].edge_count;
		edges = Komponenten [i].edges;
		spring_komp (i);
		turn ();
		Komponenten [i].nodes = nodes;
	}

	Komponenten_sort ();
	abs_coord (breite, hoehe);
	gl = spring_langsam_to_graph (impl);
	free_glob ();

	return (gl);
}

/****************************************************************************/
/* NAME: spring_komp                                                       */
/* FUNKTION: berechnet Koordinaten fuer eine Komponente                    */
/* UEBERGABEPARAMETER: nr Nr. der Komponente                               */
/* RUECKGABEWERT:                                                          */
/* ERSTELLT VON: Stefan Meier                                              */
/* AM: 17.6.95                                                             */
/* LETZTE AENDERUNG AM: 22.6.95                                            */
/****************************************************************************/
static void spring_komp (int nr)
{
  int i = 0;
  int j = 0;
  int i_max = 0;
  int d_max = 0;
  int count = 0;
  int count_aussen = 0;
  int count_ges = 0;
  float Length = .0f;
  float delta_max = .0f;

  alloc_nodes ();
  if (n == 1) {
    nodes [0].x_pos = 0;
    nodes [0].y_pos = 0;
    Kantenlaenge [nr] = 0;
  } else {
    spring_constant = (Fl_Matrix) calloc (n, sizeof (float *));
    distance = (Fl_Matrix) calloc (n, sizeof (float *));
    if (spring_constant == NULL) {
      printf ("Fehler spring\n");
      exit (0);
    }
    for (i = 0; i < n; i ++) {
      spring_constant [i] = (float *) calloc (n, sizeof (float));
      distance [i] = (float *) calloc (n, sizeof (float));
      if (spring_constant [i] == NULL || distance [i] == NULL) {
        printf ("Fehler spring\n");
        exit (0);
      }
    }
    Length = 1000;
    /* im Original-Algorithmus Laenge einer Fensterseite */
    d_max = find_path (distance);
    Length /= d_max;
    Kantenlaenge [nr] = Length;
    for (i = 0; i < n; i ++)
      for (j = 0; j < i; j ++) {
        spring_constant [i][j]
          = 1 / (float) (distance [i][j] * distance [i][j]);
        spring_constant [j][i] = spring_constant [i][j];
        distance [i][j] *= Length;
        distance [j][i] = distance [i][j];
      }

    initial_positions (nodes, n);

    count_aussen = 0;
    count_ges = 0;
    count = 0;
    delta_max = find_max (& i_max);
    while (delta_max > epsilon) {
      count_aussen ++;
      count = 0;
      while (delta_max > epsilon) {
        if (count > 100) {
          move (i_max);
	  /*
            printf ("Zu viele Iterationen (100), move () ausgefuehrt\n");
	  */
          break;
	}
        delta_max = part_min (i_max);
        count ++;
        count_ges ++;
      }
      delta_max = find_max (& i_max);

      if (count_ges > 5000) {
        spring (nr);
        break;
      }
    }
    /*
      printf ("count %d aussen %d gesamt %d\n",count,count_aussen,count_ges);
    */
    for (i = 0; i < n; i ++) {
      free (distance [i]);
      free (spring_constant [i]);
    }
    free (distance);
    free (spring_constant);
  }
}

/****************************************************************************/
/* NAME: alloc_nodes                                                        */
/* FUNKTION: reserviert Speicherplatz fuer Knoten                           */
/* UEBERGABEPARAMETER:                                                      */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 15.6.95                                                              */
/* LETZTE AENDERUNG AM: 15.6.95                                             */
/****************************************************************************/
static void alloc_nodes ()
{
  nodes = (S_NODE *) calloc (n, sizeof (S_NODE));
  if (nodes == NULL) {
    printf ("Fehler make_graph_list\n");
    exit (0);
  }
}


/****************************************************************************/
/* NAME: find_path                                                          */
/* FUNKTION: findet die Laenge der kuerzesten Pfade zwischen den Knoten     */
/* UEBERGABEPARAMETER: mat_0 Matrix in die die Pfadlaengen eingetragen      */
/*                     werden (float Matrix weil die Eintraege spaeter      */
/*                     noch mit einem Faktor mult. werden)                  */
/* RUECKGABEWERT: Laenge des laengsten Pfades                               */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 16.6.95                                                              */
/* LETZTE AENDERUNG AM: 16.6.95                                             */
/****************************************************************************/
static int find_path (Fl_Matrix mat_0)
{
  int k;
  int i;
  int j;
  int max;
  Fl_Matrix temp;
  Fl_Matrix mat_1;

  mat_1 = (Fl_Matrix) calloc (n, sizeof (float *));

  if (mat_1 == NULL) {
    printf ("Fehler find_path\n");
    exit (0);
  }

  for (i = 0; i < n; i ++) {
    mat_1 [i] = (float *) calloc (n, sizeof (float));
    if (mat_1 [i] == NULL) {
      printf ("Fehler find_path\n");
      exit (0);
    }
  }
  /* Initialisierung der Kostenmatrix */
  if (n % 2 != 0) {
    temp = mat_0;
    mat_0 = mat_1;
    mat_1 = temp;
  }
  for (i = 0; i < Kantenzahl; i ++)
    if (edges [i].tail != edges [i].head) {
      mat_0 [edges [i].head][edges [i].tail] = 1;
      mat_0 [edges [i].tail][edges [i].head] = 1;
    }
  for (i = 0; i < n; i ++)
    for (j = 0; j < n; j ++)
      if (i != j && mat_0 [i][j] == 0)
        mat_0 [i][j] = VERY_BIG;

  for (k = 1; k <= n; k ++) {
    temp = mat_0;
    mat_0 = mat_1;
    mat_1 = temp;
    for (i = 0; i < n; i ++)
      for (j = 0; j < n; j ++)
        mat_0 [i][j] = Min (mat_1 [i][j], mat_1 [i][k - 1] + mat_1 [k - 1][j]);
  }
  max = 0;
  for (i = 0; i < n; i ++)
    for (j = 0; j < i; j ++)
      max = Max (max, mat_0 [i][j]);
  for (i = 0; i < n; i ++)
    free (mat_1 [i]);
  free (mat_1);
  return max;
}


/****************************************************************************/
/* NAME: find_max                                                           */
/* FUNKTION: findet den Knoten mit dem groessten delta                      */
/* UEBERGABEPARAMETER: in max_ptr wird Zeiger auf diesen Knoten             */
/*                     zurueckgegeben                                       */
/* RUECKGABEWERT: groesster delta_Wert                                      */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.6.95                                                              */
/* LETZTE AENDERUNG AM: 17.6.95                                             */
/****************************************************************************/
static float find_max (int * max_ptr)
{
  float max;
  float temp;
  float dx;
  float dy;
  int m;

  max = 0;
  for (m = 0; m < n; m ++) {
    dx = partd (m, 'x');
    dy = partd (m, 'y');
    temp = sqrt (dx * dx + dy * dy);
    if (temp > max) {
      max = temp;
      * max_ptr = m;
    }
  }
  return max;
}



/****************************************************************************/
/* NAME: part_min                                                           */
/* FUNKTION: berechnet ein Minimum der Energiefkt. nur abh. von             */
/*           x_m und y_m (d.h. fuehrt jeweils eine Iteration                */
/*           dieser Berechnung durch                                        */
/* UEBERGABEPARAMETER: int m                                                */
/* RUECKGABEWERT: neues delta                                               */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.6.95                                                              */
/* LETZTE AENDERUNG AM: 17.6.95                                             */
/****************************************************************************/
static float part_min (int m)
{
  float delta_x;
  float delta_y;
  float d_x;
  float d_y;
  float d_x2;
  float d_y2;
  float d_xy;

  d_x2 = partd_2 (m, 'x');
  d_y2 = partd_2 (m, 'y');
  d_xy = partd_xy (m);
  d_x = partd (m, 'x');
  d_y = partd (m, 'y');

  /*
    delta_y = (d_x2 * d_y - d_x * d_xy) / (d_xy * d_xy - d_x2 * d_y2);
    delta_x = (-d_x - d_xy * delta_y) / d_x2;
  */

  if (d_xy * d_xy - d_x2 * d_y2 == 0 || d_x2 == 0) {
    delta_y = -4;
    delta_x = 6;
  } else {
    delta_y = (d_x2 * d_y - d_x * d_xy) / (d_xy * d_xy - d_x2 * d_y2);
    delta_x = (-d_x - d_xy * delta_y) / d_x2;
  }

  nodes [m].x_pos += delta_x;
  nodes [m].y_pos += delta_y;
  d_x = partd (m, 'x');
  d_y = partd (m, 'y');
  return sqrt (d_x * d_x + d_y * d_y);
}



/****************************************************************************/
/* NAME: partd                                                              */
/* FUNKTION: berechnet eine partielle Ableitung                             */
/* UEBERGABEPARAMETER: m Knoten, coord x- oder y- Koordinate                */
/* RUECKGABEWERT: der berechnete Wert                                       */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 18.6.95                                                              */
/* LETZTE AENDERUNG AM: 18.6.95                                             */
/****************************************************************************/
static float partd (int m, char coord)
{
  float d_1;
  float d_2;
  float d;
  int i;

  d = 0;
  for (i = 0; i < n; i ++)
    if (m != i) {
      if (coord == 'x') {
        d_1 = nodes [m].x_pos - nodes [i].x_pos;
        d_2 = nodes [m].y_pos - nodes [i].y_pos;
      } else {
        d_2 = nodes [m].x_pos - nodes [i].x_pos;
        d_1 = nodes [m].y_pos - nodes [i].y_pos;
      }
      d += spring_constant [m][i] * (d_1 - distance [m][i] * d_1 /
                                     sqrt (d_1 * d_1 + d_2 * d_2));
    }
  return d;
}


/****************************************************************************/
/* NAME: partd_2                                                            */
/* FUNKTION: berechnet eine partielle Ableitung                             */
/* UEBERGABEPARAMETER: m Knoten, coord x- oder y- Koordinate                */
/* RUECKGABEWERT: der berechnete Wert                                       */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 18.6.95                                                              */
/* LETZTE AENDERUNG AM: 18.6.95                                             */
/****************************************************************************/
static float partd_2 (int m, char coord)
{
  float d_1;
  float d_2;
  float d;
  int i;

  d = 0;
  for (i = 0; i < n; i ++)
    if (m != i) {
      if (coord == 'x') {
        d_1 = nodes [m].x_pos - nodes [i].x_pos;
        d_2 = nodes [m].y_pos - nodes [i].y_pos;
      } else {
        d_2 = nodes [m].x_pos - nodes [i].x_pos;
        d_1 = nodes [m].y_pos - nodes [i].y_pos;
      }
      d += spring_constant [m][i] * (1 - distance [m][i] * d_2 * d_2 /
                                     sqrt (pow (d_1 * d_1 + d_2 * d_2, 3)));
    }
  return d;
}

/****************************************************************************/
/* NAME: partd_xy                                                           */
/* FUNKTION: berechnet eine partielle Ableitung                             */
/* UEBERGABEPARAMETER: m Knoten                                             */
/* RUECKGABEWERT: der berechnete Wert                                       */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 18.6.95                                                              */
/* LETZTE AENDERUNG AM: 18.6.95                                             */
/****************************************************************************/
static float partd_xy (int m)
{
  float d_1;
  float d_2;
  float d;
  int i;

  d = 0;
  for (i = 0; i < n; i ++)
    if (m != i) {
      d_1 = nodes [m].x_pos - nodes [i].x_pos;
      d_2 = nodes [m].y_pos - nodes [i].y_pos;
      d += spring_constant [m][i] * (distance [m][i] * d_1 * d_2 /
                                     sqrt (pow (d_1 * d_1 + d_2 * d_2, 3)));
    }
  return d;
}


/****************************************************************************/
/* NAME: abs_coord                                                          */
/* FUNKTION: berechnet die absoluten Koordinaten der Knoten                 */
/* UEBERGABEPARAMETER: breite und hoehe des Fensters                        */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 22.6.95                                                              */
/* LETZTE AENDERUNG AM: 22.6.95                                             */
/****************************************************************************/
static void abs_coord (int breite, int hoehe)
{
  int i;
  int k;
  int j;
  float temp;
  float faktor;
  S_NODE * nodes;
  int n;

  gew_Kantenlaenge = MIN_KANTENLAENGE;
  Komponentenabstand = gew_Kantenlaenge;
  total_width = 0;
  total_height = 0;

  for (i = 0; i < Komponentenzahl; i ++) {
    nodes = Komponenten [i].nodes;
    n = Komponenten [i].node_count;
    enlarge (i);
    temp = nodes [x_max_Knoten [i]].x_pos;
    for (j = 0; j < n; j ++) {
      nodes [j].x_pos += total_width;
    }

    total_width += temp + Komponentenabstand;
    total_height = Max (total_height, nodes [y_max_Knoten [i]].y_pos);
  }
  total_width -= Komponentenabstand;

  faktor = Min ((float) breite / total_width, (float) hoehe / total_height);

  for (k = 0; k < Komponentenzahl; k ++)
    for (i = 0; i < Komponenten [k].node_count; i ++) {
      Komponenten [k].nodes [i].x_pos *= faktor;
      Komponenten [k].nodes [i].y_pos *= faktor;
    }
}


/****************************************************************************/
/* NAME: enlarge                                                            */
/* FUNKTION: bringt den Teilgraphen auf richtige Groesse                    */
/* UEBERGABEPARAMETER: nr Nummer der Zush.-Komponente                       */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 22.6.95                                                              */
/* LETZTE AENDERUNG AM: 22.6.95                                             */
/****************************************************************************/
static void enlarge (int nr)
{
  int i;
  float x_min;
  float x_max;
  float y_min;
  float y_max;
  float faktor;
  float displacement;
  S_NODE * nodes;

  nodes = Komponenten [nr].nodes;
  n = Komponenten [nr].node_count;
  x_min = nodes [0].x_pos;
  y_min = nodes [0].y_pos;
  x_max_Knoten [nr] = 0;
  y_max_Knoten [nr] = 0;

  for (i = 1; i < Komponenten [nr].node_count; i ++) {
    if (nodes [i].x_pos < x_min)
      x_min = nodes [i].x_pos;
    else if (nodes [i].x_pos > nodes [x_max_Knoten [nr]].x_pos)
      x_max_Knoten [nr] = i;
    if (nodes [i].y_pos < y_min)
      y_min = nodes [i].y_pos;
    else if (nodes [i].y_pos > nodes [y_max_Knoten [nr]].y_pos)
      y_max_Knoten [nr] = i;
  }
  x_max = nodes [x_max_Knoten [nr]].x_pos;
  y_max = nodes [y_max_Knoten [nr]].y_pos;

  /* x_max, x_min usw. sind die tatsechlich vorkommenden minimalen bzw. */
  /* maximalen Werte der X- bzw. Y-Koorkinaten */

  if (Kantenlaenge [nr] > 0)
    faktor = gew_Kantenlaenge / Kantenlaenge [nr];
  else
    faktor = 1;
  displacement = x_min * faktor;
  for (i = 0; i < n; i ++)
    nodes [i].x_pos = (nodes [i].x_pos * faktor) - displacement;
  displacement = y_min * faktor;
  for (i = 0; i < n; i ++)
    nodes [i].y_pos = (nodes [i].y_pos * faktor) - displacement;
}

/****************************************************************************/
/* NAME: set_glob_var                                                       */
/* FUNKTION: initialisiert globale Variablen                                */
/* UEBERGABEPARAMETER:                                                      */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 22.6.95                                                              */
/* LETZTE AENDERUNG AM: 22.6.95                                             */
/****************************************************************************/
static void set_glob_var ()
{
  width = 1000;
  height = 1000;
  min_x = RAND;
  max_x = width - RAND;
  min_y = RAND;
  max_y = height - RAND;

  gew_Kantenlaenge = MIN_KANTENLAENGE;
  Komponentenabstand = KOMPONENTENABSTAND;
}

/****************************************************************************/
/* NAME: spring                                                             */
/* FUNKTION: berechnet Positionen mit schnellem spring-embedder             */
/* UEBERGABEPARAMETER: nr Nr. der Komponente                                */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 28.6.95                                                              */
/* LETZTE AENDERUNG AM: 24.06.98 (CTRL-C Abbruch)                           */
/****************************************************************************/
static void spring (int nr)
{
  int i;
  int area;
  float k;

  area = AREA;
  k = sqrt (area / n);
  Kantenlaenge [nr] = k;

  initial_positions (nodes, n);
  temperatur = INIT_TEMP;

  for (i = 0; (i < ITERATIONS); i ++) {

      repulsive (nodes, n, k);
    /* Abstossungskraefte berechnen */

      attraktive (nodes, edges, Kantenzahl);
    /* Anziehungskraefte berechnen */

      limit (temperatur, nodes, n);
    /* displacement auf Grenzueberschr. pruefen */

      temperatur = cool (temperatur,i);

  }
}

/****************************************************************************/
/* NAME: initial_positions                                                  */
/* FUNKTION: berechnet eine initiale Verteilung der Knoten                  */
/* UEBERGABEPARAMETER: nodes Knoten, n Kantenzahl                           */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 15.6.95                                                              */
/* LETZTE AENDERUNG AM: 11.7.95                                             */
/****************************************************************************/
static void initial_positions (S_NODE * nodes, int n)
{
  int v;
  int x;
  int y;
  int d;

  d = 1000 / sqrt (n);
  v = 0;
  y = 0;
  x = 0;
  while (v < n) {
    nodes [v].x_pos = x;
    nodes [v].y_pos = y;
    v ++;
    if (x+d > 1000) {
      x = 0;
      y += d;
    } else
      x += d;
  }
}


/****************************************************************************/
/* NAME: cool                                                               */
/* FUNKTION: verringert die Temperatur nach jeder Iteration                 */
/*           (Temperatur heisst hier max. Laenge des displacements)         */
/* UEBERGABEPARAMETER: t alte Temperatur, i Nr. der Iteration               */
/* RUECKGABEWERT: neue Temperatur                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 14.6.95                                                              */
/* LETZTE AENDERUNG AM: 27.6.95                                             */
/****************************************************************************/
static int cool (float t, int i)
{
  static int step = INIT_TEMP / (PHASE_1 + 1);

  if (i < PHASE_1)
    /* lineare Senkung der Temperatur in der */
    /* erste Phase der Iterationen */
    return t-step;
  else if (i < PHASE_2)
    return MID_TEMP;
  else
    return LOW_TEMP;
}


/****************************************************************************/
/* NAME: move                                                               */
/* FUNKTION: verschiebt einen Knoten indem fuer diesen Abstossungs- und     */
/*            Anziehungskraefte beechnet werden                             */
/* UEBERGABEPARAMETER: v Knoten                                             */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 29.6.95                                                              */
/* LETZTE AENDERUNG AM: 29.6.95                                             */
/****************************************************************************/
static void move (int v)
{
  int u;
  int e;
  float delta_x;
  float delta_y;
  float displ_x;
  float displ_y;
  float delta_laenge;
  float temperatur;
  float displ_laenge;
  float temp;

  /* k = gew_Kantenlaenge;  orginal */

  k = sqrt (AREA / n);
  temperatur = 10;
  displ_x = 0;
  displ_y = 0;
  for (e = 0; e < Kantenzahl; e ++) {
    if ((edges [e].tail == v || edges [e].head == v)
        && !(edges [e].tail == v && edges [e].head == v)) {
      if (edges [e].tail == v)
        u = edges [e].head;
      else
        u = edges [e].tail;
      delta_x = nodes [v].x_pos - nodes [u].x_pos;
      delta_y = nodes [v].y_pos - nodes [u].y_pos;
      delta_laenge = laenge (delta_x, delta_y);
      if (delta_laenge != 0) {
        delta_x /= delta_laenge;
        delta_y /= delta_laenge;
        temp = f_attr (delta_laenge);
        displ_x -= delta_x * temp;
        displ_y -= delta_y * temp;
      }
    }
  }

  for (u = 0; u < n; u ++)
    if (u != v) {
      delta_x = nodes [v].x_pos - nodes [u].x_pos;
      delta_y = nodes [v].y_pos - nodes [u].y_pos;
      delta_laenge = laenge (delta_x, delta_y);
      if (delta_laenge == 0) {
        delta_x = rand () / (float) MAX_INT - 0.5;
        delta_y = rand () / (float) MAX_INT - 0.5;
        delta_laenge = 1;
      }
      if (delta_laenge <= 2 * k) {
        delta_x /= delta_laenge;
        delta_y /= delta_laenge;
        temp = f_rep (delta_laenge);
        displ_x += delta_x * temp;
        displ_y += delta_y * temp;
      }
    }
  displ_laenge = laenge (displ_x, displ_y);
  if (displ_laenge != 0 && displ_laenge > temperatur) {
    displ_x /= displ_laenge * temperatur;
    displ_y /= displ_laenge * temperatur;
  }

  nodes [v].x_pos += displ_x;
  nodes [v].y_pos += displ_y;
}

/****************************************************************************/
/* NAME: piv                                                                */
/* FUNKTION: findet Stelle mit Wert, nach dem sortiert wird                 */
/* UEBERGABEPARAMETER: i, j Randpunkte                                      */
/* RUECKGABEWERT: der Wert, nach dem sortiert wird                          */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 30.6.95                                                              */
/* LETZTE AENDERUNG AM: 30.6.95                                             */
/****************************************************************************/
static int piv (int i, int j)
{
  int k;

  k = i;
  while (k < j && Komponenten [k].node_count == Komponenten [k + 1].node_count)
    k ++;
  if (k == j)
    return -1;
  else if (Komponenten [k].node_count > Komponenten [k + 1].node_count)
    return k + 1;
  else
    return k;
}

/****************************************************************************/
/* NAME: part                                                               */
/* FUNKTION: ordnet Komponenten nach pivot                                  */
/* UEBERGABEPARAMETER: i, j Randpunkte, pivot Wert nach den Komponenten     */
/*                     geordnet werden                                      */
/* RUECKGABEWERT: Stelle von der an Werte groesser als pivot sind           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 30.6.95                                                              */
/* LETZTE AENDERUNG AM: 30.6.95                                             */
/****************************************************************************/
static int part (int i, int j, int pivot)
{
  S_GRAPH temp;
  float tmp;

  while (Komponenten [i].node_count > pivot)
    i ++;
  while (Komponenten [j].node_count <= pivot)
    j --;
  while (i < j) {
    temp = Komponenten [i];
    Komponenten [i] = Komponenten [j];
    Komponenten [j] = temp;
    tmp = Kantenlaenge [i];
    Kantenlaenge [i] = Kantenlaenge [j];
    Kantenlaenge [j] = tmp;
    while (Komponenten [i].node_count > pivot)
      i ++;
    while (Komponenten [j].node_count <= pivot)
      j --;
  }
  return i;
}


/****************************************************************************/
/* NAME: quicksort                                                          */
/* FUNKTION: sortiert Komponenten nach Knotenzahl                           */
/* UEBERGABEPARAMETER: i, j Randpunkte                                      */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 30.6.95                                                              */
/* LETZTE AENDERUNG AM: 30.6.95                                             */
/****************************************************************************/
static void quicksort (int i, int j)
{
  int pivot_pos;
  int k;
  int pivot;

  if (i < j) {
    pivot_pos = piv (i, j);
    if (pivot_pos != -1) {
      pivot = Komponenten [pivot_pos].node_count;
      k = part (i, j, pivot);
      quicksort (i, k - 1);
      quicksort (k, j);
    }
  }
}


/****************************************************************************/
/* NAME: Komponenten_sort                                                   */
/* FUNKTION: sortiert die Komponenten nach Knotenzahl                       */
/* UEBERGABEPARAMETER:                                                      */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 30.6.95                                                              */
/* LETZTE AENDERUNG AM: 30.6.95                                             */
/****************************************************************************/
static void Komponenten_sort ()
{
  quicksort (0, Komponentenzahl - 1);
}

/****************************************************************************/
/* NAME: alloc_max_array                                                    */
/* FUNKTION: reserviert Speicherplatz                                       */
/* UEBERGABEPARAMETER:                                                      */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 4.7.95                                                               */
/* LETZTE AENDERUNG AM: 4.7.95                                              */
/****************************************************************************/
static void alloc_max_array ()
{
  x_max_Knoten = (int *) calloc (Komponentenzahl, sizeof (int));
  y_max_Knoten = (int *) calloc (Komponentenzahl, sizeof (int));
  Kantenlaenge = (float *) calloc (Komponentenzahl, sizeof (float));
  if (x_max_Knoten == NULL || y_max_Knoten == NULL || Kantenlaenge == NULL) {
    printf ("Fehler alloc_max_array\n");
    exit (0);
  }
}

/****************************************************************************/
/* NAME: spring_langsam_to_graph                                            */
/* FUNKTION: speichert Koordinaten des Graphen in graph (ein wenig          */
/*           aufwendig, da die Knoten in aufsteigender Reihenfolge in die   */
/*           Datenstruktur Graph ueberfuehrt werden muessen, dies aber bei  */
/*           den Komponenten nicht der Fall sein muss. Aufsteigende Nummer, */
/*           weil beim Loeschen neu nummeriert werden muss.)                */
/* UEBERGABEPARAMETER: rel Name der Relation, graph Graph                   */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 4.7.95                                                               */
/* LETZTE AENDERUNG AM: 4.7.95                                              */
/****************************************************************************/
graphlistptr spring_langsam_to_graph (KureRel * impl)
{
  int k;
  int i;
  int j;
  int found;
  int number_of_nodes = 0;
  Graph * gr;
  char number_name [64];
  nodelistptr node_ptr;
  edgelistptr edge_ptr;
  graphlistptr gl;

  /* Anzahl der Knoten aller Komponenten des Graphen ermitteln */
  for (k = 0; k < Komponentenzahl; k ++)
    number_of_nodes = number_of_nodes + Komponenten [k].node_count;

  gl = mk_graph (UNKNOWN_GRAPH_NAME, NORMAL);

  if (gl != (graphlistptr) NULL) {
    gr = & (gl->graph);

    for (i = 0; i < number_of_nodes; i ++) {
      k = 0;
      found = FALSE;

      while ((k < Komponentenzahl) && (found != TRUE)) {
        j = 0;
        while ((j < Komponenten [k].node_count) && (found != TRUE)) {
          if ((Komponenten [k].inj [j]) == i) {
            sprintf (number_name,"%d", Komponenten [k].inj [j] + 1);
            node_ptr
              = make_node (number_name,
                           (int) Komponenten [k].nodes [j].x_pos + DEFAULT_DIM,
                           (int) Komponenten [k].nodes [j].y_pos + DEFAULT_DIM,
                           DEFAULT_DIM,
                           VISIBLE);
            if (node_ptr != (nodelistptr) NULL) {
              append_node (gr, node_ptr);
            }
            found = TRUE;
          } else
            j ++;
        }
        k ++;
      }
    }

    for (k = 0; k < Komponentenzahl; k ++) {
      for (i = 0; i < Komponenten [k].edge_count; i ++) {
        edge_ptr = make_edge
          ("",
           Komponenten [k].inj [Komponenten [k].edges [i].tail] + 1,
           Komponenten [k].inj [Komponenten [k].edges [i].head] + 1,
           VISIBLE);
        append_edge (gr,edge_ptr);
        if (Komponenten [k].edges [i].back_and_forth == TRUE) {
          edge_ptr = make_edge
            ("",
             Komponenten [k].inj [Komponenten [k].edges [i].head] + 1,
             Komponenten [k].inj [Komponenten [k].edges [i].tail] + 1,
             VISIBLE);
          append_edge (gr,edge_ptr);
        }
      }
    }
  }
  return (gl);
}


/****************************************************************************/
/* NAME: turn                                                               */
/* FUNKTION: dreht die Komponenten, um kleinere Ausdehnung in x-Richtung    */
/*           zu finden                                                      */
/* UEBERGABEPARAMETER:                                                      */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 14.7.95                                                              */
/* LETZTE AENDERUNG AM: 14.7.95                                             */
/****************************************************************************/
static void turn ()
{
  int i;
  int i_max;
  float sinus;
  float cosinus;
  float x_min;
  float x_max;
  float x_diff;
  const float pi = 355.0 / 113.0;
  /* PI als Bruch */

  x_max = nodes [0].x_pos;
  x_min = x_max;
  for (i = 1; i < n; i ++) {
    x_max = Max (x_max, nodes [i].x_pos);
    x_min = Min (x_min, nodes [i].x_pos);
  }
  x_diff = x_max - x_min;

  i_max = 0;
  for (i = 0; i <= 36; i ++) {
    sinus = sin (pi * i / 36.0);
    cosinus = cos (pi * i / 36.0);
    drehen_x (sinus, cosinus, & x_min, & x_max);
    if (x_max - x_min < x_diff) {
      i_max = i;
      x_diff = x_max - x_min;
    }
  }

  if (i_max != 0)
    drehen (sin (pi * i_max / 36.0), cos (pi * i_max / 36.0));
}


/****************************************************************************/
/* NAME: drehen_x                                                           */
/* FUNKTION: dreht den Graphen (nur x-Koordinaten)                          */
/* UEBERGABEPARAMETER: sinus, cosinus sin- bzw. cos-Werte des Winkels um    */
/*                     den gedreht wird                                     */
/*                     x_min, x_max min. bzw. max. x-Position (Zeiger)      */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 14.7.95                                                              */
/* LETZTE AENDERUNG AM: 14.7.95                                             */
/****************************************************************************/
static void drehen_x (float sinus, float cosinus, float * x_min, float * x_max)
{
  int i;
  float x_coord;

  * x_min = nodes [0].x_pos * cosinus + nodes [0].y_pos * sinus;
  * x_max = * x_min;

  for (i = 1; i < n; i ++) {
    x_coord = nodes [i].x_pos * cosinus + nodes [i].y_pos * sinus;
    if (x_coord < * x_min)
      * x_min = x_coord;
    else if (x_coord > * x_max)
      * x_max = x_coord;
  }
}

/****************************************************************************/
/* NAME: drehen                                                             */
/* FUNKTION: dreht den Graphen                                              */
/* UEBERGABEPARAMETER: sinus, cosinus sin- bzw. cos-Werte des Winkels       */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.6.95                                                              */
/* LETZTE AENDERUNG AM: 24.6.95                                             */
/****************************************************************************/
static void drehen (float sinus, float cosinus)
{
  int i;
  float x_coord;

  for (i = 0; i < n; i ++) {
    x_coord = nodes [i].x_pos;
    nodes [i].x_pos = x_coord* cosinus + nodes [i].y_pos * sinus;
    nodes [i].y_pos = nodes [i].y_pos * cosinus - x_coord* sinus;
  }
}


/****************************************************************************/
/* NAME: limit                                                              */
/* FUNKTION: beschraenkt das displacement auf maximale Groesse bzgl.        */
/*           Temperatur  und Fenstergroesse und berechnet dann die          */
/*           neue Position der Knoten                                       */
/* UEBERGABEPARAMETER: temperatur, nodes Knoten, n Knotenzahl               */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 30.8.95                                                              */
/* LETZTE AENDERUNG AM: 30.8.95                                             */
/****************************************************************************/
static void limit (float temperatur, S_NODE * nodes, int n)
{
  int v;
  float displ_laenge;

  for (v = 0; v < n; v ++) {
    /* begrenzen bzgl. temperatur */
    displ_laenge = laenge (nodes [v].displ_x, nodes [v].displ_y);
    if (displ_laenge != 0) {
      nodes [v].displ_x /= displ_laenge;
      nodes [v].displ_y /= displ_laenge;
      displ_laenge = Min (displ_laenge, temperatur);
      nodes [v].x_pos += nodes [v].displ_x * displ_laenge;
      nodes [v].y_pos += nodes [v].displ_y * displ_laenge;
    }
    if (temperatur > 100) {
      nodes [v].x_pos = Max (min_x, nodes [v].x_pos);
      nodes [v].x_pos = Min (max_x, nodes [v].x_pos);
      nodes [v].y_pos = Max (min_y, nodes [v].y_pos);
      nodes [v].y_pos = Min (max_y, nodes [v].y_pos);
    }
  }
}



/****************************************************************************/
/* NAME: free_glob                                                          */
/* FUNKTION: gibt Speicherplatz fuer globale Parameter frei                 */
/* UEBERGABEPARAMETER:                                                      */
/* RUECKGABEWERT:                                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 7.9.95                                                               */
/* LETZTE AENDERUNG AM: 7.9.95                                              */
/****************************************************************************/
static void free_glob ()
{
  int k;

  for (k = 0; k < Komponentenzahl; k ++) {
    free (Komponenten [k].nodes);
    free (Komponenten [k].edges);
  }
  free (Komponenten);
  free (Kantenlaenge);
}

