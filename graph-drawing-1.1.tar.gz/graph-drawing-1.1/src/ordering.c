#include <stdio.h>
#include <stdlib.h>

#include "global-sme.h"
#include "ordering.h"

/* modulglobale Variablen */

static int * A_in;
static int * A_out;
static int * In;
static int * Out;
static int * rank_count;
static int n;
static int Kantenzahl;   /*  n = Knotenzahl   */
static int max_rank;
static float * median;
static EDGE * edges;
static NODE * nodes;
static INT_POINTER * order;
static INT_POINTER * best;

/****************************************************************************/
/* NAME: mk_new_graph                                                       */
/* FUNKTION: fuehrt dummy-Knoten in den Graphen ein und macht so aus        */
/*           dem Graphen eine echte Hierarchie                              */
/* UEBERGABEPARAMETER: alt_edges die alten Kanten, alt_nodes die alten      */
/*                     Knoten, alt_Kanz alte Kantenzahl, alt_n alte         */
/*                     Knotenzahl                                           */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 11.4.95                                                              */
/* LETZTE AENDERUNG AM: 11.4.95                                             */
/****************************************************************************/
static void mk_new_graph (EDGE * alt_edges, NODE * alt_nodes,
                          int alt_Kanz, int alt_n)
{
  int i;
  int laenge;
  int temp;
  int virt_count;
  int akt_node;
  int akt_edge;
  virt_count = 0;

  for (i = 0; i < alt_Kanz; i ++)
    virt_count += alt_nodes [alt_edges [i].head].rank -
      alt_nodes [alt_edges [i].tail].rank - 1;
  Kantenzahl = alt_Kanz + virt_count;
  n = alt_n + virt_count;
  edges = (EDGE *) calloc (Kantenzahl, sizeof (EDGE));
  nodes = (NODE *) calloc (n, sizeof (NODE));
  if (edges == NULL || nodes == NULL) {
    printf ("Fehler in mk_new_graph in ordering.c (Zu wenig Speicherplatz)\n");
    exit (0);
  }
  max_rank = 0;
  akt_node = alt_n;     /* neue Knoten kriegen Nr. alt_n bis n */
  akt_edge = 0;
  for (i = 0; i < alt_n; i ++) {
    nodes [i].rank = alt_nodes [i].rank;
    nodes [i].Schleife = alt_nodes [i].Schleife;
  }
  for (i = 0; i < alt_Kanz; i ++) {
    max_rank = max_rank > alt_nodes [alt_edges [i].head].rank ? max_rank :
      alt_nodes [alt_edges [i].head].rank;
    laenge = alt_nodes [alt_edges [i].head].rank
      - alt_nodes [alt_edges [i].tail].rank;
    if (laenge == 1) {
      edges [akt_edge].tail = alt_edges [i].tail;
      edges [akt_edge].head = alt_edges [i].head;
      edges [akt_edge].status = ORIGINAL;
      edges [akt_edge].gedreht = alt_edges [i].gedreht;
      edges [akt_edge].back_and_forth = alt_edges [i].back_and_forth;
      akt_edge ++;
    }
    if (laenge > 1) {
      edges [akt_edge].tail = alt_edges [i].tail;
      edges [akt_edge].head = akt_node;
      edges [akt_edge].status = VIRT_HEAD;
      edges [akt_edge].gedreht = alt_edges [i].gedreht;
      edges [akt_edge].back_and_forth = alt_edges [i].back_and_forth;
      nodes [akt_node].rank = nodes [edges [akt_edge].tail].rank + 1;
      temp = nodes [akt_node].rank;
      akt_node ++;
      akt_edge ++;
      while (temp < nodes [alt_edges [i].head].rank - 1) {
        edges [akt_edge].tail = edges [akt_edge - 1].head;
        edges [akt_edge].head = akt_node;
        edges [akt_edge].status = VIRTUAL;
        edges [akt_edge].gedreht = alt_edges [i].gedreht;
        edges [akt_edge].back_and_forth = alt_edges [i].back_and_forth;
        nodes [akt_node].rank = ++ temp;
        akt_node ++;
        akt_edge ++;
      }
      edges [akt_edge].tail = edges [akt_edge - 1].head;
      edges [akt_edge].head = alt_edges [i].head;
      edges [akt_edge].status = VIRT_TAIL;
      edges [akt_edge].gedreht = alt_edges [i].gedreht;
      edges [akt_edge].back_and_forth = alt_edges [i].back_and_forth;
      akt_edge ++;
    }
  }
}


/****************************************************************************/
/* NAME: mk_graph_list                                                      */
/* FUNKTION: erstellt Anf.-listen usw. aus Liste edges                      */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.4.95                                                              */
/* LETZTE AENDERUNG AM: 20.4.95                                             */
/****************************************************************************/
static void mk_graph_list ()
{
  int i;
  int * akt_in;
  int * akt_out;

  akt_in = (int *) calloc (n, sizeof (int));
  akt_out = (int *) calloc (n, sizeof (int));
  if (akt_in == (int *) NULL || akt_out == (int *) NULL) {
    printf ("Fehler mk_graph_list \n");
    exit (1);
  }
  for (i = 0; i < Kantenzahl; i ++) {
    akt_in [edges [i].head] ++;
    akt_out [edges [i].tail] ++;
  }
  for (i = 1; i <= n; i ++) {
    A_in [i] = A_in [i - 1] + akt_in [i - 1];
    A_out [i] = A_out [i - 1] + akt_out [i - 1];
    akt_in [i - 1] = A_in [i - 1];
    akt_out [i - 1] = A_out [i - 1];
  }
  for (i = 0; i < Kantenzahl; i ++) {
    In [akt_in [edges [i].head] ++] = i;
    Out [akt_out [edges [i].tail] ++] = i;
    edges [i].weight = 1;
    edges [i].delta = 1;
  }
  free (akt_in);
  free (akt_out);
}


/****************************************************************************/
/* NAME: mk_rank_count                                                      */
/* FUNKTION: zaehlt die Anzahl der Knoten in jedem level in dem             */
/*           Feld rank_count                                                */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 12.4.95                                                              */
/* LETZTE AENDERUNG AM: 12.4.95                                             */
/****************************************************************************/
static void mk_rank_count ()
{
  int i;

  rank_count = (int *) calloc (max_rank + 1, sizeof (int));
  if (rank_count == (int *) NULL) {
    printf ("Fehler rank_count \n");
    exit (1);
  }
  for (i = 0; i < n; i ++)
    rank_count [nodes [i].rank] ++;
}


/****************************************************************************/
/* NAME: posit                                                              */
/* FUNKTION: ordnet dem Knoten i die naechste freie Position in             */
/*           seinem level zu                                                */
/* UEBERGABEPARAMETER: i Knoten, akt_pos Feld, dass zu jedem level          */
/*                     die naechste freie Position angibt                   */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 11.4.95                                                              */
/* LETZTE AENDERUNG AM: 11.4.95                                             */
/****************************************************************************/
static void posit (int i, int * akt_pos)
{
  int rank;
  int j;

  rank = nodes [i].rank;
  nodes [i].status = SCANNED;
  nodes [i].position = akt_pos [rank];
  order [rank] [akt_pos [rank] ++] = i;
  for (j = A_out [i]; j < A_out [i + 1]; j ++)
    if (nodes [edges [Out [j]].head].status == UNSCANNED)
      posit (edges [Out [j]].head, akt_pos);
}


/****************************************************************************/
/* NAME: init_order                                                         */
/* FUNKTION: liefert initiale Ordnung der Knoten in den levels              */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 11.4.95                                                              */
/* LETZTE AENDERUNG AM: 11.4.95                                             */
/****************************************************************************/
static void init_order ()
{
  int i;
  int * akt_pos;

  mk_rank_count ();
  order = (INT_POINTER *) calloc (max_rank + 1, sizeof (INT_POINTER));
  best = (INT_POINTER *) calloc (max_rank + 1, sizeof (INT_POINTER));
  akt_pos = (int *) calloc (max_rank + 1, sizeof (int));
  if (order == (INT_POINTER *) NULL || best == (INT_POINTER *) NULL ||
      akt_pos == (int *) NULL) {
    printf ("Zu wenig Speicherplatz \n");
    exit (1);
  }
  for (i = 0; i <= max_rank; i ++)     {
    order [i] = (int *) calloc (rank_count [i], sizeof (int));
    best [i] = (int *) calloc (rank_count [i], sizeof (int));
    if (order [i] == (int *) NULL || best [i] == (int *) NULL) {
      printf ("Zu wenig Speicherplatz \n");
      exit (1);
    }
  }
  for (i = 0; i < n; i ++)
    nodes [i].status = UNSCANNED;
  for (i = 0; i < n; i ++)
    if (A_in [i] == A_in [i + 1])
      posit (i, akt_pos);
  free (akt_pos);
}


/****************************************************************************/
/* NAME: part_pos                                                           */
/* FUNKTION: ordnet list gemaess pivot                                      */
/* UEBERGABEPARAMETER: i, j Randpunkte, list Feld von Knoten                */
/*                     pivot Wert nach dem list geteilt wird                */
/* RUECKGABEWERT: Stelle von der ab Werte groesser als pivot sind           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static int part_pos (int i, int j, int pivot, int * list)
{
  int temp;

  while (nodes [list [i]].position < pivot)
    i ++;
  while (nodes [list [j]].position >= pivot)
    j --;
  while (i < j) {
    temp = list [i];
    list [i] = list [j];
    list [j] = temp;
    while (nodes [list [i]].position < pivot)
      i ++;
    while (nodes [list [j]].position >= pivot)
      j --;
    }
  return (i);
}


/****************************************************************************/
/* NAME: quicksort_pos                                                      */
/* FUNKTION: sortiert list von i bis j nach Position                        */
/* UEBERGABEPARAMETER: i, j Randpunkte, list Feld von Knoten                */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static void quicksort_pos (int i, int j, int * list)
{
  int pivot;
  int k;
  static int count = 0;

  count ++;
  if (i < j) {
    pivot = nodes [list [i + 1]].position > nodes [list [i]].position ?
      nodes [list [i + 1]].position : nodes [list [i]].position;
    k = part_pos (i, j, pivot, list);
    quicksort_pos (i, k - 1, list);
    quicksort_pos (k, j, list);
  }
}


/****************************************************************************/
/* NAME: piv_med                                                            */
/* FUNKTION: findet Wert nach dem die Liste geordnet  wird                  */
/* UEBERGABEPARAMETER: i, j Randpunkte, list Feld von Knoten                */
/* RUECKGABEWERT: der gefundene Wert                                        */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static float piv_med (int i, int j, int * list)
{
  int k;

  k = i;
  while (k < j && median [list [k]] == median [list [k + 1]])
    k += 1;
  if (k == j)
    return (-1);
  else
    if (median [list [k]] < median [list [k + 1]])
      return (k + 1);
    else
      return (k);
}


/****************************************************************************/
/* NAME: part_med                                                           */
/* FUNKTION: ordnet list genaess pivot                                      */
/* UEBERGABEPARAMETER: i, j Randpunkte, pivot Wert nach dem list            */
/*                     geordnet wird, list Feld                             */
/* RUECKGABEWERT: Stelle von der an Werte groesser als pivot sind           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static int part_med (int i, int j, float pivot, int * list)
{
  int temp;

  while (median [list [i]] < pivot)
    i ++;
  while (median [list [j]] >= pivot)
    j --;
  while (i < j) {
    temp = list [i];
    list [i] = list [j];
    list [j] = temp;
    while (median [list [i]] < pivot)
      i ++;
    while (median [list [j]] >= pivot)
      j --;
  }
  return (i);
}


/****************************************************************************/
/* NAME: quicksort_med                                                      */
/* FUNKTION: sortiert Feld nach median-Werten                               */
/* UEBERGABEPARAMETER: i, j Randpunkte, list Feld von Knoten                */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static void quicksort_med (int i, int j, int * list)
{
  int pivot_pos;
  int k;
  float pivot;

  if (i < j) {
    pivot_pos = piv_med (i, j, list);
    if (pivot_pos != -1) {
      pivot = median [list [pivot_pos]];
      k = part_med (i, j, pivot, list);
      quicksort_med (i, k - 1, list);
      quicksort_med (k, j, list);
    }
  }
}


/****************************************************************************/
/* NAME: sort                                                               */
/* FUNKTION: sortiert Knoten eines ranks nach median-Werten                 */
/* UEBERGABEPARAMETER: r rank                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static void sort (int r)
{
  int aktuell;
  int i;
  int * list;

  list = (int *) calloc (rank_count [r], sizeof (int));
  if (list == (int *) NULL) {
    printf ("Fehler sort \n");
    exit (1);
  }
  aktuell = 0;
  for (i = 0; i < rank_count [r]; i ++)
    if (median [order [r] [i]] != -1)
      list [aktuell ++] = order [r] [i];
  if (aktuell > 1)
    quicksort_med (0, aktuell - 1, list);
  aktuell = 0;
  for (i = 0; i < rank_count [r]; i ++)
    if (median [order [r] [i]] != -1) {
      order [r] [i] = list [aktuell];
      nodes [list [aktuell ++]].position = i;
    }
  free (list);
}


/****************************************************************************/
/* NAME: adj_position                                                       */
/* FUNKTION: liefert ein geordnetes Feld der benachbarten Knoten            */
/*           von v in adj_rank                                              */
/* UEBERGABEPARAMETER: v Knoten, adj_rank rank                              */
/* RUECKGABEWERT: das geordnete Feld                                        */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static int * adj_position (int v, int adj_rank)
{
  int temp;
  int dir;
  int i;
  int j;
  int * Nachbarn;

  dir = nodes [v].rank < adj_rank ? DOWN : UP;
  if (dir == DOWN) {
    temp = A_out [v + 1] - A_out [v];
    Nachbarn = (int *) calloc (temp + 1, sizeof (int));
    if (Nachbarn == (int *) NULL) {
      printf ("Fehler adj_position \n");
      exit (1);
    }
    Nachbarn [0] = temp;
    for (i = 1, j = A_out [v]; i <= temp; i ++, j ++)
      Nachbarn [i] = edges [Out [j]].head;
    if (temp > 1)
      quicksort_pos (1, temp, Nachbarn);
  }
  else {
    temp = A_in [v + 1] - A_in [v];
    Nachbarn = (int *) calloc (temp + 1, sizeof (int));
    if (Nachbarn == (int *) NULL) {
      printf ("Fehler adj_position \n");
      exit (1);
    }
    Nachbarn [0] = temp;
    for (i = 1, j = A_in [v]; i <= temp; i ++, j ++)
      Nachbarn [i] = edges [In [j]].tail;
    if (temp > 1)
      quicksort_pos (1, temp, Nachbarn);
  }
 return (Nachbarn);
}


/****************************************************************************/
/* NAME: median_value                                                       */
/* FUNKTION: berechnet mittlere Position der benachbarten Knoten            */
/*           von v in adj_rank                                              */
/* UEBERGABEPARAMETER: v Knoten, adj_rank rank                              */
/* RUECKGABEWERT: mittlere Position                                         */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static float median_value (int v, int adj_rank)
{
  int m;
  int left;
  int right;
  int * Nachbarn;
  float res;

  Nachbarn = adj_position (v, adj_rank);
  m = Nachbarn [0] / 2;
  if (Nachbarn [0] == 0)
    res = -1.0;
  else
    if (Nachbarn [0] % 2 == 1)
      res = nodes [Nachbarn [m + 1]].position;
    else
      if (Nachbarn [0] == 2)
        res =
          (nodes [Nachbarn [1]].position + nodes [Nachbarn [2]].position)
          / 2.0;
      else {
        left = nodes [Nachbarn [m]].position - nodes [Nachbarn [1]].position;
        right = nodes [Nachbarn [Nachbarn [0]]].position -
          nodes [Nachbarn [m + 1]].position;
        res = (nodes [Nachbarn [m]].position * right + 0.0 +
               nodes [Nachbarn [m + 1]].position * left) / (left + right);
      }
  free (Nachbarn);
  return (res);
}

/****************************************************************************/
/* NAME: wmedian                                                            */
/* FUNKTION: berechnet die mittlere Position der benachbarten Knoten        */
/* UEBERGABEPARAMETER: iter die Nummer der Iteration                        */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static void wmedian (int iter)
{
  int r;
  int i;

  if (iter % 2 == 0)
    for (r = 1; r <= max_rank; r ++) {
      for (i = 0; i < rank_count [r]; i ++)
        median [order [r] [i]] = median_value (order [r] [i], r - 1);
      sort (r);
    }
  else
    for (r = max_rank - 1; r >= 0; r --) {
      for (i = 0; i < rank_count [r]; i ++)
        median [order [r] [i]] = median_value (order [r] [i], r + 1);
      sort (r);
    }
}


/****************************************************************************/
/* NAME: exchange_nodes                                                     */
/* FUNKTION: vertauscht die Position der Knoten i, i + 1                    */
/* UEBERGABEPARAMETER: r rank, i Knoten                                     */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static void exchange_nodes (int r, int i)
{
  int temp;

  temp = order [r] [i];
  order [r] [i] = order [r] [i + 1];
  order [r] [i + 1] = temp;
  nodes [order [r] [i]].position = i;
  nodes [order [r] [i + 1]].position = i + 1;
}


/****************************************************************************/
/* NAME: crossing                                                           */
/* FUNKTION: berechnet Zahl der Kreuzungen, die von Kanten erzeugt          */
/*           werden, die v oder w als Knoten haben, fuer den Fall           */
/*           dass v links bzw. rechts von w liegt                           */
/* UEBERGABEPARAMETER: v, w Knoten                                          */
/* RUECKGABEWERT: flag der angibt, ob v und w vertauscht werden             */
/*                sollen oder nicht                                         */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static int crossing (int v, int w)
{
  int cross_vw = 0;
  int cross_wv = 0;
  int i;
  int j;

  for (i = A_in [v]; i < A_in [v + 1]; i ++)
    for (j = A_in [w]; j < A_in [w + 1]; j ++)
      if (nodes [edges [In [j]].tail].position <
          nodes [edges [In [i]].tail].position)
        cross_vw ++;
      else
        cross_wv ++;
  for (i = A_out [v]; i < A_out [v + 1]; i ++)
    for (j = A_out [w]; j < A_out [w + 1]; j ++)
      if (nodes [edges [Out [j]].head].position <
          nodes [edges [Out [i]].head].position)
        cross_vw ++;
      else
        cross_wv ++;
  if (cross_vw < cross_wv)
    return (BESSER);
  else
    return (SCHLECHTER);
}


/****************************************************************************/
/* NAME: transpose                                                          */
/* FUNKTION: reduziert die Anzahl der Kreuzungen durch vertauschen          */
/*           benachbarter Knoten in rank                                    */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/
static void transpose ()
{
  int improved = FALSE;
  int r;
  int i;
  int v;
  int w;

  while (improved == TRUE) {
    improved = FALSE;
    for (r = 0; r <= max_rank; r ++)
      for (i = 0; i < rank_count [r] - 1; i ++) {
        v = order [r] [i];
        w = order [r] [i + 1];
        if (crossing (v, w) == SCHLECHTER) {
          improved = TRUE;
          exchange_nodes (r, i);
        }
      }
  }
}


/****************************************************************************/
/* NAME: rank_cross                                                         */
/* FUNKTION: berechnet die Anzahl der Kreuzungen von Kanten zwischen        */
/*           Knoten aus rank und rank + 1                                   */
/* UEBERGABEPARAMETER: rank                                                 */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.4.95                                                              */
/* LETZTE AENDERUNG AM: 20.4.95                                             */
/****************************************************************************/
static int rank_cross (int rank)
{
  int res;
  int i;
  int j;
  int e;
  int f;

  res = 0;
  for (i = 0; i < rank_count [rank]; i ++)
    for (e = A_out [order [rank] [i]]; e < A_out [order [rank] [i] + 1]; e ++)
      for (j = i + 1; j < rank_count [rank]; j ++)
        for (f = A_out [order [rank] [j]];
             f < A_out [order [rank] [j] + 1];
             f ++)
          if (nodes [edges [Out [e]].head].position >
              nodes [edges [Out [f]].head].position)
            res ++;
  return (res);
}


/****************************************************************************/
/* NAME: tot_crossing                                                       */
/* FUNKTION: berechnet die Anzahl aller Kreuzungen im Graphen, wenn die     */
/*           Knoten im Sinne von order geordnet sind                        */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: Anzahl der Kreuzungen                                     */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.4.95                                                              */
/* LETZTE AENDERUNG AM: 20.4.95                                             */
/****************************************************************************/
static int tot_crossing ()
{
  int res;
  int r;

  res = 0;
  for (r = 0; r < max_rank; r ++)
    res += rank_cross (r);
  return (res);
}


/****************************************************************************/
/* NAME: copy                                                               */
/* FUNKTION: kopiert order nach best                                        */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.4.95                                                              */
/* LETZTE AENDERUNG AM: 20.4.95                                             */
/****************************************************************************/
static void copy ()
{
  int r;
  int i;

  for (r = 0; r < max_rank; r ++)
    for (i = 0; i < rank_count [r]; i ++)
      best [r] [i] = order [r] [i];
}


/****************************************************************************/
/* NAME: free_temp_list                                                     */
/* FUNKTION: gibt den Speicherplatz fuer die Hilfslisten wieder frei        */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.4.95                                                              */
/* LETZTE AENDERUNG AM: 20.4.95                                             */
/****************************************************************************/
static void free_temp_list ()
{
  int r;

  for (r = 0; r < max_rank; r ++)
    free (best [r]);
  free (best);
  free (median);
}


/****************************************************************************/
/* NAME: pos_setzen                                                         */
/* FUNKTION: setzt in der Struktur nodes [] die Komponente position         */
/*           gemaess order                                                  */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.4.95                                                              */
/* LETZTE AENDERUNG AM: 24.4.95                                             */
/****************************************************************************/
static void pos_setzen ()
{
  int r;
  int i;

  for (r = 0; r <= max_rank; r ++)
    for (i = 0; i < rank_count [r]; i ++)
      nodes [order [r] [i]].position = i;
}


/****************************************************************************/
/* NAME: rueckgabe                                                          */
/* FUNKTION: setzt die Uebergabeparameter von ordering                      */
/* UEBERGABEPARAMETER: A_in1, A_out1, In1, Out1 Nachbarlisten               */
/*                     alt_edges die alten Kanten, alt_nodes die alten      */
/*                     Knoten, n_ptr Zeiger auf die Zahl der Original-      */
/*                     knoten, Kanz_ptr Zeiger auf die Zahl der             */
/*                     Originalkanten, order1, rank_count1, max_rank1       */
/*                     wie bei ordering                                     */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.4.95                                                              */
/* LETZTE AENDERUNG AM: 24.4.95                                             */
/****************************************************************************/
static void rueckgabe (int ** A_in_ptr, int ** A_out_ptr, int ** In_ptr,
                       int ** Out_ptr, EDGE ** edge_ptr, NODE ** node_ptr,
                       int * Kanz_ptr, int * n_ptr, INT_POINTER ** order_ptr,
                       int ** rank_count_ptr, int * max_rank_ptr)
{
  free (* node_ptr);
  * Kanz_ptr = Kantenzahl;
  * n_ptr = n;
  * edge_ptr = edges;
  * node_ptr = nodes;
  * order_ptr = order;
  * rank_count_ptr = rank_count;
  * max_rank_ptr = max_rank;
  * A_in_ptr = A_in;
  * A_out_ptr = A_out;
  * In_ptr = In;
  * Out_ptr = Out;
}

/****************************************************************************/
/* NAME: set_list                                                           */
/* FUNKTION: reserviert Speicherplatz fuer Listen A_in, A_out usw.          */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 21.4.95                                                              */
/* LETZTE AENDERUNG AM: 21.4.95                                             */
/****************************************************************************/
static void set_list ()
{
  A_out = (int *) calloc (n + 1, sizeof (int));
  A_in = (int *) calloc (n + 1, sizeof (int));
  Out = (int *) calloc (Kantenzahl, sizeof (int));
  In = (int *) calloc (Kantenzahl, sizeof (int));

  if (A_out == NULL || A_in == NULL || In == NULL || Out == NULL) {
    printf ("Fehler set_list in ordering\n");
    exit (0);
  }
}


/****************************************************************************/
/* NAME: ordering                                                           */
/* FUNKTION: fuehrt dummy-Knoten ein, um aus dem Graphen eine echte         */
/*           Hierarchie zu machen, und findet dann Ordnung der Knoten       */
/*           in den levels mit moeglichst wenig Kreuzungen der Kanten       */
/* UEBERGABEPARAMETER: A_in1, A_out1, In1, Out1 Nachbarlisten,              */
/*                     alt_edges die alten Kanten, alt_nodes die alten      */
/*                     Knoten, n_ptr Zeiger auf die Zahl der Original-      */
/*                     knoten, Kanz_ptr Zeiger auf die Zahl der             */
/*                     Originalkanten, order Ordnung der Knoten in den      */
/*                     ranks, rank_count Anzahl der Knoten in jedem         */
/*                     rank, max_rank hoechster rank                        */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 17.4.95                                                              */
/* LETZTE AENDERUNG AM: 17.4.95                                             */
/****************************************************************************/

void ordering (int ** A_in_ptr, int ** A_out_ptr, int ** In_ptr,
               int ** Out_ptr, EDGE ** edge_ptr, NODE ** node_ptr,
               int * Kanz_ptr, int * n_ptr, INT_POINTER ** order_ptr,
               int ** rank_count_ptr, int * max_rank_ptr)
{
  int i;
  int cross;
  int temp;
  int alt_n;
  int alt_Kanz;
  EDGE * alt_edges;
  NODE * alt_nodes;

  alt_n = * n_ptr;
  alt_Kanz = * Kanz_ptr;
  alt_edges = * edge_ptr;
  alt_nodes = * node_ptr;
  mk_new_graph (alt_edges, alt_nodes, alt_Kanz, alt_n);
  set_list ();
  mk_graph_list ();
  init_order ();
  copy (order, best);
  cross = tot_crossing ();
  median = (float *) calloc (n, sizeof (float));
  for (i = 0; i < MAX_ITERATIONS; i ++) {
    wmedian (i);
    pos_setzen ();
    transpose ();
    if ((temp = tot_crossing ()) < cross) {
      copy (order, best);
      cross = temp;
    }
    pos_setzen ();
  }

  free_temp_list ();
  rueckgabe (A_in_ptr, A_out_ptr, In_ptr, Out_ptr, edge_ptr, node_ptr,
             Kanz_ptr, n_ptr, order_ptr, rank_count_ptr, max_rank_ptr);
}

