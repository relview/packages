#include <stdlib.h>
#include <stdio.h>

#include "global-sme.h"
#include "position-sme.h"

/* modulglobale Variablen */

static int * A_in;
static int * A_out;
static int * In;
static int * Out;
static int * rank_count;
static int max_rank;
static INT_POINTER * order;
static int n;
static int Kantenzahl;
static EDGE * edges;
static NODE * nodes;
static int * hor_Kanten;
static int * vater;
static int * parent;


/****************************************************************************/
/* NAME: mk_aux_graph                                                       */
/* FUNKTION: erstellt den auxilliary-Graph                                  */
/* UEBERGABEPARAMETER: alt_edges alte Kanten, alt_n alte Knotenzahl         */
/*                     alt_Kanz alte Kantenzahl                             */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 22.4.95                                                              */
/* LETZTE AENDERUNG AM: 22.4.95                                             */
/****************************************************************************/
static void mk_aux_graph (NODE * alt_nodes, EDGE * alt_edges, int alt_n,
                          int alt_Kanz)
{
  int sum;
  int i;
  int akt;
  int aktuell;
  int r;
  int v;
  int weight;

  n = alt_n + alt_Kanz;

  nodes = (NODE *) calloc ((unsigned) n, sizeof (NODE));
  if (nodes == (NODE *) NULL) {
    printf ("Fehler mk_aux_graph\n");
    exit (1);
  }

  for (v = alt_n; v < n; v ++)
    nodes [v].status = UNSCANNED;

  sum = 0;
  for (r = 0; r <= max_rank; r ++)
    sum += rank_count[r] - 1;

  Kantenzahl = 2 * alt_Kanz + sum;
  edges = (EDGE *) calloc (Kantenzahl, sizeof (EDGE));
  if (edges == (EDGE *) NULL) {
    printf ("Fehler mk_aux_graph\n");
    exit (1);
  }

  for (i = 0; i < alt_Kanz; i ++) {
    akt = 2 * i;
    edges [akt].tail = alt_n + i;
    edges [akt].head = alt_edges [i].tail;
    edges [akt ++].delta = 0;
    edges [akt].tail = alt_n + i;
    edges [akt].head = alt_edges [i].head;
    edges [akt].delta = 0;
    if (alt_edges [i].status == ORIGINAL)
      weight = WEIGHT_1;
    else
      if (alt_edges [i].status == VIRTUAL)
        weight = WEIGHT_3;
      else
        weight = WEIGHT_2;
    edges [akt --].weight = weight;
    edges [akt].weight = weight;
  }

  hor_Kanten = (int *) calloc (alt_n, sizeof (int));
  if (hor_Kanten == (int *) NULL) {
    printf ("Fehler mk_aux_graph\n");
    exit (1);
  }

  aktuell = 2 * alt_Kanz;
  for (r = 0; r <= max_rank; r ++)
    for (i = 0; i < rank_count [r] - 1; i ++) {
      edges [aktuell].tail = order [r] [i];
      edges [aktuell].head = order [r] [i + 1];

      if (alt_nodes [order [r] [i]].status  == VIRTUAL)
        if (alt_nodes [order [r] [i + 1]].status == VIRTUAL)
          edges [aktuell].delta = MIN_SEP_1;
        else
          edges [aktuell].delta = MIN_SEP_2;
      else
        if (alt_nodes [order [r] [i + 1]].status == VIRTUAL)
          edges [aktuell].delta = MIN_SEP_2;
        else
          edges [aktuell].delta = MIN_SEP_3;
      /*
        edges[aktuell].delta = MIN_SEP;
        */
      edges [aktuell].weight = 0;
      hor_Kanten [order [r] [i]] = aktuell;
      aktuell ++;
    }
}


/****************************************************************************/
/* NAME: feasible_tree                                                      */
/* FUNKTION: findet aufspannenden Baum, der feasible ranking induziert      */
/* UEBERGABEPARAMETER: alt_nodes alte Knoten, alt_n alteKnotenzahl          */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 22.4.95                                                              */
/* LETZTE AENDERUNG AM: 22.4.95                                             */
/****************************************************************************/
static void feasible_tree (NODE * alt_nodes, int alt_n)
{
  int rank;
  int r;
  int i;
  int alt_edge;
  int v;
  int * vert_pos;
  int * pos;

  vater = (int *) calloc (n, sizeof (int));
  parent = (int *) calloc (n, sizeof (int));
  if (vater == (int *) NULL || parent == (int *) NULL) {
    printf ("Fehler feasible_tree_pos\n");
    exit (1);
  }
  vert_pos = (int *) calloc (max_rank + 1, sizeof (int));
  if (vert_pos == (int *) NULL) {
    printf ("Fehler feasible_tree_pos\n");
    exit (1);
  }
  for (v = alt_n; v < n; v ++)
    nodes [v].status = UNSCANNED;
  vater [0] = -1;
  parent [0] = -1;
  rank = alt_nodes [0].rank;
  vert_pos [rank] = alt_nodes [0].position;
  for (r = 0; r < rank; r ++) {
    i = 0;
    while (A_out [order [r] [i]] == A_out [order [r] [i] + 1])
      i ++;
    vert_pos [r] = i;
    alt_edge = Out [A_out [order [r] [i]]];
    vater [order [r] [i]] = alt_n + alt_edge;
    parent [order [r] [i]] = 2 * alt_edge;
    vater [alt_n + alt_edge] = edges [2 * alt_edge + 1].head;
    parent [alt_n + alt_edge] = 2 * alt_edge + 1;
    nodes [alt_n + alt_edge].status = SCANNED;
  }
  for (r = rank + 1; r <= max_rank; r ++) {
    i = 0;
    while (A_in [order [r] [i]] == A_in[order [r] [i] + 1])
      i ++;
    vert_pos [r] = i;
    alt_edge = In [A_in [order [r] [i]]];
    vater [order [r] [i]] = alt_n +alt_edge;
    parent [order [r] [i]] = 2 * alt_edge + 1;
    vater [alt_n + alt_edge] = edges [2 * alt_edge].head;
    parent [alt_n + alt_edge] = 2 * alt_edge;
    nodes [alt_n + alt_edge].status = SCANNED;
  }
  for (r = 0; r <= max_rank; r ++) {
    for (i = 0; i < vert_pos [r]; i ++) {
      vater [order [r] [i]] = order [r] [i + 1];
      parent [order [r] [i]] = hor_Kanten [order [r] [i]];
    }
    for (i = vert_pos [r]; i < rank_count [r] - 1; i ++) {
      vater [order [r] [i + 1]] = order [r] [i];
      parent [order [r] [i + 1]] = hor_Kanten [order [r] [i]];
    }
  }

  /* relative Position der alten Knoten zueinander berechnen */

  pos = (int *) calloc (alt_n, sizeof (int));
  if (pos == (int *) NULL) {
    printf ("Fehler feasible_tree_pos\n");
    exit (0);
  }
  pos [0] = 0;
  for (r = rank; r >= 0; r --) {
    if (r != rank)
      pos [order [r] [vert_pos [r]]] =
        pos [vater [vater [order [r] [vert_pos [r]]]]];
    for (i = vert_pos [r]; i > 0; i --)
      pos [order [r] [i - 1]] =
        pos [order [r] [i]] - edges [hor_Kanten [order [r] [i - 1]]].delta;
    for (i = vert_pos [r]; i < rank_count [r] - 1; i ++)
      pos [order [r] [i + 1]] =
        pos [order [r] [i]] + edges [hor_Kanten [order [r] [i]]].delta;
  }
  for (r = rank + 1;r <= max_rank; r ++) {
    pos [order [r] [vert_pos [r]]] =
      pos [vater [vater [order [r] [vert_pos [r]]]]];
    for (i = vert_pos [r]; i > 0; i --)
      pos [order [r] [i - 1]] =
        pos [order [r] [i]] - edges [hor_Kanten [order [r] [i - 1]]].delta;
    for (i = vert_pos [r]; i < rank_count [r] - 1; i ++)
      pos [order [r] [i + 1]] =
        pos [order [r] [i]] + edges [hor_Kanten [order [r] [i]]].delta;
  }

  for (v = alt_n; v < n; v ++) {
    if (nodes [v].status == UNSCANNED) {
      i = v - alt_n;
      if (pos [edges [2 * i].head] < pos [edges [2 * i + 1].head]) {
        vater [v] = edges [2 * i].head;
        parent [v] = 2 * i;
      }
      else {
        vater [v] = edges [2 * i + 1].head;
        parent [v] = 2 * i + 1;
      }
    }
  }

  free (vert_pos);
  free (pos);
}


/****************************************************************************/
/* NAME: set_list                                                           */
/* FUNKTION: setzt die globalen Variablen                                   */
/* UEBERGABEPARAMETER: A_in1, A_out1, In1, Out1, order1, rank_count1,       */
/*                     max_rank1  wie in position                           */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.4.95                                                              */
/* LETZTE AENDERUNG AM: 24.4.95                                             */
/****************************************************************************/
static void set_list (int * A_in1, int * A_out1, int * In1, int * Out1,
                      INT_POINTER * order1, int * rank_count1, int max_rank1)
{
  A_in = A_in1;
  A_out = A_out1;
  In = In1;
  Out = Out1;
  order = order1;
  rank_count = rank_count1;
  max_rank = max_rank1;
}


/****************************************************************************/
/* NAME: mk_graph_list                                                      */
/* FUNKTION: erstellt Anf.-listen usw. aus Liste edges                      */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.4..95                                                             */
/* LETZTE AENDERUNG AM: 24.4.95                                             */
/****************************************************************************/
static void mk_graph_list ()
{
  int i;
  int * akt_in;
  int * akt_out;

  A_in = (int *) calloc (n + 1, sizeof (int));
  A_out = (int *) calloc (n + 1, sizeof (int));
  In = (int *) calloc (Kantenzahl, sizeof (int));
  Out = (int *) calloc (Kantenzahl, sizeof (int));
  akt_in = (int *) calloc (n, sizeof (int));
  akt_out = (int *) calloc (n, sizeof (int));
  if (akt_in == (int *) NULL || akt_out == (int*) NULL ||
      A_in == (int *) NULL || A_out == (int *) NULL ||
      In == (int *) NULL || Out == (int *) NULL) {
    printf ("Fehler mk_graph_list_pos\n");
    exit (1);
  }
  for (i = 0; i < Kantenzahl; i ++) {
    akt_in [edges [i].head] ++;
    akt_out [edges [i].tail] ++;
  }
  for (i = 1; i <= n; i ++) {
    A_in [i] = A_in [i - 1] + akt_in [i - 1];
    A_out [i] = A_out [i - 1] + akt_out [i - 1];
    akt_in [i - 1] = A_in [i - 1];
    akt_out [i - 1] = A_out [i - 1];
  }
  for (i = 0; i < Kantenzahl; i ++) {
    In [akt_in [edges [i].head] ++] = i;
    Out [akt_out [edges [i].tail] ++] = i;
  }
  free (akt_in);
  free (akt_out);
}



/****************************************************************************/
/* NAME: position                                                           */
/* FUNKTION: berechnet X-Position der Knoten                                */
/* UEBERGABEPARAMETER: A_in1, A_out1, In1, Out1, nodes, edges               */
/*                     Graph-Listen                                         */
/*                     alt_n Knotenzahl, alt_Kanz Kantenzahl, order         */
/*                     ordnung der Knoten, rank_count Anzahl der            */
/*                     Knoten in jedem level, max_rank hoechster level      */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 24.4.95                                                              */
/* LETZTE AENDERUNG AM: 24.4.95                                             */
/****************************************************************************/
void position (int * A_in1, int * A_out1, int * In1, int * Out1,
               NODE ** node_ptr, EDGE * alt_edges, int alt_n, int alt_Kanz,
               INT_POINTER * order1, int * rank_count1, int max_rank1)
{
  int v;
  NODE * alt_nodes;

  alt_nodes = * node_ptr;
  set_list (A_in1, A_out1, In1, Out1, order1, rank_count1, max_rank1);

  mk_aux_graph (alt_nodes, alt_edges, alt_n, alt_Kanz);

  feasible_tree (* node_ptr, alt_n);

  for (v = 0; v < alt_n; v ++) {
    nodes [v].position = alt_nodes [v].rank;
    nodes [v].Schleife = alt_nodes [v].Schleife;
  }

  mk_graph_list ();

  rank (A_in, A_out, In, Out, edges, nodes, Kantenzahl, n, vater, parent);

  * node_ptr = nodes;
}

