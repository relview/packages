#define _embedding_c_

#define EMBEDDING_FILE
#define PLANAR_DATA

#include "graph.h"
#include "embedding.h"
#include "planar.h"

#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <malloc.h>

/* NAME : embedding
 * FUNKTION : berechnet eine Einbettung fuer S((x,y)) jede Kante bekommt eine Nummer, mit der spaeter sortiert werden kann
 * UEBERGABEPARAMETER : Ecke (x,y), Seite t, Palmenadjazenz, Seiteninformation (alpha), 
 *                      Listen von darts (T, A), naechste freie Nummer, Array mit Vaetern
 *                      Matrix fuer Sortiernummern, Array fuer Bauminformation, 
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (28.10.1998)
 * LETZTE AENDERUNG AM : 29.10.1998
 */
void embedding (int x, int y, enum side t, p_adjList adj, char **alpha,
		p_genList T, p_genList A, int *cur_nr, int **sort_num, int *tree_edge_into,
		int *parent)
{
  p_genList Al = getNewGenList ();
  p_genList Ar = getNewGenList ();
  p_genList Tprime = getNewGenList ();
  p_genList Aprime = getNewGenList ();
  p_edge pEcke;
  p_intListNode pIter;
  p_genListNode gIter;
  int temp;

  /* determine the cycle C((x,y)) */
  int wk = y;
  int back_edge_into_w0;
  int w;
  int w0;

  /* printf ("\n\ntesting Segment S(%i,%i) which will be embedded on side %i\n",x,y,t); */

  tree_edge_into[y] = x;
  while ((temp = adj->aList[wk]->first->val) > wk) {
    tree_edge_into[temp] = wk;
    wk = temp;
  }

  w0 = adj->aList[wk]->first->val;
  back_edge_into_w0 = wk;

  /* process the subsegments */
  w = wk;
  clearGenList (T);
  pEcke = (p_edge) malloc (sizeof (edge));

  pEcke->from = wk;
  pEcke->to = w0;
  addLastGen (T, pEcke);

  while (w != x) {
    pIter = adj->aList[w]->first->next;		/* leave out first edge of node */
    while (pIter) {
      /* embed recursively */
      if (w < pIter->val) {
	/* a tree edge */
	enum side tprime = ((t == alpha[w][pIter->val]) ? left : right);

	embedding (w, pIter->val, tprime, adj, alpha, Tprime, Aprime, cur_nr, sort_num, tree_edge_into, parent);
      } else {
	/* a back edge */
	pEcke = (p_edge) malloc (sizeof (edge));

	pEcke->from = w;
	pEcke->to = pIter->val;
	addLastGen (Tprime, pEcke);
	pEcke = (p_edge) malloc (sizeof (edge));

	pEcke->from = pIter->val;
	pEcke->to = w;
	addLastGen (Aprime, pEcke);
      }

      /* update lists T, Al, Ar */

      if (t == alpha[w][pIter->val]) {
	concGenList (Tprime, T);
	concGenList (T, Tprime);
	concGenList (Al, Aprime);
      } else {
	assert (t == (1 - alpha[w][pIter->val]));
	concGenList (T, Tprime);
	concGenList (Aprime, Ar);
	concGenList (Ar, Aprime);
      }

      pIter = pIter->next;
    }

    /* compute w's adjecency list and prepare for next iteration */
    pEcke = (p_edge) malloc (sizeof (edge));

    pEcke->from = w;
    pEcke->to = tree_edge_into[w];
    addLastGen (T, pEcke);

    gIter = T->first;
    while (gIter) {
      /* printf ("Kante (%i,%i)\n",((p_edge) gIter->data)->from,((p_edge) gIter->data)->to); */
      assert (sort_num[((p_edge) gIter->data)->from][((p_edge) gIter->data)->to]==UNDEF); /* jeder nur ein Kreuz ;-) */
      sort_num[((p_edge) gIter->data)->from][((p_edge) gIter->data)->to] = (*cur_nr)++;
      gIter = gIter->next;
    }
    clearGenList (T);

    while (Al->size &&
	   ((p_edge) Al->last->data)->from == parent[w]) {
      pEcke = (p_edge) popLastGen (Al);
      addFirstGen (T, pEcke);
    }
    pEcke = (p_edge) malloc (sizeof (edge));

    pEcke->from = tree_edge_into[w];
    pEcke->to = w;
    addLastGen (T, pEcke);

    while (Ar->size &&
	   ((p_edge) Ar->first->data)->from == parent[w]) {
      pEcke = (p_edge) popFirstGen (Ar);
      addLastGen (T, pEcke);
    }

    w = parent[w];
  }

  /* prepare the output */
  clearGenList (A);
  concGenList (A, Ar);
  pEcke = (p_edge) malloc (sizeof (edge));

  pEcke->to = back_edge_into_w0;
  pEcke->from = w0;

  addLastGen (A, pEcke);
  concGenList (A, Al);

  /* free memory */
  delGenList (Al);
  delGenList (Ar);
  delGenList (Tprime);
  delGenList (Aprime);

}

/* NAME : computeEmbedding 
 * FUNKTION : Berechnet eine Einbettung und veraendert planarData->adj entsprechend
 * UEBERGABEPARAMETER : -
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (28.10.1998)
 * LETZTE AENDERUNG AM : 29.10.1998
 */
void computeEmbedding (void)
{
  p_genList T = getNewGenList ();
  p_genList A = getNewGenList ();
  p_genListNode gIter;
  p_intListNode pIter;
  int cur_nr = 0;
  int **sort_num = NULL;
  int *tree_edge_into = NULL;
  p_edge buckets;

  int i, j;

  assert (planarData.planar.adj != NULL &&
	  planarData.planar.preorder != NULL &&
	  planarData.planar.alpha != NULL);	/* sonst darf diese Prozedur nicht aufgerufen werden */

  tree_edge_into = (int *) malloc (sizeof (int) * planarData.planar.adj->size);
  sort_num = (int **) malloc (sizeof (int *) * planarData.planar.adj->size);

  for (i = 0; i < planarData.planar.adj->size; i++) {
    sort_num[i] = (int *) malloc (sizeof (int) * planarData.planar.adj->size);

    for (j = 0; j < planarData.planar.adj->size; j++)
      sort_num[i][j] = UNDEF;
  }

  embedding (0, 1, left, planarData.planar.adj, planarData.planar.alpha, T, A,
	     &cur_nr, sort_num, tree_edge_into, planarData.planar.parent);

  concGenList (T, A);
  gIter = T->first;
  while (gIter) {
    sort_num[((p_edge) gIter->data)->from][((p_edge) gIter->data)->to] = cur_nr++;
    gIter = gIter->next;
  }

  /* Fuehre Bucketsort durch und erstelle Embedding */
  buckets = (p_edge) malloc ((cur_nr + 2) * sizeof (edge));

  for (i = 0; i < planarData.planar.adj->size; i++) {
    pIter = planarData.planar.adj->aList[i]->first;
    while (pIter) {
      assert (sort_num[i][pIter->val] >= 0 && sort_num[pIter->val][i] >= 0); /* sonst stimmt die Einbettung-routine nicht */
      buckets[sort_num[i][pIter->val]].from = i;
      buckets[sort_num[i][pIter->val]].to = pIter->val;
      buckets[sort_num[pIter->val][i]].from = pIter->val;
      buckets[sort_num[pIter->val][i]].to = i;

      pIter = pIter->next;
    }
  }

  planarData.embedding.embedding = getNewAdjList (planarData.planar.adj->size);
  for (i = 0; i < cur_nr; i++) {
    addNewEdge (planarData.embedding.embedding, buckets[i].from, buckets[i].to);
  }

  /* Speicher freigeben */
  delGenList (T);
  delGenList (A);
  free (buckets);
  for (i = 0; i < planarData.planar.adj->size; i++)
    free (sort_num[i]);
  free (sort_num);
  free (tree_edge_into);
}

/* NAME : computeSimpleTriangulation 
 * FUNKTION : berechnet Triangulierung und canonical ordering, veraendert planarData.embedding
 * UEBERGABEPARAMETER : -
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (02.11.1998)
 * LETZTE AENDERUNG AM : 04.11.1998
 */
void computeSimpleTriangulation (void)
{
  int *old = (int *) malloc (sizeof (int) * planarData.planar.adj->size);
  int *visit = (int *) malloc (sizeof (int) * planarData.planar.adj->size);
  p_intSet Gk = getNewIntSet (planarData.planar.adj->size);
  p_intSet readylist = getNewIntSet (planarData.planar.adj->size);
  p_intListNode pIter, remIter;
  p_adjList adj = planarData.embedding.embedding;	/* shortcut, do not free memory afterwards */
  int k, vk, ci, cj, cl, cr, lu, ru;	/* explained in [K93], p.77 */
  int ci_alt;
  p_intListNode pci, pcj;	/* Zeiger auf Knoten ci,cj in irgendwelchen Listen */
  p_intSet tempSet = getNewIntSet (sizeof (int) * planarData.planar.adj->size);
  p_intList Ck_1 = getNewIntList ();	/* Front von C_{k-1} */
  p_intSet Ck_1Set = getNewIntSet (planarData.planar.adj->size);	/* same as above, unordered with O(1)-access */
  int ru0 = UNDEF;
  int lu1 = UNDEF;

  assert (adj);			/* has to exist */

  cj = ci = UNDEF;

  /* printIntArr ("preorder:", planarData.preorder, adj->size); */
  /* printAdjList (adj); */

  for (k = 0; k < adj->size; k++)
    old[k] = visit[k] = 0;

  /* Start with edge (0,1), which is always present in biconnected DFS-Graph */
  planarData.embedding.canonical = getNewIntList ();
  addLast (planarData.embedding.canonical, 0);
  addLast (planarData.embedding.canonical, 1);

  pIter = adj->aList[0]->first;
  while (pIter) {
    old[pIter->val]++;
    if (pIter->val == 1)
      intSetIncl (readylist, ru0 = prevClock (pIter)->val);	/* rightup(v0) */
    pIter = pIter->next;
  }
  pIter = adj->aList[1]->first;
  while (pIter) {
    old[pIter->val]++;
    if (pIter->val == 0)
      intSetIncl (readylist, lu1 = nextClock (pIter)->val);	/* leftup (v1) */
    pIter = pIter->next;
  }
  intSetIncl (Gk, 0);
  intSetIncl (Gk, 1);
  addLast (Ck_1, 0);
  addLast (Ck_1, 1);
  intSetIncl (Ck_1Set, 0);
  intSetIncl (Ck_1Set, 1);

  if (readylist->size && areNeighbours (adj, ru0, 1) && prevClockNode (adj, ru0, 0) != 1) {
    /* printf ("excl ru0\n"); */
    intSetExcl (readylist, ru0);
  }
  if (readylist->size && areNeighbours (adj, lu1, 0) && nextClockNode (adj, lu1, 1) != 0) {
    /* printf ("excl lu1\n"); */
    intSetExcl (readylist, lu1);
  }
  /* printf ("ru0 = %i, lu1 = %i\n", ru0, lu1); */
  assert (readylist->size);

  for (k = 2; k < adj->size; k++) {

    /* printf ("\n\n\n****************** Iteration k=%i ***********************************\n", k); 
    
    printf ("canonical so far:");
    printIntList (planarData.embedding.canonical);
    printf ("\n");
    printf ("readylist: ");
    printIntSet (readylist);
    printf ("\n");
    printf ("Front of Ck_1: ");
    printIntList (Ck_1); printIntSet (Ck_1Set);
    printf ("\n");
    printIntArr ("old  : ", old, adj->size);
    printIntArr ("visit: ", visit, adj->size);
    printf ("     : ");
    { 
      int i;
      for (i=0; i<adj->size; i++) {
	if ((i%10) == 0) printf ("| ");
	if (inList(planarData.embedding.canonical, i)) 
	  printf ("x "); 
	else 
	  printf ("%i ",old[i]-visit[i]);
      }
    }
    { 
      p_intListNode xIter,yIter;
      printf("\noutgoing front:");
      xIter = Ck_1->first;
      while (xIter) {
	if (countNeighboursIn (adj,xIter->val, Gk)<adj->aList[xIter->val]->size) {
	  printf ("%i:( ",xIter->val);
	  yIter = adj->aList[xIter->val]->first;
	  while (!isInIntSet(Gk,yIter->val))
	    yIter = nextClock(yIter);
	  while (isInIntSet(Gk,yIter->val))
	    yIter = nextClock(yIter);
	  while (!isInIntSet(Gk,yIter->val)) {
	    printf ("%i ",yIter->val);
	    yIter = nextClock(yIter);
	  }
	  printf (") ");
	}
	xIter = xIter->next;
      }
      printf ("\n");
    }
    printf ("Gk = ");
    printIntSet (Gk);
    printf ("\n");
    printAdjList (adj); */

    if (readylist->size == 0) {
      /* printf ("XXX XXX XXX XXX emergency vk needed now !!!\n"); */
      int cand;
      intSetClear (tempSet);
      for (ci = 0; ci < adj->size; ci++) {
	if (!isInIntSet (Gk, ci) && old[ci] == visit[ci] + 1)
	  intSetIncl (tempSet, ci);
      }

      assert (tempSet->size != 0);	/* how does control ever reach this ??? */

      if (tempSet->size == 1) {
	intSetIncl (readylist, tempSet->firstElem);	/* ohne Netz und doppelten Boden, sehr riskant... */
      } else {
	/* printf ("\ncandidates = ");
	 printIntSet (tempSet);
	 printf ("\n"); */

	cand = tempSet->firstElem;
	while (cand != NONE) {

	  while (cand != NONE && areNeighbours (adj, cand, 0) && !isInIntSet (Ck_1Set, nextClockNode (adj, 0, cand))) {
	    /* printf ("(k=%i) ignore candidate %i\n",k,cand); */
	    cand = tempSet->nextElem[cand];
	  }

	  /* while (cand != NONE && areNeighbours (adj, cand, 1) && !isInIntSet (Ck_1Set, prevClockNode (adj, 1, cand))) {
	    printf ("(k=%i) ignore2 candidate %i\n",k,cand);
	    cand = tempSet->nextElem[cand];
	  } */

	  if (cand == NONE)
	    break;

	  pIter = adj->aList[cand]->first;
	  while (pIter) {
	    if (isInIntSet (Ck_1Set, pIter->val)) {
	      remIter = adj->aList[pIter->val]->first;
	      while (remIter) {
		if (remIter->val == cand)
		  break;
		remIter = remIter->next;
	      }
	      if (!((isInIntSet (Ck_1Set, prevClock (remIter)->val)) ||
		    (isInIntSet (Ck_1Set, nextClock (remIter)->val)))) {
	      } else {
		intSetIncl (readylist, cand);
	      }
	    }
	    pIter = pIter->next;
	  }
	  cand = tempSet->nextElem[cand];
	}
      }

      /* following hack has unknown theoretical background */
      intSetClear (tempSet);
      cand = readylist->firstElem;
      while (cand != NONE) {
	if (areNeighbours(adj,cand,1))
	  intSetIncl (tempSet, cand);
	cand = readylist->nextElem[cand];
      }
      if (readylist->size>tempSet->size) {
	cand = tempSet->firstElem;
	while (cand != NONE) {
	  intSetExcl (readylist, cand);
	  cand = tempSet->nextElem[cand];
	}
      }

      /* printf ("readylist:");
      printIntSet (readylist);
      printf ("\n"); */
    }
    assert (readylist->size);

    vk = readylist->firstElem;
    intSetExcl (readylist, vk);

    addLast (planarData.embedding.canonical, vk);
    intSetIncl (Gk, vk);

    /* printf ("\nvk = %i\n", vk); */

    /* delete vl from readylist (if present) */
    pIter = adj->aList[vk]->first;
    while (pIter) {
      if (!isInIntSet (Gk, pIter->val)) {
	old[pIter->val]++;
	intSetExcl (readylist, pIter->val);
      }
      pIter = pIter->next;
    }

    /* compute ci,cj */

    pIter = adj->aList[vk]->first;
    while (pIter) {
      if (!isInIntSet (Ck_1Set, pIter->val))
	break;
      pIter = pIter->next;
    }

    if (pIter) {
      /* printf ("fall a\n"); */
      pIter = adj->aList[vk]->first;
      while (!isInIntSet (Ck_1Set, pIter->val) || isInIntSet (Ck_1Set, nextClock (pIter)->val))
	pIter = nextClock (pIter);
      ci = pIter->val;
      while (isInIntSet (Ck_1Set, pIter->val) || !isInIntSet (Ck_1Set, nextClock (pIter)->val))
	pIter = nextClock (pIter);
      cj = nextClock (pIter)->val;
    } else {
      /* Sonderbehandlung, da alle Nachbarn von vk auf Ck_1 */
      int b = true;

      /* printf ("fall b\n"); */

      intSetClear (tempSet);
      pIter = adj->aList[vk]->first;
      while (pIter) {
	intSetIncl (tempSet, pIter->val);
	pIter = pIter->next;
      }

      pIter = Ck_1->first;
      while (pIter) {
	if (isInIntSet (tempSet, pIter->val)) {
	  if (b) {
	    ci = pIter->val;
	    b = false;
	  } else {
	    cj = pIter->val;
	  }
	}
	pIter = pIter->next;
      }
    }

    /* printf ("found (ci,cj)=(%i,%i)\n", ci,cj); */
    ci_alt = ci;

    pci = Ck_1->first;
    while (pci && pci->val != ci) {
      pci = pci->next;
      assert (pci != NULL);	/* ci muss auf der Front von Ck_1 sein */
    }
    pcj = pci;
    while (pci && pcj->val != cj) {
      pcj = pcj->next;
      assert (pcj != NULL);	/* cj muss in der Front von Ck_1 sein */
    }

    assert (pci && pcj);

    if (ci != 0 && ci == cj && vk == leftUp (adj, ci, pci->prev->val)) {
      /* cj = ci; Befehl im Originalalgorithmus ueberfluessig */
      ci = pci->prev->val;
      pci = pci->prev;
    } else if (ci != 1 && ci == cj && vk == rightUp (adj, ci, pci->next->val)) {
      /* ci = cj; Befehl im Originalalgorithmus ueberfluessig */
      cj = pci->next->val;
      pcj = pci->next;
    }
    /* printf ("new (ci,cj)=(%i,%i)\n", ci,cj); */

    while (ci != 0) {
      pIter = adj->aList[ci]->first;
      while (pIter) {
	if (!isInIntSet (Gk, pIter->val))
	  break;
	pIter = pIter->next;
      }
      if (pIter != NULL)
	break;
      pci = pci->prev;
      ci = pci->val;
    }

    while (cj != 1) {
      pIter = adj->aList[cj]->first;
      while (pIter) {
	if (!isInIntSet (Gk, pIter->val))
	  break;
	pIter = pIter->next;
      }
      if (pIter != NULL)
	break;
      pcj = pcj->next;
      cj = pcj->val;
    }

    if (ci == cj) {
      if (ci == 1) {
	pci = pci->prev;
	ci = pci->val;
      } else if (ci == 0) {
	pcj = pcj->next;
	cj = pcj->val;
      } else {
	assert (false && false);	/* what the heck has happened ??? */
      }
    }
    /* add edges (ci...cj, vk), (vk, ci..cj) s.t. embedding stays valid (internally triconnected) */

    /* printf ("newer (ci,cj)=(%i,%i)\n", ci,cj); */

    remIter = adj->aList[vk]->first;
    while (remIter->val != ci_alt) {
      remIter = prevClock (remIter);
      assert (remIter != adj->aList[vk]->first);	/* Value not found, not possible */
    }

    pIter = pci;
    while (pIter != pcj->next) {

      /* printf ("neue Kante (%i,%i), remIter->val=%i\n", vk, pIter->val, remIter->val); */

      if (remIter->val != pIter->val) {
	/* Zunaechst Kanten von vk weg zu pIter->val */
	/* printf ("add after %i, %i (nextClock(remIter)->val=%i)\n", remIter->val, pIter->val, nextClock(remIter)->val); */
	addAfter (remIter, pIter->val);

	/* Nun Kanten von pIter->val weg */
	if (pIter->val == ci) {
	  addNewEdgeBefore (adj, pIter->val, vk, pIter->next->val);
	} else {
	  addNewEdgeAfter (adj, pIter->val, vk, pIter->prev->val);
	}

	/* printf ("neue Kante (%i,%i)\n", vk, pIter->val); */
      } else {
	remIter = prevClock (remIter);
	/* printf ("edge already there modified remIter->val=%i\n\n", remIter->val); */
      }

      pIter = pIter->next;
    }

    /* Ck_1 und Ck_1Set korrigieren */
    pIter = Ck_1->first;
    while (pIter->val != ci)
      pIter = pIter->next;
    assert (pIter);

    addAfter (pIter, vk);
    intSetIncl (Ck_1Set, vk);

    pIter = pIter->next->next;
    while (pIter != pcj) {
      remIter = pIter;
      pIter = pIter->next;
      intSetExcl (Ck_1Set, remIter->val);
      delNode (remIter);
      assert (pIter);
    }

    /* visit und readylist neu berechnen */

    cl = rightUp (adj, ci, pci->next->val);
    cr = leftUp (adj, cj, pcj->prev->val);
    lu = leftUp (adj, vk, ci);
    ru = rightUp (adj, vk, cj);

    /* Pruefen, ob vk Nachbarn ausserhalb von Gk hat */
    pIter = adj->aList[vk]->first;
    while (pIter) {
      if (!isInIntSet (Gk, pIter->val))
	break;
      pIter = pIter->next;
    }

    if (!pIter) {
      /* alle Nachbarn von vk sind auf Ck_1 */
      if (cl == cr)
	visit[cl]++;
    } else {
      /* es gibt Nachbarn von vk in G-Gk */
      if (cl == lu)
	visit[cl]++;
      if (cr == ru)
	visit[cr]++;
    }

    if (old[cl] == visit[cl] + 1 && !isInIntSet (Gk, cl))
      intSetIncl (readylist, cl);
    if (old[cr] == visit[cr] + 1 && !isInIntSet (Gk, cr))
      intSetIncl (readylist, cr);

    if (cl == cr) {
      if (old[lu] == visit[lu] + 1 && !isInIntSet (Gk, lu))
	intSetIncl (readylist, lu);
      if (old[ru] == visit[ru] + 1 && !isInIntSet (Gk, ru))
	intSetIncl (readylist, ru);
    }
    if (ru == cl && !isInIntSet (Gk, lu) && old[lu] == visit[lu] + 1) {
      intSetIncl (readylist, lu);
    }
    if (lu == cr && !isInIntSet (Gk, ru) && old[ru] == visit[ru] + 1) {
      intSetIncl (readylist, ru);
    }
  }

  free (old);
  free (visit);
  delIntSet (readylist);
  delIntList (Ck_1);
  delIntSet (Ck_1Set);
  delIntSet (tempSet);

}

/* NAME : computeEnhacedOrdering 
 * FUNKTION : berechnet lmc-ordering
 * UEBERGABEPARAMETER : -
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 10.02.1999
 */
void computeEnhacedOrdering (void)
{
  p_ordpartition part = getNewOrdPartition ();
  p_intListListNode oIter;
  p_intList newCandList = NULL;
  p_intList shortNewCandList = NULL;
  p_intList temp2;
  p_intList Ck_1 = getNewIntList ();	/* Front von C_{k-1} */
  p_intSet Ck_1Set = getNewIntSet (planarData.planar.adj->size);	/* same as above, unordered with O(1)-access */
  p_intSet Gk_1Set = getNewIntSet (planarData.planar.adj->size);	/* Knoten des Teilgraphen */
  p_intSet visited = getNewIntSet (planarData.planar.adj->size);
  p_intSet newPathSet = getNewIntSet (planarData.planar.adj->size);
  p_adjList adj = planarData.embedding.embedding;	/* shortcut, do not free memory afterwards */
  int *singleCandidate = (int *) malloc (sizeof (int) * adj->size);
  p_intSet vp_neigh = getNewIntSet (adj->size);
  p_intSet leftOfCl = getNewIntSet (adj->size);
  int t1, t2;
  int found;
  int counter;
  int node;
  int error = false;

  p_intListNode cl;
  p_intListNode cr, crl, crr;
  p_intListNode vIter, gIter, cIter, nIter;	/* virtual, general, circle, node -Iteratoren */

  /* printf("Einbettung:\n");
   * printAdjList (adj); */

  assert (adj);			/* has to exist */

  cr = (p_intListNode) NULL;

  initIntArr (singleCandidate, adj->size, 0);

  /* initialize Ck_1, Ck_1Set, Gk_1Set */
  addLast (Ck_1, 0);
  addLast (Ck_1, 1);
  intSetIncl (Ck_1Set, 0);
  intSetIncl (Ck_1Set, 1);
  intSetIncl (Gk_1Set, 0);
  intSetIncl (Gk_1Set, 1);

  /* initialize first values */
  newCandList = getNewIntList ();
  addLast (newCandList, 0);
  addLast (newCandList, 1);
  addLastOrdPart (part, newCandList);

  counter = 2;
  while (counter < adj->size) {
    found = false;
    /*printf ("\n\nCk_1 = ");
     * printIntList (Ck_1);
     * printf("\n");
     * printf ("Partition bisher (counter=%i):",counter);
     * printOrdPartition (part);
     * printf ("\n");    
     * printf ("\n\nBegin of new loop\n"); */

    /* Fall 1: Suche nach Pfad p=cl,v_1,...,v_p,cr so dass v_i keine Nachbarn auf Ck_1 haben und p>1 (p=1 -> Fall 2) */
    /*printf ("Fall 1\n"); */

    newCandList = getNewIntList ();

    cl = Ck_1->first;
    intSetClear (leftOfCl);

    while (cl->next) {		/* Suche ab Knoten 1 (=c_n) kann nicht erfolgreich sein, da der Graph biconnected ist */
      int v_base, v_next, v_temp, v_first;	/* Variablen zum Abwandern des Pfades v_1,...,v_p */

      if (cl->prev)
	intSetIncl (leftOfCl, cl->prev->val);
      found = false;
      v_base = cl->val;
      v_next = prevClockNode (adj, v_base, cl->next->val);
      v_first = v_next;
      clearIntList (newCandList);

      /* erster Knoten des Pfades darf nur genau einen Nachbarn auf Ck_1 haben */
      if (countNeighboursIn (adj, v_next, Ck_1Set) > 1) {
	cl = cl->next;
	continue;
      };

      /* Wandere entlang des Pfades */
      while (!neighboursIn (adj, v_next, Ck_1Set) || v_next == v_first) {
	addLast (newCandList, v_next);
	v_temp = v_next;
	v_next = prevClockNode (adj, v_next, v_base);
	v_base = v_temp;
      }

      if (neighboursIn (adj, v_next, leftOfCl)) {
	/* irgendwo aussen herum gewandert und links von cl gelandet --> etwas eingeschlossen */
	cl = cl->next;
	continue;
      }
      if (!isInIntSet (Ck_1Set, prevClockNode (adj, v_next, v_base))) {
	cl = cl->next;
	continue;
	/* eigentlich was fuer Fall 2 --> viel spaeter */
      }
      if (newCandList->size > 0) {
	/* Pfad gefunden, nun ueberpruefen, ob die Nachbarn von v_p auf Ck_1 in der Einbettung nebeneinander liegen */
	intSetClear (vp_neigh);
	addLast (newCandList, v_next);

	/* printf ("found path :");
	 * printIntList (newCandList);
	 * printf ("\n"); */

	cIter = adj->aList[v_next]->first;
	while (cIter) {
	  if (isInIntSet (Ck_1Set, cIter->val))
	    intSetIncl (vp_neigh, cIter->val);
	  cIter = cIter->next;
	}

	/* printf ("Nachbarn von v_next auf Ck_1: ");
	 * printIntSet (vp_neigh);
	 * printf ("\n"); */

	if (vp_neigh->size > 1) {
	  // int b = false;
	  cIter = adj->aList[v_next]->first;
	  while (!isInIntSet (vp_neigh, cIter->val))
	    cIter = cIter->next;
	  assert (cIter);
	  while (vp_neigh->size && isInIntSet (vp_neigh, cIter->val)) {
	    intSetExcl (vp_neigh, cIter->val);
	    cIter = nextClock (cIter);
	  }
	  if (vp_neigh->size == 0)
	    found = true;
	  else
	    found = false;	/* waren nicht aufeinanderfolgend */

	} else {
	  assert (vp_neigh->size == 1);		/* Es muss einen Nachbarn geben, naemlich cr */
	  found = true;
	}

	/* printf ("Kandidat: "); */
	/* printIntList (newCandList); */
	/* printf ("\n"); */

	/* Nun diverse Disqualifikationsgruende durcharbeiten */

	if (found) {
	  /* Falls v_p Nachbar von cl ist -> disqualifizieren ist was fuer Fall 2 */
	  if (areNeighbours (adj, cl->val, newCandList->last->val)) {
	    /* printf ("disqualified path, v_p neighbour of cl (v_p=newCandList->last->val suits case 2): ");
	     * printIntList (newCandList);
	     * printf ("\n"); */
	    if (newCandList->size > 2 && (!shortNewCandList || newCandList->size > shortNewCandList->size)) {
	      if (shortNewCandList)
		delIntList (shortNewCandList);
	      shortNewCandList = copyIntList (newCandList);
	    }
	    found = false;
	  }
	}
	if (found) {
	  /* Ueberpruefen, ob keine unbearbeiteten Knoten eingeschlossen wuerden (Sonderfall cl) 
	   * innere Knoten werden spaeter im Fall 1 betrachtet */
	  if (nextClockNode (adj, cl->val, newCandList->first->val) != cl->next->val) {
	    /* printf ("disqualified path (imbeds unprocessed node (special cl): ");
	     * printIntList (newCandList);
	     * printf ("\n"); */
	    found = false;
	  }
	}
	if (found) {
	  /* Ueberpruefen, ob keine unbearbeiteten Knoten eingeschlossen wuerden
	   * innere Knoten werden spaeter im Fall 1 || 2 betrachtet */
	  crl = cl;
	  while (crl && !areNeighbours (adj, crl->val, newCandList->last->val))
	    crl = crl->next;
	  assert (crl);		/* muss was gefunden haben */

	  assert (cl->next);
	  gIter = cl->next;
	  while (gIter && gIter->next && gIter->next->val != crl->val && gIter->val != crl->val) {
	    if (gIter->next->val != nextClockNode (adj, gIter->val, gIter->prev->val)) {
	      /* printf ("disqualified path (imbeds unprocessed nodes): ");
	       * printIntList (newCandList);
	       * printf ("\n"); */
	      found = false;
	      break;
	    }
	    gIter = gIter->next;
	  }
	}
	if (found) {
	  crl = cl;
	  while (crl && !areNeighbours (adj, crl->val, newCandList->last->val))
	    crl = crl->next;
	  assert (crl);		/* muss was gefunden haben */
	  if (crl->prev && prevClockNode (adj, crl->val, newCandList->last->val) != crl->prev->val) {
	    /* printf ("disqualified path (path embeds nodes (special case crl): ");
	     * printIntList (newCandList);
	     * printf ("\n"); */
	    found = false;
	    break;
	  }
	}
	if (found) {
	  crl = cl;
	  while (crl && !areNeighbours (adj, crl->val, newCandList->last->val))
	    crl = crl->next;
	  assert (crl);		/* muss was gefunden haben */
	  crr = Ck_1->last;
	  while (crr && !areNeighbours (adj, crr->val, newCandList->last->val))
	    crr = crr->prev;
	  assert (crr);		/* muss was gefunden haben */

	  if (crl->val != crr->val) {
	    /* printf ("vp hat Faecher\n"); */
	    while (crl && crl->val != crr->val) {
	      assert (crl->next);
	      if (nextClockNode (adj, crl->next->val, crl->val) != newCandList->last->val &&
		  (crl->next->next && nextClockNode (adj, crl->next->val, crl->val) != crl->next->next->val)) {
		/* printf ("disqualified path (fan of vp imbeds unprocessed nodes): ");
		 * printIntList (newCandList);
		 * printf ("\n"); */
		found = false;
		break;
	      }
	      crl = crl->next;
	    }
	  }
	}
	if (found) {
	  /* Pfad aufnehmen, Ck_1 und Ck_1Set korrigieren Gk_1Set reparieren 
	   * Falls Knoten des Pfades untereinander verbunden sind, und auf dem Pfad Abstand >2 haben, 
	   * ist es notwendig, diese Kanten in das Innere von Gk_1 zu verlegen. Dazu muss die Einbettung 
	   * leider geaendert werden.
	   */

	  /* Zunaechst die Einbettung ueberpruefen und ggf. modifizieren 
           * (bei 2 Knoten kann keine solche Kante existieren) */

	  if (newCandList->size > 2) {
	    /*printf ("ggf. Modifikation der Einbettung vorbereiten\n"); */
	    p_intListNode rIter;

	    intSetClear (newPathSet);

	    gIter = newCandList->first;
	    assert (gIter);

	    while (gIter) {
	      intSetIncl (newPathSet, gIter->val);
	      gIter = gIter->next;
	    }

	    gIter = newCandList->first;
	    while (gIter) {

	      if (gIter->prev && gIter->next) {
		vIter = adj->aList[gIter->val]->first;
		while (vIter && vIter->val != gIter->prev->val)
		  vIter = vIter->next;
		assert (vIter);	/* has to find something */

		rIter = vIter;
		vIter = nextClock (vIter);

		while (vIter->val != gIter->next->val) {
		  if (isInIntSet (newPathSet, vIter->val)) {
		    p_intListNode toDel;

		    /* change of embedding needed */
		    /* printf ("Kante (%i,%i) wird nach innen verlegt\n", gIter->val, vIter->val); */
		    addNewEdgeBefore (adj, gIter->val, vIter->val, rIter->val);
		    rIter = prevClock (rIter);
		    toDel = vIter;
		    vIter = nextClock (vIter);
		    delNode (toDel);
		  } else {
		    vIter = nextClock (vIter);
		  }
		}

	      } else if (gIter->next) {
		p_intList changed = getNewIntList ();

		vIter = adj->aList[gIter->val]->first;
		while (vIter && vIter->val != gIter->next->val)
		  vIter = vIter->next;
		assert (vIter);	/* has to find something */

		rIter = vIter;
		vIter = prevClock (vIter);

		while (vIter->val != gIter->next->val && !inList (changed, vIter->val)) {
		  if (isInIntSet (newPathSet, vIter->val) && vIter->val != gIter->next->val) {
		    p_intListNode toDel;

		    /* change of embedding needed */
		    /* printf ("Kante (%i,%i) wird nach innen verlegt\n", gIter->val, vIter->val); */
		    addNewEdgeAfter (adj, gIter->val, vIter->val, rIter->val);
		    rIter = nextClock (rIter);
		    addLast (changed, vIter->val);
		    toDel = vIter;
		    vIter = prevClock (vIter);
		    delNode (toDel);
		  } else {
		    vIter = prevClock (vIter);
		  }
		}
		delIntList (changed);
	      } else if (gIter->prev) {
		p_intList changed = getNewIntList ();

		vIter = adj->aList[gIter->val]->first;
		while (vIter && vIter->val != gIter->prev->val)
		  vIter = vIter->next;
		assert (vIter);	/* has to find something */

		rIter = vIter;
		vIter = nextClock (vIter);

		while (vIter->val != gIter->prev->val && !inList (changed, vIter->val)) {
		  if (isInIntSet (newPathSet, vIter->val) && vIter->val != gIter->prev->val) {
		    p_intListNode toDel;

		    /* change of embedding needed */
		    /* printf ("Kante (%i,%i) wird nach innen verlegt\n", gIter->val, vIter->val); */
		    addNewEdgeBefore (adj, gIter->val, vIter->val, rIter->val);
		    rIter = prevClock (rIter);
		    addLast (changed, vIter->val);
		    toDel = vIter;
		    vIter = nextClock (vIter);
		    delNode (toDel);
		  } else {
		    vIter = nextClock (vIter);
		  }
		}
	      } else {
		assert (false);	/* newCandList->size == 2 */
	      }
	      gIter = gIter->next;
	    }
	  }
	  /* Pfad aufnehmen, Ck_1 und Ck_1Set korrigieren Gk_1Set reparieren */
	  /* printf ("Reparatur von Ck_1\n"); */
	  temp2 = copyIntList (newCandList);

	  counter += temp2->size;
	  addLastOrdPart (part, temp2);

	  gIter = newCandList->first;
	  while (gIter) {
	    intSetIncl (Ck_1Set, gIter->val);
	    intSetIncl (Gk_1Set, gIter->val);
	    gIter = gIter->next;
	  }
	  cr = Ck_1->last;
	  while (!areNeighbours (adj, newCandList->last->val, cr->val))
	    cr = cr->prev;

	  replaceChain (cl, cr, newCandList);

	  gIter = newCandList->first;
	  while (gIter) {
	    intSetExcl (Ck_1Set, gIter->val);
	    gIter = gIter->next;
	  }

	  delIntList (newCandList);
	  newCandList = NULL;
	}
      }
      if (found)
	break;
      cl = cl->next;
    }

    if (newCandList)
      delIntList (newCandList);
    newCandList = NULL;

    if (found)
      continue;

    /* Fall 1b */
    /* speziellen disqualifizierten Pfad aufnehmen lassen */
    if (shortNewCandList) {
      /* printf ("Spezialfall, shortNewCandList=");
       * printIntList (shortNewCandList);
       * printf ("\n"); */
      assert (shortNewCandList->size > 2);
      crl = Ck_1->first;
      while (crl && (!areNeighbours (adj, crl->val, shortNewCandList->last->val) ||
		     areNeighbours (adj, crl->val, shortNewCandList->first->val)))
	crl = crl->next;
      assert (crl);
      /* printf ("verbinde Knoten %i und %i\n",crl->val,shortNewCandList->last->prev->val); */
      addNewEdgeAfter (adj, shortNewCandList->last->prev->val, crl->val, shortNewCandList->last->val);
      addNewEdgeBefore (adj, crl->val, shortNewCandList->last->prev->val, shortNewCandList->last->val);
      delIntList (shortNewCandList);
      shortNewCandList = NULL;
      continue;
    }
    /* Fall 2 nur durchfuehren, wenn Suche in Fall 1 erfolglos */
    /* Suche nach Einzelknoten, deren Anfuegen an die Partitionsliste keine unbehandelten Knoten
     * im Kreis Ck_1 einschliesst, alle Kandidaten berechnen und den waehlen, der bisher am haeufigsten
     * Kandidat war */

    /* printf ("\nFall 2\n"); */
    newCandList = getNewIntList ();
    intSetClear (visited);
    cIter = Ck_1->first;
    while (cIter) {
      nIter = adj->aList[cIter->val]->first;
      while (nIter) {
	if (!isInIntSet (Gk_1Set, nIter->val) && !isInIntSet (visited, nIter->val)) {
	  assert (countNeighboursIn (adj, nIter->val, Ck_1Set) >= 1);
	  /* what has happened otherwise nIter->val and cIter->val are neighbours! */

	  if (countNeighboursIn (adj, nIter->val, Ck_1Set) > 1) {
	    int node;

	    intSetIncl (visited, nIter->val);	/* jeden Knoten pro Durchlauf nur einmal untersuchen */

	    intSetClear (vp_neigh);	/* Soll Nachbarn von nIter->val aufnehmen */
	    gIter = adj->aList[nIter->val]->first;
	    while (gIter) {
	      intSetIncl (vp_neigh, gIter->val);
	      gIter = gIter->next;
	    }

	    cl = Ck_1->first;
	    while (cr && !isInIntSet (vp_neigh, cl->val))
	      cl = cl->next;

	    cr = Ck_1->last;
	    while (cr && !isInIntSet (vp_neigh, cr->val))
	      cr = cr->prev;
	    assert (cr && cl && (cl != cr));

	    /*printf ("has more than two neighbours on Ck_1, cl = %i cr = %i\n",cl->val,cr->val); */

	    gIter = cl;

	    found = true;
	    while (gIter != cr) {
	      /* printf ("checking gIter->val = %i  ",gIter->val); */
	      gIter = gIter->next;
	      node = nextClockNode (adj, gIter->val, gIter->prev->val);
	      /* printf ("node = %i\n",node); */
	      if (node != nIter->val &&
		  !isInIntSet (Ck_1Set, node)) {
		found = false;
		/* printf ("Kandidat %i ungeeignet\n",nIter->val); */
		break;		/* Kandidat ungeeignet */
	      }
	    }

	    if (found) {
	      /* pruefen, ob unbearbeitete Knoten eingeschlossen werden */
	      p_intListNode testIter = adj->aList[nIter->val]->first;

	      while (testIter && testIter->val != cl->val)
		testIter = testIter->next;
	      assert (testIter);	/* es muss etwas gefunden worden sein */

	      gIter = cl;
	      while (gIter != cr) {
		if (gIter->val == testIter->val)
		  testIter = prevClock (testIter);
		gIter = gIter->next;
	      }

	      if (testIter->val != gIter->val) {
		found = false;
		/* printf ("Kandidat %i disqualifiziert, imbeds nodes\n", nIter->val); */
	      }
	    }
	    if (found) {
	      /* nIter->val ist geeigneter Einzelkandidat, in Partition aufnehmen 
	       * sowie Ck_1, Ck_1Set, Gk_1Set reparieren */

	      addLast (newCandList, nIter->val);
	      singleCandidate[nIter->val]++;
	      found = false;
	    }
	  }
	}
	nIter = nIter->next;
      }
      cIter = cIter->next;
    }

    if (newCandList->size) {
      /* Kandidaten fuer Fall 2 auswerten */
      int max = 0;
      int maxnode = 0;
      p_intList temp = getNewIntList ();

      /* printf ("Kandidaten fuer Fall 2 : "); */
      /* printIntList (newCandList);printf ("\n"); */
      nIter = newCandList->first;
      while (nIter) {
	if (singleCandidate[nIter->val] > max) {
	  maxnode = nIter->val;
	  max = singleCandidate[nIter->val];
	}
	nIter = nIter->next;
      }

      cl = Ck_1->first;
      while (cl && !areNeighbours (adj, cl->val, maxnode)) {
	cl = cl->next;
      }
      cr = Ck_1->last;
      while (cr && !areNeighbours (adj, cr->val, maxnode)) {
	cr = cr->prev;
      }
      assert (cl);
      assert (cr);		/* beide Suchen muessen erfolgreich sein */

      addLast (temp, maxnode);
      intSetIncl (Gk_1Set, maxnode);
      intSetIncl (Ck_1Set, maxnode);
      replaceChain (cl, cr, temp);
      gIter = temp->first;
      while (gIter) {
	intSetExcl (Ck_1Set, gIter->val);
	gIter = gIter->next;
      }
      clearIntList (temp);
      addLast (temp, maxnode);
      counter += temp->size;
      addLastOrdPart (part, temp);
      /* printf ("partition " );
       * printOrdPartition (part);
       * printf ("\n"); */
      found = true;
    }
    delIntList (newCandList);
    newCandList = NULL;

    if (found)
      continue;
    /* Fall 3 nur durchfuehren, wenn Suche in Fall 1&2 erfolglos */
    /* Graphen geeignet ergaenzen, damit Fall 1 oder Fall 2 anschlaegt */

    /* Fall 3.1: Suche nach Pfaden mit Knoten vom Grad 2, die Ck_1 verlassen 
     *           und mindestens Laenge 2 haben */

    /* printf ("\nFall 3.1\n"); */
    cIter = Ck_1->first;
    while (cIter && !found) {
      if (countNeighboursIn (adj, cIter->val, Gk_1Set) != degNode (adj, cIter->val)) {
	/* Es gibt Nachbarn ausserhalb von Gk_1 */

	nIter = adj->aList[cIter->val]->first;
	while (nIter && !found) {
	  if (!isInIntSet (Ck_1Set, nIter->val) && (degNode (adj, nIter->val) == 2)) {
	    /*printf ("%i-> (%i has deg 2)\n",cIter->val,nIter->val); */
	    if (degNode (adj, nextClockNode (adj, nIter->val, cIter->val)) == 2) {
	      int lastChainNode = nextClockNode (adj, nIter->val, cIter->val);

	      t1 = nIter->val;
	      while (degNode (adj, t2 = nextClockNode (adj, lastChainNode, t1)) == 2) {
		t1 = lastChainNode;
		lastChainNode = t2;
	      }
	      /* found path with len>=2 , nun pruefen, ob der "geerdet" werden kann */
	      if (cIter->prev && prevClockNode (adj, cIter->val, nIter->val) == cIter->prev->val) {
		/* printf ("add edge %i, %i\n", lastChainNode, cIter->prev->val); */
		addNewEdgeBefore (adj, cIter->prev->val, lastChainNode, cIter->val);
		addNewEdgeBefore (adj, lastChainNode, cIter->prev->val, t2);
		found = true;
		break;
	      } else if (cIter->next && nextClockNode (adj, cIter->val, nIter->val) == cIter->next->val) {
		/*printf ("add edge %i, %i\n", lastChainNode, cIter->next->val); */
		addNewEdgeAfter (adj, cIter->next->val, lastChainNode, cIter->val);
		addNewEdgeAfter (adj, lastChainNode, cIter->next->val, t2);
		found = true;
		break;
	      } else
		break;

	    }
	  }
	  nIter = nIter->next;
	}
      }
      cIter = cIter->next;
    }

    if (found)
      continue;
    /* Fall 3.2 */
    /* Suche einen geeigneten Nachbarn von Ck_1, 
     * der nur einen Nachbarn auf Ck_1 hat und dessen Kante zu Ck_1 
     * direkter Nachfolger oder Vorgaenger einer Kante zu Ck_1 ist,
     * und verbinde diesen mit einem Knoten auf Ck_1 */

    cIter = Ck_1->first;
    while (cIter->next) {
      /* base cIter->val */

      node = prevClockNode (adj, cIter->val, cIter->next->val);
      /*printf ("checking node %i with %i neighbours on Ck_1\n", node, countNeighboursIn(adj, node, Ck_1Set)); */

      if (countNeighboursIn (adj, node, Ck_1Set) == 1) {
	/*printf ("connecting (%i,%i)\n", node, cIter->next->val); */
	found = true;
	addNewEdgeBefore (adj, node, cIter->next->val, cIter->val);
	addNewEdgeAfter (adj, cIter->next->val, node, cIter->val);
	break;
      }
      /* base cIter->next->val */
      node = nextClockNode (adj, cIter->next->val, cIter->val);
      /*printf ("checking node %i with %i neighbours on Ck_1\n", node, countNeighboursIn(adj, node, Ck_1Set)); */

      if (countNeighboursIn (adj, node, Ck_1Set) == 1) {
	found = true;
	/*printf ("connecting (%i,%i)\n", node, cIter->val); */
	addNewEdgeBefore (adj, cIter->val, node, cIter->next->val);
	addNewEdgeAfter (adj, node, cIter->val, cIter->next->val);
	break;
      }
      cIter = cIter->next;
    }

    if (found)
      continue;

    /* Falls das Programm hier ankommt, kann der Graph nicht gezeichnet werden, 
     * weil die Ordnung nicht komplett berechnet werden konnte. Ein Fall 3.x muss 
     * dann angefuegt werden, der Graphen dieser Art behandelt und eine Kante anfuegt, 
     * damit Fall 1 oder Fall 2 etwas finden. */

    printf ("\n\n*************************************************************\n");
    printf ("***** planar graph drawing failed, algorithm incomplete *****\n");
    printf ("*****       drawings is stored in /tmp/planar.log       *****\n");
    printf ("*****       send it to sul@informatik.uni-kiel.de       *****\n");
    printf ("*************************************************************%c%c%c\n",7,7,7);
    printf ("running out of drawing ideas :-( counter=%i/%i\npartition so far:", counter, adj->size);
    printOrdPartition (part);
    printf ("\n");
    printf ("Circle Ck_1 so far: ");
    printIntList (Ck_1);
    printf ("\n");
    error = true;

    delOrdPartition  (part);
    delIntList (Ck_1);
    delIntSet (Ck_1Set);
    delIntSet (Gk_1Set);
    delIntSet (visited);
    delIntSet (vp_neigh);
    delIntSet (newPathSet);
    delIntSet (leftOfCl);
    free (singleCandidate);
    
    return;
  }

  planarData.embedding.ordpart = part;

  /* zum Schluss noch das Ranking berechnen */
  planarData.embedding.ranking = (int *) malloc (adj->size * sizeof (int));

  counter = 0;
  oIter = part->first;
  while (oIter) {
    gIter = oIter->data->first;
    while (gIter) {
      planarData.embedding.ranking[gIter->val] = counter;
      gIter = gIter->next;
    }
    counter++;
    oIter = oIter->next;
  }

  delIntList (Ck_1);
  delIntSet (Ck_1Set);
  delIntSet (Gk_1Set);
  delIntSet (visited);
  delIntSet (vp_neigh);
  delIntSet (newPathSet);
  delIntSet (leftOfCl);
  free (singleCandidate);
}

/* NAME : ConvertTriangularOrdering2EnhacedOrdering
 * FUNKTION : einfache konvertierung der Ordnungen
 * UEBERGABEPARAMETER : -
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (24.02.1999)
 * LETZTE AENDERUNG AM : 24.02.1999
 */
void ConvertTriangularOrdering2EnhacedOrdering (void)
{
  p_intListNode gIter;
  p_intList list;
  int counter;
  p_intListListNode oIter;

  assert (planarData.embedding.ordpart == NULL);
  assert (planarData.embedding.canonical);

  planarData.embedding.ordpart = getNewOrdPartition ();

  gIter = planarData.embedding.canonical->first;

  list = getNewIntList ();
  addLast (list, gIter->val);
  gIter = gIter->next;
  addLast (list, gIter->val);
  gIter = gIter->next;

  addLastOrdPart (planarData.embedding.ordpart, list);

  while (gIter) {
    list = getNewIntList ();
    addLast (list, gIter->val);
    addLastOrdPart (planarData.embedding.ordpart, list);
    gIter = gIter->next;
  }

  planarData.embedding.ranking = (int *) malloc (planarData.embedding.embedding->size * sizeof (int));

  counter = 0;
  oIter = planarData.embedding.ordpart->first;
  while (oIter) {
    gIter = oIter->data->first;
    while (gIter) {
      planarData.embedding.ranking[gIter->val] = counter;
      gIter = gIter->next;
    }
    counter++;
    oIter = oIter->next;
  }

}
