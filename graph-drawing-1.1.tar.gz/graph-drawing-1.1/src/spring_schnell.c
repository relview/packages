#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global-sme.h"
#include "spring_schnell.h"

/* modulglobale Variablen */

static S_EDGE * edges;
static S_NODE * nodes;
static int width;
static int height;
static int min_x;
static int max_x;
static int min_y;
static int max_y;
static int n;
static int Kantenzahl;
static int double_count; /* n Knotenzahl, double_count Zahl der */
static float temperatur;            /* hin und her Kanten */


/****************************************************************************/
/* NAME: make_graph_schnell                                                 */
/* FUNKTION: liest Relation und erstellt daraus Kantenliste fuer            */
/*           spring_schnell                                                 */
/* UEBERGABEPARAMETER: rel_name Name der Relation                           */
/*                     edges Kantenliste (wird hier initialisiert)          */
/*                     n Knotenzahl, Kanz Kantenzahl                        */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 5.7.95                                                               */
/* LETZTE AENDERUNG AM: 5.7.95                                              */
/****************************************************************************/
void make_graph_schnell (KureRel * impl, S_EDGE ** edges, int * n, int * Kanz,
                         int * double_count)
{
	int lines = kure_rel_get_rows_si (impl);
	int columns = kure_rel_get_cols_si (impl);

	int i;
	int j;
	int akt_bot;
	int akt_top;
	int vars_zeilen = kure_rel_get_vars_rows (impl);
	int vars_spalten = kure_rel_get_vars_cols (impl);

	if ( !kure_is_hom (impl, NULL)) {
		g_warning ("make_graph_schnell: Relation is not homogeneous.");
	} else {
		* n = lines;
		* Kanz = 0;
		for (i = 0; i < lines; i ++)
			for (j = 0; j < columns; j ++)
				if (kure_get_bit_fast_si (impl, i,j,vars_zeilen, vars_spalten))
					//if (get_rel_bit (rel, j, i, vars_zeilen, vars_spalten) != 0)
					(* Kanz) ++;
		* edges = (S_EDGE *) calloc (* Kanz, sizeof (S_EDGE));

		if (* edges == NULL) {
			printf ("Fehler make_graph\n");
			exit (0);
		}

		akt_bot = 0;
		akt_top = * Kanz;
		* double_count = 0;

		for (i = 0; i < lines; i ++)
			for (j = 0; j < columns; j ++)
				if (kure_get_bit_fast_si (impl, i,j, vars_zeilen, vars_spalten)) {
					//if (get_rel_bit (rel, j, i, vars_zeilen, vars_spalten) != 0) {
					if (i < j && kure_get_bit_fast_si (impl, i,j, vars_zeilen, vars_spalten)) {
						//&& get_rel_bit (rel, i, j, vars_zeilen, vars_spalten) != 0) {
						/* wenn auch umgekehrte */
						/* Kante existiert, wird */
						(* edges) [-- akt_top].tail = i;
						/* diese Kante ans Ende der */
						(* edges) [akt_top].head = j;
						/* Liste eingetragen */
						(* double_count) ++;
						/* double_count zaehlt diese Kanten */
					} else {
						(* edges) [akt_bot].tail = i;
						(* edges) [akt_bot ++].head = j;
					}
				}
	}
}


/****************************************************************************/
/* NAME: spring_schnell                                                     */
/* FUNKTION: berechnet Koordinaten fuer die Knoten                          */
/* UEBERGABEPARAMETER: rel Name der Relation, breite und hoehe des Fensters */
/* RUECKGABEWERT: graphlistptr Zeiger auf Graphen                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 14.6.95                                                              */
/* LETZTE AENDERUNG AM: 5.7.95                                              */
/****************************************************************************/
graphlistptr spring_schnell (KureRel * impl, int breite, int hoehe)
{
  int i;
  float area;
  graphlistptr gl;

  make_graph_schnell (impl, & edges, & n, & Kantenzahl, & double_count);
  alloc_glob ();
  area = AREA; /* im Original-Algorithmus Breite*Hoehe des Fensters */
  k = sqrt (area / n) ;

  initial_positions (nodes, n);

  for (i = 0; (i < ITERATIONS); i ++) {

      repulsive (nodes, n, k);
    /* Abstossungskraefte berechnen */

      attraktive (nodes, edges, Kantenzahl);
    /* Anziehungskraefte berechnen */

      limit (temperatur, nodes, n);
    /* displacement auf Grenzueberschr. pruefen */

      temperatur = cool (temperatur, i);
  }
  enlarge (breite, hoehe);

  gl = spring_schnell_to_graph (UNKNOWN_GRAPH_NAME);

  free (nodes);
  free (edges);

  return (gl);
}

/****************************************************************************/
/* NAME: repulsive                                                          */
/* FUNKTION: berechnet die Abstossungskraefte zwischen den Knoten           */
/* UEBERGABEPARAMETER: nodes Knoten, n Knotenzahl, kk radius in dem         */
/*                     Abstossungskraefte berechnet werden                  */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 14.6.95                                                              */
/* LETZTE AENDERUNG AM: 14.6.95                                             */
/****************************************************************************/
void repulsive (S_NODE * nodes, int n, int kk)
{
  int v;
  int u;
  float delta_laenge;
  float delta_x;
  float delta_y;
  float temp;

  k = kk; /* damit kleine Graphen nicht so weit auseinander driften */

  for (v = 0; v < n; v ++) {
    nodes [v].displ_x = 0;
    nodes [v].displ_y = 0;
    for (u = 0; u < n; u ++)
      if (u != v) {
        delta_x = nodes [v].x_pos - nodes [u].x_pos;
        delta_y = nodes [v].y_pos - nodes [u].y_pos;
        delta_laenge = laenge (delta_x, delta_y);
        if (delta_laenge == 0) {
          delta_x = (float) u / n - 0.5;
          delta_y = (float) u / n - 0.5;
          delta_laenge = 10;
        }
        if (delta_laenge <= 2 * k) {
          delta_x /= delta_laenge;
          delta_y /= delta_laenge;
          temp = f_rep (delta_laenge);
          nodes [v].displ_x += delta_x * temp;
          nodes [v].displ_y += delta_y * temp;
        }
      }
  }
}


/****************************************************************************/
/* NAME: attraktive                                                         */
/* FUNKTION: berechnet Anziehungskraefte                                    */
/* UEBERGABEPARAMETER: nodes Knoten, edges Kanten, Kantenzahl               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 14.6.95                                                              */
/* LETZTE AENDERUNG AM: 6.7.95                                              */
/****************************************************************************/
void attraktive (S_NODE * nodes, S_EDGE * edges, int Kantenzahl)
{
  int u;
  int v;
  int e;
  float delta_x;
  float delta_y;
  float delta_laenge;
  float temp;

  for (e = 0; e < Kantenzahl; e ++) {
    v = edges [e].head;
    u = edges [e].tail;
    delta_x = nodes [v].x_pos - nodes [u].x_pos;
    delta_y = nodes [v].y_pos - nodes [u].y_pos;
    delta_laenge = laenge (delta_x, delta_y);
    if (delta_laenge != 0) {
      delta_x /= delta_laenge;
      delta_y /= delta_laenge;
      temp = f_attr (delta_laenge);
      nodes [v].displ_x -= delta_x * temp;
      nodes [v].displ_y -= delta_y * temp;
      nodes [u].displ_x += delta_x * temp;
      nodes [u].displ_y += delta_y * temp;
    }
  }
}


/****************************************************************************/
/* NAME: limit                                                              */
/* FUNKTION: beschraenkt das displacement auf maximale Groesse bzgl.        */
/*           Temperatur  und Fenstergroesse und berechnet dann die          */
/*           neue Position der Knoten                                       */
/* UEBERGABEPARAMETER: temperatur, nodes Knoten, n Knotenzahl               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 14.6.95                                                              */
/* LETZTE AENDERUNG AM: 14.6.95                                             */
/****************************************************************************/
static void limit (float temperatur, S_NODE * nodes, int n)
{
  int v;
  float displ_laenge;

  for (v = 0; v < n; v ++) {
    /* begrenzen bzgl. temperatur */
    displ_laenge = laenge (nodes [v].displ_x, nodes [v].displ_y);
    if (displ_laenge != 0) {
      nodes [v].displ_x /= displ_laenge;
      nodes [v].displ_y /= displ_laenge;
      displ_laenge = Min (displ_laenge, temperatur);
      nodes [v].x_pos += nodes [v].displ_x * displ_laenge;
      nodes [v].y_pos += nodes [v].displ_y * displ_laenge;
    }

    /* begrenzen um zu grosse Streuung der Komponenten zu verhindern */

    if (temperatur > 100) {
      nodes [v].x_pos = Max (min_x, nodes [v].x_pos);
      nodes [v].x_pos = Min (max_x, nodes [v].x_pos);
      nodes [v].y_pos = Max (min_y, nodes [v].y_pos);
      nodes [v].y_pos = Min (max_y, nodes [v].y_pos);
    }
  }
}


/****************************************************************************/
/* NAME: cool                                                               */
/* FUNKTION: verringert die Temperatur nach jeder Iteration                 */
/*           (Temperatur heisst hier max. Laenge des displacements)         */
/* UEBERGABEPARAMETER: t alte Temperatur, i Nr. der Iteration               */
/* RUECKGABEWERT: neue Temperatur                                           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 14.6.95                                                              */
/* LETZTE AENDERUNG AM: 14.6.95                                             */
/****************************************************************************/
static int cool (float t, int i)
{
  static int step = INIT_TEMP / (PHASE_1 + 1);

  if (i < PHASE_1)
    /* lineare Senkung der Temperatur in der */
    /* erste Phase der Iterationen */
    return (t - step);
  else if (i < PHASE_2)
    return (MID_TEMP);
  else
    return (LOW_TEMP);
}


/****************************************************************************/
/* NAME: laenge                                                             */
/* FUNKTION: berechnet Laenge eines 2-dim. Vektors                          */
/* UEBERGABEPARAMETER: x,y Koordinaten eines 2-dim. Vektors                 */
/* RUECKGABEWERT: Laenge des Vektors                                        */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 14.6.95                                                              */
/* LETZTE AENDERUNG AM: 14.6.95                                             */
/****************************************************************************/
float laenge (float x, float y)
{
  float res;

  res = sqrt (x * x + y * y);
  return (res);
}


/****************************************************************************/
/* NAME: initial_positions                                                  */
/* FUNKTION: berechnet eine initiale Verteilung der Knoten                  */
/* UEBERGABEPARAMETER: nodes Knoten, n Kantenzahl                           */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 15.6.95                                                              */
/* LETZTE AENDERUNG AM: 15.6.95                                             */
/****************************************************************************/
static void initial_positions (S_NODE * nodes, int n)
{
  int v;
  int x;
  int y;
  int d;

  d = 1000 / sqrt (n);
  v = 0;
  y = 0;
  x = 0;
  while (v < n) {
    nodes [v].x_pos = x;
    nodes [v].y_pos = y;
    v ++;
    if (x + d > 1000) {
      x = 0;
      y += d;
    } else
      x += d;
  }
}


/****************************************************************************/
/* NAME: alloc_glob                                                         */
/* FUNKTION: reserviert Speicherplatz fuer bzw. init. globale Variablen     */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 15.6.95                                                              */
/* LETZTE AENDERUNG AM: 15.6.95                                             */
/****************************************************************************/
static void alloc_glob ()
{
  nodes = (S_NODE *) calloc (n, sizeof (NODE));
  if (nodes == (S_NODE *) NULL) {
    printf ("Fehler make_graph_list\n");
    exit (0);
  }
  width = 1000 ;
  height = 1000;
  temperatur = INIT_TEMP;
  min_x = RAND;
  max_x = width - RAND;
  min_y = RAND;
  max_y = height - RAND;
}


/****************************************************************************/
/* NAME: f_rep                                                              */
/* FUNKTION: berechnet die Abstossungskraefte zwischen zwei Knoten          */
/* UEBERGABEPARAMETER: delta Entfernung der beiden Knoten                   */
/* RUECKGABEWERT: Abstossungskraefte                                        */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 15.6.95                                                              */
/* LETZTE AENDERUNG AM: 15.6.95                                             */
/****************************************************************************/
float f_rep (float delta)
{
  return  (k * k) / delta;
}


/****************************************************************************/
/* NAME: f_attr                                                             */
/* FUNKTION: berechnet die Anziehungskraefte zwischen zwei Knoten           */
/* UEBERGABEPARAMETER: delta Entfernung der beiden Knoten                   */
/* RUECKGABEWERT: Anziehungskraefte                                         */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.6.95                                                              */
/* LETZTE AENDERUNG AM: 20.6.95                                             */
/****************************************************************************/
float f_attr (float delta)
{
  return (delta * delta) / k;
}


/****************************************************************************/
/* NAME: enlarge                                                            */
/* FUNKTION: bringt Koordinaten auf einheitliche Groesse                    */
/* UEBERGABEPARAMETER: breite und hoehe des Fensters                        */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 16.6.95                                                              */
/* LETZTE AENDERUNG AM: 16.6.95                                             */
/****************************************************************************/
static void enlarge (int breite, int hoehe)
{
  int i;
  float x_min;
  float x_max;
  float y_min;
  float y_max;
  float faktor;
  float displacement;

  x_min = nodes [0].x_pos;
  y_min = nodes [0].y_pos;
  x_max = x_min;
  y_max = y_min;
  for (i = 1; i < n; i ++) {
    if (nodes [i].x_pos < x_min)
      x_min = nodes [i].x_pos;
    else if (nodes [i].x_pos > x_max)
      x_max = nodes [i].x_pos;
    if (nodes [i].y_pos < y_min)
      y_min = nodes [i].y_pos;
    else if (nodes [i].y_pos > y_max)
      y_max = nodes [i].y_pos;
  }
  /* x_max, x_min usw. sind die tatsechlich vorkommenden minimalen bzw. */
  /* maximalen Werte der X- bzw. Y-Koordinaten */

  if (x_max - x_min >= 1 || y_max - y_min >= 1)
    faktor =
      Min ((float) breite / (x_max - x_min), (float) hoehe / (y_max - y_min));
  else
    faktor = 1;

  displacement = x_min * faktor ;
  for (i = 0; i < n; i ++)
    nodes [i].x_pos = (nodes [i].x_pos * faktor) - displacement;
  displacement = y_min * faktor ;
  for (i = 0; i < n; i ++)
    nodes [i].y_pos = (nodes [i].y_pos * faktor) - displacement;
}

/****************************************************************************/
/* NAME: spring_schnell_to_graph                                            */
/* FUNKTION: speichert Koordinaten des Graphen                              */
/* UEBERGABEPARAMETER: name Name der Relation                               */
/* RUECKGABEWERT: Zeiger auf Graphen                                        */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 4.7.95                                                               */
/* LETZTE AENDERUNG AM: 12.7.95                                             */
/****************************************************************************/
graphlistptr spring_schnell_to_graph (char * name)
{
  int i;
  Graph * gr;
  char number_name [64];
  nodelistptr node_ptr;
  edgelistptr edge_ptr;
  graphlistptr gl;

  gl = mk_graph (name, NORMAL);

  if (gl != (graphlistptr) NULL) {
    gr = & (gl->graph);

    for (i = 0; i < n; i ++) {
      sprintf (number_name, "%d", (i + 1));
      node_ptr = make_node (number_name,
                            (int) nodes [i].x_pos + DEFAULT_DIM,
                            (int) nodes [i].y_pos + DEFAULT_DIM,
                            DEFAULT_DIM, VISIBLE);
      if (node_ptr != (nodelistptr) NULL)
        append_node (gr, node_ptr);
    }
    for (i = 0; i < Kantenzahl; i ++) {
      edge_ptr =
        make_edge ("", edges [i].tail + 1, edges [i].head + 1,VISIBLE);
      append_edge (gr, edge_ptr);
    }
  }
  return (gl);
}
