#include "global-sme.h"
#include "draw_graph.h"

#include <stdlib.h>
#include <stdio.h>

/* modulglobale Variablen */

static int n;
static int Kantenzahl;
static int max_rank;
static int x_max;
static int y_max;
static int * A_in;
static int * A_out;
static int * In;
static int * Out;
static NODE * nodes;
static EDGE * edges;
static EDGE * original_edges;
static INT_POINTER * order;
static int * rank_count;
static int Komponentenzahl;
static int * Inj;
static int * Schleifen;
static int loop_count;
static GRAPH * Komponenten;
static int n_ges;
static int Kanz_ges; /* neue Knoten- bzw. Kantenzahl incl. Hilfsknoten */

static void make_graph_dag (KureRel*, EDGE **, int *, int *, int **);

/****************************************************************************/
/* NAME: make_graph_list                                                    */
/* FUNKTION:                                                                */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: .95                                                                  */
/* LETZTE AENDERUNG AM: .95                                                 */
/****************************************************************************/
static void mk_graph_list ()
{
  int i;
  int * akt_in;
  int * akt_out;

  nodes = (NODE *) calloc (n, sizeof (NODE));
  if (nodes == NULL) {
    printf ("Fehler mk_graph_list_draw\n");
    exit (0);
  }
  if (n != 1) {
    In = (int *) calloc (Kantenzahl, sizeof (int));
    Out = (int *) calloc (Kantenzahl, sizeof (int));
    A_in = (int *) calloc (n + 1, sizeof (int));
    A_out = (int *) calloc (n + 1, sizeof (int));
    akt_in = (int *) calloc (n, sizeof (int));
    akt_out = (int *) calloc (n, sizeof (int));

    if (akt_in == (int *) NULL || akt_out == (int *) NULL || In == NULL ||
        Out == NULL || A_in == NULL || A_out == NULL) {
      printf ("Fehler mk_graph_list \n");
      exit (0);
    }
    for (i = 0; i < Kantenzahl; i ++) {
      akt_in [edges [i].head] ++;
      akt_out [edges [i].tail] ++;
    }
    for (i = 1; i <= n; i ++) {
      A_in [i] = A_in [i - 1] + akt_in [i - 1];
      A_out [i] = A_out [i - 1] + akt_out [i - 1];
      akt_in [i - 1] = A_in [i - 1];
      akt_out [i - 1] = A_out [i - 1];
    }
    for (i = 0; i < Kantenzahl; i ++) {
      In [akt_in [edges [i].head] ++] = i;
      Out [akt_out [edges [i].tail] ++] = i;
      edges [i].weight = 1;
      edges [i].delta = 1;
    }
    free (akt_in);
    free (akt_out);
  }
}


/****************************************************************************/
/* NAME: dag                                                                */
/* FUNKTION: berechnet Knotenpositionen                                     */
/* UEBERGABEPARAMETER: rel Name der Relation, x_Abstand y_Abstand Abstand   */
/*                     in x- bzw. y-Richtung der Knoten                     */
/* RUECKGABEWERT: Zeiger auf Graphen                                        */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.6.95                                                              */
/* LETZTE AENDERUNG AM: 6.9.95                                              */
/****************************************************************************/
graphlistptr dag (KureRel * impl, int x_Abstand, int y_Abstand)
{
  int i;
  int j;
  int aktuell;
  graphlistptr gl;

  make_graph_dag (impl, & edges, & n, & Kantenzahl, & Schleifen);
  original_edges = edges;   /* Kantenliste fuer spaeter aufbewahren */
  aktuell = n;

  zerlegen_dag (n, Kantenzahl, edges, & Komponenten, & Komponentenzahl);

  n_ges = 0;
  Kanz_ges = 0;

  for (i = 0; i < Komponentenzahl; i ++) {
    n = Komponenten [i].node_count;
    Kantenzahl = Komponenten [i].edge_count;
    edges = Komponenten [i].edges;
    mk_graph_list ();

    if (n > 1)
      if (make_acyc () == TRUE) {
        free (A_in);
        free (A_out);
        free (In);
        free (Out);
        free (nodes);
        mk_graph_list ();
      }

    Inj = Komponenten [i].inj;
    loop_count = 0;

    for (j = 0; j < n; j ++)
      if (Schleifen [Inj [j]] != 0) {
        loop_count ++;
        nodes [j].Schleife = TRUE;
      }
      else
        nodes [j].Schleife = FALSE;

    draw_graph ();
    aktuell = uebertragen (i, aktuell);

  }
  Komponenten_sort ();

  abs_coord (x_Abstand, y_Abstand);

  gl = dag_to_graph (impl);
  return (gl);
}

/****************************************************************************/
/* NAME: make_graph_dag                                                     */
/* FUNKTION: liest Relation und erstellt daraus Kantenliste fuer dag-Algor. */
/* UEBERGABEPARAMETER: rel_name Name der Relation                           */
/*                     edges Kantenliste (wird hier initialisiert)          */
/*                     n Knotenzahl, Kanz Kantenzahl ,Schleifen speichert   */
/*                     die Kanten von Knoten zu sich selbst                 */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 7.7.95                                                               */
/* LETZTE AENDERUNG AM: 7.7.95                                              */
/****************************************************************************/
static void make_graph_dag (KureRel * impl, EDGE ** edges, int * n,
		int * Kanz, int ** Schleifen)
{
	int lines = kure_rel_get_rows_si (impl);
	int columns = kure_rel_get_cols_si (impl);
	int i;
	int j;
	int aktuell;
	int vars_zeilen = kure_rel_get_vars_rows (impl);
	int vars_spalten = kure_rel_get_vars_cols (impl);

	g_assert (kure_is_hom (impl, NULL));

	*n = lines;
	*Kanz = 0;

	for (i = 0; i < lines; i ++)
		for (j = 0; j < i; j ++)
			if (kure_get_bit_fast_si (impl, i,j,vars_zeilen, vars_spalten))
				//if (get_rel_bit (rel, j, i, vars_zeilen, vars_spalten))
				(* Kanz) ++;
			else
				if (kure_get_bit_fast_si (impl, j,i,vars_zeilen, vars_spalten))
					//if (get_rel_bit (rel, i, j, vars_zeilen, vars_spalten))
					(* Kanz) ++;
	* edges = (EDGE *) calloc (* Kanz, sizeof (EDGE));
	* Schleifen = (int *) calloc (* n, sizeof (int));

	for (i = 0; i < lines; i ++)
		if (kure_get_bit_fast_si (impl, i,i, vars_zeilen, vars_spalten))
			//if (get_rel_bit (rel, i, i, vars_zeilen, vars_spalten) != 0)
			(* Schleifen) [i] = TRUE;

	aktuell = 0;
	for (i = 0; i < lines; i ++)
		for (j = 0; j < i; j ++)
			if (kure_get_bit_fast_si (impl, i,j,vars_zeilen, vars_spalten)) {
				//if (get_rel_bit (rel, j, i, vars_zeilen, vars_spalten) != 0) {
				(* edges) [aktuell].tail = i;
				(* edges) [aktuell].head = j;
				if (kure_get_bit_fast_si (impl, j,i, vars_zeilen, vars_spalten))
					//if (get_rel_bit (rel, i, j, vars_zeilen, vars_spalten) != 0)
					(* edges) [aktuell ++].back_and_forth = TRUE;
				else
					(* edges) [aktuell ++].back_and_forth = FALSE;
			}
			else
				if (kure_get_bit_fast_si (impl, j,i, vars_zeilen, vars_spalten)) {
					//if (get_rel_bit (rel, i, j, vars_zeilen, vars_spalten) != 0) {
					(* edges) [aktuell].tail = j;
					(* edges) [aktuell].head = i;
					(* edges) [aktuell ++].back_and_forth = FALSE;
				}
}


/****************************************************************************/
/* NAME: draw_graph                                                         */
/* FUNKTION: berechnet die Koordinaten der Punkte des Graphen               */
/* UEBERGABEPARAMETER:                                                      */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.6.95                                                              */
/* LETZTE AENDERUNG AM: 20.6.95                                             */
/****************************************************************************/
static void draw_graph ()
{
  int * parent = (int *) NULL;
  int * vater;
  int i;
  int orig_n;

  if (n == 1) {
    nodes [0].rank = 0;
    nodes [0].position = 0;
    x_max = 0;
    y_max = 0;
  }
  else {
    vater = (int *) NULL;
    rank (A_in, A_out, In, Out, edges, nodes, Kantenzahl, n, vater, parent);
    free (A_in);
    free (A_out);
    free (In);
    free (Out);
    orig_n = n;

    // Hinzufuegen von Hilfsknoten
    ordering (& A_in, & A_out, & In, & Out, & edges, & nodes, & Kantenzahl,
              & n, & order, & rank_count, & max_rank);

    position (A_in, A_out, In, Out, & nodes, edges, n, Kantenzahl, order,
              rank_count, max_rank);

    for (i = 0; i < orig_n; i ++)
      nodes [i].status = ORIGINAL;
    for (i = orig_n; i < n; i ++){
      nodes [i].status = ORIGINAL;
      //nodes [i].status = VIRTUAL;
    }

    find_width ();

    free (A_in);
    free (A_out);
    free (In);
    free (Out);
  }
}


/****************************************************************************/
/* NAME: find_max                                                           */
/* FUNKTION: findet maximalen level der Original-Knoten                     */
/* UEBERGABEPARAMETER: max_ptr Zeiger auf max.level                         */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 4.5.95                                                               */
/* LETZTE AENDERUNG AM: 21.6.95                                             */
/****************************************************************************/
static void max_find (int * max_ptr)
{
  int i;
  int max;

  max = 0;
  for (i = 0; i < n; i ++)
    if (nodes [i].rank > max)
      max = nodes [i].rank;
  * max_ptr = max;
}


/****************************************************************************/
/* NAME: find_width                                                         */
/* FUNKTION: findet die max. x- und y-Koordinaten                           */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 21.6.95                                                              */
/* LETZTE AENDERUNG AM: 21.6.95                                             */
/****************************************************************************/
static void find_width ()
{
  max_find (& x_max);
  y_max = max_rank;
}


/****************************************************************************/
/* NAME: uebertragen                                                        */
/* FUNKTION: uebertraegt die Werte, die fuer die Teilgraphen errechnet      */
/*           wurden, in die Liste des Gesamtgraphen                         */
/* UEBERGABEPARAMETER: nr Nummer des Teilgraphen, aktuell naechste zu       */
/*                     vergebende Nummer fuer Hilfsknoten                   */
/* RUECKGABEWERT: naechste zu vergebende Nummer                             */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 20.6.95                                                              */
/* LETZTE AENDERUNG AM: 13.7.95                                             */
/****************************************************************************/
static int uebertragen (int nr, int aktuell)
{
  int i;

  Komponenten [nr].x_max = x_max;
  Komponenten [nr].y_max = y_max;
  Komponenten [nr].alt_n = Komponenten [nr].node_count;
  Komponenten [nr].node_count = n;
  Komponenten [nr].edge_count = Kantenzahl;
  Komponenten [nr].edges = edges;
  Komponenten [nr].nodes = nodes;
  Komponenten [nr].inj = (int *) malloc (n * sizeof (int));
  if (Komponenten [nr].inj == NULL) {
    printf ("Fehler draw\n");
    exit (0);
  }
  for (i = 0; i < Komponenten [nr].alt_n; i ++)
    Komponenten [nr].inj [i] = Inj [i];
  for (i = Komponenten [nr].alt_n; i < Komponenten [nr].node_count; i ++)
    Komponenten [nr].inj [i] = aktuell ++;
  n_ges += n;
  Kanz_ges += Kantenzahl;
  return (aktuell);
}


/****************************************************************************/
/* NAME: abs_coord                                                          */
/* FUNKTION: berechnet absolute Koordinaten                                 */
/* UEBERGABEPARAMETER: x_Abstand, y_Abstand                                 */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 21.6.95                                                              */
/* LETZTE AENDERUNG AM: 21.6.95                                             */
/****************************************************************************/
static void abs_coord (int x_Abstand, int y_Abstand)
{
  int i;
  int j;
  int total_width;
  int total_height;
  int temp;
  int offset;
  int Komponentenabstand = 1;
  int mind_x_abstand = x_Abstand;
  int mind_y_abstand = y_Abstand;

  total_height = 0;
  total_width = 0;
  for (i = 0; i < Komponentenzahl; i ++) {
    total_width += Komponenten [i].x_max;
    temp = Komponenten [i].y_max + 2;
    total_height = total_height < temp ? temp : total_height;
  }
  total_width += (Komponentenzahl - 1) * Komponentenabstand;

  offset = Komponenten [0].x_max + Komponentenabstand;
  for (i = 1; i < Komponentenzahl; i ++) {
    for (j = 0; j < Komponenten [i].node_count; j ++)
      Komponenten [i].nodes [j].rank += offset;  /* rank = x-Koordinate */
    offset += Komponenten [i].x_max + Komponentenabstand;
  }
  /*
    if ((temp = WINDOW_WIDTH/total_width) > mind_x_abstand)
    mind_x_abstand = temp;
    if ((temp = WINDOW_HEIGHT/total_height) > mind_y_abstand)
    mind_y_abstand = temp;
    */
  /* hier kriegen sie erst die richtigen Koordinaten */

  for (i = 0; i < Komponentenzahl; i ++)
    for (j = 0; j < Komponenten [i].node_count; j ++) {
      Komponenten [i].nodes [j].rank *= mind_x_abstand;
      Komponenten [i].nodes [j].position *= mind_y_abstand;
    }
}


/****************************************************************************/
/* NAME: make_acyc                                                          */
/* FUNKTION: macht den Graphen azyklisch                                    */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: TRUE wenn Graph nicht schon azyklisch war, sonst FALSE    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.6.95                                                              */
/* LETZTE AENDERUNG AM: 27.6.95                                             */
/****************************************************************************/
static int make_acyc ()
{
  int * besucht;
  int * verlassen;
  int e;
  int temp;
  int flag;

  besucht = (int *) calloc (n, sizeof (int));
  verlassen = (int *) calloc (n, sizeof (int));
  if (besucht == NULL || verlassen == NULL) {
    printf ("Fehler DFS\n");
    exit (0);
  }

  DFS (besucht, verlassen);

  flag = FALSE;
  for (e = 0; e < Kantenzahl; e++)
    if (besucht [edges [e].tail] > besucht [edges [e].head] &&
        verlassen [edges [e].tail] < verlassen [edges [e].head]) {
      temp = edges [e].tail;
      edges [e].tail = edges [e].head;
      edges [e].head = temp;
      edges [e].gedreht = TRUE;
      flag = TRUE;
    }
    else
      edges [e].gedreht = FALSE;
  free (besucht);
  free (verlassen);
  return (flag);
}


/****************************************************************************/
/* NAME: DFS                                                                */
/* FUNKTION: fuehrt Tiefensuche auf dem Graphen aus                         */
/* UEBERGABEPARAMETER: besucht, verlassen Felder, die angeben wann die      */
/*                     Knoten das erste bzw. das letzte mal erreicht wurden */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.6.95                                                              */
/* LETZTE AENDERUNG AM: 27.6.95                                             */
/****************************************************************************/
static void DFS (int * besucht, int * verlassen)
{
  int v;
  int time;
  int * color;

  color = (int *) malloc (n * sizeof (int));
  if (color == NULL) {
    printf ("Fehler DFS\n");
    exit (0);
  }
  for (v = 0; v < n; v ++)
    color [v] = WEISS;
  time = 0;

  for (v = 0; v < n; v ++)
    if (color [v] == WEISS)
      DFS_visit (color, besucht, verlassen, & time, v);
  free (color);
}


/****************************************************************************/
/* NAME: DFS_visit                                                          */
/* FUNKTION: besucht alle Nachfolger eines Knoten                           */
/* UEBERGABEPARAMETER: color Feld, das angibt, ob ein Knoten schon besucht  */
/*                     wurde, besucht, verlassen wie bisher, time Zaehler,  */
/*                     der bei jedem Knotenbesuch hochgezaehlt wird,        */
/*                     v der Konten der gerade besucht wird                 */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 27.6.95                                                              */
/* LETZTE AENDERUNG AM: 27.6.95                                             */
/****************************************************************************/
static void DFS_visit (int * color, int * besucht, int * verlassen,
                       int * time, int v)
{
  int i;

  color [v] = GRAU;
  (* time) ++;
  besucht [v] = * time;

  for (i = A_out [v]; i < A_out [v + 1]; i ++)
    if (color [edges [Out [i]].head] == WEISS)
      DFS_visit (color, besucht, verlassen, time, edges [Out [i]].head);

  (* time) ++;
  verlassen [v] = * time;
}


/****************************************************************************/
/* NAME: piv                                                                */
/* FUNKTION: findet Stelle mit Wert, nach dem sortiert wird                 */
/* UEBERGABEPARAMETER: i, j Randpunkte                                      */
/* RUECKGABEWERT: der Wert, nach dem sortiert wird                          */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 30.6.95                                                              */
/* LETZTE AENDERUNG AM: 30.6.95                                             */
/****************************************************************************/
static int piv (int i, int j)
{
  int k;

  k = i;
  while (k < j && Komponenten [k].node_count == Komponenten [k + 1].node_count)
    k += 1;
  if (k == j)
    return (-1);
  else
    if (Komponenten [k].node_count > Komponenten [k + 1].node_count)
      return (k + 1);
    else
      return (k);
}


/****************************************************************************/
/* NAME: part                                                               */
/* FUNKTION: ordnet Komponenten nach pivot                                  */
/* UEBERGABEPARAMETER: i, j Randpunkte, pivot Wert nach dem Kompnenten      */
/*                     geordnet werden                                      */
/* RUECKGABEWERT: Stelle von der an Werte groesser als pivot sind           */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 30.6.95                                                              */
/* LETZTE AENDERUNG AM: 30.6.95                                             */
/****************************************************************************/
static int part (int i, int j, int pivot)
{
  GRAPH temp;

  while (Komponenten [i].node_count > pivot)
    i ++;
  while (Komponenten [j].node_count <= pivot)
    j --;
  while (i < j) {
    temp = Komponenten [i];
    Komponenten [i] = Komponenten [j];
    Komponenten [j] = temp;
    while (Komponenten [i].node_count > pivot)
      i ++;
    while (Komponenten [j].node_count <= pivot)
      j --;
  }
  return (i);
}


/****************************************************************************/
/* NAME: quicksort                                                          */
/* FUNKTION: sortiert Komponenten nach Knotenzahl                           */
/* UEBERGABEPARAMETER: i, j Randpunkte                                      */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 30.6.95                                                              */
/* LETZTE AENDERUNG AM: 30.6.95                                             */
/****************************************************************************/
static void quicksort (int i, int j)
{
  int pivot_pos;
  int k;
  int pivot;

  if (i < j) {
    pivot_pos = piv (i, j);
    if (pivot_pos != -1) {
      pivot = Komponenten [pivot_pos].node_count;
      k = part (i, j, pivot);
      quicksort (i, k - 1);
      quicksort (k, j);
    }
  }
}


/****************************************************************************/
/* NAME: Komponenten_sort                                                   */
/* FUNKTION: sortiert die Komponenten nach Knotenzahl                       */
/* UEBERGABEPARAMETER: KEINER                                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 30.6.95                                                              */
/* LETZTE AENDERUNG AM: 30.6.95                                             */
/****************************************************************************/
static void Komponenten_sort ()
{
  quicksort (0, Komponentenzahl - 1);
}

/****************************************************************************/
/* NAME: dag_to_graph                                                       */
/* FUNKTION: speichert Koordinaten des Graphen (ein wenig aufwendig, da die */
/*           Knoten in aufsteigender Reihenfolge in die Datenstruktur Graph */
/*           ueberfuehrt werden muessen, dies aber bei den Komponeneten     */
/*           nicht der Fall sein muss. Aufsteigende Nummer, weil beim       */
/*           Loeschen neu numeriert werden muss)                            */
/* UEBERGABEPARAMETER: rel Name der Relation                                */
/* RUECKGABEWERT: Zeiger auf eine Liste von Graphen                         */
/* ERSTELLT VON: Stefan Meier                                               */
/* AM: 4.7.95                                                               */
/* LETZTE AENDERUNG AM: 4.7.95                                              */
/****************************************************************************/
graphlistptr dag_to_graph (KureRel * impl)
{
  int k;
  int i;
  int j;
  int found;
  int number_of_nodes = 0;
  Graph * gr;
  char number_name [64];
  nodelistptr node_ptr;
  edgelistptr edge_ptr;
  graphlistptr gl;

  /* Anzahl der Knoten aller Komponenten des Graphen ermitteln */

  for (k = 0; k < Komponentenzahl; k ++)
    number_of_nodes = number_of_nodes + Komponenten [k].node_count;

  gl = mk_graph (UNKNOWN_GRAPH_NAME, NORMAL);

  if (gl != (graphlistptr) NULL) {
    gr = & (gl->graph);

    for (i = 0; i < number_of_nodes; i ++) {
      k = 0;
      found = FALSE;

      while ((k < Komponentenzahl) && (found != TRUE)) {
        j = 0;
        while ((j < Komponenten [k].node_count) && (found != TRUE)) {
          if ((Komponenten [k].inj [j]) == i) {
            sprintf (number_name, "%d", Komponenten [k].inj [j] + 1);
            if (Komponenten [k].nodes [j].status == ORIGINAL)
              node_ptr =
                make_node
                (number_name,
                 (int) Komponenten [k].nodes [j].rank + DEFAULT_DIM,
                 (int) Komponenten [k].nodes [j].position + DEFAULT_DIM,
                 DEFAULT_DIM,
                 VISIBLE);
            else
              node_ptr =
                make_node
                ("",
                 (int) Komponenten [k].nodes [j].rank + DEFAULT_DIM,
                 (int) Komponenten [k].nodes [j].position + DEFAULT_DIM,
                 DEFAULT_DIM,
                 VISIBLE);//HELP);
            if (node_ptr != (nodelistptr) NULL)
              append_node (gr, node_ptr);
            if (Komponenten [k].nodes [j].Schleife == TRUE) {
              edge_ptr = make_edge ("", i + 1, i + 1, VISIBLE);
              append_edge (gr, edge_ptr);
            }
            found = TRUE;
          }
          else
            j ++;
        }
        k ++;
      }
    }

    for (k = 0; k < Komponentenzahl; k ++) {
      for (i = 0; i < Komponenten [k].edge_count; i ++) {
        if (Komponenten [k].edges [i].gedreht == FALSE) {
          edge_ptr =
            make_edge
            ("",
             Komponenten [k].inj [Komponenten [k].edges [i].tail] + 1,
             Komponenten [k].inj [Komponenten [k].edges [i].head] + 1,
             VISIBLE);
          append_edge (gr, edge_ptr);
          if (Komponenten [k].edges [i].back_and_forth == TRUE) {
            edge_ptr =
              make_edge
              ("",
               Komponenten [k].inj [Komponenten [k].edges [i].head] + 1,
               Komponenten [k].inj [Komponenten [k].edges [i].tail] + 1,
               VISIBLE);
            append_edge (gr, edge_ptr);
          }
        }
        else {
          edge_ptr =
            make_edge
            ("",
             Komponenten [k].inj [Komponenten [k].edges [i].head] + 1,
             Komponenten [k].inj [Komponenten [k].edges [i].tail] + 1,
             VISIBLE);
          append_edge (gr, edge_ptr);
          if (Komponenten [k].edges [i].back_and_forth == TRUE) {
            edge_ptr =
              make_edge
              ("",
               Komponenten [k].inj [Komponenten [k].edges [i].tail] + 1,
               Komponenten [k].inj [Komponenten [k].edges [i].head] + 1,
               VISIBLE);
            append_edge (gr, edge_ptr);
          }
        }
      }
    }
  }
  return (gl);
}
