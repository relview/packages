#define _simpleposition_c_

#define POSITION_FILE
#define PLANAR_DATA

#include "simpleposition.h"
#include "planar.h" // global variable planarData

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <malloc.h>

#define DEFAULT_GRAPH_RADIUS  150

/* NAME : computeSimplePositions
 * FUNKTION : Berechnet Positionen der Knoten aus der Struktur PlanarData
 * VORAUSSETZUNG : zugrunde liegender Grapph ist trianguliert und es existiert eine canonical ordering
 * UEBERGABEPARAMETER : (size) Anzahl der Knoten im Graphen
 * RUECKGABEWERT : Zeiger auf Positionsarray, aufrufende Funktion ist fuer den Speicher verantwortlich
 * ERSTELLT VON : Sascha Ulbrand (09.11.1998)
 * LETZTE AENDERUNG AM : 09.11.1998
 */
p_pair computeSimplePositions() {
  p_pair res = (p_pair) malloc (sizeof(pair) * ((planarData.planar.adj !=NULL) ? planarData.planar.adj->size : 4));
  p_adjList adj = planarData.embedding.embedding;
  p_intListNode cIter,pIter,remIter;
  p_intSet* M=NULL;

  p_intList Ck_1 = getNewIntList(); /* Front von C_{k-1} */
  p_intSet Ck_1Set = getNewIntSet ((planarData.planar.adj==NULL) ? 4 : planarData.planar.adj->size); /* same as above, unordered with O(1)-access */

  p_intListNode p_wp;
  int wp,wq,wpnext;

  int h,d,xwq_,ywq_; /* wq_ ist ein Punkt der Zeichenebene !!! */

  int i;

  if (planarData.planar.adj->size < 5) {
    /* Handarbeit fuer kleine Graphen */
    if (planarData.planar.adj != NULL) {
      res[0].x = res[0].y = 0;
      if (planarData.planar.adj->size > 1) {
	res[1].x = 4;
	res[1].y = 0;
	if (planarData.planar.adj->size > 2) {
	  res[2].x = 2;
	  res[2].y = 4;
	  if (planarData.planar.adj->size > 3) {
	    res[3].x = 2;
	    res[3].y = 2;
	  }
	}
      }
    }
    assert (planarData.planar.preorder == NULL); /* darf noch nicht gesetzt sein */
    planarData.planar.preorder = getNewReorder(4);
    for (i=0; i<4; i++)
      planarData.planar.preorder->phi[i] = planarData.planar.preorder->phi_1[i] = i;
  } else {
    assert (planarData.embedding.embedding != NULL);
    assert (planarData.embedding.canonical != NULL);
    assert (planarData.planar.adj != NULL);
    assert (planarData.embedding.canonical->size == planarData.planar.adj->size);

    M = (p_intSet*) malloc (sizeof(intSet)*planarData.planar.adj->size);
    for (i=0; i<planarData.planar.adj->size; i++) {
      M[i] = getNewIntSet(planarData.planar.adj->size);
      res[i].x = res[i].y = -1;
    }

    assert (planarData.embedding.canonical->first);
    assert (planarData.embedding.canonical->first->next);
    assert (planarData.embedding.canonical->first->next->next);

    i = planarData.embedding.canonical->first->next->next->val;
    res[0].x = res[0].y = 0;
    res[1].y = 0;
    res[1].x = 2;
    res[i].y = 1;
    res[i].x = 1;

    intSetIncl (M[0],0);
    intSetIncl (M[0],1);
    intSetIncl (M[0],i);

    intSetIncl (M[i],1);
    intSetIncl (M[i],i);

    intSetIncl (M[1],1);

    addLast (Ck_1, 0);
    addLast (Ck_1, i);
    addLast (Ck_1, 1);

    intSetIncl (Ck_1Set, 0);
    intSetIncl (Ck_1Set, 1);
    intSetIncl (Ck_1Set, i);

    assert (planarData.embedding.canonical->size > 3);
    cIter = planarData.embedding.canonical->first->next->next->next;
    while (cIter) {
      /* compute wp, wq , entspricht ci,cj in computeTriangulation, neue Namensgebung aus [EM97]*/

      pIter = adj->aList[cIter->val]->first;
      while (pIter) {
	if (!isInIntSet (Ck_1Set, pIter->val)) break;
	pIter = pIter->next;
      }

      if (pIter) {
	pIter = adj->aList[cIter->val]->first;
	while (!isInIntSet(Ck_1Set, pIter->val) || isInIntSet(Ck_1Set, nextClock(pIter)->val))
	  pIter = nextClock (pIter);
	wp = pIter->val;
	while (isInIntSet(Ck_1Set, pIter->val) || !isInIntSet(Ck_1Set, nextClock(pIter)->val))
	  pIter = nextClock (pIter);
	wq = nextClock(pIter)->val;
      } else {
	/* Sonderbehandlung, sollte eigentlich nur fuer den letzten Knoten vorkommen */
	assert (cIter->next == NULL);
	wp = 0;
	wq = 1;
      }

      pIter = Ck_1->first;
      while (pIter->val != wp) {
	pIter = pIter->next;
      }
      p_wp = pIter;
      wpnext = p_wp->next->val;

      i = M[wpnext]->firstElem;
      assert (i != NONE);
      while (i != NONE) {
	res[i].x ++;
	i = M[wpnext]->nextElem[i];
      }
      i = M[wq]->firstElem;
      assert (i != NONE);
      while (i != NONE) {
	res[i].x ++;
	i = M[wq]->nextElem[i];
      }

      /* Ck_1 und Ck_1Set neu berechnen */
      pIter = Ck_1->first;
      while (pIter->val != wp)
	pIter = pIter->next;
      assert (pIter);

      addAfter (pIter, cIter->val);
      intSetIncl (Ck_1Set, cIter->val);

      pIter = pIter->next->next;
      while (pIter->val != wq) {
	remIter = pIter;
	pIter = pIter->next;
	intSetExcl (Ck_1Set, remIter->val);
	delNode (remIter);
	assert (pIter);
      }

      pIter = Ck_1->first;
      while (pIter) {
        if (pIter->val==cIter->val) {
	  copyIntSet (M[pIter->val], M[wpnext]);
	  intSetIncl (M[pIter->val], pIter->val);
	  pIter = NULL;
	} else {
	  intSetIncl (M[pIter->val],cIter->val);
	  pIter = pIter->next;
	}
      }
      pIter = Ck_1->first;
      while (pIter) {
	pIter = pIter->next;
      }

      /* \mu (wp,wq) berechnen und setzen */

      h = res[wp].y - res[wq].y;
      ywq_ = res[wq].y + h;
      xwq_ = res[wq].x - h;
      d = (xwq_ - res[wp].x) / 2;

      res[cIter->val].x = res[wp].x + d;
      res[cIter->val].y = res[wp].y + d;

      cIter = cIter ->next;
    }
  }
  delIntList (Ck_1);
  delIntSet (Ck_1Set);
  if (M != NULL) {
    for (i=0; i<planarData.planar.adj->size; i++)
      delIntSet (M[i]);
      free (M);
  }

  return res;
}

/* NAME : stripEmbedding
 * FUNKTION : streicht alle hinzugefuegten Kanten aus der Einbettung planarData.embedding.embedding
 * KONSEQUENZ: Der Graph ist danach nicht notwendigerweise zweifach zusammenhaengend, aber ungerichtet !
 * UEBERGABEPARAMETER : eine RELVIEW-Relation (rel) zum Abgleich
 * RUECKGABEWERT : -
 * VORAUSSETZUNG: Graph ist planar und Einbettung wurde generiert
 * ERSTELLT VON : Sascha Ulbrand (13.01.1998)
 * LETZTE AENDERUNG AM : 13.01.1998
 * Umstellung auf grosse Zahlen 15.05.2000
 */
void stripEmbedding (KureRel * impl)
{
	p_adjList adj = planarData.embedding.embedding;
	p_intListNode gIter,dIter;
	//Kure_MINT * SIZE;
	int v;
	int x,y;
	int vars_zeilen = kure_rel_get_vars_rows (impl);
	int vars_spalten = kure_rel_get_vars_cols (impl);

	assert (planarData.connect.preorder && planarData.planar.preorder);
	assert (planarData.connect.preorder->size == kure_rel_get_cols_si(impl));

	//SIZE = Kure_mp_itom (0);
	//Kure_mp_int2mint (planarData.connect.preorder->size, SIZE);
	//assert (Kure_mp_mcmp (SIZE, relData->breite) == 0);
	//Kure_mp_mfree (SIZE);

	//vars_zeilen = Kure_mp_number_of_vars (relData->hoehe);
	//vars_spalten = Kure_mp_number_of_vars (relData->breite);

	for (v = 0; v < adj->size; v ++) {
		gIter = adj->aList[v]->first;
		while (gIter) {
			x = planarData.planar.preorder->phi_1 [v];
			x = planarData.connect.preorder->phi_1 [x];
			y = planarData.planar.preorder->phi_1 [gIter->val];
			y = planarData.connect.preorder->phi_1 [y];

			if ( ! kure_get_bit_fast_si (impl, y, x, vars_zeilen,vars_spalten)
					&& ! kure_get_bit_fast_si (impl, x, y, vars_zeilen, vars_spalten)) {
					//get_rel_bit (relData, x, y, vars_zeilen, vars_spalten) &&
					//!get_rel_bit (relData, y, x, vars_zeilen, vars_spalten)) {
				dIter = gIter;
				gIter = gIter->next;
				delNode (dIter);
			} else {
				gIter = gIter->next;
			}
		}
	}
}

/* NAME : getEmbeddingInOrigNumbering
 * FUNKTION : liefert Einbettung mit originaler Nummerierung der Knoten inkl. aller Singletons
 * EMPFEHLUNG : vorher stripEmbedding ausfuehren um ueberfluessige Kanten zu entfernen
 * NEBENWIRKUNG : die globalen Daten werden freigegeben
 * UEBERGABEPARAMETER : -
 * RUECKGABEWERT : Zeiger auf eine eingebettete Adjazenzliste
 * ERSTELLT VON : Sascha Ulbrand (18.01.1999)
 * LETZTE AENDERUNG AM : 18.01.1999
 */
p_adjList getEmbeddingInOrigNumbering(void) {
  p_adjList resadj;
  p_intListNode gIter;
  int fromOld, fromNew, toOld;

  assert (planarData.connect.preorder);
  assert (planarData.planar.preorder);
  assert (planarData.embedding.embedding);

  resadj = getNewAdjList (planarData.connect.preorder->size);

  for (fromNew=0; fromNew<planarData.embedding.embedding->size; fromNew++) {
    gIter = planarData.embedding.embedding->aList[fromNew]->first;
    while (gIter) {
      fromOld = planarData.planar.preorder->phi_1[fromNew];
      fromOld = planarData.connect.preorder->phi_1[fromOld];
      toOld = planarData.planar.preorder->phi_1[gIter->val];
      toOld = planarData.connect.preorder->phi_1[toOld];

      addNewEdge (resadj, fromOld, toOld);

      gIter = gIter->next;
    }
  }

  freePlanarMemory();
  return resadj;
}

