
#define PLANAR_DATA
#define PLANAR_FILE
#define _planar_c_

//#include "global.h"
//#include "relation.h"
//#include "graph.h"

#include "planar.h"
//#include "helpfunc.h" // included by planar.h

#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <malloc.h>

/* NAME : freePlanarMemory
 * FUNKTION : gibt belegten Speicher des Planaritaetstests frei und setzt Zeiger auf NULL
 * UEBERGABEPARAMETER : -
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (16.11.1998)
 * LETZTE AENDERUNG AM : 16.11.1998
 */
void freePlanarMemory (void)
{
	int i;

	if (planarData.connect.preorder) {
		delReorder (planarData.connect.preorder);
		planarData.connect.preorder = NULL;
	}
	if (planarData.connect.singletons) {
		delIntList (planarData.connect.singletons);
		planarData.connect.singletons = NULL;
	}
	if (planarData.planar.alpha) {
		for (i = 0; i < planarData.planar.adj->size; i++)
			free (planarData.planar.alpha[i]);
		free (planarData.planar.alpha);
		planarData.planar.alpha = NULL;
	}
	if (planarData.planar.preorder) {
		delReorder (planarData.planar.preorder);
		planarData.planar.preorder = NULL;
	}
	if (planarData.planar.adj) {
		delAdjList (planarData.planar.adj);
		planarData.planar.adj = NULL;
	}
	if (planarData.planar.parent) {
		free (planarData.planar.parent);
		planarData.planar.parent = NULL;
	}
	if (planarData.embedding.embedding) {
		delAdjList (planarData.embedding.embedding);
		planarData.embedding.embedding = NULL;
	}
	if (planarData.embedding.canonical) {
		delIntList (planarData.embedding.canonical);
		planarData.embedding.canonical = NULL;
	}
	if (planarData.embedding.ordpart) {
		delOrdPartition (planarData.embedding.ordpart);
		planarData.embedding.ordpart = NULL;
	}
	if (planarData.embedding.ranking) {
		free (planarData.embedding.ranking);
		planarData.embedding.ranking = NULL;
	}
	if (planarData.mixedmodel.edgelevels) {
		delGenList (planarData.mixedmodel.edgelevels);
		planarData.mixedmodel.edgelevels = NULL;
	}
}

/* NAME : removeSingletons
 * FUNKTION : berechnet neue Adjazenzliste ohne Singletons, traegt Singletons in Liste ein
 * UEBERGABEPARAMETER : Zeiger auf Adjazenzliste
 * RUECKGABEWERT : Zeiger auf neue Adjazenz
 * ERSTELLT VON : Sascha Ulbrand (16.11.1998)
 * LETZTE AENDERUNG AM : 16.11.1998
 */
p_adjList removeSingletons (p_adjList adj)
{
	p_adjList newAdj = NULL;
	p_intListNode pIter;
	int i;
	int beg = 0;
	int end = adj->size - 1;

	planarData.connect.preorder = getNewReorder (adj->size);
	planarData.connect.singletons = getNewIntList ();

	for (i = 0; i < adj->size; i++) {
		assert (beg <= end);

		if (adj->aList[i]->size == 0) {
			addFirst (planarData.connect.singletons, i);
			planarData.connect.preorder->phi[i] = end;
			planarData.connect.preorder->phi_1[end--] = i;
		} else {
			planarData.connect.preorder->phi[i] = beg;
			planarData.connect.preorder->phi_1[beg++] = i;
		}
	}

	/* printf ("Singletons: "); printIntList (planarData.connect.singletons); printf ("\n");
	 * printIntArr ("order after removing ", planarData.connect.preorder->phi, planarData.connect.preorder->size); */
	newAdj = getNewAdjList (adj->size - planarData.connect.singletons->size);	/* Neue Adjazenz ohne Singletons */
	for (i = 0; i < adj->size; i++) {
		pIter = adj->aList[i]->first;
		while (pIter) {
			addNewEdge (newAdj, planarData.connect.preorder->phi[i], planarData.connect.preorder->phi[pIter->val]);
			pIter = pIter->next;
		}
	}

	/* printf ("result in removeSingletons\n"); */
	/* printAdjList (newAdj); */

	return newAdj;
}


/* NAME : DFS
 * FUNKTION : einfache Tiefensuche, wird benoetigt zum Ermitteln der Wurzeln eines Waldes
 * UEBERGABEPARAMETER : Zeiger auf eine Adjazenzliste, Startknoten (v), (tested) Array bereits besuchter Knoten
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (26.10.1998)
 * LETZTE AENDERUNG AM : 26.10.1998
 */
void DFS (p_adjList adj, int v, int *tested)
{
	p_intListNode pIter;

	tested[v] = true;
	pIter = adj->aList[v]->first;
	while (pIter) {
		if (!tested[pIter->val])
			DFS (adj, pIter->val, tested);
		pIter = pIter->next;
	}
}

/* NAME : DistanceDFS
 * FUNKTION : Entfernungsberechnung fur Graphen
 * UEBERGABEPARAMETER : Zeiger auf eine Adjazenzliste, Startknoten (v), (tested) Array bereits besuchter Knoten
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (15.03.1999)
 * LETZTE AENDERUNG AM : 15.03.1999
 */
void DistanceDFS (p_adjList adj, int v, int *tested, int dist)
{
	p_intListNode pIter;
	tested[v]=dist;
	pIter = adj->aList[v]->first;
	while (pIter) {
		if (tested[pIter->val]<0)
			DistanceDFS (adj, pIter->val, tested,dist+1);
		pIter = pIter->next;
	}
}

/* NAME : TreeConnect
 * FUNKTION : Sonderbehandlung f�r B�ume
 * UEBERGABEPARAMETER : Eine verbundene Adjazenzliste
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (12.03.1999)
 * LETZTE AENDERUNG AM : 12.03.1999
 */
void TreeConnect(p_adjList adj) {
	int count=0;
	int i;
	assert (adj);
	for (i=0; i<adj->size; i++) {
		count += adj->aList[i]->size;
	}

	if (count/2 == adj->size-1) {
		int max;
		int maxat;
		int from,to;
		int* d = malloc(sizeof(int)*adj->size);
		/* printf ("Sonderbehandlung f�r B�ume m�glich (root 0)\n"); */
		initIntArr (d,adj->size,-1);
		DistanceDFS (adj,0,d,0);
		/* printIntArr ("dist ",d,adj->size); */
		max = 0; maxat = -1;
		for (i=0; i<adj->size; i++) {
			if (d[i]>max) {
				max = d[i];
				maxat = i;
			}
		}
		/* printf ("maxat = %i, deg(%i)=%i\n", maxat,maxat,adj->aList[maxat]->size); */
		from = maxat;
		initIntArr (d,adj->size,-1);
		DistanceDFS (adj,maxat,d,0);
		/* printf ("maxat = %i, deg(%i)=%i\n", maxat,maxat,adj->aList[maxat]->size); */
		max = 0; maxat = -1;
		for (i=0; i<adj->size; i++) {
			if (d[i]>max) {
				max = d[i];
				maxat = i;
			}
		}
		to = maxat;
		/* printf ("edge (%i,%i)\n",from,to); */
		addNewEdge (adj,from,to);
		addNewEdge (adj,to,from);
		free (d);
	}
}

/* NAME : PathConnect
 * FUNKTION : Verbindet die Enden von Pfaden mit Knoten vom Grad 2
 * UEBERGABEPARAMETER : Zeiger auf Adjazenzliste
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (18.02.1999)
 * LETZTE AENDERUNG AM : 18.02.1999
 */
void PathConnect (p_adjList adj)
{
	int i;
	p_intList deg_1_nodes = getNewIntList ();
	p_intListNode gIter;
	int from, comingfrom, to, length;

	assert (adj);

	for (i = 0; i < adj->size; i++) {
		if (adj->aList[i]->size == 1)
			addLast (deg_1_nodes, i);
	}

	/* printf ("deg 1 nodes : ");printIntList (deg_1_nodes);printf ("\n"); */

	while (deg_1_nodes->size) {
		length = 0;
		from = popFirst (deg_1_nodes);
		to = adj->aList[from]->first->val;
		comingfrom = from;

		while (adj->aList[to]->size == 2) {
			if (adj->aList[to]->first->val == comingfrom) {
				comingfrom = to;
				to = adj->aList[to]->last->val;
			} else {
				assert (adj->aList[to]->last->val == comingfrom);
				comingfrom = to;
				to = adj->aList[to]->first->val;
			}
			length++;
		}

		if (adj->aList[to]->size == 1 && !areNeighbours (adj, from, to)) {
			/* printf ("add new Edge type 1 in pathconnect (%i,%i)\n", from,to); */
			addNewEdge (adj, from, to);
			addNewEdge (adj, to, from);
			delVal (deg_1_nodes, to);
		} else if (!areNeighbours (adj, from, to)) {
			gIter = adj->aList[to]->first;
			while (gIter->val == from || gIter->val == comingfrom)
				gIter = gIter->next;
			if (adj->aList[gIter->val]->size == 1)
				delVal (deg_1_nodes, gIter->val);
			addNewEdge (adj, from, gIter->val);
			addNewEdge (adj, gIter->val, from);
			/* printf ("add new Edge type 2 in pathconnect (%i,%i)\n", from, gIter->val); */
		}
	}

	delIntList (deg_1_nodes);
}

/* NAME : BridgeConnect
 * FUNKTION : verbindet die Enden eines langen Pfades mit Knoten vom Grad 2
 * UEBERGABEPARAMETER : Zeiger auf PalmTree, Zeiger auf Adjazenzliste
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (16.03.1999)
 * LETZTE AENDERUNG AM : 16.03.1999
 */
void BridgeConnect(p_palmTree palme, p_adjList adj) {
	int i;
	p_adjList bridges;
	p_intList deg1 = getNewIntList();
	assert (adj);
	bridges = getNewAdjList (adj->size);
	for (i=0; i<adj->size; i++) {
		if (adj->aList[i]->size==2) {
			if (!areNeighbours(bridges, i, adj->aList[i]->first->val)) {
				addNewEdge (bridges, i, adj->aList[i]->first->val);
				addNewEdge (bridges, adj->aList[i]->first->val, i);
			}
			if (!areNeighbours(bridges,i, adj->aList[i]->last->val)) {
				addNewEdge (bridges, i, adj->aList[i]->last->val);
				addNewEdge (bridges, adj->aList[i]->last->val, i);
			}
		}
	}

	for (i=0; i<bridges->size; i++) {
		if (bridges->aList[i]->size == 1)
			addLast (deg1,i);
	}

	printf ("deg1:");printIntList (deg1);printf("\n");

	while (deg1->size) {
		int from = popFirst(deg1);
		int fto=from;
		int t;
		int to = bridges->aList[from]->first->val;
		int len=1;

		while (bridges->aList[to]->size == 2) {
			t = to;
			len++;
			if (bridges->aList[to]->first->val==fto) {
				to = bridges->aList[to]->last->val;
			} else {
				to = bridges->aList[to]->first->val;
			}
			fto = t;
		}
		delVal (deg1, to);
		if (len>2 && from != to) {
			printf ("adding (%i,%i)\n",from,to);
			addNewEdge (adj,from,to);
			addNewEdge (adj,to,from);
		}
	}

	delIntList (deg1);
	delAdjList (bridges);
}

/* NAME : PalmTree
 * FUNKTION : berechnet PalmTree eines Graphen (Implementierung des Algorithmus aus MKRS95)
 * UEBERGABEPARAMETER : Adjazenzliste
 * RUECKGABEWERT : Zeiger auf eine initialisierte Struktur mit den Werten fuer den Baum, nichts weiter
 * ERSTELLT VON : Sascha Ulbrand (17.09.1998)
 * LETZTE AENDERUNG AM : 05.10.1998
 */
p_palmTree PalmTree (p_adjList adj)
{
	p_palmTree palme = getNewPalmTree (adj->size);

	p_adjList unconsidered = copyAdjList (adj);
	int vertex = 0, uvertex;
	int NumberOfEdges = 0;
	int treearcs = 0;
	int frondarcs = 0;
	int minNode = 0;
	int Set_number = 0;		/* f�r Neunummerierung der Knoten */
	int *Set = (int *) malloc (sizeof (int) * adj->size);
	int *visited = (int *) malloc (sizeof (int) * adj->size);
	p_intList stack = getNewIntList ();
	int i;

	/* Kanten zaehlen */
	for (i = 0; i < adj->size; i++)
		NumberOfEdges += adj->aList[i]->size;

	for (i = 0; i < adj->size; i++) {
		Set[i] = 0;
		visited[i] = false;
	}

	palme->preorder[vertex] = 0;
	palme->preorder_1[0] = vertex;
	addLast (palme->roots, vertex);
	Set[vertex] = true;
	Set_number++;
	visited[vertex] = true;

	addLast (stack, vertex);
	do {
		while (stack->size) {
			vertex = stack->last->val;	/* most recently visited vertex */
			if (unconsidered->aList[vertex]->size) {	/* any unconsidered edges left for vertex ? */
				uvertex = popFirst (unconsidered->aList[vertex]);
				delVal (unconsidered->aList[uvertex], vertex);
				if (visited[uvertex]) {
					addNewEdge (palme->fronds, vertex, uvertex);
					frondarcs++;
				} else {
					if (!Set[uvertex]) {
						Set_number++;
						Set[uvertex] = true;
					}
					visited[uvertex] = true;
					addNewEdge (palme->tree, vertex, uvertex);
					palme->parent[uvertex] = vertex;
					treearcs++;
					palme->preorder[uvertex] = Set_number - 1;
					palme->preorder_1[Set_number - 1] = uvertex;
					addLast (stack, uvertex);
				}
			} else {
				popLast (stack);
			}
		}
		if ((NumberOfEdges / 2) > frondarcs + treearcs) {	/* neue Zusammenhangskomponente ermitteln und neue Suche starten */
			while (minNode < adj->size && visited[minNode])
				minNode++;
			vertex = minNode;
			addLast (palme->roots, vertex);
			palme->preorder[vertex] = Set_number;
			palme->preorder_1[Set_number++] = vertex;
			Set[vertex] = true;
			visited[vertex] = true;
			addLast (stack, vertex);
		}
	}
	while ((NumberOfEdges / 2) > frondarcs + treearcs);

	while (minNode < adj->size) {
		if (!visited[minNode]) {
			palme->preorder[minNode] = Set_number;
			palme->preorder_1[Set_number++] = minNode;
			Set[minNode] = true;
			visited[minNode] = true;
		}
		minNode++;
	}

	delIntList (stack);
	delAdjList (unconsidered);
	free (visited);
	free (Set);
	return palme;
}

/* NAME : computeLow
 * FUNKTION : Berechnung der low(.)-Funktion (Implementierung des Algorithmus aus MKRS95)
 * UEBERGABEPARAMETER : Zeiger auf einen PalmTree
 * RUECKGABEWERT : -
 * BEMERKUNG: Aufrufende Funktion ist verantwortlich Speicherbereitstellung von palme->low;
 * ERSTELLT VON : Sascha Ulbrand (17.09.1998)
 * LETZTE AENDERUNG AM : 05.10.1998
 */
void computeLow (p_palmTree palme)
{
	int i;
	int wvertex;
	p_intListNode pIter = NULL;

	assert (palme && palme->low);

	for (i = 0; i < palme->size; i++)
		palme->low[i] = i;

	i = palme->size - 1;
	wvertex = palme->preorder_1[i];	/* wvertex enthaelt die Originalnummer des Knotens, muss immer mit palme->preorder gelesen werden */

	while (i > 0) {
		assert (palme->preorder[wvertex] == i);	/* wehe, wenn nicht, dann ist die Palmtreeberechnung falsch */
		pIter = palme->fronds->aList[wvertex]->first;
		while (pIter) {
			if (palme->preorder[pIter->val] < palme->low[palme->preorder[wvertex]]) {
				palme->low[palme->preorder[wvertex]] = palme->preorder[pIter->val];
			}
			pIter = pIter->next;
		}
		if (palme->low[palme->preorder[palme->parent[wvertex]]] > palme->low[palme->preorder[wvertex]]) {
			palme->low[palme->preorder[palme->parent[wvertex]]] = palme->low[palme->preorder[wvertex]];
		}
		wvertex = palme->preorder_1[--i];
	}
}

/* NAME : computeNd
 * FUNKTION : Berechnung der nd(.)-Funktion (Implementierung des Algorithmus aus MKRS95)
 * UEBERGABEPARAMETER : Zeiger auf einen PalmTree
 * RUECKGABEWERT : Zeiger auf Array mit nd-Werten, Aufrufende Funktion ist verantwortlich fuer Speicherfreigabe
 * ERSTELLT VON : Sascha Ulbrand (21.09.1998)
 * LETZTE AENDERUNG AM : 05.10.1998
 */
int *computeNd (p_palmTree palme)
{
	int *nd = (int *) malloc (sizeof (int) * palme->size);
	int i, vertex;

	for (i = 0; i < palme->size; i++)
		nd[i] = 1;

	i = palme->size - 1;
	while (i > 0) {
		vertex = palme->preorder_1[i];
		nd[palme->parent[vertex]] += nd[vertex];
		i--;
	}

	return nd;
}

/* NAME : computeIndependantVertexSet
 * FUNKTION : Berechnet Liste von unabh�nigen Knoten (Implementierung des Algorithmus aus MKRS95)
 * UEBERGABEPARAMETER : Zeiger auf PalmTree (palme) mit korrekt initialisiertem Array (palme->low)
 * RUECKGABEWERT : -
 * BEMERKUNG: aufrufende Funktion ist fuer Speicherverwaltung verantwortlich
 * ERSTELLT VON : Sascha Ulbrand (17.09.1998)
 * LETZTE AENDERUNG AM : 30.09.1998
 */
void computeIndependantVertexSet (p_palmTree palme)
{
	int v;

	for (v = 0; v < palme->size; v++) {
		if (palme->parent[v] >= 0)
			if (palme->preorder[palme->parent[v]] <= palme->low[palme->preorder[v]])
				addLast (palme->IndepVertex, v);
	}
}

/* NAME : ComputeBVi
 * FUNKTION : Berechnet Liste einer zweifach zusammenhaengenden Komponente fuer einen
 *unabhaengigen Knoten i (Implementierung des Algorithmus aus MKRS95)
 * VORAUSSETZUNG : (palme) ist korrekt initialisiert
 * UEBERGABEPARAMETER : PalmTree (palme), Array mit nd-Werten (nd) und unabhaeniger Knoten (ind)
 * RUECKGABEWERT : Liste von Knoten, aufrufende Funktion ist verantwortlich fuer Speicherfreigabe
 * ERSTELLT VON : Sascha Ulbrand (21.09.1998)
 * LETZTE AENDERUNG AM : 16.11.1998
 */
p_intList ComputeBVi (p_palmTree palme, int *nd, int ind, p_intList indep)
{
	p_intList BVi = getNewIntList ();
	int vertex;
	int *indepArr = (int *) malloc (sizeof (int) * palme->size);
	p_intListNode pIter = indep->first;

	for (vertex = 0; vertex < palme->size; vertex++)
		indepArr[vertex] = 0;
	while (pIter) {
		indepArr[palme->preorder[pIter->val]] = 1;
		pIter = pIter->next;
	}

	addLast (BVi, palme->parent[ind]);
	addLast (BVi, ind);

	vertex = palme->preorder[ind] + 1;

	while (vertex < palme->preorder[ind] + nd[ind]) {
		if (indepArr[vertex]) {
			vertex += nd[palme->preorder_1[vertex]];
		} else {
			addLast (BVi, palme->preorder_1[vertex++]);
		}
	}

	free (indepArr);

	return BVi;
}

/* NAME : ComputeBiconnectedParts
 * FUNKTION : berechnet zweifach zusammenh�ngende Komponenten eines Graphen
 * UEBERGABEPARAMETER : Adjazenzliste (adj)
 * RUECKGABEWERT : Zeiger auf korrekt initialisierten PalmTree
 * ERSTELLT VON : Sascha Ulbrand (14.09.1998)
 * LETZTE AENDERUNG AM : 30.09.1998
 */
p_palmTree ComputeBiconnectedParts (p_adjList adj)
{
	int i;
	int *nd;
	p_intListNode pIter;
	p_palmTree palme = PalmTree (adj);

	computeLow (palme);
	nd = computeNd (palme);

	computeIndependantVertexSet (palme);
	palme->VertSets = (p_intList *) malloc (sizeof (p_intList *) * palme->IndepVertex->size);

	pIter = palme->IndepVertex->first;
	i = 0;
	while (pIter) {
		palme->VertSets[i++] = ComputeBVi (palme, nd, pIter->val, palme->IndepVertex);
		pIter = pIter->next;
	}

	free (nd);
	return palme;
}

/* NAME : AugmentToBiconnectedGraph
 * FUNKTION : ergaenzt einen palmTree so, dass er nur noch eine zweifache Zusammenhangskomponente hat
 * UEBERGABEPARAMETER : einen PalmTree (palme) und die zu vermehrende Adjazenzliste (adj)
 * WARNUNG: palme ist mit DFS-Nummern, adj mit den Nummern vor der DF-Suche
 * RUECKGABEWERT : einen ergaenzten PalmTree
 * ERSTELLT VON : Sascha Ulbrand (05.10.1998)
 * LETZTE AENDERUNG AM : 16.11.1998
 */
void AugmentToBiconnectedGraph (p_palmTree palme, p_adjList adj)
{
	int i, v_i;
	p_intListNode pIter;
	p_intSet *blocks;
	p_intSet *added = (p_intSet *) malloc (sizeof (p_intSet) * palme->size);
	p_intSet IndepPart = getNewIntSet (palme->IndepVertex->size);
	p_intSet cutnodes = getNewIntSet (palme->size);
	int b = false;

	assert (adj != NULL);
	assert (palme != NULL);
	assert (palme->IndepVertex->size);
	assert (adj->size == palme->size);

	pIter = palme->IndepVertex->first;
	while (pIter) {
		if (palme->preorder[palme->parent[pIter->val]] != 0)
			intSetIncl (cutnodes, palme->preorder[palme->parent[pIter->val]]);
		else {
			if (b)
				intSetIncl (cutnodes, palme->preorder[palme->parent[pIter->val]]);
			else
				b = 1;
		}
		pIter = pIter->next;
	}

	blocks = (p_intSet *) malloc (sizeof (p_intSet) * palme->IndepVertex->size);

	for (i = 0; i < palme->IndepVertex->size; i++) {
		blocks[i] = getNewIntSet (palme->size);
		pIter = palme->VertSets[i]->first;
		while (pIter) {
			intSetIncl (blocks[i], pIter->val);
			pIter = pIter->next;
		}
	}

	for (i = 0; i < palme->size; i++)
		added[i] = getNewIntSet (palme->size);

	/* preparation done, compute augmentation */

	for (v_i = 0; v_i < palme->size; v_i++) {
		if (isInIntSet (cutnodes, v_i)) {
			intSetClear (IndepPart);	/* Beinhaltet, welche Bloecke v_i beinhalten */
			for (i = 0; i < palme->IndepVertex->size; i++) {
				if (isInIntSet (blocks[i], palme->preorder_1[v_i]))
					intSetIncl (IndepPart, i);
			}

			i = IndepPart->firstElem;
			while (i != NONE && IndepPart->nextElem[i] != NONE) {
				int from = UNDEF;
				int to = UNDEF;

				pIter = palme->VertSets[i]->first;
				while (pIter) {
					if (inList (adj->aList[palme->preorder_1[v_i]], pIter->val)) {
						from = pIter->val;
						break;
					}
					pIter = pIter->next;
				}

				pIter = palme->VertSets[IndepPart->nextElem[i]]->first;
				while (pIter) {
					if (inList (adj->aList[palme->preorder_1[v_i]], pIter->val)) {
						to = pIter->val;
						break;
					}
					pIter = pIter->next;
				}

				/* printf ("augmenting (%i,%i)\n",from,to); */
				addNewEdge (adj, from, to);
				addNewEdge (adj, to, from);

				i = IndepPart->nextElem[i];
			}
		}
	}
	/* cleanup memory */
	for (i = 0; i < palme->IndepVertex->size; i++)
		delIntSet (blocks[i]);
	for (i = 0; i < palme->size; i++)
		delIntSet (added[i]);
	free (blocks);
	free (added);
	delIntSet (IndepPart);
	delIntSet (cutnodes);
}

/* NAME : GetBiconnectedComponents
 * FUNKTION : Liefert Array von zweifach zusammenhaengengen Komponenten
 * UEBERGABEPARAMETER : Zeiger auf int (anz) = Anzahl der Komponenten und Zeiger auf Adjazenzliste (adj)
 * BEDINGUNG : Graph ist einfach zusammenhaengend
 * RUECKGABEWERT : Zeiger auf Array von intLists
 * ERSTELLT VON : Sascha Ulbrand (17.02.1999)
 * LETZTE AENDERUNG AM : 17.02.1999
 */
p_intList *GetBiconnectedComponents (int *anz, p_adjList adj)
{
	p_palmTree biconnect = NULL;
	p_intList *result;

	assert (anz && adj);
	biconnect = ComputeBiconnectedParts (adj);

	result = biconnect->VertSets;
	biconnect->VertSets = NULL;

	assert (biconnect->preorder_1);

	*anz = biconnect->IndepVertex->size;

	delPalmTree (biconnect);
	biconnect = NULL;		/* wird nicht mehr gebraucht */

	return result;
}

/* NAME : HopcroftDFS
 * FUNKTION : Nummeriert
 * UEBERGABEPARAMETER : Palme (palme), Adjazenzliste (adj), (u), (v), (n) wie in [HT74] S. 552f
 * VORAUSSETZUNG : (adj) beschreibt einen zusammenhaengenden zweifach verbundenen Graphen,
 * : (palme, adj) sind entsprechend initialisiert
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (07.10.1998)
 * LETZTE AENDERUNG AM : 07.10.1998
 */
void HopcroftDFS (p_palmTree palme, p_adjList adj, int v, int u, int *n)
{
	p_intListNode wIter;
	int w;

	palme->parent[v] = u;

	palme->preorder[v] = *n;
	(*n)++;

	/* label a: */
	palme->low[v] = palme->low2[v] = palme->preorder[v];

	wIter = adj->aList[v]->first;
	while (wIter) {
		w = wIter->val;
		if (palme->preorder[w] == -1) {
			/* w is a new vertex */
			HopcroftDFS (palme, adj, w, v, n);
			addNewEdge (palme->tree, v, w);

			/* label b: */
			if (palme->low[w] < palme->low[v]) {
				palme->low2[v] = MINIMUM (palme->low[v], palme->low2[w]);
				palme->low[v] = palme->low[w];
			} else if (palme->low[w] == palme->low[v]) {
				palme->low2[v] = MINIMUM (palme->low2[v], palme->low2[w]);
			} else {
				palme->low2[v] = MINIMUM (palme->low2[v], palme->low[w]);
			}

		} else {
			if ((palme->preorder[w] < palme->preorder[v]) && w != u) {
				addNewEdge (palme->fronds, v, w);

				/* label c: */
				if (palme->preorder[w] < palme->low[v]) {
					palme->low2[v] = palme->low[v];
					palme->low[v] = palme->preorder[w];
				} else if (palme->preorder[w] > palme->low[v]) {
					palme->low2[v] = MINIMUM (palme->low2[v], palme->preorder[w]);
				}
			}
		}
		wIter = wIter->next;
	}
}

/* NAME : renameNodeNames
 * FUNKTION : rechnet Adjazenzlisten um gemaess preorder (Macht spaetere Berechnungen einfacher)
 * UEBERGABEPARAMETER : (palme) PalmTree mit entsprechender Preorder und (adj) Adjazenzliste, es werden neue Strukturen
 *(realpalme, realadj) erzeugt, Speicherfreigabe wird von der aufrufenden Prozedur erledigt.
 * RUECKGABEWERT : Anzahl der Kanten der Adjazenzliste
 * ERSTELLT VON : Sascha Ulbrand (14.10.1998)
 * LETZTE AENDERUNG AM : 23.10.1998
 */
int renameNodeNames (p_palmTree palme, p_adjList adj, p_palmTree *realpalme, p_adjList *realadj)
{
	int i;
	p_intListNode pIter;
	int count = 0;

	assert (palme->size == adj->size);

	*realpalme = getNewPalmTree (palme->size);
	*realadj = getNewAdjList (adj->size);

	for (i = 0; i < palme->size; i++) {
		(*realpalme)->low[palme->preorder[i]] = palme->low[i];
		(*realpalme)->low2[palme->preorder[i]] = palme->low2[i];
		if (palme->parent[i] >= 0)
			(*realpalme)->parent[palme->preorder[i]] = palme->preorder[palme->parent[i]];
		else
			(*realpalme)->parent[palme->preorder[i]] = -1;
		pIter = palme->tree->aList[i]->first;
		while (pIter) {
			addNewEdge ((*realpalme)->tree, palme->preorder[i], palme->preorder[pIter->val]);
			pIter = pIter->next;
		}
		pIter = palme->fronds->aList[i]->first;
		while (pIter) {
			addNewEdge ((*realpalme)->fronds, palme->preorder[i], palme->preorder[pIter->val]);
			pIter = pIter->next;
		}
		pIter = adj->aList[i]->first;
		while (pIter) {
			addNewEdge ((*realadj), palme->preorder[i], palme->preorder[pIter->val]);
			count++;
			pIter = pIter->next;
		}
	}
	return count;
}

/* NAME : SortAdj
 * FUNKTION : sortiert Adjazenzlisten gemaess Funktion \phi((v,w)) [HT74]
 * UEBERGABEPARAMETER : Zeiger auf PalmTree
 * RUECKGABEWERT : Zeiger auf Adjazenzliste
 * ERSTELLT VON : Sascha Ulbrand (08.10.1998)
 * LETZTE AENDERUNG AM : 08.10.1998
 */
p_adjList SortAdj (p_palmTree palme)
{
	p_adjList adj = getNewAdjList (palme->size);
	p_genList *buckets = (p_genList *) malloc (sizeof (p_genList) * ((2 * palme->size) + 1));
	p_intListNode pIter = NULL;
	p_edge pEcke = NULL;
	int i;

	for (i = 0; i < (2 * palme->size) + 1; i++)
		buckets[i] = getNewGenList ();

	for (i = 0; i < palme->size; i++) {
		pIter = palme->tree->aList[i]->first;
		while (pIter) {
			pEcke = (p_edge) malloc (sizeof (edge));

			pEcke->from = i;		/* entspricht v */
			pEcke->to = pIter->val;	/* entspricht w */

			if (palme->low2[pEcke->to] >= pEcke->from)
				addLastGen (buckets[2 * palme->low[pEcke->to]], pEcke);
			else
				addLastGen (buckets[2 * palme->low[pEcke->to] + 1], pEcke);

			pIter = pIter->next;
		}
		pIter = palme->fronds->aList[i]->first;
		while (pIter) {
			pEcke = (p_edge) malloc (sizeof (edge));

			pEcke->from = i;
			pEcke->to = pIter->val;

			addLastGen (buckets[2 * pEcke->to], pEcke);

			pIter = pIter->next;
		}
	}

	for (i = 0; i < 2 * adj->size + 1; i++) {
		while (buckets[i]->size) {
			pEcke = (p_edge) popFirstGen (buckets[i]);
			addNewEdge (adj, pEcke->from, pEcke->to);
			free (pEcke);
		}
		free (buckets[i]);
	}

	return adj;
}

/* NAME : stronglyplanar
 * FUNKTION : berechnet, ob ein Segment planar ist
 * UEBERGABEPARAMETER : (x,y) Kante, die ein Segment bestimmt
 * (adj) Adjazenzliste (sortiert wie in [HT74] beschrieben)
 * (parent) Parent-Funktion
 * (Att) wie in [MMN93] beschrieben
 * (alpha) alpha[x][y] sagt, ob das S(s,y) links oder rechts eingebettet werden muss
 * RUECKGABEWERT : wahr oder falsch
 * ERSTELLT VON : Sascha Ulbrand (??.10.1998)
 * LETZTE AENDERUNG AM : 16.11.1998
 */
int stronglyplanar (int x, int y, p_adjList adj, int *parent,
		p_intList Att, char **alpha)
{

	/* find spine cycle C(e_0), e_0 = (x,y) by starting in node y and always take the
	 * first edge on every adjecency list until a back edge is encountered. */

	p_intListNode eIter = NULL;
	p_intList A = getNewIntList ();
	p_genList S = getNewGenList ();
	p_block B;

	int wk = y;
	int w0;
	int w;
	int temp;

	/* printf ("\n\nstronglyplanar:\nTeste Segment S(%i, %i)\n",x,y); */

	while ((temp = adj->aList[wk]->first->val) > wk) {
		wk = temp;
	}

	w0 = adj->aList[wk]->first->val;
	w = wk;

	while (w != x) {
		eIter = adj->aList[w]->first->next;
		while (eIter) {
			/* test recursively */
			clearIntList (A);
			if (w < eIter->val) {
				/* tree edge */
				if (!stronglyplanar (w, eIter->val, adj, parent, A, alpha)) {
					/* call for stronglyplanar failed, graph is not planar */
					while (S->size)
						delBlock ((p_block) popLastGen (S));
					delGenList (S);
					delIntList (A);
					return false;
				}
			} else {
				/* back edge */
				addLast (A, eIter->val);	/* a back edge */
			}

			/* update stack S of attachments */
			B = getNewBlock (w, eIter->val, A);
			while (1) {
				if (left_interlace_block (B, S))
					flipBlock ((p_block) S->last->data);
				if (left_interlace_block (B, S)) {
					delBlock (B);
					while (S->size)
						delBlock ((p_block) popLastGen (S));
					delGenList (S);
					delIntList (A);
					return false;
				}
				if (right_interlace_block (B, S)) {
					combine_blocks (B, (p_block) popLastGen (S));
				} else
					break;
			}
			addLastGen (S, B);

			eIter = eIter->next;
		}
		/* prepare for next iteration */
		while (S->size && clean_block ((p_block) S->last->data, parent[w], alpha))
			delBlock ((p_block) popLastGen (S));

		w = parent[w];
	}

	/* test for strong planarity */
	clearIntList (Att);
	while (S->size) {
		B = (p_block) popLastGen (S);
		if (B->Latt->size &&
				B->Ratt->size &&
				B->Latt->first->val > w0 &&
				B->Ratt->first->val > w0) {
			delBlock (B);
			while (S->size)
				delBlock ((p_block) popLastGen (S));
			delGenList (S);
			delIntList (A);
			return false;
		}
		add_to_att_block (B, Att, w0, alpha);
		delBlock (B);
	}

	if (w0 != x)
		addLast (Att, w0);

	delIntList (A);
	while (S->size)
		delBlock ((p_block) popLastGen (S));
	delGenList (S);
	return true;
}

/* NAME : BiconnectedComponentPlanar
 * FUNKTION : Testet einen zweifach zusammenhaengenden Graphen auf Planaritaet
 * VORAUSSETZUNG: uebergebener Graph ist zweifach zusammenhaengend (wird nicht ueberprueft)
 * UEBERGABEPARAMETER : eine Adjazenzliste
 * RUECKGABEWERT : wahr oder falsch
 * ERSTELLT VON : Sascha Ulbrand (07.10.1998)
 * LETZTE AENDERUNG AM : 15.10.1998
 */
int BiconnectedComponentPlanar (p_adjList adj, int alp)
{
	p_palmTree palme = getNewPalmTree (adj->size);
	p_palmTree realpalme = NULL;
	p_adjList realadj = NULL;
	p_adjList newadj = NULL;
	int n, m;
	int result;
	int EdgeNum;
	char **alpha = NULL;
	p_intList Att = getNewIntList ();

	if (adj->size < 5) {
		planarData.planar.adj = copyAdjList (adj);
		return true;		/* Graphen mit 4 Knoten oder weniger sind immer planar, embedding manuell erstellen */
	}
	if (alp) {
		alpha = (char **) malloc (adj->size * sizeof (char *));

		for (n = 0; n < adj->size; n++) {
			alpha[n] = (char *) malloc (adj->size * sizeof (char));

			for (m = 0; m < adj->size; m++)
				alpha[n][m] = -1;
		}
	} else {
		alpha = NULL;
	}

	n = 0;
	HopcroftDFS (palme, adj, 0, -1, &n);

	EdgeNum = renameNodeNames (palme, adj, &realpalme, &realadj);

	newadj = SortAdj (realpalme);

	if (alpha)
		alpha[0][0] = left;

	result = stronglyplanar (0, realpalme->tree->aList[0]->first->val, newadj, realpalme->parent, Att, alpha);
	/* printf ("Ergebnis von stronglyplanar: %i\n", result); */

	if (result) {
		if (alp)
			planarData.planar.alpha = alpha;	/* Daten werden gerettet */
		planarData.planar.preorder = getNewReorder (realpalme->size);

		planarData.planar.parent = (int *) malloc (sizeof (int) * realpalme->size);

		for (n = 0; n < realpalme->size; n++) {
			planarData.planar.preorder->phi[n] = palme->preorder[n];
			planarData.planar.preorder->phi_1[palme->preorder[n]] = n;
			planarData.planar.parent[n] = realpalme->parent[n];
		}
		planarData.planar.adj = newadj;
	} else {
		if (alpha) {
			for (n = 0; n < adj->size; n++)
				free (alpha[n]);
			free (alpha);
		}
		delAdjList (newadj);
	}

	delAdjList (realadj);
	delPalmTree (palme);
	delPalmTree (realpalme);
	delIntList (Att);

	return result;
}

/* NAME : isPlanar
 * FUNKTION : ueberprueft, ob Relation einen planaren Graphen repraesentiert
 * UEBERGABEPARAMETER : Zeiger auf eine Relation
 * RUECKGABEWERT : Zeiger auf Graphliststruktur
 * ERSTELLT VON : Sascha Ulbrand (10.09.1998)
 * LETZTE AENDERUNG AM : 16.11.1998
 * Umstellung auf grosse Zahlen: 15.05.2000
 */
int isPlanar (KureRel * impl, int alp)
{
	int x, y, i;
	int v;
	int countEdges = 0;
	int planar;
	int breite = kure_rel_get_cols_si (impl);
	int vars_zeilen = kure_rel_get_vars_rows (impl);
	int vars_spalten = kure_rel_get_vars_cols (impl);

	int * tested = NULL;
	p_adjList connectedAdj = NULL;

	p_adjList adj = NULL;
	p_palmTree biconnect = NULL;

	assert (kure_is_hom(impl, NULL));

	//Kure_mp_mint2int (relData->breite);
	//vars_zeilen = Kure_mp_number_of_vars (relData->hoehe);
	//vars_spalten = Kure_mp_number_of_vars (relData->breite);

	freePlanarMemory ();

	/* adjList aus der Relation erstellen, Adjazenz ist ungerichtet und
     enthaelt keine Kanten (x,x) */
	adj = getNewAdjList (breite);
	for (x = 0; x < breite ; x ++)
		for (y = 0; y < breite ; y ++)
			/* stb: don't count reflexive edges! They cause SIGSEGVs in PalmTree, if there
			 *      are no non-reflexive edges. */
			if (x < y && (kure_get_bit_fast_si(impl, y, x, vars_zeilen, vars_spalten)
					|| kure_get_bit_fast_si (impl, x, y, vars_zeilen, vars_spalten))) {
				countEdges ++;
				if (x != y) {
					addNewEdge (adj, y, x);
					addNewEdge (adj, x, y);
				}
			}
	if (breite < 5) {
		planarData.planar.adj = adj;
		return true;		/* Zeichnung wird manuell erstellt */
	}
	/* Anwendung des Lemmas aus [HT74] */
	if (countEdges >= 3 * breite - 3) {
		delAdjList (adj);
		return false;
	}
	if (countEdges == 0)
		return true;

	/* Kopie der Adjazenz erstellen, ohne Singletons zu beruecksichtigen */
	connectedAdj = removeSingletons (adj);

	/* einfache DFS durchfuehren und Roots der Komponenten verbinden */
	tested = (int *) malloc (sizeof (int) * connectedAdj->size);

	for (i = 0; i < connectedAdj->size; i++)
		tested[i] = false;

	for (v = 0; v < connectedAdj->size; v++)
		if (!tested[v]) {
			DFS (connectedAdj, v, tested);
			if (v != 0) {
				// printf ("ergaenze Kante (%i, %i)\n", 0,v);
				addNewEdge (connectedAdj, 0, v);
				addNewEdge (connectedAdj, v, 0);
			}
		}
	free (tested);

	/* einfache Heuristiken, um weniger Kanten in einen Graphen einzuf"ugen */
	if (alp) {
		TreeConnect (connectedAdj);    /* Bei Problemen auskommentieren */
		PathConnect (connectedAdj);    /* Bei Problemen auskommentieren */
	}
	/* printAdjList (connectedAdj); */

	/* berechne Biconnected components */
	biconnect = ComputeBiconnectedParts (connectedAdj);

	/* weitere einfach Heuristik, um weniger Kanten hinzuzufuegen */
	if (alp) {
		// BridgeConnect (biconnect, connectedAdj); /* Bei Problemen auskommentieren */
	}

	AugmentToBiconnectedGraph (biconnect, connectedAdj);

	delPalmTree (biconnect);
	biconnect = NULL;		/* wird nicht mehr gebraucht */

	planar = BiconnectedComponentPlanar (connectedAdj, alp);

	if (!alp)
		freePlanarMemory ();

	delAdjList (adj);
	delAdjList (connectedAdj);
	return planar;
}
