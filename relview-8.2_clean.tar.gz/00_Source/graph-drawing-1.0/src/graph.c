#include "graph.h"

#include "relview/plugin.h" // LayoutPoint

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include <assert.h>

/*! Get the graph node count.
 *
 * \author stb
 * \date 09-MAR-2008
 * \param graph The graph to get the node count for.
 * \return Returns the node count.
 *
 * \note Is in O(n), where n is the number of nodes belonging to the graph.
 *       Doesn't count (selected) helper nodes!
 */
int graph_get_node_count (Graph * gr)
{
  return get_last_node (gr);
}


#ifdef EDGES_TREE_LOOKUP
static int _edge_compare_func(const Edge * a, const Edge * b);

static int
_edge_compare_func(const Edge * a, const Edge * b)
{
	int diff = a->from - b->from;

	if (0 == diff) return a->to - b->to;
	else return diff;
}
#endif

#ifdef NODES_TREE_LOOKUP
static int _node_compare_func(int a, int b);

static int
_node_compare_func(int a, int b)
{
  return a - b;
}
#endif

/****************************************************************************/
/* NAME: mk_graph                                                           */
/* FUNKTION: erzeugt einen Graphen                                          */
/* UEBERGABEPARAMETER: char * name (Name der Graphen), int state            */
/* RUECKGABEWERT: graphlistptr auf ein Element oder NULL bei Fehler         */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 10.07.95                                                             */
/* LETZTE AENDERUNG AM: 30.01.97 (zufuegen von state)                       */
/****************************************************************************/
graphlistptr mk_graph (char * name, int state)
{
  graphlistptr tmp;

  /* Platz fuer neues Element in der Liste schaffen */

  if ((tmp = (graphlistptr) calloc (1, sizeof (graphelem)))) {
    tmp->graph.node_root = NULL;
    tmp->graph.edge_root = NULL;
    tmp->graph.state = state;
    strcpy (tmp->graph.name, name);
    tmp->next = NULL;

#ifdef EDGES_TREE_LOOKUP
    tmp->graph.edge_tree = g_tree_new ((GCompareFunc) _edge_compare_func);
#endif

#ifdef NODES_TREE_LOOKUP
    tmp->graph.node_tree = g_tree_new ((GCompareFunc) _node_compare_func);
#endif
  } else
    tmp = NULL;

  return (tmp);
}

/****************************************************************************/
/* NAME: append_graph                                                       */
/* FUNKTION: haengt neuen Graph in die Liste                                */
/* UEBERGABEPARAMETER: graphlistptr root, graphlistptr graph                */
/* RUECKGABEWERT: graphlistptr (root der Graph liste)                       */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 10.07.95                                                             */
/* LETZTE AENDERUNG AM: 10.07.95                                            */
/****************************************************************************/
graphlistptr append_graph (graphlistptr root, graphlistptr graph)
{
  graphlistptr gl;

  if (!root)
    root = graph;
  else {
    gl = root;
    while (gl->next)
      gl = gl->next;
    gl->next = graph;
  }

  return (root);
}

/****************************************************************************/
/* NAME: get_graph                                                          */
/* FUNKTION: holt graphen aus der Liste der Graphen                         */
/* UEBERGABEPARAMETER: graphlistptr root, char * name                       */
/* RUECKGABEWERT: Graph * (der Graph) oder NULL                             */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 08.08.95                                                             */
/* LETZTE AENDERUNG AM: 08.08.95                                            */
/****************************************************************************/
Graph * get_graph (graphlistptr root, char * name)
{
  graphlistptr gl;
  int flag = FALSE;

  gl = root;

  while (gl && (flag == FALSE)) {
    if (strcmp (gl->graph.name, name) == 0)
      flag = TRUE;
    else
      gl = gl->next;
  }

  if (flag == FALSE)
    return (NULL);

  return (& (gl->graph));
}

/****************************************************************************/
/* NAME: get_graphlistptr                                                   */
/* FUNKTION: holt graphen aus der Liste der Graphen                         */
/* UEBERGABEPARAMETER: graphlistptr root, char * name                       */
/* RUECKGABEWERT: graphlistptr (der Graph) oder NULL                        */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 20.03.97                                                             */
/* LETZTE AENDERUNG AM: 20.03.97                                            */
/****************************************************************************/
graphlistptr get_graphlistptr (graphlistptr root, char * name)
{
  graphlistptr gl;
  int flag = FALSE;

  gl = root;

  while (gl && (flag == FALSE)) {
    if (strcmp (gl->graph.name, name) == 0)
      flag = TRUE;
    else
      gl = gl->next;
  }

  if (flag == FALSE)
    return (NULL);

  return (gl);
}

/****************************************************************************/
/* NAME: free_graph                                                         */
/* FUNKTION: gibt den Speicher eines Graphen wieder frei                    */
/* UEBERGABEPARAMETER: Graph * graph                                        */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 17.02.99                                                             */
/* LETZTE AENDERUNG AM: 17.02.99                                            */
/****************************************************************************/
void free_graph (Graph * graph)
{
  edgelistptr el;
  edgelistptr tmp_el;
  nodelistptr nl;
  nodelistptr tmp_nl;
  intlistptr il;
  intlistptr tmp_il;

  if (graph) {
#ifdef EDGES_TREE_LOOKUP
    g_tree_destroy (graph->edge_tree);
#endif

#ifdef NODES_TREE_LOOKUP
    g_tree_destroy (graph->node_tree);
#endif

    el = graph->edge_root;
    nl = graph->node_root;

    while (nl) {
      tmp_nl = nl;
      nl = nl->next;
      free (tmp_nl);
    }

    while (el) {
      il = el->edge.path;

      while (il) {
        tmp_il = il;
        il = il->next;
        free (tmp_il);
      }

      il = NULL;

      tmp_el = el;
      el = el->next;
      free (tmp_el);
    }
    graph->edge_root = NULL;
    graph->node_root = NULL;

    graph = NULL;
  }
}

/****************************************************************************/
/* NAME: del_graph                                                          */
/* FUNKTION: loescht eine Graphen aus der Liste                             */
/* UEBERGABEPARAMETER: graphlistptr root, char * name                       */
/*                     Wurzel der Liste aus der geloescht werden soll       */
/*                     Name der Graphen, die geloescht werden soll          */
/* RUECKGABEWERT: Wurzel oder NULL bei Fehler                               */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 23.01.95                                                             */
/* LETZTE AENDERUNG AM: 23.01.95                                            */
/****************************************************************************/
graphlistptr del_graph (graphlistptr root, char * name)
{
  int found = FALSE;
  /* ob der Name gefunden wurde (0 = NEIN) */
  graphlistptr tmp;
  graphlistptr rescue;

  tmp = root;

  if (strcmp (tmp->graph.name, name) == 0) {
    /* gefunden und Listenanfang */
    root = tmp->next;
    /* root auf naechsten verbiegen */
    /* oder falls einziger graph -> NULL */
    /* free_graph (& (tmp->graph));   und Speicher wieder freigeben */
    tmp = NULL;
  } else {
    /* wenn nicht das erste Element */
    rescue = tmp;
    tmp = tmp->next;

    while (tmp && (found == FALSE)) {
      if ((strcmp (tmp->graph.name, name)) == 0) {
        /* gefunden */
        found = TRUE;
        rescue->next = tmp->next;
        /* naechster wird Nachfolger */
        /* free_graph (& (tmp->graph));    und Speicher wieder freigeben */
        tmp = NULL;
      } else {
        rescue = tmp;
        tmp = tmp->next;
      }
    }
  }
  return (root);
}

/****************************************************************************/
/* NAME: copy_graph                                                         */
/* FUNKTION: copiert einen graphen                                          */
/* UEBERGABEPARAMETER: Graph * graph, char * name                           */
/* RUECKGABEWERT: graphlistptr                                              */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 07.01.97                                                             */
/* LETZTE AENDERUNG AM: 07.01.97                                            */
/****************************************************************************/
graphlistptr copy_graph (Graph * gr, char * name)
{
  graphlistptr graph_copy = NULL;
  nodelistptr node_list_copy = NULL;
  nodelistptr nl_orig;
  edgelistptr edge_list_copy = NULL;
  edgelistptr el_orig;
  intlistptr pl_orig;

  if (gr) {
    nl_orig = gr->node_root;
    el_orig = gr->edge_root;

    graph_copy = mk_graph (name, NORMAL);

    if (graph_copy) {
      while (nl_orig) {
        node_list_copy = make_node (nl_orig->node.name,
                                    nl_orig->node.x_pos, nl_orig->node.y_pos,
                                    nl_orig->node.dim, nl_orig->node.state);

        if (node_list_copy) {
          append_node (& (graph_copy->graph), node_list_copy);
          node_list_copy->node.number = nl_orig->node.number;
        }
        nl_orig = nl_orig->next;
      }

      while (el_orig) {
        edge_list_copy = make_edge (el_orig->edge.name,
                                    el_orig->edge.from, el_orig->edge.to,
                                    el_orig->edge.state);

        if (edge_list_copy) {
          append_edge (& (graph_copy->graph), edge_list_copy);

          pl_orig = el_orig->edge.path;

          while (pl_orig) {
            append_edge_pathnode (& (edge_list_copy->edge), pl_orig->number);
            pl_orig = pl_orig->next;
          }
        }
        el_orig = el_orig->next;
      }

#ifdef EDGES_TREE_LOOKUP
      /* Successively add all edges of the graph copy to the tree. */
      {
        edgelistptr iter = graph_copy->graph.edge_root;
        for ( ; iter ; iter = iter->next)
          g_tree_insert (graph_copy->graph.edge_tree,
                         &iter->edge, iter);
      }
#endif

#ifdef NODES_TREE_LOOKUP
      /* Successively add all nodes of the graph copy to the tree. */
      {
        nodelistptr iter = graph_copy->graph.node_root;
        for ( ; iter ; iter = iter->next)
          g_tree_insert (graph_copy->graph.node_tree,
                         (gpointer)iter->node.number, iter);
      }
#endif
    }
  }

  return (graph_copy);
}

/****************************************************************************/
/* NAME: rename_graph                                                       */
/* FUNKTION: benennt einen graph um                                         */
/* UEBERGABEPARAMETER: Graph * graph, char * name                           */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 22.08.95                                                             */
/* LETZTE AENDERUNG AM: 22.08.95                                            */
/****************************************************************************/
void rename_graph (Graph * gr, char * name)
{
  if (gr)
    strcpy (gr->name, name);
}

/****************************************************************************/
/* NAME: set_graph_state                                                    */
/* FUNKTION: setzt den Status eines Graphen                                 */
/* UEBERGABEPARAMETER: Graph * (der Graph), int (den Status)                */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 31.01.97                                                             */
/* LETZTE AENDERUNG AM: 31.01.97                                            */
/****************************************************************************/
void set_graph_state (Graph * gr, int state)
{
  if (gr)
    gr->state = state;
}

/****************************************************************************/
/* NAME: graph_info                                                         */
/* FUNKTION: gibt Auskunft ueber einen Graphen                              */
/* UEBERGABEPARAMETER: Graph * graph                                        */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 13.09.95                                                             */
/* LETZTE AENDERUNG AM: 13.09.95                                            */
/****************************************************************************/
void graph_info (Graph * gr)
{
  int n_vnodes = 0;
  int n_snodes = 0;
  int n_hnodes = 0;
  int n_edges = 0;
  int n_senodes = 0;
  int n_shnodes = 0;
  nodelistptr nl;
  edgelistptr el;

  if (gr) {
    nl = gr->node_root;
    el = gr->edge_root;

    while (nl) {
      switch (nl->node.state) {
      case HELP:
        n_hnodes ++;
        break;

      case SELECTED_HELP:
        n_shnodes ++;
        break;

      case VISIBLE:
        n_vnodes ++;
        break;

      case SELECTED:
      case SELECTED_SECOND:
      case SELECTED_BOTH:
        n_snodes ++;
        break;

      case SELECTED_FOR_EDGE:
        n_senodes ++;
        break;
      }
      nl = nl->next;
    }

    while (el) {
      n_edges ++;
      el = el->next;
    }

    printf ("Visible       Nodes: %d\n", n_vnodes);
    printf ("Help          Nodes: %d\n", n_hnodes);
    printf ("Selected      Nodes: %d\n", n_snodes);
    printf ("Selected Help Nodes: %d\n", n_shnodes);
    printf ("Selected Edge Nodes: %d\n", n_senodes);

    printf ("---------------------\n");

    printf ("Nodes: %d\n",
            n_vnodes + n_hnodes + n_snodes + n_shnodes + n_senodes);
    printf ("Edges: %d\n", n_edges);
  }
}

/****************************************************************************/
/* NAME: concat_graph_lists                                                 */
/* FUNKTION: haengt zwei Fun-Listen zusammen                                */
/* UEBERGABEPARAMETER: 2 X graphlistptr die jeweiligen Wurzeln              */
/* RUECKGABEWERT: graphlistptr (die Wurzel der neuen Liste)                 */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 20.04.95                                                             */
/* LETZTE AENDERUNG AM: 20.04.95                                            */
/****************************************************************************/
graphlistptr concat_graph_lists (graphlistptr first, graphlistptr second)
{
  graphlistptr f;

  if (first) {
    f = first;
    while (f->next)
      f = f->next;
    f->next = second;    /* hinten anhaengen */
  } else
    first = second;

  return (first);
}

/****************************************************************************/
/* NAME: merge_graph_lists                                                  */
/* FUNKTION: haengt zwei Listen-Listen zusammen (master, target)            */
/*           master bestimmt die Eindeutigkeit, d.h gleicher Name in der    */
/*           target-liste wird nicht in die Liste eingefuegt                */
/* UEBERGABEPARAMETER: 2 X graphlistptr die jeweiligen Wurzeln              */
/* RUECKGABEWERT: graphlistptr (die Wurzel der neuen Liste)                 */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 21.03.97                                                             */
/* LETZTE AENDERUNG AM: 21.03.97                                            */
/****************************************************************************/
graphlistptr merge_graph_lists (graphlistptr master, graphlistptr target)
{
  graphlistptr tl;
  graphlistptr rl;

  tl = target;
  rl = master;

  while (tl) {
    if ((graph_exist (rl, tl->graph.name)) == TRUE)
      target = del_graph (target, tl->graph.name);

    tl = tl->next;
  }

  rl = concat_graph_lists (rl, target);

  return (rl);
}

/****************************************************************************/
/* NAME: graph_exist                                                        */
/* FUNKTION: testet ob ein Graph mit dem Name vorhanden                     */
/* UEBERGABEPARAMETER: graphlistptr root, char * name                       */
/* RUECKGABEWERT: TRUE falls vorhanden, ansonsten  FALSE                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 08.08.95                                                             */
/* LETZTE AENDERUNG AM: 08.08.95                                            */
/****************************************************************************/
int graph_exist (graphlistptr root, char * name)
{
  graphlistptr gl;
  int flag = FALSE;

  gl = root;

  while (gl && flag == FALSE) {
    if (strcmp (gl->graph.name, name) == 0)
      flag = TRUE;
    else
      gl = gl->next;
  }

  return (flag);
}

/****************************************************************************/
/* NAME: graph_next                                                         */
/* FUNKTION: gibt den naechsten in der Liste stehenden Graphen zurueck      */
/* UEBERGABEPARAMETER: graphlistptr gl                                      */
/* RUECKGABEWERT: graphlistptr (der Nachfolger)                             */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 04.03.96                                                             */
/* LETZTE AENDERUNG AM: 04.03.96                                            */
/****************************************************************************/
graphlistptr graph_next (graphlistptr gl)
{
  return (gl->next);
}

/****************************************************************************/
/* NAME: get_graph_minx                                                     */
/* FUNKTION: ermittelt die min x_pos des Graphen                            */
/* UEBERGABEPARAMETER: Graph * (der Graph)                                  */
/* RUECKGABEWERT: int min_xpos                                              */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 18.08.95                                                             */
/* LETZTE AENDERUNG AM: 18.08.95                                            */
/****************************************************************************/
int get_graph_minx (Graph * gr)
{
  nodelistptr nl;
  int min_x = 0;

  if (gr) {
    nl = gr->node_root;

    if (nl)
      if (& (nl->node))
        min_x = nl->node.x_pos - nl->node.dim;

    while (nl) {
      if (nl->node.x_pos < min_x)
        min_x = nl->node.x_pos - nl->node.dim;

      nl = nl->next;
    }
  }

  return (min_x);
}

/****************************************************************************/
/* NAME: get_graph_width                                                    */
/* FUNKTION: ermittelt die max x_pos des Graphen                            */
/* UEBERGABEPARAMETER: Graph * (der Graph)                                  */
/* RUECKGABEWERT: int max_xpos                                              */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.08.95                                                             */
/* LETZTE AENDERUNG AM: 14.08.95                                            */
/****************************************************************************/
int get_graph_width (Graph * gr)
{
  nodelistptr nl;
  int node_width = 0;
  int max_x = 0;

  if (gr) {
    nl = gr->node_root;

    if (nl)
      if (& (nl->node))
        node_width = nl->node.dim;

    while (nl) {
      if (max_x < nl->node.x_pos)
        max_x = nl->node.x_pos;

      nl = nl->next;
    }
  }
  return (max_x + node_width);
}

/****************************************************************************/
/* NAME: get_graph_miny                                                     */
/* FUNKTION: ermittelt die min y_pos des Graphen                            */
/* UEBERGABEPARAMETER: Graph * (der Graph)                                  */
/* RUECKGABEWERT: int min_y                                                 */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 05.10.95                                                             */
/* LETZTE AENDERUNG AM: 05.10.95                                            */
/****************************************************************************/
int get_graph_miny (Graph * gr)
{
  nodelistptr nl;
  int node_dim = 0;
  int min_y = 0;

  if (gr) {
    nl = gr->node_root;

    if (nl)
      if (& (nl->node)) {
        node_dim = nl->node.dim;
        min_y = nl->node.y_pos;
      }

    while (nl) {
      if (nl->node.y_pos < min_y) /* minimale y-position */
        min_y = nl->node.y_pos;

      nl = nl->next;
    }
  }
  return (min_y - node_dim);
}

/****************************************************************************/
/* NAME: get_graph_height                                                   */
/* FUNKTION: ermittelt die max y_pos des Graphen                            */
/* UEBERGABEPARAMETER: Graph * (der Graph)                                  */
/* RUECKGABEWERT: int max_y                                                 */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.08.95                                                             */
/* LETZTE AENDERUNG AM: 14.08.95                                            */
/****************************************************************************/
int get_graph_height (Graph * gr)
{
  nodelistptr nl;
  int node_dim = 0;
  int max_y = 0;

  if (gr) {
    nl = gr->node_root;

    if (nl)
      if (& (nl->node))
        node_dim = nl->node.dim;

    while (nl) {
      if (max_y < nl->node.y_pos)  /* maximale y-position */
        max_y = nl->node.y_pos;

      nl = nl->next;
    }
  }
  return (max_y + node_dim);
}

/****************************************************************************/
/* NAME: append_node                                                        */
/* FUNKTION: haengt neuen Knoten an einen Graphen                           */
/* UEBERGABEPARAMETER: Graph * (der Graph)                                  */
/*                     nodelistptr node                                     */
/* RUECKGABEWERT: TRUE falls erfolgreich ansonsten FALSE                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 10.07.95                                                             */
/* LETZTE AENDERUNG AM: 10.07.95                                            */
/****************************************************************************/
int append_node (Graph * graph, nodelistptr node)
{
  nodelistptr nl;

  if (!graph)
    return (FALSE);

  if (!(graph->node_root)) {
    node->node.number = 1;
    graph->node_root = node;
  } else {
    nl = graph->node_root;

    while (nl->next)
      nl = nl->next;

    node->node.number = nl->node.number + 1;
    nl->next = node;
  }

#ifdef NODES_TREE_LOOKUP
  {
    nodelistptr iter = node;
    while (iter) {
      g_tree_insert(graph->node_tree, iter->node.number, iter);
      iter = iter->next;
    }
  }
#endif

  return (TRUE);
}

/*!
 * Prepends a node the graph's node list. Needs only O(1) time, compared
 * to O(n) for append_node(). So use this operation, when possible.
 *
 * \note This method numbers to nodes.
 *
 * \author stb
 * \date 27.10.2008
 *
 * \param gr The graph to add the node to.
 * \param node The node to add.
 * \param number The internal (unique) node number. Numbering should start
 *               with 1.
 */
void graph_prepend_node (Graph * gr, nodelistptr node, int number)
{
  assert (gr != NULL && node != NULL);

  node->node.number = number;
  node->next = gr->node_root;
  gr->node_root = node;

#ifdef NODES_TREE_LOOKUP
  g_tree_insert(gr->node_tree, (gpointer)node->node.number, node);
#endif
}

/****************************************************************************/
/* NAME: append_edge                                                        */
/* FUNKTION: haengt neuen Knoten an einen Graphen                           */
/* UEBERGABEPARAMETER: char * name (Name der Graphen)                       */
/*                     edgelist * edge                                      */
/* RUECKGABEWERT: TRUE falls erfolgreich ansonsten FALSE                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 10.07.95                                                             */
/* LETZTE AENDERUNG AM: 10.07.95                                            */
/****************************************************************************/

/* edge may be a list of edges. In this case we concatenate the
 * current and the given list. E.g. copy_edgelist in the
 * orthogonal module uses this technique. */
int append_edge (Graph * graph, edgelistptr edge)
{
  edgelistptr el;

  /* Remark: Because the list is only singly-linked, this operation
   *         requires linear time! And for many edges linear time can
   *         be overkill! use prepend_edge instead, which requires only
   *         constant time (for updating list). */

  if (!graph)
    return (FALSE);

  if (!(graph->edge_root))
    graph->edge_root = edge;
  else {
    el = graph->edge_root;
    while (el->next)
      el = el->next;
    el->next = edge;
  }

#ifdef EDGES_TREE_LOOKUP
  {
    edgelistptr iter = edge;
    while (iter) {
      g_tree_insert(graph->edge_tree, &iter->edge, iter);
      iter = iter->next;
    }
  }
#endif

  return (TRUE);
}

/*!
 * Prepends a edge to the list of the graph's edges.
 *
 * Note: Time is on O(1).
 *
 * \param graph The graph the edge will be added to.
 * \param edge The edge to add to the graph.
 * \return Returns TRUE on error, or FALSE, if graph, or edge is NULL.
 */
void graph_prepend_edge (Graph * graph, edgelistptr edge)
{
  assert (graph != NULL && edge != NULL);

  /* 'edge' must not be an list, but only a single node! */
  assert (edge->next == NULL);

  edge->next = graph->edge_root;
  graph->edge_root = edge;

#ifdef EDGES_TREE_LOOKUP
  g_tree_insert(graph->edge_tree, &edge->edge, edge);
#endif
}

/****************************************************************************/
/* NAME: make_node                                                          */
/* FUNKTION: erzeugt neuen Knoten an einen Graphen                          */
/* UEBERGABEPARAMETER: char * name (Name der Knotens)                       */
/*                     int x_pos, y_pos, dim, state                         */
/* RUECKGABEWERT: nodelistptr auf neuen Knoten oder NULL                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 10.07.95                                                             */
/* LETZTE AENDERUNG AM: 10.07.95                                            */
/****************************************************************************/
nodelistptr make_node (char * name, int x_pos, int y_pos, int dim, int state)
{
  nodelistptr nl;

  if ((x_pos >= 0) && (y_pos >= 0)) {
    nl = (nodelistptr) malloc (sizeof (nodeelem));
    if (nl) {
      nl->next = NULL;
      memset (&nl->node, 0, sizeof (Node));
      strcpy (nl->node.name, name);
      NODE_ADD_FLAG(nl->node.flags, NODE_VISIBLE);
      nl->node.x_pos = x_pos;
      nl->node.y_pos = y_pos;
      nl->node.dim = dim;
      nl->node.state = state;
    } else
      nl = NULL;
  } else
    nl = NULL;

  return (nl);
}

/*! Register an observer, which will get called, when something
 * interesting happens.
 *
 * \author stb
 * \param observer A GraphObserver struct identifying the object functions
 *                 which are called, when an event happens. NULL function-
 *                 pointers are ignored. Any struct can be registered once.
 *                 The new observer is added in any order to the list.
 */
void graph_register_observer (Graph * gr, GraphObserver * observer)
{
  if (NULL == g_slist_find (gr->observers, observer)) {
    gr->observers = g_slist_prepend (gr->observers, observer);
  }
}

/*! Unregister the given observer from the graph.
 *
 * \author stb
 * \param observer The GraphObserver struct to unregister.
 */
void graph_unregister_observer (Graph * gr, GraphObserver * observer)
{
  gr->observers = g_slist_remove (gr->observers, observer);
}


/****************************************************************************/
/* NAME: make_edge                                                          */
/* FUNKTION: erzeugt neuen Knoten an einen Graphen                          */
/* UEBERGABEPARAMETER: char * name (Name der Knotens)                       */
/*                     int from, to, state                                  */
/* RUECKGABEWERT: edgelistptr auf neuen Knoten oder NULL                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 10.07.95                                                             */
/* LETZTE AENDERUNG AM: 10.07.95                                            */
/****************************************************************************/
edgelistptr make_edge (char * name, int from, int to, int state)
{
  edgelistptr el;

  el = (edgelistptr) calloc (1, sizeof (edgeelem));
  assert (el != NULL);

  if (el) {
    el->next = NULL;
    memset (&el->edge, 0, sizeof (Edge));
    strcpy (el->edge.name, name);
    el->edge.flags = EDGE_VISIBLE;
    el->edge.from = from;
    el->edge.path = NULL;
    el->edge.to = to;
    el->edge.state = state;
  }

  return (el);
}


/****************************************************************************/
/* NAME: append_edge_pathnode                                               */
/* FUNKTION: haengt einen Knoten in die Path-liste der Kante ein            */
/* UEBERGABEPARAMETER: Edge * die Kante                                     */
/*                     int path_node der Knoten                             */
/* RUECKGABEWERT: Keiner                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 18.09.95                                                             */
/* LETZTE AENDERUNG AM: 18.09.95                                            */
/****************************************************************************/
void append_edge_pathnode (Edge * e, int path_node)
{
  intlistptr tmp_path;
  intlistptr il;

  if (e) {
    il = (intlistptr) malloc (sizeof (intelem));

    if (il) {
      il->number = path_node;
      il->next = NULL;

      if (!(e->path))
        e->path = il;
      else {
        tmp_path = e->path;

        while (tmp_path->next)
          tmp_path = tmp_path->next;
        tmp_path->next = il;
      }
    }
  }
}

/****************************************************************************/
/* NAME: prepend_edge_pathnode                                              */
/* FUNKTION: haengt einen Knoten an den Anfang der Path-liste               */
/* UEBERGABEPARAMETER: Edge * die Kante                                     */
/*                     int path_node der Knoten                             */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 17.02.99                                                             */
/* LETZTE AENDERUNG AM: 15.03.99                                            */
/* (il->next mit NULL initialisiert) [immer diese Nachlaessigkeiten];-))    */
/****************************************************************************/
void prepend_edge_pathnode (Edge * e, int path_node)
{
  intlistptr il;

  if (e) {
    il = (intlistptr) malloc (sizeof (intelem));

    if (il) {
      il->number = path_node;

      if (!(e->path)) {
        /* wenns noch keine Liste gab */
        e->path = il;
        /* wird der neue der Anfang   */
        il->next = NULL;
      } else {
        il->next = e->path;
        e->path = il;
      }
    }
  }
}

/****************************************************************************/
/* NAME: del_path_node                                                      */
/* FUNKTION: loescht einen Knoten aus der Path-liste                        */
/* UEBERGABEPARAMETER: Edge * die Kante                                     */
/*                     int path_node der Knoten                             */
/* RUECKGABEWERT: Keiner                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 18.09.95                                                             */
/* LETZTE AENDERUNG AM: 18.09.95                                            */
/****************************************************************************/
intlistptr del_path_node (intlistptr root, int path_node)
{
  int found = FALSE;
  /* ob der Name gefunden wurde (0 = NEIN) */
  intlistptr tmp;
  intlistptr rescue = NULL;

  tmp = root;

  if (root->number == path_node) {
    /* gefunden und Listenanfang */
    root = (intlistptr) NULL;
    /* Liste gibt es nun nicht mehr */
    free (tmp);
  } else {
    /* wenn nicht das erste Element */
    while (tmp && (found == FALSE)) {
      if (tmp->number == path_node) {
        /* gefunden */
        found = TRUE;
        rescue->next = tmp->next;
        /* naechster wird Nachfolger */
        free (tmp);
      }
      rescue = tmp;
      tmp = tmp->next;
    }
  }
  return (root);
}


/****************************************************************************/
/* NAME: get_node                                                           */
/* FUNKTION: liefert den Knoten mit der Nummer                              */
/* UEBERGABEPARAMETER: graphlistptr (der graph)                             */
/*                     int die Nummer des Knotens                           */
/* RUECKGABEWERT: Node * (der Knoten)                                       */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 10.08.95                                                             */
/* LETZTE AENDERUNG AM: 10.08.95                                            */
/****************************************************************************/
Node * get_node (Graph * graph, int nr)
{
#ifdef NODES_TREE_LOOKUP
  nodelistptr nl = g_tree_lookup(graph->node_tree, (gpointer) nr);
  if (nl)
    return &nl->node;
  else
    return NULL;

#else
  nodelistptr nl;
  Node * ret = NULL;
  int flag = FALSE;

  if (graph) {
    nl = graph->node_root;

    while (nl && (flag == FALSE)) {
      if (nl->node.number == nr) {
        flag = TRUE;
        ret = & (nl->node);
      }

      nl = nl->next;
    }
  }
  return (ret);
#endif
}

/****************************************************************************/
/* NAME: get_internal_node_nr                                               */
/* FUNKTION: ermittelt die interne Nummer eines Knotens mit                 */
/*           dem Namen (Titel)                                              */
/* UEBERGABEPARAMETER: Graph * (der Graph)                                  */
/*                     int Nr, der Name (bzw. Titel) des Knotens            */
/* RUECKGABEWERT: int internal_nr oder -1 wenn Fehler                       */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 11.08.95                                                             */
/* LETZTE AENDERUNG AM: 11.02.98                                            */
/*                      (Probleme mit den HELP-Nodes)                       */
/* Helpnodes haben auch Namen (nummern) -> ein knoten mit dem Titel         */
/* z.B. "57" konnte zweimal auftreten. Daher die Abfrage nach dem           */
/* Status des Knotens                                                       */
/****************************************************************************/
int get_internal_node_nr (Graph * gr, int nr)
{
  nodelistptr nl;
  char title [64];
  int i_nr = -1;
  int flag = FALSE;

  if (gr) {
    sprintf (title, "%d", nr);

    nl = gr->node_root;

    while (nl && (flag == FALSE)) {
      if (strlen (nl->node.name) != 0)
        if ((strcmp (title, nl->node.name) == 0) &&
            (nl->node.state != HELP) && (nl->node.state != SELECTED_HELP)) {
          i_nr = nl->node.number;
          flag = TRUE;
        }

      nl = nl->next;
    }
  }

  return (i_nr);
}

/****************************************************************************/
/* NAME: get_node_xpos                                                      */
/* FUNKTION: liefert die X-Position eines Knotens                           */
/* UEBERGABEPARAMETER: char * name (Name der Knotens)                       */
/*                     graphlistptr graph                                   */
/* RUECKGABEWERT: int xpos                                                  */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 14.07.95                                            */
/****************************************************************************/
int get_node_xpos (Graph * graph, int nr)
{
  nodelistptr nl;
  int ret = GRAPH_NULL;
  int flag = FALSE;

  if (!graph)
    ret = GRAPH_NULL;
  else {
    if (!(graph->node_root))
      ret = NODELIST_NULL;
    else {
      for (nl = graph->node_root; nl && (flag == FALSE); nl = nl->next)
        if (nl->node.number == nr) {
          flag = TRUE;
          ret = nl->node.x_pos;
        }
    }
    if (flag == FALSE)
      ret = NODE_NOT_FOUND;
  }

  return (ret);
}

/****************************************************************************/
/* NAME: get_node_ypos                                                      */
/* FUNKTION: liefert die Y-Position eines Knotens                           */
/* UEBERGABEPARAMETER: char * name (Name der Knotens)                       */
/*                     graphlistptr graph                                   */
/* RUECKGABEWERT: int ypos                                                  */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 14.07.95                                            */
/****************************************************************************/
int get_node_ypos (Graph * graph, int nr)
{
  nodelistptr nl;
  int ret = GRAPH_NULL;
  int flag = FALSE;

  if (!graph)
    ret = GRAPH_NULL;
  else {
    if (!(graph->node_root))
      ret = NODELIST_NULL;
    else {
      for (nl = graph->node_root; nl && (flag == FALSE); nl = nl->next)
        if (nl->node.number == nr) {
          flag = TRUE;
          ret = nl->node.y_pos;
        }
    }
    if (flag == FALSE)
      ret = NODE_NOT_FOUND;
  }

  return (ret);
}

/****************************************************************************/
/* NAME: set_node_state                                                     */
/* FUNKTION: setzt den status eines Knotens                                 */
/* UEBERGABEPARAMETER: Graph * graph                                        */
/*                     int nummer des Knotens                               */
/*                     int status                                           */
/* RUECKGABEWERT: int TRUE falls erfolgreich, sonst Fehlernummer            */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 14.07.95                                            */
/****************************************************************************/
int set_node_state (Graph * graph, int nr, int state)
{
  nodelistptr nl;
  int ret = GRAPH_NULL;
  int flag = FALSE;

  if (!graph)
    ret = GRAPH_NULL;
  else {
    if (!(graph->node_root))
      ret = NODELIST_NULL;
    else {
      nl = graph->node_root;
      while (nl && (flag == FALSE)) {
        if (nl->node.number == nr) {
          flag = TRUE;
          ret = TRUE;
          nl->node.state = state;
        }

        nl = nl->next;
      }
    }
    if (flag == FALSE)
      ret = NODE_NOT_FOUND;
  }

  return (ret);
}

/****************************************************************************/
/* NAME: get_node_state                                                     */
/* FUNKTION: ermittelt den status eines Knotens                             */
/* UEBERGABEPARAMETER: Graph * graph                                        */
/*                     int nummer des Knotens                               */
/* RUECKGABEWERT: int (den Status des Knotens)                              */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 23.02.1999                                                           */
/* LETZTE AENDERUNG AM: 23.02.1999                                          */
/****************************************************************************/
int get_node_state (Graph * graph, int nr)
{
  nodelistptr nl;
  int flag = FALSE;
  int state = MARK_NODE_ERROR;

  if (!graph)
    state = MARK_NODE_ERROR;
  else {
    if (!(graph->node_root))
      state = MARK_NODE_ERROR;
    else {
      nl = graph->node_root;
      while (nl && (flag == FALSE)) {
        if (nl->node.number == nr) {
          flag = TRUE;
          state = nl->node.state;
        }

        nl = nl->next;
      }
    }
  }

  return (state);
}

/****************************************************************************/
/* NAME: set_edge_state                                                     */
/* FUNKTION: setzt den status einer Kante                                   */
/* UEBERGABEPARAMETER: graphlistptr graph                                   */
/*                     char * from, char * to (beteiligte Knoten)           */
/*                     int status                                           */
/* RUECKGABEWERT: int TRUE falls erfolgreich, sonst Fehlernummer            */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 14.07.95                                            */
/****************************************************************************/
int set_edge_state (Graph * graph, int from, int to, int state)
{
  edgelistptr el;
  int ret = GRAPH_NULL;
  int flag = FALSE;

  if (!graph)
    ret = GRAPH_NULL;
  else {
    if (!(graph->edge_root))
      ret = EDGELIST_NULL;
    else {
      for (el = graph->edge_root; el && (flag == FALSE); el = el->next)
        if ((el->edge.from == from) && (el->edge.to == to)) {
          flag = TRUE;
          ret = TRUE;
          el->edge.state = state;
        }
    }
    if (flag == FALSE)
      ret = EDGE_NOT_FOUND;
  }

  return (ret);
}

/****************************************************************************/
/* NAME: set_node_position                                                  */
/* FUNKTION: setzt die X-, u. Y-Position eines Knotens                      */
/* UEBERGABEPARAMETER: graphlistptr graph                                   */
/*                     char * name des Knotens                              */
/*                     int x,y neue Positionen                              */
/* RUECKGABEWERT: int TRUE falls erfolgreich, sonst Fehlernummer            */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 14.07.95                                            */
/****************************************************************************/
int set_node_positions (Graph * graph, int nr, int x, int y)
{
  nodelistptr nl;
  int ret = GRAPH_NULL;
  int flag = FALSE;

  if (!graph)
    ret = GRAPH_NULL;
  else {
    if (!(graph->node_root))
      ret = NODELIST_NULL;
    else {
      for (nl = graph->node_root; nl && (flag == FALSE); nl = nl->next)
        if (nl->node.number == nr) {
          flag = TRUE;
          ret = TRUE;
          nl->node.x_pos = x;
          nl->node.y_pos = y;
        }
    }
    if (flag == FALSE)
      ret = NODE_NOT_FOUND;
  }

  return (ret);
}

/****************************************************************************/
/* NAME: get_edge                                                           */
/* FUNKTION: hole Kante aus einem graph                                     */
/* UEBERGABEPARAMETER: graphlistptr graph                                   */
/*                     int from, int to                                     */
/* RUECKGABEWERT: Edge * auf Kante, oder NULL                               */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 23.08.95                                            */
/****************************************************************************/
static Edge * _get_edge_by_list (Graph * gl, int from, int to)
{
  edgelistptr el = NULL;
  int ret = FALSE;

  if (gl) {
    el = gl->edge_root;
    while (el && (ret == FALSE)) {
      if ((el->edge.from == from) && (el->edge.to == to))
        ret = TRUE;
      else
        el = el->next;
    }
  }

  if (ret != TRUE)
    return (NULL);
  else
    return (& (el->edge));
}

Edge * get_edge (Graph * gl, int from, int to)
{
#ifdef EDGES_TREE_LOOKUP
  Edge key;
  key.from = from;
  key.to = to;

  {
    edgelistptr el = g_tree_lookup (gl->edge_tree, &key);
    if (el) {
      assert (el->edge.from == from && el->edge.to == to);
      return &el->edge;
    }
    else return NULL;
  }
#else
 return _get_edge_by_list (gl, from, to);
#endif
}


gboolean graph_edge_exists (Graph * gr, Node * from, Node * to)
{
	return graph_edge_exists_int (gr, from->number, to->number);
}

gboolean graph_edge_exists_int (Graph * gr, int from, int to)
{
#ifdef EDGES_TREE_LOOKUP
	Edge key;
	key.from = from;
	key.to = to;

	return NULL != g_tree_lookup(gr->edge_tree, &key);
#else
	return (NULL != get_edge (gr, from, to));
#endif
}

/****************************************************************************/
/* NAME: get_last_node                                                      */
/* FUNKTION: ermittelt die Nummer des letzten regulaeren Knotens            */
/* UEBERGABEPARAMETER: Graph * graph                                        */
/* RUECKGABEWERT: int die Nummer                                            */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 21.07.95                                                             */
/* LETZTE AENDERUNG AM: 12.07.95                                            */
/****************************************************************************/
int get_last_node (Graph * g)
{
  nodelistptr nl;
  int i = 0;

  if (g) {
    nl = g->node_root;

    while (nl) {
      if ((nl->node.state != HELP) && (nl->node.state != SELECTED_HELP))
        i ++;

      nl = nl->next;
    }
  }
  return (i);
}

/****************************************************************************/
/* NAME: renumber_graph                                                     */
/* FUNKTION: nummeriert die Titel der Knoten des graphen neu durch          */
/* UEBERGABEPARAMETER: graphlistptr der graph                               */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 21.07.95                                                             */
/* LETZTE AENDERUNG AM: 21.07.95                                            */
/****************************************************************************/
void renumber_graph (Graph * gl)
{
  nodelistptr nl;
  int i = 1;
  char title [64];

  if (gl) {
    nl = gl->node_root;

    while (nl) {
      switch (nl->node.state) {
      case VISIBLE:
      case SELECTED:
      case SELECTED_SECOND:
      case SELECTED_BOTH:
        sprintf (title, "%d", i);
        strcpy (nl->node.name, title);
        i ++;
        break;

      default:
        break;
      }

      nl = nl->next;
    }
  }
}

/* use `_x` macros for the `args` parameter, since it's not
 * encapsulated in parenthesis. The for-line must be not end with the
 *  opening '{'. Otherwise the gcc-2.95 cannot handle the macro. */
#define GRAPH_OBSERVER_NOTIFY(gr,func,args)                     \
{                                                               \
  GSList * iter = (gr)->observers;                              \
  for ( ; iter ; iter = g_slist_next (iter)) { GraphObserver * o = (GraphObserver*)iter->data;     \
    if (o->func)                                                \
       o->func ((o)->object,(gr),args);                         \
  }                                                             \
}
#if defined _1 || defined _2 || defined _3
#  warning Macros _1, _2 and/or _3 already defined.
#  undef _1
#  undef _2
#  undef _3
#endif
#define _1(a)   (a)
#define _2(a,b) (a),(b)
#define _3(a,b) (a),(b),(c)


/****************************************************************************/
/* NAME: del_node                                                           */
/* FUNKTION: loescht Knoten mit allen zu/abfuehrenden Kanten                */
/* UEBERGABEPARAMETER: graphlistptr graph, int node_nr                      */
/* RUECKGABEWERT: TRUE falls geloescht, sonst error                         */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 14.07.95                                            */
/****************************************************************************/
int del_node (Graph * gl, int nr)
{
  int found = FALSE;
  /* ob der Name gefunden wurde  */
  nodelistptr tmp;
  nodelistptr rescue = NULL;

  if (gl) {
    tmp = gl->node_root;

    if (tmp->node.number == nr) {
      /* gefunden und Listenanfang */
      found = TRUE;
      del_connected_edges (gl, nr);

      GRAPH_OBSERVER_NOTIFY (gl, onDeleteNode, _1 (&tmp->node));

      /* root auf naechsten verbiegen, or NULL */
      gl->node_root = gl->node_root->next;
    } else {
      /* wenn nicht das erste Element */
      while (tmp && (found == FALSE)) {
        if (tmp->node.number == nr) {

          /* gefunden */
          found = TRUE;
          del_connected_edges (gl, nr);

          GRAPH_OBSERVER_NOTIFY (gl, onDeleteNode, _1 (&tmp->node));

          rescue->next = tmp->next;
          /* naechster wird Nachfolger */
        }
        rescue = tmp;
        tmp = tmp->next;
      }
    }
  }

#ifdef NODES_TREE_LOOKUP
  /* Delete the node from the tree. Must be removed from the tree
   * after the observers are notified. See del_edge for details on
   * that issue. */
  g_tree_remove (gl->node_tree, (gpointer) nr);
#endif

  /* TODO: When is the node freed? */

  return (found);
}

/****************************************************************************/
/* NAME: del_single_node                                                    */
/* FUNKTION: loescht Knoten aus dem graph                                   */
/* UEBERGABEPARAMETER: graphlistptr graph, nodelistptr node                 */
/* RUECKGABEWERT: TRUE falls geloescht, sonst error                         */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 14.07.95                                            */
/****************************************************************************/
int del_single_node (Graph * gl, int nr)
{
  int found = FALSE;
  /* ob der Name gefunden wurde */
  nodelistptr tmp;
  nodelistptr rescue = NULL;

  if (gl) {
    tmp = gl->node_root;

    if (tmp->node.number == nr) {
      GRAPH_OBSERVER_NOTIFY (gl, onDeleteNode, _1 (&tmp->node));

      /* gefunden und Listenanfang */
      found = TRUE;
      gl->node_root = gl->node_root->next;
      /* free (tmp); */

      /* root auf naechsten verbiegen */
    } else {
      /* wenn nicht das erste Element */
      while (tmp && (found == FALSE)) {
        if (tmp->node.number == nr) {
          GRAPH_OBSERVER_NOTIFY (gl, onDeleteNode, _1 (&tmp->node));

          /* gefunden */
          found = TRUE;
          rescue->next = tmp->next;
          /* naechster wird Nachfolger */
          /* free (tmp); */
        }
        rescue = tmp;
        tmp = tmp->next;
      }
    }
  }

#ifdef NODES_TREE_LOOKUP
  /* Delete the node from the tree. Must be removed from the tree
   * after the observers are notified. See del_edge for details on
   * that issue. */
  g_tree_remove (gl->node_tree, (gpointer) nr);
#endif

  return (found);
}

#if 0
/****************************************************************************/
/* NAME: del_marked_nodes                                                   */
/* FUNKTION: loescht markierte Knoten aus dem graph                         */
/*           und markiert die an- u. abgehenden Kanten                      */
/* UEBERGABEPARAMETER: graphlistptr graph                                   */
/* RUECKGABEWERT: TRUE falls geloescht, sonst error                         */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 14.07.95                                            */
/****************************************************************************/
int del_marked_nodes (Graph * gl)
{
  nodelistptr nl;
  edgelistptr el;
  int ret = NODE_NOT_FOUND;

  if (!gl)
    return (GRAPH_NULL);

  if (gl->node_root) {
    if (gl->node_root->node.state == SELECTED)
      gl->node_root = gl->node_root->next;

    nl = gl->node_root;

    if (nl) {
      while (nl->next) {
        if (nl->next->node.state == SELECTED) {
          ret = TRUE;

          el = gl->edge_root;

          while (el) {
            if ((el->edge.from == nl->next->node.number) ||
                (el->edge.to == nl->next->node.number)) {
              el->edge.state = SELECTED;
            }

            el = el->next;
          }

          if (nl->next->next)
            nl->next = nl->next->next;
          else
            nl->next = NULL;
        }

        else
          nl = nl->next;
      }
    }
  }
  return (ret);
}
#endif

/****************************************************************************/
/* NAME: del_connected_edges                                                */
/* FUNKTION: loescht Kanten, die vom Knoten an - od. abgehen                */
/*                           aus dem graph                                  */
/* UEBERGABEPARAMETER: graphlistptr graph, char * knotenname                */
/* RUECKGABEWERT: Anzahl der geloeschten Kanten                             */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 20.07.95                                                             */
/* LETZTE AENDERUNG AM: 20.07.95                                            */
/****************************************************************************/
int del_connected_edges (Graph * gl, int nr)
{
  edgelistptr tl;
  edgelistptr h_el;
  int edge_count = 0;
  int from;
  int to;
  int found;
  Node * node_from;
  Node * node_to;

  if (gl) {
    tl = gl->edge_root;

    while (tl) {
      if (tl->edge.from == nr) {
        /* alle abgehenden Kanten */
        from = nr;
        node_to = get_node (gl, tl->edge.to);

        if (node_to) {
          if (node_to->state != HELP) {
            del_edge (gl, from, node_to->number);
            edge_count ++;
          } else {
            while (node_to->state == HELP) {
              /* wenn HELP-Knoten, dann */
              /* den kopletten Pfad loeschen */

              del_edge (gl, from, node_to->number);
              edge_count ++;

              h_el = gl->edge_root;
              found = FALSE;

              while (h_el && (found != TRUE)) {
                if (h_el->edge.from == node_to->number) {
                  from = h_el->edge.from;
                  node_to = get_node (gl, h_el->edge.to);
                  found = TRUE;
                } else
                  h_el = h_el->next;
              }

              del_single_node (gl, from);
            }

            /* die letzte Kante vom Help-Knote zum Nicht-HELP-Knoten */
            del_edge (gl, from, node_to->number);
            edge_count ++;
          }
        }
      }
      tl = tl->next;
    }

    tl = gl->edge_root;
    while (tl) {
      if (tl->edge.to == nr) {
        /* alle ankommenden Kanten */
        to = tl->edge.to;
        node_from = get_node (gl, tl->edge.from);

        if (node_from) {
          if (node_from->state != HELP) {
            del_edge (gl, node_from->number, to);
            edge_count ++;
          } else {
            while (node_from->state == HELP) {
              /* wenn vom HELP-Knoten */
              /* dann kompletten Pfad */

              del_edge (gl, node_from->number, to);
              edge_count ++;

              h_el = gl->edge_root;
              found = FALSE;

              while (h_el && (found != TRUE)) {
                if (h_el->edge.to == node_from->number) {
                  node_from = get_node (gl, h_el->edge.from);
                  to = h_el->edge.to;
                  found = TRUE;
                } else
                  h_el = h_el->next;
              }

              del_single_node (gl, to);
            }

            /* die letzte Kante vom nicht HELP-Knoten zum HELP-Knoten */
            del_edge (gl, node_from->number, to);
            edge_count ++;
          }
        }
      }

      tl = tl->next;
    }
  }
  return (edge_count);
}

/****************************************************************************/
/* NAME: del_edge                                                           */
/* FUNKTION: loescht Kante aus dem graphen                                  */
/* UEBERGABEPARAMETER: graphlistptr graph,                                  */
/*                     int from, int to (die beiden Knoten)                 */
/* RUECKGABEWERT: TRUE falls geloescht, sonst error                         */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 20.07.95                                                             */
/* LETZTE AENDERUNG AM: 19.09.95                                            */
/* (Anpassung an die neue Datenstruktur, d.h. from, to sind die             */
/* regulaeren Knoten, => path = die zu durchlaufenden Hilfsknoten           */
/* werden mitgeloescht, da Hilfsknoten nur in einem Pfad liegen duerfen     */
/****************************************************************************/
int del_edge (Graph * gl, int from, int to)
{
  int ret = EDGE_NOT_FOUND;
  edgelistptr el;
  edgelistptr rescue = NULL;

  if (gl) {
    el = gl->edge_root;

    /* wenn erstes Element in der Liste */
    if ((el->edge.from == from) && (el->edge.to == to)) {
      GRAPH_OBSERVER_NOTIFY (gl, onDeleteEdge, _1(&el->edge));

      ret = TRUE;

      /* wenn es noch andere Elemente in der Liste gibt */

      if (gl->edge_root->next) {
        gl->edge_root = gl->edge_root->next;
      } else {
        /* falls es das einzige ist */
        gl->edge_root = NULL;
      }

      free (& (el->edge));
    } else {
      while (el && (ret != TRUE)) {
        if ((el->edge.from == from) && (el->edge.to == to)) {
          GRAPH_OBSERVER_NOTIFY (gl, onDeleteEdge, _1(&el->edge));

          ret = TRUE;
          rescue->next = el->next;
          /* naechster wird Nachfolger */
        }
        rescue = el;
        el = el->next;
      }

      free (& (rescue->edge));
    }
  }

#ifdef EDGES_TREE_LOOKUP
  /* We must not delete the edge from the tree, if someone (e.g. the display
   * could lookup a node with get_node, because get_node uses the tree). */
  if (TRUE == ret) {
    Edge key;
    key.from = from;
    key.to = to;

    g_tree_remove (gl->edge_tree, &key);
  }
#endif

  return (ret);
}

/****************************************************************************/
/* NAME: del_marked_edges                                                   */
/* FUNKTION: loescht markierte Kanten aus dem graphen                       */
/* UEBERGABEPARAMETER: graphlistptr graph                                   */
/* RUECKGABEWERT: Anzahl der geloeschten Kanten                             */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 13.09.95                                            */
/****************************************************************************/
int del_marked_edges (Graph * gl)
{
  edgelistptr el;
  int ret = 0;

  if (!gl)
    return (GRAPH_NULL);

  el = gl->edge_root;

  while (el) {
    if (el->edge.state == SELECTED) {
      del_edge (gl, el->edge.from, el->edge.to);
      ret ++;
    }
    el = el->next;
  }

  return (ret);
}

/****************************************************************************/
/* NAME: del_help_nodes                                                     */
/* FUNKTION: loescht alle Hilfsknoten aus dem graphen, die nicht            */
/*           an einer Kante beteiligt sind.                                 */
/* UEBERGABEPARAMETER: graphlistptr graph                                   */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 03.11.95                                                             */
/* LETZTE AENDERUNG AM: 03.11.95                                            */
/****************************************************************************/
void del_help_nodes (Graph * gl)
{
  edgelistptr el;
  intlistptr il;
  nodelistptr nl;
  int needed;

  if (gl) {
    nl = gl->node_root;

    while (nl) {
      if (nl->node.state == HELP) {
        needed = FALSE;

        el = gl->edge_root;
        while (el) {
          il = el->edge.path;

          while (il) {
            if (nl->node.number == il->number)
              needed = TRUE;

            il = il->next;
          }
          el = el->next;
        }

        if (needed == FALSE)
          del_single_node (gl, nl->node.number);
      }
      nl = nl->next;
    }
  }
}

/****************************************************************************/
/* NAME: test_if_edge_exist                                                 */
/* FUNKTION: teste ob Knate im graph vorhanden                              */
/* UEBERGABEPARAMETER: graphlistptr graph                                   */
/*                     char * from, char * to                               */
/* RUECKGABEWERT: int TRUE falls ja, sonst FALSE                            */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 19.09.95 (Anpassung an die neue Datenstruktur from, */
/*                      to immer die regulaeren Knoten                      */
/****************************************************************************/
int test_if_edge_exist (Graph * gl, int from, int to)
{
#if EDGES_TREE_LOOKUP
	return graph_edge_exists_int (gl, from, to);
#else
  int found = FALSE;
  edgelistptr el;

  if (gl) {
    el = gl->edge_root;

    while (el && found != TRUE) {
      if ((el->edge.from == from) && (el->edge.to == to))
        found = TRUE;
      else
        el = el->next;
    }
  }

  return (found);
#endif
}

/****************************************************************************/
/* NAME: test_if_node_nearby                                                */
/* FUNKTION: testet ob ein Knoten in der Naehe                              */
/* UEBERGABEPARAMETER: graphlistptr graph                                   */
/*                     int x,y die zu testenden Positionen                  */
/* RUECKGABEWERT: nodelistptr auf den Knoten, sonst NULL                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 14.07.95                                                             */
/* LETZTE AENDERUNG AM: 29.01.97 (der geringst Abstand zum Maus             */
/*                      zeiger gewinnt)                                     */
/****************************************************************************/
Node * test_if_node_nearby (Graph * gl, int x, int y)
{
  nodelistptr nl;
  Node * node_close_to = NULL;
  int min_delta;
  int tmp_delta;
  int xp;
  int yp;
  int d;

  if (gl) {
    nl = gl->node_root;
    if (nl) {
      min_delta = nl->node.dim * nl->node.dim;

      /* auf maximal moegliche Entfernung (im Quadrat) setzen */
      /* um auf kleinere Entfernungen reagieren zu koennen */

      while (nl) {
        xp = nl->node.x_pos;
        yp = nl->node.y_pos;
        d = nl->node.dim;

        if ((x < (xp + d)) && (x > (xp - d)) && (y < (yp + d))
            && (y > (yp - d))) {
          tmp_delta = (((x - xp) * (x - xp)) + ((y - yp) * (y - yp)));
          /* Laenge im Quadrat */
          if (tmp_delta < min_delta) {
            min_delta = tmp_delta;
            node_close_to = (& (nl->node));
          }
        }
        nl = nl->next;
      }
    }
  }
  return (node_close_to);
}


static void _graph_clear (Graph * gr);
static void _graph_clear_edges (Graph * gr);

/*!
 * Remove all nodes and edges from the given graph.
 *
 * \note Does not update the display. Notifies the observers, when deleting
 *       nodes or edges. Does not clear the observer list. Does not change
 *       the graph's state.
 *
 * \auhtor stb
 * \data 27.10.2008
 *
 * \param graph The graph to clear.
 */
void _graph_clear (Graph * gr)
{
  /* Delete the nodes and the adjacent edges. */
  while (gr->node_root != NULL) {
     del_node (gr, gr->node_root->node.number);
  }

  assert (NULL == gr->edge_root);
}

/*!
 * Remove all edges from the given graph.
 *
 * \note Does not update the display. Notifies the observers, when deleting
 *       edges. Does not clear the observer list. Does not change the graph's
 *       state.
 *
 * \auhtor stb
 * \data 27.10.2008
 *
 * \param graph The graph, whose edges should be deleted.
 */
void _graph_clear_edges (Graph * gr)
{
  /* Delete the edges. */
  while (gr->edge_root != NULL) {
    Edge * e = &gr->edge_root->edge;
    del_edge (gr, e->from, e->to);
  }
}

/****************************************************************************/
/* NAME: unmark_graph_edges                                                 */
/* FUNKTION: demarkiert die Kanten eines Graphen anhand von rel             */
/* UEBERGABEPARAMETER: graphlistptr graph                                   */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 17.08.95                                                             */
/* LETZTE AENDERUNG AM: 26.02.1999                                          */
/* (zweiter Markierungslevel ergaenzt, d.h leoschen eines Levels)           */
/****************************************************************************/
void unmark_graph_edges (Graph * gr, int mark_level)
{
  edgelistptr el;

  if (gr) {
    el = gr->edge_root;

    while (el) {
      switch (el->edge.state) {
      case HELP:
        break;

      case SELECTED:
        if (mark_level == SELECTED)
          el->edge.state = VISIBLE;
        break;

      case SELECTED_SECOND:
        if (mark_level == SELECTED_SECOND)
          el->edge.state = VISIBLE;
        break;

      case SELECTED_BOTH:
        if (mark_level == SELECTED)
          el->edge.state = SELECTED_SECOND;

        if (mark_level == SELECTED_SECOND)
          el->edge.state = SELECTED;

        if (mark_level == SELECTED_BOTH)
          el->edge.state = VISIBLE;
        break;

      default:
        el->edge.state = VISIBLE;
      }
      el = el->next;
    }
  }
}

/****************************************************************************/
/* NAME: unmark_graph_nodes                                                 */
/* FUNKTION: demarkiert die Knoten eines Graphen anhand von rel             */
/* UEBERGABEPARAMETER: graphlistptr graph                                   */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 17.08.95                                                             */
/* LETZTE AENDERUNG AM: 26.02.1999                                          */
/* zweite Markierungsart ergaenzt, d.h. nur ein level wird geloescht        */
/****************************************************************************/
void unmark_graph_nodes (Graph * gr, int mark_level)
{
  nodelistptr nl;

  if (gr) {
    nl = gr->node_root;

    while (nl) {
      switch (nl->node.state) {
      case SELECTED:
        if (mark_level == SELECTED)
          nl->node.state = VISIBLE;
        break;

      case SELECTED_SECOND:
        if (mark_level == SELECTED_SECOND)
          nl->node.state = VISIBLE;
        break;

      case SELECTED_BOTH:
        if (mark_level == SELECTED)
          nl->node.state = SELECTED_SECOND;
        if (mark_level == SELECTED_SECOND)
          nl->node.state = SELECTED;
        if (mark_level == SELECTED_BOTH)
          nl->node.state = VISIBLE;
        break;

      case SELECTED_FOR_EDGE:
        nl->node.state = VISIBLE;
        break;

      case HELP:
        break;

      case SELECTED_HELP:
        nl->node.state = HELP;
        break;

      default:
        nl->node.state = VISIBLE;
        break;
      }
      nl = nl->next;
    }
  }
}

void unmark_graph_nodes_complete (Graph * graph)
{
  unmark_graph_nodes (graph, SELECTED);
  unmark_graph_nodes (graph, SELECTED_SECOND);
  unmark_graph_nodes (graph, SELECTED_BOTH);
}

void unmark_graph_edges_complete (Graph * graph)
{
  unmark_graph_edges (graph, SELECTED);
  unmark_graph_edges (graph, SELECTED_SECOND);
  unmark_graph_edges (graph, SELECTED_BOTH);
}

/****************************************************************************/
/* NAME: get_edgemarked_nodes                                               */
/* FUNKTION: liefert die Anzahl der fuer eine Kante markierten Knoten       */
/* UEBERGABEPARAMETER: Graph * gr                                           */
/* RUECKGABEWERT: int (Anzahl der markierten Knoten)                        */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 18.08.95                                                             */
/* LETZTE AENDERUNG AM: 18.08.95                                            */
/****************************************************************************/
int get_edgemarked_nodes (Graph *gr)
{
  nodelistptr nl;
  int i = 0;

  if (gr) {
    nl = gr->node_root;

    while (nl) {
      if ((nl->node.state == SELECTED_FOR_EDGE) ||
          (nl->node.state == SELECTED_HELP))
        i ++;

      nl = nl->next;
    }
  }
  return (i);
}

/****************************************************************************/
/* NAME: get_first_unmarked_node                                            */
/* FUNKTION: liefert den ersten unmarkierten (VISIBLE = 0) Knoten           */
/* UEBERGABEPARAMETER: Graph * gr                                           */
/* RUECKGABEWERT: nodelistptr (der gefundene Knoten oder NULL)              */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 31.08.95                                                             */
/* LETZTE AENDERUNG AM: 31.08.95                                            */
/****************************************************************************/
Node * get_first_unmarked_node (Graph *gr)
{
  nodelistptr nl = NULL;
  int flag = FALSE;

  if (gr) {
    nl = gr->node_root;

    while (nl && (flag == FALSE)) {
      if (nl->node.state == VISIBLE)
        flag = TRUE;
      else
        nl = nl->next;
    }
  }
  return (& (nl->node));
}


#if 0
/****************************************************************************/
/* NAME: split_next_komponent                                               */
/* FUNKTION: gibt einen Graphen zurueck der die naechste noch nicht         */
/*           gesplittete Komponente des graphen darstellt                   */
/* UEBERGABEPARAMETER: Graph * gr                                           */
/* RUECKGABEWERT: graphlistptr auf die Komponente oder NULL                 */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 31.08.95                                                             */
/* LETZTE AENDERUNG AM: 31.08.95                                            */
/****************************************************************************/
Graph * split_next_komponent (Graph *gr, char * name)
{
  nodelistptr nl = NULL;
  nodelistptr noli = NULL;
  Node * node = NULL;
  edgelistptr el = NULL;
  edgelistptr eoli = NULL;
  graphlistptr gl = NULL;
  Graph * g;

  gl = mk_graph (name, NORMAL);

  g = & (gl->graph);
  g->node_root = NULL;
  g->edge_root = NULL;

  if (gr) {
    if ((node = get_first_unmarked_node (gr))) {
      node->state = SELECTED;
      noli = make_node (node->name, node->x_pos, node->y_pos,
                        node->dim, SELECTED);

      append_node (g, noli);
      noli->node.number = node->number;

      nl = g->node_root;

      while (nl) {
        el = gr->edge_root;

        while (el) {
          if (el->edge.from == nl->node.number) {
            if (!(get_node (g, el->edge.to))) {
              if ((node = get_node (gr, el->edge.to))) {
                node->state = SELECTED;
                noli = make_node (node->name, node->x_pos, node->y_pos,
                                  node->dim, SELECTED);
                append_node (g, noli);
                noli->node.number = el->edge.to;
              }
            }

            eoli = make_edge ("", el->edge.from, el->edge.to, WEIGHT);
            append_edge (g, eoli);
          }

          if (el->edge.to == nl->node.number) {
            if (!(get_node (g, el->edge.from))) {
              if ((node = get_node (gr, el->edge.from))) {
                node = get_node (gr, el->edge.from);
                node->state = SELECTED;
                noli = make_node (node->name, node->x_pos, node->y_pos,
                                  node->dim, SELECTED);
                append_node (g, noli);
                noli->node.number = el->edge.from;
              }
            }
            eoli = make_edge ("", el->edge.from, el->edge.to, WEIGHT);
            append_edge (g, eoli);
          }

          el = el->next;
        }

        nl = nl->next;
      }
    }
  }

  if (!(g->node_root))
    /* keine Knoten vorhanden */
    g = NULL;
  /* dh. keine Komponenete mehr da */

  return (g);
}
#endif

#if 0
/****************************************************************************/
/* NAME: run_edge_path                                                      */
/* FUNKTION: durchlaueft die Kanten von Knoten from nach Knoten nach        */
/* und liefert die Knotenliste von Knoten von nach Knoten nach              */
/* (Ist noetig, da HELP-Knoten im Spiel und von einem Knoten                */
/* verschiedene Pfade losgehen koennen)                                     */
/* UEBERGABEPARAMETER: graphlistptr graph, int from, int to                 */
/* RUECKGABEWERT: int (TRUE) wenn erfolgreich, sonst FALSE                  */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 13.09.95                                                             */
/* LETZTE AENDERUNG AM: 13.09.95                                            */
/****************************************************************************/
nodelistptr run_edge_path (Graph * graph, int from, int to)
{
  int found;
  int path_found = FALSE;
  Node * node_from;
  Node * node_to;
  graphlistptr tmp_gl;
  Graph * tmp_graph = NULL;
  nodelistptr tmp_nl;
  edgelistptr el;
  edgelistptr h_el;

  if (graph) {
    el = graph->edge_root;

    tmp_gl = mk_graph ("RUN_PATH", NORMAL);
    /* temporaeren Graph erzeugen */
    tmp_graph = & (tmp_gl->graph);

    node_from = get_node (graph, from);
    /* ersten Knoten holen */

    while (el && (path_found != TRUE)) {
      if (el->edge.from == from) {
        /* erste Kante gefunden */
        node_to = get_node (graph, el->edge.to);

        if (node_to) {
          if (node_to->state == HELP) {
            while (node_to->state == HELP) {
              h_el = graph->edge_root;
              found = FALSE;
              tmp_nl = make_node ("", 0, 0, 0, 0);
              append_node (tmp_graph, tmp_nl);
              tmp_nl->node.number = node_to->number;
              while (h_el && (found != TRUE)) {
                if (h_el->edge.from == node_to->number) {
                  node_to = get_node (graph, h_el->edge.to);
                  found = TRUE;
                } else
                  h_el = h_el->next;
              }
            }
            if ((atoi (node_to->name)) == to)
              /* Ziel des zu suchenden Pfades */ {
              /* stimmt mi aktuellem ueberein */
              path_found = TRUE;
            } else {
              /* ansonsten von vorne */
              tmp_graph->node_root = NULL;
            }
          }
        }
      }
      el = el->next;
    }
  }
  if (path_found != TRUE)
    tmp_graph->node_root = NULL;

  return (tmp_graph->node_root);
}
#endif

/****************************************************************************/
/* NAME: find_edge_path                                                     */
/* FUNKTION: startet bei Knoten from und sucht nach einem Pfad im           */
/* Graphen der durch Hilfsknoten laeuft und loescht diesen                  */
/* liefert die Knotenliste von Knoten von nach Knoten nach                  */
/* (Ist noetig, da HELP-Knoten im Spiel und von einem Knoten                */
/* verschiedene Pfade losgehen koennen)                                     */
/* UEBERGABEPARAMETER: graphlistptr graph, int from                         */
/* RUECKGABEWERT: edgelistptr die neue Kante mit den pathnodes              */
/* d.h. [1]->[2] { [34H], [35H], [36H] ..... }                              */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 13.09.95                                                             */
/* LETZTE AENDERUNG AM: 27.09.95                                            */
/****************************************************************************/
edgelistptr find_edge_path (Graph * graph, int from)
{
  int pre_node;
  int found;
  int path_found = FALSE;
  Node * node_to;
  edgelistptr el;
  edgelistptr h_el;
  edgelistptr tmp_el = NULL;

  if (graph) {
    el = graph->edge_root;

    while (el && (path_found != TRUE)) {
      if (el->edge.from == from) {
        /* erste Kante gefunden */
        node_to = get_node (graph, el->edge.to);

        /* Anfangsknoten eintragen */
        tmp_el = make_edge ("", from, 0, 0);
        /* to ist noch nicht bekannt */

        /* wenn Kante zwischen zwei regulaeren Knoten (ohne Hilfsknoten) */

        if (node_to && (node_to->state != HELP)) {
          tmp_el->edge.to = node_to->number;
          del_edge (graph, from, node_to->number);
          path_found = TRUE;
        } else {
          /* alle Hilfsknoten eintragen */
          pre_node = from;
          while (node_to->state == HELP) {
            h_el = graph->edge_root;
            found = FALSE;
            append_edge_pathnode (& (tmp_el->edge), node_to->number);
            del_edge (graph, pre_node, node_to->number);
            while (h_el && (found != TRUE)) {
              if ((h_el->edge.from == node_to->number) &&
                  (h_el->edge.to != pre_node)) {
                pre_node = h_el->edge.from;
                node_to = get_node (graph, h_el->edge.to);
                found = TRUE;
              } else
                h_el = h_el->next;
            }
          }
          /* End-Knoten auch eintragen */
          del_edge (graph, pre_node, node_to->number);
          tmp_el->edge.to = node_to->number;
          path_found = TRUE;
        }
      }
      el = el->next;
    }
  }
  if (path_found == FALSE)
    tmp_el = NULL;

  return (tmp_el);
}

/****************************************************************************/
/* NAME: reorder_graph                                                      */
/* FUNKTION: wandelt einen einfachen Graph, der aus Kanten =                */
/* Kontenpaaren besteht in einen Graph mit Knotenpaar von->nach             */
/* und im path die zu durchlaufenden Hilfsknoten.                           */
/* (d.h aus [1->2h] [2h->4h] [4h->3h] [3h->5] wird [1->5] [2h-4h-3h])       */
/* UEBERGABEPARAMETER: Graph * der zu wandelnde Graph                       */
/* RUECKGABEWERT: graphlistptr (der gewandelte Graph zum einhaengen         */
/*                in die Graph-Liste)                                       */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 19.09.95                                                             */
/* LETZTE AENDERUNG AM: 27.09.95                                            */
/****************************************************************************/
graphlistptr reorder_graph (Graph * gr)
{
  int nodes;
  int j;
  nodelistptr nl;
  nodelistptr n;
  edgelistptr el;
  Node * from;
  graphlistptr g_new = NULL;

  if (gr) {
    nodes = get_last_node (gr);

    g_new = mk_graph (gr->name, NORMAL);
    nl = gr->node_root;

    while (nl) {
      n = make_node (nl->node.name, nl->node.x_pos, nl->node.y_pos,
                     nl->node.dim, nl->node.state);

      n->node.number = nl->node.number;

      append_node (& (g_new->graph), n);
      nl = nl->next;
    }
    for (j = 1; j <= nodes; j ++) {
      from = get_node (gr, j);
      if (from) {
        if ((from->state != HELP) && (from->state != SELECTED_HELP)) {
          while ((el = find_edge_path (gr, j))) {
            /* solange Pfade vom Knoten da */
            append_edge (& (g_new->graph), el);
          }
        }
      }
    }
  }
  return (g_new);
}

/****************************************************************************/
/* NAME: correct_graph                                                      */
/* FUNKTION: Korrigiert die internen Knotennummern falls Knoten geloescht   */
/*           worden sind                                                    */
/* UEBERGABEPARAMETER: Graph * der zu wandelnde Graph                       */
/* RUECKGABEWERT: Keiner                                                    */
/* ERSTELLT VON: Ulf Milanese                                               */
/* AM: 09-NOV-2001                                                          */
/* LETZTE AENDERUNG AM: 09-NOV-2001                                         */
/****************************************************************************/
void correct_graph (Graph * gr)
{
  int nodes;
  int j;
  int * neueliste;
  nodelistptr nl;
  edgelistptr el;
  intlistptr il;

  if (gr) {
    nodes = get_last_node (gr);

    nl = gr->node_root;
    /* Zuerst pruefen wir, ob der letzte Knoten die richtige Nummer hat */
    j = 0;
    while (nl) {
      j = nl->node.number;
      nl = nl->next;
    }
    if (j == nodes)
      return;

    /* Falls der letzte Knoten nicht die richtige Nummer hat, erstellen wir
       eine Liste der Umbenennungen und benennen die Knoten um */
    neueliste = (int *) malloc (sizeof (int) * (j + 1));
    nl = gr->node_root;
    j = 1;
    while (nl) {
      neueliste [nl->node.number] = j;
      nl->node.number = j ++;
      nl = nl->next;
    }

    /* Nun kommen die Kanten dran */
    el = gr->edge_root;
    while (el) {
      el->edge.from = neueliste [el->edge.from];
      el->edge.to = neueliste [el->edge.to];
      il = el->edge.path;
      while (il) {
        il->number = neueliste [il->number];
        il = il->next;
      }
      el = el->next;
    }
    free (neueliste);
  }
}

/****************************************************************************/
/* NAME: graph_name                                                         */
/* FUNKTION: gibt den Namen des Graphen zurueck                             */
/* UEBERGABEPARAMETER: graphlistptr (der Graph)                             */
/* RUECKGABEWERT: char * (der Name)                                         */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 04.03.96                                                             */
/* LETZTE AENDERUNG AM: 04.03.96                                            */
/****************************************************************************/
char * graph_name (graphlistptr gl)
{
  return (gl->graph.name);
}

/****************************************************************************/
/* NAME: swap_graph_hori                                                    */
/* FUNKTION: spiegelt den Graphen um die horizontale Achse                  */
/* UEBERGABEPARAMETER: graphlistptr (der Graph)                             */
/* RUECKGABEWERT: KEINER                                                    */
/* ERSTELLT VON: Peter Schneider                                            */
/* AM: 04.03.96                                                             */
/* LETZTE AENDERUNG AM: 04.03.96                                            */
/****************************************************************************/
void swap_graph_hori (Graph * gr)
{
  nodelistptr nl;
  int max_y;
  int y_pos;

  if (gr) {
    nl = gr->node_root;
    max_y = get_graph_height (gr);
    while (nl) {
      y_pos = nl->node.y_pos;
      nl->node.y_pos = max_y - y_pos;
      nl = nl->next;
    }
  }
}


static gboolean _graph_node_is_helper (Node * node)
{
  return node->state == HELP || node->state == SELECTED_HELP;
}


static void _graph_node_dump (Node * node)
{
  printf ("___node_(%p)__:\n"
          "     name : \"%s\"\n"
          "    x_pos : %d\n"
          "    y_pos : %d\n"
          "   number : %d\n"
          "      dim : %d\n"
          "    state : %d\n"
          "    flags : %d\n"
          "\n", node, node->name, node->x_pos, node->y_pos,
          node->number, node->dim, node->state, node->flags);
}

static void _graph_edge_dump (Edge * edge)
{
  printf ("___edge_(%p)__:\n"
          "       name : \"%s\"\n"
          "   from, to : %d -> %d\n"
          "      state : %d\n"
          "      flags : 0%x\n"
          "       path : ",
          edge, edge->name, edge->from, edge->to,
          edge->state, edge->flags);
  if (! edge->path)
    printf ("(null)");
  else {
    intlistptr il = edge->path;
    while (il) {
      printf ("%d", il->number);
      il = il->next;
      if (il)
        printf (" -> ");
    }
  }
  puts ("\n");
}

int graph_get_edge_count (Graph * gr)
{
#ifdef EDGES_TREE_LOOKUP
  return g_tree_nnodes (gr->edge_tree);
#else
  edgelistptr el = gr->edge_root;
  int n = 0;

  while (el) { n++; el=el->next; }
  return n;
#endif
}

/* Counts all nodes. */
static int _graph_get_all_node_count (Graph * gr)
{
#ifdef NODES_TREE_LOOKUP
  return g_tree_nnodes (gr->node_tree);
#else
  nodelistptr nl = gr->node_root;
  int n = 0;

  while (nl) { n++; nl=nl->next; }
  return n;
#endif
}

void graph_dump (Graph * gr)
{
  int nodeCount = graph_get_node_count (gr);
  int edgeCount = graph_get_edge_count (gr);
  int allNodeCount = graph_get_node_count (gr);
  int nodesInTree = -1, edgesInTree = -1;
  int observerCount = g_slist_length (gr->observers);

#ifdef EDGES_TREE_LOOKUP
  edgesInTree = g_tree_nnodes (gr->edge_tree);
#endif

#ifdef NODES_TREE_LOOKUP
  nodesInTree = g_tree_nnodes (gr->node_tree);
#endif

  printf ("___graph_(%p)__:\n"
          "        name : \"%s\"\n"
          "       state : %d\n"
          "       nodes : %d (%d in tree, with helpers: %d)\n"
          "       edges : %d (%d in tree)\n"
          "   observers : %d\n"
          "\n", gr, gr->name, gr->state, nodeCount, nodesInTree,
          allNodeCount, edgeCount, edgesInTree, observerCount);

  printf ("   Node enumation follows ...\n");
  {
    nodelistptr nl = gr->node_root;
    while (nl) {
      _graph_node_dump (&nl->node);
      nl = nl->next;
    }
  }

  printf ("   Edge enumation follows ...\n");
  {
    edgelistptr el = gr->edge_root;
    while (el) {
      _graph_edge_dump (&el->edge);
      el = el->next;
    }
  }

  printf ("  graph dumped!\n"
          "\n");
}

/* ----------------------------------------------------------- EdgeLayout --- */

GraphEdgeLayout * graph_edge_layout_new (gint from, gint to)
{
  GraphEdgeLayout * self = g_new0 (GraphEdgeLayout, 1);

  self->fromId = from;
  self->toId = to;
  self->type = EDGE_LAYOUT_DEFAULT;

  return self;
}

void graph_edge_layout_destroy (GraphEdgeLayout * self)
{
  if (EDGE_LAYOUT_SEGMENTS == self->type) {
    GList * segIter = self->segs->head;

    while (segIter) {
      free (segIter->data);
      segIter = segIter->next;
    }

    g_queue_free (self->segs);
  }
  else { ; }

  g_free (self);
}

void graph_edge_layout_add_segments (GraphEdgeLayout * self,
                                     int ptsCount, float * pts)
{
  if (EDGE_LAYOUT_DEFAULT == self->type) {
    self->type = EDGE_LAYOUT_SEGMENTS;
    self->segs = g_queue_new ();
  }

  if (EDGE_LAYOUT_SEGMENTS == self->type) {
    int i;

    for (i = 0 ; i < ptsCount ; i ++) {
      LayoutPoint * pt = g_new (LayoutPoint, 1);
      pt->x = pts[2*i];
      pt->y = pts[2*i+1];

      //printf ("point[%d]: %f, %f\n", i, pt->x, pt->y);

      g_queue_push_tail (self->segs, pt);
    }
  }
  else {
    /* Ignore. */
  }
}

void graph_edge_layout_add_segments_with_list (GraphEdgeLayout * self,
                                               GList/*<GraphLayoutPoint>*/ * pts)
{
  if (pts) /* at least one element. */ {
    int ptCount = g_list_length (pts);
    float * ptsArr = g_new(float, 2 * ptCount);
    GList * iter = pts;
    int i = 0;

    while (iter) {
      GraphLayoutPoint * pt = (GraphLayoutPoint*) iter->data;
      ptsArr[i] = pt->x;
      ptsArr[i+1] = pt->y;
      i += 2;
      iter = iter->next;
    }

    graph_edge_layout_add_segments (self, ptCount, ptsArr);

    g_free (ptsArr);
  }
}

static void _graph_edge_create_layout (Graph * gr, Edge * edge, EdgeLayout * layout);

/* The graph is necessary due to helper node creation/deletion. */
void graph_edge_apply_layout (Graph * gr, Edge * edge, GraphEdgeLayout * layout)
{
  _graph_edge_create_layout (gr, edge, layout);
}

void graph_edge_layout_dump (GraphEdgeLayout * self)
{
  printf ("_GraphEdgeLayout:___\n"
          "\tfromId : %d\n"
          "\t  toId : %d\n"
          "\t  type : %s\n"
          "\t  segs : \n"
          "\t\t", self->fromId, self->toId,
#define ENUM2STRING(val,en) ((val) == en) ? #en
          ENUM2STRING(self->type, EDGE_LAYOUT_DEFAULT)
          : ENUM2STRING(self->type, EDGE_LAYOUT_SEGMENTS) : "UNKNOWN");
#undef ENUM2STRING
  if (self->type != EDGE_LAYOUT_SEGMENTS)
    printf ("\t\ttype doesn't have segments.\n");
  else {
    GList * iter = self->segs->head;
    if (! iter) {
      printf ("no segments.\n");
    }
    else {
      while (iter) {
        LayoutPoint * pt = (LayoutPoint*) iter->data;
        printf ("(%f,%f) ", pt->x, pt->y);
        iter = iter->next;
      }
      putchar ('\n');
    }
  }
  putchar ('\n');
}

/* ---------------------------------------------------------- GraphLayout --- */

/*!
 * Convertes edges with pathes into edges without pathes. Also removes
 * all helper nodes from the graph.
 *
 * \author stb
 * \date 29.10.2008
 */
void graph_simplify_layout (Graph * gr)
{
  edgelistptr el = gr->edge_root;

  while (el) {
    graph_edge_remove_layout (gr, &el->edge);
    el = el->next;
  }

  assert (graph_get_node_count (gr) == _graph_get_all_node_count (gr));
}

/*!
 * Remove the edges layout.
 *
 * \author stb
 * \date 28.10.2008
 *
 * \param gr The graph the edge belongs to.
 * \param edge The edge.
 */
void graph_edge_remove_layout (Graph * gr, Edge * edge)
{
  intlistptr il = edge->path, tmp_il;

  assert (gr && edge);

  while (il) {
    del_single_node (gr, il->number); /* Delete the help node. */

    tmp_il = il;
    free (tmp_il);
    il = il->next;
  }

  edge->path = NULL;
}

/*!
 * Layout the given edge of the given graph according to the given
 * edge layout.
 *
 * \author stb
 * \date 28.10.2008
 *
 * \param gr The graph the edge belongs to.
 * \param edge The edge.
 * \param layout The layout to use.
 */
void _graph_edge_create_layout (Graph * gr, Edge * edge, EdgeLayout * layout)
{
  assert (gr && edge && layout);

  /* Delete a previous layout. */
  graph_edge_remove_layout (gr, edge);

  if (layout->type == EDGE_LAYOUT_DEFAULT) {
    return;
  }
  else if (EDGE_LAYOUT_SEGMENTS == layout->type) {
    intlistptr tail = NULL;
    GList * segIter = layout->segs->head;

    while (segIter) {
      nodelistptr helper = NULL;
      LayoutPoint * pt = (LayoutPoint*) segIter->data;
      intlistptr cur = (intlistptr) calloc (1, sizeof (intelem));

      if (! tail) /* first */ {
        edge->path = cur;
      } else tail->next = cur;
      tail = cur;

      /* If one of the components is smaller than 0, set it to 0. */
      if (pt->x < 0 || pt->y < 0) {
        float x = pt->x, y = pt->y;
        pt->x = MAX(.0f, x);
        pt->y = MAX(.0f, y);

        printf ("_graph_edge_create_layout: point (%.f,%.f) is fixed "
                "to (%.f,%.f)\n", x,y, pt->x, pt->y);
      }

      /* Create a help node for the 'intelem' */
      helper = make_node ("", pt->x, pt->y, 0, HELP);
      assert (helper != NULL);
      append_node (gr, helper); /* TODO: Slow! */

      cur->number = helper->node.number;
      //printf ("number: %d\n", cur->number);

      segIter = segIter->next;
    }
  }
}

/*!
 * Apply the given layout to the given graph. Overwrite any previous layout.
 *
 * \note Does not update the owning GraphWindow.
 *
 * \author stb
 * \date 28.10.2008
 *
 * \param gr The graph to layout.
 * \param layout The layout to use.
 */
gboolean graph_apply_layout (Graph * gr, GraphLayout * layout)
{
  assert (gr && layout);

  /* Every node must be layed out. */
  if (graph_get_node_count(gr) != g_queue_get_length (layout->nodes))
    return FALSE;

  /* Layout the nodes first. */
  {
    GList * nodeIter = layout->nodes->head;

    while (nodeIter) {
      NodeLayout * nl = (NodeLayout*)nodeIter->data;
      Node * n = get_node (gr, nl->id);
      n->x_pos = nl->x;
      n->y_pos = nl->y;

      nodeIter = nodeIter->next;
    }
  }

  /* Delete the edges' layout and apply our own one. */
  {
    edgelistptr edgeIter = gr->edge_root;
    GList * edgeLayoutIter = layout->edges->head;

    while (edgeIter) {
      graph_edge_remove_layout (gr, &edgeIter->edge);
      edgeIter = edgeIter->next;
    }

    while (edgeLayoutIter) {
      EdgeLayout * el = (EdgeLayout*)edgeLayoutIter->data;
      Edge * e = get_edge (gr, el->fromId, el->toId);
      _graph_edge_create_layout (gr, e, el);

      edgeLayoutIter = edgeLayoutIter->next;
    }
  }

  return TRUE;
}


/*!
 * Create an empty graph layout.
 *
 * \author stb
 * \date 30.10.2008
 *
 * \return Returns the newly created graph layout.
 */
GraphLayout * graph_layout_new ()
{
  GraphLayout * obj = (GraphLayout*) calloc(1, sizeof(GraphLayout));

  obj->nodes = g_queue_new ();
  obj->edges = g_queue_new ();

  return obj;
}

/*!
 * Destroy a previouly created graph layout.
 *
 * \author stb
 * \date 30.10.2008
 *
 * \param obj The graph layout to destroy.
 */
void graph_layout_destroy (GraphLayout * obj)
{
  GList * nlIter = obj->nodes->head;
  GList * elIter = obj->edges->head;

  /* Destroy the layout data for the nodes ... */
  while (nlIter) {
    free (nlIter->data);
    nlIter = nlIter->next;
  }

  /* ... and for the edges ... */
  while (elIter) {
#if 1
    graph_edge_layout_destroy ((GraphEdgeLayout*) elIter->data);
#else
    EdgeLayout * el = (EdgeLayout*) elIter->data;
    GList * segIter = el->segs->head;

    while (segIter) {
      free (segIter->data);
      segIter = segIter->next;
    }

    g_queue_free (el->segs);
    free (el);
#endif
    elIter = elIter->next;
  }

  /* ... and the corresponding queues. */
  g_queue_free (obj->nodes);
  g_queue_free (obj->edges);

  free(obj);
}


/*!
 * Layout the node with the given id.
 *
 * \author stb
 * \date 30.10.2008
 *
 * \param self The graph layout.
 * \param id Identifies the node to layout
 * \param x The x coord. of the node in the layout.
 * \param y The y coord. of the node in the layout.
 */
void graph_layout_add_node (GraphLayout * self, gint id, gfloat x, gfloat y)
{
  NodeLayout * nl = (NodeLayout*) calloc (1, sizeof (NodeLayout));
  nl->id = id;
  nl->x = x;
  nl->y = y;

  assert (self != NULL);

  g_queue_push_tail (self->nodes, nl);
}

/*!
 * Layout the edge incident to the given node id's. ptsCount contains the
 * number of breakpoints to use for the edge. Don't call this function, if
 * the edge is a straight line. ptsCount should then be 0. Because each
 * edge is layouted as a straight line by default, a call in case of ptsCount
 * equals to 0 is useless. In case ptsCount is greater than 0, pts contains
 * 2*ptsCount values, whereby the odd values are the x coords and the even
 * values are the corresponding y coords.
 *
 * \note If both edges from->to and to->from are in the graph, they are
 *       layouted in the same way. If different layouts are set, anyone
 *       is choosen..
 *
 * \author stb
 * \date 30.10.2008
 *
 * \param self The graph layout.
 * \param fromId The edge starts here.
 * \param toId The edge ends here.
 * \param ptsCount The number of breakpoints. Should be greater than 0.
 * \param pts 2*ptsCount values. See above for details.
 */
void graph_layout_add_edge_segments (GraphLayout * self, gint fromId, gint toId,
                                     gint ptsCount, gfloat * pts)
{
  if (ptsCount < 0)
    return;
  else {
#if 1
    GraphEdgeLayout * el = graph_edge_layout_new (fromId, toId);

    graph_edge_layout_add_segments (el, ptsCount, pts);
    g_queue_push_tail (self->edges, el);

#else
    int i;
    EdgeLayout * el = (EdgeLayout*) calloc (1, sizeof (EdgeLayout));
    el->fromId = fromId;
    el->toId = toId;
    el->segs = g_queue_new ();

    assert (self != NULL);

    for (i = 0 ; i < ptsCount ; i ++) {
      LayoutPoint * pt = (LayoutPoint*) calloc (1, sizeof (LayoutPoint));
      pt->x = pts[2*i];
      pt->y = pts[2*i+1];

      //printf ("point[%d]: %f, %f\n", i, pt->x, pt->y);

      g_queue_push_tail (el->segs, pt);
    }

    g_queue_push_tail (self->edges, el);
#endif

  }
}

graphlistptr graph_create_default (KureRel * impl, int radius, const char * name)
{
  int i;
  int j;
  double pi = 355.0 / 113.0;
  /* PI als Bruch */
  double delta_alpha;
  int x;
  int y;
  int dim = 24;
  char title [64];
  graphlistptr gl;
  nodelistptr nl;
  edgelistptr el;
  int vars_zeilen = kure_rel_get_vars_rows (impl);
  int vars_spalten = kure_rel_get_vars_cols (impl);

  if ( !kure_is_hom(impl, NULL)) {
  //if (Kure_mp_mcmp (rel->hoehe, rel->breite) != 0)
    gl = NULL;
  }
  else {
    int knoten_anzahl = kure_rel_get_rows_si (impl);
    //... = Kure_mp_mint2int (rel->hoehe);

    gl = mk_graph ((char*)name, NORMAL);

    delta_alpha = 2 * pi / (double) (knoten_anzahl);

    /* Create the nodes in backward order, so we can use prepend,
     * instead of the (very) slow append operation. */
    for (i = knoten_anzahl; i-- > 0 ;) {
      sprintf (title, "%d", i + 1);

      x = 2 * dim + radius - radius * sin (i * delta_alpha);
      y = 2 * dim + radius + radius * cos (i * delta_alpha);

      nl = make_node (title, x, y, dim, VISIBLE);

      graph_prepend_node (& (gl->graph), nl, i+1);
    }

    for (i = 0; i < knoten_anzahl; i ++)
      for (j = 0; j < knoten_anzahl; j ++) {
    	  if (kure_get_bit_fast_si (impl, i,j, vars_zeilen, vars_spalten)) {
        //if (get_rel_bit (rel, j, i, vars_zeilen, vars_spalten) != 0) {
          el = make_edge ("", i + 1, j + 1, WEIGHT);
          graph_prepend_edge (& (gl->graph), el);
        }
      }
  }

  return (gl);
}
