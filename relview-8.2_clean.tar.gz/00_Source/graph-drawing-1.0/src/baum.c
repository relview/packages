//#include "global.h"
//#include "relation.h"
//#include "label.h"

#include "global-sme.h"
#include "zerlegen.h"
#include "baum.h"

#include "graph.h"

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

/* modulglobale Variablen */

static S_GRAPH * Komponenten;
static int kanzahl;  /* = Knotenzahl */
static int Komponentenzahl;
static int max_tree;
static int ** feld;
static S_EDGE * edges;


/****************************************************************************/
/* NAME : make_graph_baum                                                   */
/* FUNKTION : liest Relation und erstellt daraus Kantenliste                */
/* UEBERGABEPARAMETER : name Name der Relation                              */
/*                      edges Kantenliste (wird hier initialisiert)         */
/*                      n Knotenzahl, Kanz Kantenzahl                       */
/* RUECKGABEWERT : Anzahl der Kanten, die hin und her gehen                 */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 05.05.95                                                            */
/* LETZTE AENDERUNG AM :05.05.95                                            */
/****************************************************************************/
int make_graph_baum (KureRel * impl, S_EDGE **edges, int * n, int * Kanz)
{
	int lines;
	int columns;
	int i;
	int j;
	int aktuell;
	int double_count = 0;
	int vars_zeilen;
	int vars_spalten;

	if ( !kure_is_hom(impl, NULL)) {
		g_warning ("make_graph_baum: Relation is not homogeneous.");
		return 0;
	}

	lines = kure_rel_get_rows_si(impl);
	columns = kure_rel_get_cols_si(impl);

	*n = lines;
	*Kanz = 0;

	vars_zeilen = kure_rel_get_vars_rows (impl);
	vars_spalten = kure_rel_get_vars_cols (impl);

	for (i = 0; i < lines; i ++)
		for (j = 0; j <= i; j ++)
			if (kure_get_bit_fast_si (impl, i,j,vars_zeilen,vars_spalten)
					|| kure_get_bit_fast_si (impl, j,i,vars_zeilen, vars_spalten))
				//if ((get_rel_bit (rel, j, i, vars_zeilen, vars_spalten)) ||
				//		(get_rel_bit (rel, i, j, vars_zeilen, vars_spalten)))
				(* Kanz) ++;

	* edges = (S_EDGE *) calloc (* Kanz, sizeof (S_EDGE));

	aktuell = 0;
	for (i = 0; i < lines; i++)
		for (j = 0; j < i; j++)
			if (kure_get_bit_fast_si(impl, i,j,vars_zeilen,vars_spalten)) {
				//if (get_rel_bit (rel, j, i, vars_zeilen, vars_spalten)) {
				(* edges) [aktuell].tail = i;
				(* edges) [aktuell].head = j;
				if (kure_get_bit_fast_si (impl, j,i, vars_zeilen, vars_spalten)) {
					//if (get_rel_bit (rel, i, j, vars_zeilen, vars_spalten)) {
					(* edges) [aktuell ++].back_and_forth = TRUE;
					double_count ++;
				} else
					(* edges) [aktuell ++].back_and_forth = FALSE;
			}
			else if (kure_get_bit_fast_si (impl, j, i,vars_zeilen, vars_spalten)) {
					//if (get_rel_bit (rel, i, j, vars_zeilen, vars_spalten)) {
					(* edges) [aktuell].back_and_forth = FALSE;
					(* edges) [aktuell].tail = j;
					(* edges) [aktuell++].head = i;
				}

	for (i = 0; i < lines; i++) {
		if (kure_get_bit_fast_si (impl, i,i, vars_zeilen, vars_spalten)) {
			//if (get_rel_bit (rel, i, i, vars_zeilen, vars_spalten)) {
			(* edges) [aktuell].tail = i;
			(* edges) [aktuell].head = i;
			(* edges) [aktuell++].back_and_forth = FALSE;
		}
	}

	return (double_count);
}

/****************************************************************************/
/* NAME : tree                                                              */
/* FUNKTION : malt den Graph als Baum bzw. als Wald                         */
/* UEBERGABEPARAMETER : rel Relationname, x_Abstand, y_Abstand der Knoten   */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 25.8.95                                                             */
/* LETZTE AENDERUNG AM : 25.8.95                                            */
/****************************************************************************/
graphlistptr tree (KureRel * impl, int x_Abstand, int y_Abstand)
{
  int i;
  int n;
  int Kantenzahl;
  graphlistptr gl;

  if (make_graph_baum (impl, &edges, &n, &Kantenzahl) != 0
      || baum_test (n, Kantenzahl) == FALSE) {
    free (edges);
    g_warning ("tree: Graph is no forst. Using DAG instead.");
    gl = dag (impl, x_Abstand, y_Abstand);
    return (gl);
  }
  else zerlegen_spring (n, Kantenzahl, edges, &Komponenten,  &Komponentenzahl);

  free (edges);
  for (i = 0; i < Komponentenzahl; i++) {
    kanzahl = Komponenten[i].node_count;
    feld = make_feld (Komponenten[i]);
    baum ();
    uebertragen (i);
    find_max (i);
  }

  Komponenten_sort ();
  abs_coord (x_Abstand, y_Abstand);
  gl = baum_to_graph (impl);
  free_glob ();

  return (gl);
}

/****************************************************************************/
/* NAME : make_feld                                                         */
/* FUNKTION : macht aus der Kantenliste eine Darstellung des Graphen als    */
/*            Matrix                                                        */
/* UEBERGABEPARAMETER : graph  eine Komponente vom Typ S_GRAPH              */
/* RUECKGABEWERT : die Matrix                                               */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 25.8.95                                                             */
/* LETZTE AENDERUNG AM : 25.8.95                                            */
/****************************************************************************/
static int ** make_feld (S_GRAPH graph)
{
	int i;
	int n;
	int **feld;

	n = graph.node_count + 5;
	feld = (int **) calloc (n, sizeof (int *));

	for (i = 0; i < n; i++) {
		feld[i] = (int *) calloc (n, sizeof (int));
	}

	for (i = 0; i < graph.edge_count; i++)
		feld[graph.edges[i].tail + 1][graph.edges[i].head + 3] = 1;

	return (feld);
}


/****************************************************************************/
/* NAME : uebertragen                                                       */
/* FUNKTION : uebertraegt die Positionen aus der Matrix in die              */
/*            S_GRAPH-Struktur                                              */
/* UEBERGABEPARAMETER : nr Nummer der Komponente                            */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 28.8.95                                                             */
/* LETZTE AENDERUNG AM : 28.8.95                                            */
/****************************************************************************/
static void uebertragen (int nr)
{
	int i;

	Komponenten[nr].nodes = (S_NODE *) calloc (Komponenten[nr].node_count,
			sizeof (S_NODE));

	for (i = 0; i < Komponenten[nr].node_count; i++) {
		Komponenten[nr].nodes[i].x_pos = feld[i + 1][1];
		Komponenten[nr].nodes[i].y_pos = feld[i + 1][2];
	}
}


/****************************************************************************/
/* NAME : abs_coord                                                         */
/* FUNKTION : berechnet absolute Koordinaten                                */
/* UEBERGABEPARAMETER : x_Abstand, y_Abstand  der Knoten                    */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 28.8.95                                                             */
/* LETZTE AENDERUNG AM : 28.8.95                                            */
/****************************************************************************/
static void abs_coord (int x_Abstand, int y_Abstand)
{
	int i;
	int j;
	int offset;
	int Komponentenabstand = 2;
	int mind_x_abstand = x_Abstand;
	int mind_y_abstand = y_Abstand;

	offset = Komponenten[0].x_max + Komponentenabstand;
	for (i = 1; i < Komponentenzahl; i++) {
		for (j = 0; j < Komponenten[i].node_count; j++)
			Komponenten[i].nodes[j].x_pos += offset;  /* rank = x-Koordinate */
		offset += Komponenten[i].x_max + Komponentenabstand;
	}

	/* hier kriegen sie erst die richtigen Koordinaten */

	for (i = 0; i < Komponentenzahl; i++)
		for (j = 0; j < Komponenten[i].node_count; j++) {
			Komponenten[i].nodes[j].x_pos *= mind_x_abstand;
			Komponenten[i].nodes[j].y_pos -= 1;
			Komponenten[i].nodes[j].y_pos *= mind_y_abstand;
		}
}


/****************************************************************************/
/* NAME : find_max                                                          */
/* FUNKTION : findet die max. x- bzw. y-Koordinaten einer Komponente        */
/* UEBERGABEPARAMETER : nr Nummer der Komponente                            */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 29.8.95                                                             */
/* LETZTE AENDERUNG AM : 29.8.95                                            */
/****************************************************************************/
static void find_max (int nr)
{
	int i;
	int x_max;
	int y_max;
	int x_min;

	x_max = 0;
	y_max = 0;
	x_min = 0;

	for (i = 0; i < Komponenten[nr].node_count; i++) {
		x_max = Max (x_max, Komponenten[nr].nodes[i].x_pos);
		y_max = Max (y_max, Komponenten[nr].nodes[i].y_pos);
		x_min = Min (x_min, Komponenten[nr].nodes[i].x_pos);
	}

	if (x_min != 0)
		for (i = 0; i < Komponenten[nr].node_count; i++)
			Komponenten[nr].nodes[i].x_pos -= x_min;

	Komponenten[nr].x_max = x_max - x_min;
	Komponenten[nr].y_max = y_max;
}


/****************************************************************************/
/* NAME : free_glob                                                         */
/* FUNKTION : gibt Speicherplatz fuer globale Variablen wieder frei         */
/* UEBERGABEPARAMETER :                                                     */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 28.8.95                                                             */
/* LETZTE AENDERUNG AM : 28.8.95                                            */
/****************************************************************************/
static void free_glob ()
{
	int i;

	for (i = 0; i < Komponentenzahl; i++) {
		free(Komponenten[i].nodes);
		free(Komponenten[i].edges);
	}
	free (Komponenten);

	for (i = 0; i < kanzahl + 5; i++)
		free (feld[i]);
	free (feld);
}

/****************************************************************************/
/* NAME : baum_test                                                         */
/* FUNKTION : testet, ob Graph ein Wald ist                                 */
/* UEBERGABEPARAMETER : n Knotenzahl, Kantenzahl                            */
/* RUECKGABEWERT : TRUE wenn ja, FALSE wenn nicht                           */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 6.9.95                                                              */
/* LETZTE AENDERUNG AM : 6.9.95                                             */
/****************************************************************************/
static int baum_test (int n, int Kantenzahl)
{
	int i;
	int res;
	int * sohn_test;

	sohn_test = (int *) calloc (n, sizeof (int));
	if (sohn_test == NULL) {
		exit (0);
	}

	res = TRUE;
	for (i = 0; i < Kantenzahl; i++)
		if (sohn_test[edges[i].head] == 0)
			sohn_test[edges[i].head] = 1;
		else {
			res = FALSE;
			break;
		}

	free (sohn_test);

	return (res);
}

/****************************************************************************/
/* NAME : baum_to_graph                                                     */
/* FUNKTION : speichert Koordinaten des Graphen                             */
/*            (ein wenig aufwendig, da die Knoten in aufsteigender          */
/*            Reihenfolge in die Datenstruktur Graph ueberfuehrt werden     */
/*            muessen, dies aber bei den Komponeneten nicht der Fall sein   */
/*            muss. aufsteigende Nummer, weil beim Loeschen neu nummeriert  */
/*            werden muss)                                                  */
/* UEBERGABEPARAMETER : rel Name der Relation                               */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 4.7.95                                                              */
/* LETZTE AENDERUNG AM : 4.7.95                                             */
/****************************************************************************/
graphlistptr baum_to_graph (KureRel * impl)
{
	int k;
	int i;
	int j;
	int found;
	int number_of_nodes = 0;
	Graph * gr;
	char number_name[16];
	nodelistptr node_ptr;
	edgelistptr edge_ptr;
	graphlistptr gl;

	/* Anzahl der Knoten aller Komponenten des Graphen ermitteln */

	for (k = 0; k < Komponentenzahl; k++)
		number_of_nodes = number_of_nodes + Komponenten[k].node_count ;

	gl = mk_graph (UNKNOWN_GRAPH_NAME, NORMAL);

	if (gl != (graphlistptr) NULL) {
		gr = &(gl->graph);

		for (i = 0; i < number_of_nodes; i++) {
			k = 0;
			found = FALSE;

			while ((k < Komponentenzahl) && (found != TRUE)) {
				j = 0;
				while ((j < Komponenten[k].node_count ) && (found != TRUE)) {
					if ((Komponenten[k].inj[j]) == i) {
						sprintf (number_name, "%d", Komponenten[k].inj[j] + 1);

						node_ptr =
								make_node (number_name,
										(int) Komponenten[k].nodes[j].x_pos + DEFAULT_DIM,
										(int) Komponenten[k].nodes[j].y_pos + DEFAULT_DIM,
										DEFAULT_DIM, VISIBLE);

						if (node_ptr != (nodelistptr) NULL)
							append_node (gr, node_ptr);

						found = TRUE;
					}

					else
						j++;
				}
				k++;
			}
		}

		for (k = 0; k < Komponentenzahl; k++) {
			for (i = 0; i < Komponenten[k].edge_count; i++) {
				edge_ptr =
						make_edge ("", Komponenten[k].inj[Komponenten[k].edges[i].tail] + 1,
								Komponenten[k].inj[Komponenten[k].edges[i].head] + 1,
								VISIBLE);

				append_edge (gr, edge_ptr);
			}
		}
	}

	return (gl);
}

/****************************************************************************/
/* NAME : piv                                                               */
/* FUNKTION : findet Stelle mit Wert, nach dem sortiert wird                */
/* UEBERGABEPARAMETER : i, j Randpunkte                                     */
/* RUECKGABEWERT : der Wert, nach dem sortiert wird                         */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 30.6.95                                                             */
/* LETZTE AENDERUNG AM : 30.6.95                                            */
/****************************************************************************/
static int piv (int i, int j)
{
	int k;

	k = i;
	while (k < j && Komponenten[k].node_count == Komponenten[k + 1].node_count)
		k = k + 1;
	if (k == j)
		return (-1);
	else
		if (Komponenten[k].node_count > Komponenten[k + 1].node_count)
			return (k + 1);
		else
			return (k);
}

/****************************************************************************/
/* NAME : part                                                              */
/* FUNKTION : ordnet Komponenten nach pivot                                 */
/* UEBERGABEPARAMETER : i, j Randpunkte, pivot Wert nach dem Komponenten    */
/*                      geordnet werden                                     */
/* RUECKGABEWERT : Stelle von der an Werte groesser als pivot sind          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 30.6.95                                                             */
/* LETZTE AENDERUNG AM : 30.6.95                                            */
/****************************************************************************/
static int part (int i, int j, int pivot)
{
	S_GRAPH temp;

	while (Komponenten[i].node_count > pivot)
		i++;
	while (Komponenten[j].node_count <= pivot)
		j--;
	while (i < j) {
		temp = Komponenten[i];
		Komponenten[i] = Komponenten[j];
		Komponenten[j] = temp;
		while (Komponenten[i].node_count > pivot)
			i++;
		while (Komponenten[j].node_count <= pivot)
			j--;
	}
	return (i);
}


/****************************************************************************/
/* NAME : quicksort                                                         */
/* FUNKTION : sortiert Komponenten nach Knotenzahl                          */
/* UEBERGABEPARAMETER : i, j Randpunkte                                     */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 30.6.95                                                             */
/* LETZTE AENDERUNG AM : 30.6.95                                            */
/****************************************************************************/
static void quicksort (int i, int j)
{
	int pivot_pos;
	int k;
	int pivot;

	if (i < j) {
		pivot_pos = piv (i, j);
		if (pivot_pos != -1) {
			pivot = Komponenten[pivot_pos].node_count;
			k = part (i, j, pivot);
			quicksort (i, k - 1);
			quicksort (k, j);
		}
	}
}


/****************************************************************************/
/* NAME : Komponenten_sort                                                  */
/* FUNKTION : sortiert die Komponenten nach Knotenzahl                      */
/* UEBERGABEPARAMETER :                                                     */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 30.6.95                                                             */
/* LETZTE AENDERUNG AM : 30.6.95                                            */
/****************************************************************************/
static void Komponenten_sort ()
{
	quicksort (0, Komponentenzahl - 1);
}


/****************************************************************************/
/* NAME : baum                                                              */
/* FUNKTION : stellt eine Komponente als Baum dar                           */
/* UEBERGABEPARAMETER :                                                     */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 28.8.95                                                             */
/* LETZTE AENDERUNG AM : 28.8.95                                            */
/****************************************************************************/
static void baum ()
{
	int zeile;
	int spalte;
	int wurzel = 0;
	void setup_tree ();
	void pos_tree ();
	void petrify ();

	max_tree = 0;

	/* Nun muss die Wurzel gesucht werden = Knoten, auf den keine Kante
     weist, davon kann es nur einen geben (wie im Film)               */

	for (spalte = 3; spalte <= kanzahl + 2; spalte++)
		for (zeile = 1; zeile <= kanzahl; zeile++) {
			if (feld[zeile][spalte])  /* Wenn etwas in der Spalte > 0 */
				break;               /* steht -> naechste Spalte     */

			if (zeile == kanzahl) {
				wurzel = spalte - 2;
				spalte = kanzahl + 3;
			}
		}

	/* Als naechstes wird die Hoehe des Baumes bestimmt, und jedem Knoten
     seine Hoehe zugewiesen. feld wird umorganisiert                   */

	setup_tree (wurzel, 0, &max_tree);

	pos_tree (wurzel);
}


/****************************************************************************/
/* NAME : setup_tree                                                        */
/* FUNKTION : feld wird umorganisiert                                       */
/* UEBERGABEPARAMETER : knoten, level aktueller Level des Knotens,          */
/*                      hoehe Zeiger auf bisherigen maximalen level         */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 28.8.95                                                             */
/* LETZTE AENDERUNG AM : 28.8.95                                            */
/****************************************************************************/
static void setup_tree (int knoten, int level, int * hoehe)
{
	int sohncount = 0;
	int spalte;

	/* Finde alle Soehne von Knoten      */
	for (spalte = 3; spalte <= kanzahl + 2; spalte++)
		if (feld[knoten][spalte]) {
			sohncount++;
			feld[knoten][sohncount + 2] = spalte - 2;
		}

	feld[knoten][0] = sohncount;           /* Lege Anzahl der Soehne ab  */
	feld[knoten][1] = 0;
	feld[knoten][2] = level;               /* Merke dir die Hoehe d.K.   */
	feld[knoten][kanzahl + 2] = 0;           /* Modifier merken            */
	feld[knoten][kanzahl + 3] = 0;           /* Status + Pointer auf Sohn  */

	if(level > *hoehe)
		*hoehe = level;

	spalte = 1;

	while (spalte <= sohncount) {
		feld [(feld[knoten][spalte + 2])][kanzahl + 4] = knoten;
		setup_tree (feld[knoten][spalte + 2], level + 1, hoehe);
		spalte++;
	}
}


/****************************************************************************/
/* NAME : pos_tree                                                          */
/* FUNKTION : berechnet die Positionen der Knoten in ihrem level            */
/* UEBERGABEPARAMETER : wurzel Wurzel des Baumes                            */
/* RUECKGABEWERT :                                                          */
/* ERSTELLT VON : Stefan Meier                                              */
/* AM : 28.8.95                                                             */
/* LETZTE AENDERUNG AM : 28.8.95                                            */
/****************************************************************************/
static void pos_tree (int wurzel)
{
	int * next_pos;
	int * modifier;
	int i;
	int place;
	int h;
	int is_leaf;
	int modifier_sum = 0;
	int current;
	int sohnxsum;
	int status = kanzahl + 3;
	int vater = kanzahl + 4;
	int soehne = 0;
	int height = 2;
	int modif = kanzahl + 2;

	next_pos = (int *) calloc (max_tree + 1, sizeof (int));
	modifier = (int *) calloc (max_tree + 1, sizeof (int));
	if (next_pos == NULL || modifier == NULL) {
		printf ("Fehler pos_tree\n");
		exit (0);
	}

	for (i = 0; i <= max_tree; i++) {
		modifier[i] = 0;
		next_pos[i] = 0;
	}

	current = wurzel;
	feld[current][status] = 0;     /* == first_visit */

	while (current) {
		if (feld[current][status] == 0)  /* also bei first_visit */ {
			feld[current][status]++;     /* status == left_visit! */
			if (feld[current][soehne]) {
				current = feld[current][feld[current][status] + 2];
				feld[current][status] = 0; /* == first_visit */
			}
		}
		else                           /* schon mal da gewesen   */ {
			feld[current][status]++;  /* status == right_visit! */
			if (feld[current][status] <= feld[current][soehne]) {
				current = feld[current][feld[current][status] + 2]; /* next son */
				feld[current][status] = 0;
			}
			else   /* schon alle Soehne besucht */ {
				h = feld[current][height];
				if (!(feld[current][soehne]))
					is_leaf = TRUE;
				else
					is_leaf = FALSE;

				if (is_leaf)
					place = next_pos[h];      /* wenn Blatt */
				else
					if (feld[current][soehne] == 1)  /* nur ein Sohn! */
						place = feld[feld[current][3]][1];
					else {
						sohnxsum = 0;
						for (i = 1; i <= feld[current][soehne]; i++)
							sohnxsum += feld[feld[current][i + 2]][1];
						place = sohnxsum / (feld[current][soehne]);
					}
				modifier[h] = Max (modifier[h], (next_pos[h] - place));
				if (is_leaf)
					feld[current][1] = place;
				else
					feld[current][1] = place + modifier[h];

				next_pos[h] = feld[current][1] + 2;
				feld[current][modif] = modifier[h];
				current = feld[current][vater];
			}
		}
	}

	current = wurzel;
	feld[current][status] = 0;
	modifier_sum = 0;

	while(current) {
		if (feld[current][status] == 0) {
			feld[current][1] += modifier_sum;
			modifier_sum += feld[current][modif];
			feld[current][2]++;
			feld[current][status]++;
			if(feld[current][soehne]) {
				current = feld[current][feld[current][status] + 2];
				feld[current][status] = 0;
			}
		}
		else {
			feld[current][status]++;
			if (feld[current][status] <= feld[current][soehne]) {
				current = feld[current][feld[current][status] + 2];
				feld[current][status] = 0;
			}
			else {
				modifier_sum = modifier_sum - feld[current][modif];
				current = feld[current][vater];
			}
		}
	}
	free (next_pos);
	free (modifier);
}
