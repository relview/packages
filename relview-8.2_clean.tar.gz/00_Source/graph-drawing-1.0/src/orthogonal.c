/****************************************************************************/
/* Dateiname: orthogonal.c                                                  */
/* Enthaelt Funktionen fuer die Darstellung von orthogonalen Graphen,       */
/* Autor: Ulf Milanese                                                      */
/* erstellt am: 09.12.1998                                                  */
/* zuletzt geaendert am 01.02.1999                                          */
/* LETZTE AENDERUNG AM: 10.04.2000 (Umstellung auf grosse Zahlen)           */
/****************************************************************************/

#include "orthogonal.h"
#include "embedding.h"
#include "simpleposition.h"

#include <stdio.h>
#include <malloc.h>

/****************************************************************************/
/* NAME : rel_orthogonal                                                    */
/* FUNKTION : ueberprueft RelView-Relation rel auf (deg (rel) < 5)          */
/* UEBERGABEPARAMETER : Zeiger auf eine Relation                            */
/* RUECKGABEWERT : 1 falls rel orthogonal ist, 0 sonst                      */
/* ERSTELLT VON : Ulf Milanese (09.12.1998)                                 */
/* LETZTE AENDERUNG AM: 10.04.2000 (Umstellung auf grosse Zahlen)           */
/****************************************************************************/
int rel_orthogonal (KureRel * impl)
{
	unsigned int degree;
	int node_1, node_2;
	int vars_zeilen =kure_rel_get_vars_rows (impl) ;
	int vars_spalten = kure_rel_get_vars_cols (impl);
	int n = kure_rel_get_cols_si (impl);

	/* Nicht darstellbare Relation? */
	if ( !kure_is_hom(impl, NULL))
		return 0;

	for (node_1 = 0 ; node_1 < n ; ++ node_1) {
		degree = 0;

		for (node_2 = 0 ; node_2 < n && degree <= 4 ; ++node_2) {
			if ((node_1 != node_2) &&
#if 1
					(kure_get_bit_fast_si (impl, node_2, node_1, vars_zeilen, vars_spalten) ||
							kure_get_bit_fast_si (impl, node_1, node_2, vars_zeilen, vars_spalten)))
#else
				(get_rel_bit (relData, node_1, node_2, vars_zeilen, vars_spalten) ||
						get_rel_bit (relData, node_2, node_1, vars_zeilen, vars_spalten)))
#endif
						degree ++;
		}
		if (degree > 4)
			return (0);
	}

	return (1);
}


/****************************************************************************/
/* NAME : planar_subrelation                                                */
/* FUNKTION : Heuristik zur Erzeugung einer planaren Sub-Relation (nicht    */
/*            der minimalen)                                                */
/* UEBERGABEPARAMETER : Zeiger auf eine Relation (relData)                  */
/* VORAUSSETZUNG:                                                           */
/* RUECKGABEWERT : Zeiger auf eine Relation                                 */
/* ERSTELLT VON : Ulf Milanese (10.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/* 15.05.2000 (Umstellung auf grosse Zahlen)                                */
/****************************************************************************/
KureRel * planar_subrelation (KureRel * impl)
{
	KureRel *     resultat;
	//KureRel *  tmp_rel;
	edgelistptr edges;
	edgelistptr tmp_edges;
	edgelistptr new_edges;
	edgelistptr tmp_new_edges;
	edgelistptr deleted_edges = (edgelistptr) NULL;
	//Rel *    tmp_relData;
	int     node_1;
	int     node_2;
	int     highest_degree;
	int     actual_degree;
	int breite = kure_rel_get_cols_si (impl);
	int hoehe = kure_rel_get_rows_si (impl);
	//int     breite = Kure_mp_mint2int (relData->breite);
	//int     hoehe = Kure_mp_mint2int (relData->hoehe);
	unsigned int degrees [breite];
	unsigned int degrees_copy [breite];
	int     vars_zeilen = kure_rel_get_vars_rows (impl);
	int     vars_spalten = kure_rel_get_vars_cols (impl);

	resultat = kure_rel_new_with_proto (impl);
	//resultat = mk_rel (relData->name, relData->breite, relData->hoehe,
	//                 relData->state);

	/* In degrees werden die Grade der Knoten des reduzierten Graphens */
	/* gespeichert. */
	for (node_1 = 0; node_1 < breite; node_1 ++)
		degrees [node_1] = 0;

	edges = make_edge ("", 0, 0, VISIBLE);
	tmp_edges = edges;

	for (node_1 = 0; node_1 < breite - 1; node_1 ++)
		for (node_2 = node_1 + 1; node_2 < hoehe; node_2 ++) {
			if ((kure_get_bit_si (impl, node_1, node_2, NULL) || kure_get_bit_si (impl, node_2, node_1, NULL))) {
				kure_set_bit_si (resultat, TRUE, node_2, node_1);

				tmp_edges->next = make_edge ("", node_1, node_2, VISIBLE);
				tmp_edges = tmp_edges->next;
				degrees [node_1]++;
				degrees [node_2]++;
			}
		}

	for (node_1 = 0; node_1 < breite; node_1 ++)
		degrees_copy [node_1] = degrees [node_1];
	tmp_edges = edges;
	edges = edges->next;
	free (tmp_edges);

	/* edges enthaelt jetzt eine Liste aller Kanten (x,y) aus impl mit */
	/* x < y, degrees enthaelt die Grade aller Knoten */

	while (isPlanar (resultat, 0) == 0) {
		KureRel * tmp = kure_rel_new_copy (impl);
		//tmp_rel = copy_rel (resultatData, relData->name);
		//tmp_relData = get_rel (tmp_rel, relData->name);

		new_edges = make_edge ("", 0, 0, VISIBLE);
		tmp_new_edges = new_edges;
		tmp_edges = edges;
		while (tmp_edges) {
			node_1 = tmp_edges->edge.from;
			node_2 = tmp_edges->edge.to;
			if (((degrees [node_1] >= 2) && (degrees [node_2] >= 3)) ||
					((degrees [node_1] >= 3) && (degrees [node_2] >= 2))) {

				kure_set_bit_si (tmp, FALSE, node_2, node_1);

				//clear_rel_bit (tmp_relData, node_1, node_2, Kure_mp_mint2int (tmp_relData->breite), Kure_mp_mint2int (tmp_relData->hoehe));
				if (isPlanar (tmp, 0)) {
					kure_set_bit_si (tmp, TRUE, node_2, node_1);
					//set_rel_bit (tmp_relData, node_1, node_2, Kure_mp_mint2int (tmp_relData->breite), Kure_mp_mint2int (tmp_relData->hoehe));
					tmp_new_edges->next = make_edge ("", node_1, node_2, VISIBLE);
					tmp_new_edges = tmp_new_edges->next;
				}
				else {
					degrees [node_1] -= 1;
					degrees [node_2] -= 1;
				}
			}
			tmp_edges = tmp_edges->next;
		}
		tmp_new_edges = new_edges;
		new_edges = new_edges->next;
		free (tmp_new_edges);

		/* tmp_relData ist jetzt eine minimale nicht-planare Sub-Relation von */
		/* resultatData und new_edges enthaelt die dazugehoerigen Kanten */

		tmp_new_edges = new_edges;
		highest_degree = 8;
		while (1) {
			node_1 = tmp_new_edges->edge.from;
			node_2 = tmp_new_edges->edge.to;
			actual_degree = degrees [node_1] + degrees [node_2];
			if ((highest_degree == actual_degree) && (degrees [node_1] >= 2) &&
					(degrees [node_2] >= 2)) {
				kure_set_bit_si (resultat, FALSE, node_2, node_1);
				//clear_rel_bit (resultatData, node_1, node_2, Kure_mp_mint2int (resultatData->breite), Kure_mp_mint2int (resultatData->hoehe));
				degrees_copy [node_1] -= 1;
				degrees_copy [node_2] -= 1;
				if (!deleted_edges)
					deleted_edges = make_edge ("", node_1, node_2, VISIBLE);
				else
					append_edge_to_edgelist (make_edge ("", node_1, node_2, VISIBLE),
							deleted_edges);
				break;
			}
			if (tmp_new_edges->next)
				tmp_new_edges = tmp_new_edges->next;
			else {
				tmp_new_edges = new_edges;
				highest_degree--;
			}
		}

		for (node_1 = 0; node_1 < breite; node_1 ++)
			degrees [node_1] = degrees_copy [node_1];
		del_edgelistptr (new_edges);
		kure_rel_destroy (tmp);
		//del_rel (tmp, <name>);
		/* in resultatData wurde genau ein Element einer minimalen */
		/* nicht-planaren Sub-Relation geloescht */
	}
	del_edgelistptr (edges);

	/* Es werden die geloeschten Kanten nochmals Kantenweise hinzugefuegt, */
	/* da eventuell zu viele Kanten geloescht worden sind. */
	edges = deleted_edges;
	while (edges) {
		node_1 = edges->edge.from;
		node_2 = edges->edge.to;
		kure_set_bit_si (resultat, TRUE, node_2, node_1);
		//set_rel_bit (resultatData, node_1, node_2, Kure_mp_mint2int (resultatData->breite), Kure_mp_mint2int (resultatData->hoehe));
		if (!isPlanar (resultat, 0))
			kure_set_bit_si (resultat, TRUE, node_2, node_1);
		//clear_rel_bit (resultatData, node_1, node_2,
		//		Kure_mp_mint2int (resultatData->breite), Kure_mp_mint2int (resultatData->hoehe));
		edges = edges->next;
	}
	del_edgelistptr (deleted_edges);


	for (node_1 = 0; node_1 < breite - 1; node_1 ++)
		for (node_2 = node_1 + 1; node_2 < hoehe; node_2 ++)
			if (kure_get_bit_fast_si (resultat, node_2, node_1, vars_zeilen, vars_spalten)) {
				//if (get_rel_bit (resultatData, node_1, node_2, vars_zeilen, vars_spalten))
				kure_set_bit_si (resultat, TRUE, node_1, node_2);
				//set_rel_bit (resultatData, node_2, node_1,
				//	Kure_mp_mint2int (resultatData->breite), Kure_mp_mint2int (resultatData->hoehe));
			}

	return (resultat);
}

/****************************************************************************/
/* NAME : faces_of_embedding                                                */
/* FUNKTION : Erzeugung einer Liste von Flaechen.                           */
/* UEBERGABEPARAMETER : Zeiger auf eine Einbettung embedding;               */
/*                      zwei Startknoten node_s und node_t;                 */
/*                      eine Liste von Knoten                               */
/* VORAUSSETZUNG: embedding beschreibt einen planaren Graphen (wird nicht   */
/*                geprueft); die Kante {node_s, node_t} ist in embedding    */
/*                enthalten (wird geprueft); die Knoten aus nodes sind in   */
/*                embedding enthalten (wird nicht geprueft)                 */
/* RUECKGABEWERT : Zeiger auf eine Liste von Flaechen                       */
/* ERSTELLT VON : Ulf Milanese (10.12.1998)                                 */
/* LETZTE AENDERUNG AM : 26.01.1999                                         */
/****************************************************************************/

facelistptr faces_of_embedding (p_adjList embedding, int node_s, int node_t, p_intList nodes)
{
	edgelistptr   rest_edges;
	edgelistptr   tmp_rest_edges;
	int       node_1;
	int       node_2;
	int       edge_in_embedding = 0;
	edgelistptr   stack_edges_first;
	edgelistptr   outer_edges_first;
	edgelistptr   face_edges;
	edgelistptr   outer_edges;
	facelistptr   faces;
	edgelistptr   stack_edges;
	edgelistptr   tmp_face_edges;
	edgelistptr   back_edge;
	facelistptr   result = (facelistptr) NULL;

	/* Ist die Embedding leer? */
	if (embedding->size) {

		/* Aus der Relation wird eine Liste aller Kanten erzeugt */
		/* rest_edges = Adjazenz Liste mit Hin- und Rueckkanten (mit Dummy) */
		rest_edges = make_edge ("", 0, 0, VISIBLE);
		tmp_rest_edges = rest_edges;
		for (node_1 = 0; node_1 < embedding->size - 1; node_1 ++)
			for (node_2 = node_1 + 1; node_2 < embedding->size; node_2 ++)
				if ((areNeighbours (embedding, node_1, node_2)) &&
						(inList (nodes, node_1)) && (inList (nodes, node_2))) {
					tmp_rest_edges->next = make_edge ("", node_1, node_2, VISIBLE);
					tmp_rest_edges = tmp_rest_edges->next;
					tmp_rest_edges->next = make_edge ("", node_2, node_1, VISIBLE);
					tmp_rest_edges = tmp_rest_edges->next;
					if (((node_1 == node_s) && (node_2 == node_t)) ||
							((node_1 == node_t) && (node_2 == node_s)))
						edge_in_embedding = 1;
				}

		if (!edge_in_embedding) {
			del_edgelistptr (rest_edges);
			return ((facelistptr) NULL);
		}

		/* Die erste Kante ist die Kante {node_s, node_t} */
		stack_edges_first = make_edge ("", node_s, node_t, VISIBLE);
		outer_edges_first = make_edge ("", node_t, node_s, VISIBLE);
		outer_edges = right_face_of_edge (outer_edges_first, embedding, nodes);
		del_edgelistptr (outer_edges_first);

		/* rest_edges = rest_edges \ outer_edges */
		del_edges_in_edgelist (rest_edges, outer_edges);

		result = new_facelist ();
		faces = result;

		/* stack_edges = {(x->y)} (das erste Element ist ein Dummy) */
		stack_edges = make_edge ("", 0, 0, VISIBLE);
		stack_edges->next = stack_edges_first;

		/* if stack_edges == LeereMenge then ende */
		while (stack_edges_first) {

			/* face_edges = Flaeche zu stack_edges_first */
			face_edges = right_face_of_edge (stack_edges_first, embedding, nodes);

			/* stack_edges = stack_edges \ face_edges */
			del_edges_in_edgelist (stack_edges, face_edges);

			/* rest_edges = rest_edges \ face_edges */
			del_edges_in_edgelist (rest_edges, face_edges);

			/* for all (a->b) in face_edges do */
			tmp_face_edges = face_edges;
			while (tmp_face_edges) {

				/* back_edge = (b->a) */
				node_1 = tmp_face_edges->edge.from;
				node_2 = tmp_face_edges->edge.to;
				back_edge = make_edge ("", node_2, node_1, VISIBLE);

				/* if (b->a) in rest_edges, dann begrenzt (b->a) eine neue
           Innenflaeche */
				if (edge_is_in (back_edge, rest_edges)) {

					/* rest_edges = rest_edges \ {(b->a)} */
					del_edges_in_edgelist (rest_edges, back_edge);

					/* stack_edges = stack_edges^{(b->a)} */
					append_edge_to_edgelist (back_edge, stack_edges);
				}
				del_edgelistptr (back_edge);
				tmp_face_edges = tmp_face_edges->next;
			}
			faces->face = copy_edgelist (face_edges);
			faces->next = new_facelist ();
			faces = faces->next;
			del_edgelistptr (face_edges);
			stack_edges_first = stack_edges->next;
		}
		del_edgelistptr (stack_edges);
		del_edgelistptr (rest_edges);
		faces->face = copy_edgelist (outer_edges);
		del_edgelistptr (outer_edges);
	}
	return (result);
}



/****************************************************************************/
/* NAME : st_numbering                                                      */
/* FUNKTION : Erzeugung einer st-Nummerierung gemaess dem Paper "Computing  */
/*            an st-NUMBERING" von S. Even et al.                           */
/* UEBERGABEPARAMETER : Zeiger auf eine Einbettung embedding                */
/* VORAUSSETZUNG: embedding beschreibt einen zusammenhaengenden, zweifach-  */
/*                zusammenhaengenden und planaren Graphen (wird alles       */
/*                nicht ueberprueft);                                       */
/* RUECKGABEWERT : Zeiger auf eine Knoten-Liste, die nach ihren st-Nummern  */
/*                 sortiert sind.                                           */
/* ERSTELLT VON : Ulf Milanese (01.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/
p_intList st_numbering (p_adjList embedding)
{
  p_intList resultat;
  p_intList numbers = getNewIntList ();
  int       counter;

  for (counter = 0; counter < embedding->size; counter++)
    addLast (numbers, counter);
  resultat = st_numbering_with_source (embedding, 0, numbers);
  clearIntList (numbers);
  return (resultat);
}




/****************************************************************************/
/* NAME : st_numbering_with_source                                          */
/* FUNKTION : Erzeugung einer st-Nummerierung gemaess dem Paper "Computing  */
/*            an st-NUMBERING" von S. Even et al.                           */
/* UEBERGABEPARAMETER : Zeiger auf eine Einbettung embedding; Startknoten;  */
/*                      Liste von Integers                                  */
/* VORAUSSETZUNG: embedding beschreibt einen zusammenhaengenden, planaren   */
/*                Graphen (wird nicht ueberprueft); source ist in block     */
/*                vorhanden; block ist in embedding vorhanden (wird nicht   */
/*                geprueft)                                                 */
/* RUECKGABEWERT : Zeiger auf eine Knoten-Liste, die nach ihren st-Nummern  */
/*                 sortiert sind.                                           */
/* ERSTELLT VON : Ulf Milanese (17.02.1999)                                 */
/* LETZTE AENDERUNG AM : 18.02.1999                                         */
/****************************************************************************/
p_intList st_numbering_with_source (p_adjList embedding, int node_s,
                                    p_intList block)
{
  p_intList resultat = getNewIntList ();

  /* Ist die Embedding leer? */
  if (!embedding)
    return (resultat);

  if (!inList (block, node_s))
    return (resultat);

  if (block->size == 2) {
    int node_t;
    p_intList copy_of_block = copyIntList (block);

    addFirst (resultat, node_s);
    node_t = popFirst (copy_of_block);
    if (node_t == node_s)
      node_t = popFirst (copy_of_block);
    addLast (resultat, node_t);
    clearIntList (copy_of_block);
    return (resultat);
  } else {
    int size = block->size;
    p_intList forward_edges  [size];
    p_intList backward_edges [size];
    p_intList tree_edges     [size];
    int       parent         [size];
    p_intList low_edges      [size];
    int       DFS_of_node    [size];
    int       DFS_number     = 1;
    int       low_number     [size];
    int       st_number      = 0;
    int       pos_of_node    [embedding->size];
    int       node_of_pos    [size];
    int       node_of_st     [size];
    int       node_1;
    int       node_2;
    int       node_3;
    int       node_t = 0;
    int       last_node;
    p_intList stack;
    p_intList stack_edges;
    p_intList path;
    p_intList copy_of_block  = copyIntList (block);
    int       node_new       [size];

    /* Implementierung des Algorithmus "Computing an st-numbering" von
       S. Even et al. (1976)

       1. Schritt: Depth-First-Search (DFS) mit gleichzeitiger Berechnung
       der Vorwaerts-, Rueckwaerts- und Baumkanten, Abspeicherung des
       Vorgaengers eines Knotens v (parent (v)) und eines Knotens w, so
       dass fuer einen Knoten v gilt: DFS (w) = L (DFS (v)) oder
       L (DFS (w)) = L (DFS (v)) (L (v) = Lempel-Nummer von v). */


    /* Bestimme eine Kante {s, t} */
    while (copy_of_block->first) {
      node_t = popFirst (copy_of_block);
      if (areNeighbours (embedding, node_s, node_t) && (node_s != node_t))
        break;
    }
    clearIntList (copy_of_block);

    /* Berechnung eines DFS-Baumes mit der Wurzel t und der ersten Kante
       {s, t}. */
    /* Diverse Initialisierungen */
    copy_of_block = copyIntList (block);
    for (node_1 = 0; node_1 < size; node_1 ++) {
      forward_edges [node_1] = getNewIntList ();
      backward_edges [node_1] = getNewIntList ();
      tree_edges [node_1] = getNewIntList ();
      parent [node_1] = -1;
      low_edges [node_1] = getNewIntList ();
      DFS_of_node [node_1] = -1;
      low_number [node_1] = -1;
      node_new [node_1] = 1;
      node_2 = popFirst (copy_of_block);
      pos_of_node [node_2] = node_1;
      node_of_pos [node_1] = node_2;
    }
    clearIntList (copy_of_block);
    stack = getNewIntList ();

    addLast (tree_edges [pos_of_node [node_t]], node_s);
    parent [pos_of_node [node_s]] = node_t;
    low_number [pos_of_node [node_t]] = 1;
    addLast (low_edges [pos_of_node [node_t]], node_s);
    DFS_of_node [pos_of_node [node_t]] = DFS_number++;
    DFS_of_node [pos_of_node [node_s]] = DFS_number++;
    last_node = node_t;
    addLast (stack, node_t);
    addFirst (stack, node_s);

    while (stack->first) {
      node_1 = popFirst (stack);
      node_2 = nextClockNode (embedding, node_1, last_node);
      while (!inList (block, node_2))
        node_2 = nextClockNode (embedding, node_1, node_2);

      /* 1. Fall: node_2 hat noch keine DFS-Nummer bekommen: */
      if (DFS_of_node [pos_of_node [node_2]] == -1) {
        addLast (tree_edges [pos_of_node [node_1]], node_2);
        parent [pos_of_node [node_2]] = node_1;
        DFS_of_node [pos_of_node [node_2]] = DFS_number++;
        node_new [pos_of_node [node_2]] = 1;
        last_node = node_1;
        addFirst (stack, node_1);
        addFirst (stack, node_2);
      } else {

        /* 2. Fall: node_2 ist parent von node_1: */
        if (parent [pos_of_node [node_1]] == node_2) {
          /* L (v) = min ({v} \cup {u | \exists w such that v-*>w and
             w - - u}). */
          low_number [pos_of_node [node_1]] =
            DFS_of_node [pos_of_node [node_1]];
          stack_edges = copyIntList (tree_edges [pos_of_node [node_1]]);
          while (stack_edges->first) {
            node_3 = popFirst (stack_edges);
            if (low_number [pos_of_node [node_3]] <
                low_number [pos_of_node [node_1]])
              low_number [pos_of_node [node_1]] =
                low_number [pos_of_node [node_3]];
          }
          clearIntList (stack_edges);
          stack_edges = copyIntList (forward_edges [pos_of_node [node_1]]);
          while (stack_edges->first) {
            node_3 = popFirst (stack_edges);
            if (DFS_of_node [pos_of_node [node_3]] <
                low_number [pos_of_node [node_1]])
              low_number [pos_of_node [node_1]] =
                DFS_of_node [pos_of_node [node_3]];
          }
          clearIntList (stack_edges);
          stack_edges = copyIntList (backward_edges [pos_of_node [node_1]]);
          while (stack_edges->first) {
            node_3 = popFirst (stack_edges);
            if (DFS_of_node [pos_of_node [node_3]] <
                low_number [pos_of_node [node_1]])
              low_number [pos_of_node [node_1]] =
                DFS_of_node [pos_of_node [node_3]];
          }
          clearIntList (stack_edges);

          /* low_number ist bestimmt, jetzt muessen die low_edges
             noch bestimmt werden */
          stack_edges = copyIntList (tree_edges [pos_of_node [node_1]]);
          while (stack_edges->first) {
            node_3 = popFirst (stack_edges);
            if (low_number [pos_of_node [node_3]] ==
                low_number [pos_of_node [node_1]])
              addLast (low_edges [pos_of_node [node_1]], node_3);
          }
          clearIntList (stack_edges);
          stack_edges = copyIntList (forward_edges [pos_of_node [node_1]]);
          while (stack_edges->first) {
            node_3 = popFirst (stack_edges);
            if (DFS_of_node [pos_of_node [node_3]] ==
                low_number [pos_of_node [node_1]])
              addLast (low_edges [pos_of_node [node_1]], node_3);
          }
          clearIntList (stack_edges);
          stack_edges = copyIntList (backward_edges [pos_of_node [node_1]]);
          while (stack_edges->first) {
            node_3 = popFirst (stack_edges);
            if (DFS_of_node [pos_of_node [node_3]] ==
                low_number [pos_of_node [node_1]])
              addLast (low_edges [pos_of_node [node_1]], node_3);
          }
          clearIntList (stack_edges);
          last_node = node_1;
        } else {

          /* 3. Fall: {node_1, node_2} ist keine Baum-Kante:*/
          if (!inList (tree_edges [pos_of_node [node_1]], node_2)) {
            if (DFS_of_node [pos_of_node [node_1]] >
                DFS_of_node [pos_of_node [node_2]])
              addLast (backward_edges [pos_of_node [node_1]], node_2);
            if (DFS_of_node [pos_of_node [node_1]] <
                DFS_of_node [pos_of_node [node_2]])
              addLast (forward_edges [pos_of_node [node_1]], node_2);
            last_node = node_2;
            addFirst (stack, node_1);
          }
        }
      }
    }

    /* 2. Schritt: algorithm STNUMBER */
    /* mark s, t, and {s, t} old, all other vertices and edges new */
    node_new [pos_of_node [node_s]] = 0;
    node_new [pos_of_node [node_t]] = 0;
    delVal (tree_edges [pos_of_node [node_t]], node_s);
    parent [pos_of_node [node_s]] = -1;
    delVal (low_edges [pos_of_node [node_t]], node_s);
    delVal (low_edges [pos_of_node [node_s]], node_t);

    /* initialize stack to contain s on top of t; */
    addFirst (stack, node_s);
    addLast (stack, node_t);

    /* i := 0; (bereits initialisiert */
    path = getNewIntList ();

    /* while stack is not empty do */
    while (stack->first) {

      /* let v be top vertex on stack;
         delete v from stack; */
      node_1 = popFirst (stack);

      /* let {v_1, v_2}, ..., {v_{k-1}, v_k} be path found by
         PATHFINDER (v) */

      /* algorithm PATHFINDER (v) */

      /* if there is a new cycle edge {v, w} with w-*> v then */
      if ((backward_edges [pos_of_node [node_1]])->first) {

        /* mark {v, w} old */
        node_2 = popFirst (backward_edges [pos_of_node [node_1]]);
        delVal (forward_edges [pos_of_node [node_2]], node_1);
        delVal (low_edges [pos_of_node [node_1]], node_2);
        delVal (low_edges [pos_of_node [node_2]], node_1);

        /* let path be {v, w} */
        addFirst (path, node_1);
        addLast (path, node_2);
      } else {

        /* else if there is a new tree edge v->w then */
        if ((tree_edges [pos_of_node [node_1]])->first) {

          /* mark {v, w} old; */
          node_2 = popFirst (tree_edges [pos_of_node [node_1]]);
          parent [pos_of_node [node_2]] = -1;
          delVal (low_edges [pos_of_node [node_1]], node_2);
          delVal (low_edges [pos_of_node [node_2]], node_1);

          /* initialize path to be {v, w}; */
          addFirst (path, node_1);
          addLast (path, node_2);

          /* while w is new do */
          while (node_new [pos_of_node [node_2]]) {

            /* find a new edge {w, x} with x = L (w) or L (x) = L (w) */
            node_3 = popFirst (low_edges [pos_of_node [node_2]]);

            /* mark w and {w, x} old */
            node_new [pos_of_node [node_2]] = 0;
            delVal (backward_edges [pos_of_node [node_2]], node_3);
            delVal (forward_edges [pos_of_node [node_2]], node_3);
            delVal (tree_edges [pos_of_node [node_2]], node_3);
            if (parent [pos_of_node [node_2]] == node_3)
              parent [pos_of_node [node_2]] = -1;
            delVal (backward_edges [pos_of_node [node_3]], node_2);
            delVal (forward_edges [pos_of_node [node_3]], node_2);
            delVal (tree_edges [pos_of_node [node_3]], node_2);
            delVal (low_edges [pos_of_node [node_3]], node_2);
            if (parent [pos_of_node [node_3]] == node_2)
              parent [pos_of_node [node_3]] = -1;

            /* add {w, x} to path; */
            addLast (path, node_3);

            /* w := x; */
            node_2 = node_3;
          }
        } else {

          /* else if there is a new cycle edge {v, w} with v-*>w then */
          if ((forward_edges [pos_of_node [node_1]])->first) {

            /* mark {v, w} old */
            node_2 = popFirst (forward_edges [pos_of_node [node_1]]);
            delVal (low_edges [pos_of_node [node_1]], node_2);
            delVal (backward_edges [pos_of_node [node_2]], node_1);
            delVal (low_edges [pos_of_node [node_2]], node_1);

            /* initialize path to be {v, w} */
            addFirst (path, node_1);
            addLast (path, node_2);

            /* while w is new do */
            while (node_new [pos_of_node [node_2]]) {

              /* find the new edge {w, x} with x->w; */
              node_3 = parent [pos_of_node [node_2]];

              /* mark w and {w, x} old; */
              node_new [pos_of_node [node_2]] = 0;
              parent [pos_of_node [node_2]] = -1;
              delVal (low_edges [pos_of_node [node_2]], node_3);
              delVal (tree_edges [pos_of_node [node_3]], node_2);
              delVal (low_edges [pos_of_node [node_3]], node_2);

              /* add {w, x} to path; */
              addLast (path, node_3);

              /* w := x; */
              node_2 = node_3;
            }
          }
        }
      }

      /* if path not null then add v_{k-1}, ... v_1 (v_1 = v on top) to
         stack */
      if (path->first) {
        node_3 = popLast (path);
        while (path->first)
          addFirst (stack, popLast (path));
      } else
        /* else number (v) := i := i + 1; */
        node_of_st [st_number++] = node_1;
    }

    for (node_1 = 0; node_1 < size; node_1 ++) {
      addLast (resultat, node_of_st [node_1]);
      clearIntList (forward_edges [node_1]);
      clearIntList (backward_edges [node_1]);
      clearIntList (tree_edges [node_1]);
      clearIntList (low_edges [node_1]);
    }
    clearIntList (stack);
    clearIntList (path);

    return (resultat);
  }
}




/****************************************************************************/
/* NAME : visibility_representation                                         */
/* FUNKTION : Erzeugung einer Visibility Representation                     */
/* UEBERGABEPARAMETER : Zeiger auf eine Einbettung embedding                */
/* VORAUSSETZUNG: embedding beschreibt einen zusammenhaengenden, zweifach-  */
/*                zusammenhaengenden und planaren Graphen (wird alles       */
/*                nicht ueberprueft);                                       */
/*                embedding muss mindestens fuenf Knoten besitzen (wird     */
/*                geprueft).                                                */
/* RUECKGABEWERT : Zeiger auf eine Visibility Representation                */
/* ERSTELLT VON : Ulf Milanese (10.12.1998)                                 */
/* LETZTE AENDERUNG AM : 22.02.1999                                         */
/****************************************************************************/
visibilityrepptr visibility_representation (p_adjList embedding)
{
  visibilityrepptr vr = NULL;
  p_intList st_numbers;
  int size;
  int node_1;
  int node_2;
  int node_s;
  int number_faces = 0;
  int face_1;
  int ready;
  facelistptr faces;
  facelistptr tmp_faces;
  edgelistptr face_edges;
  int number_of_blocks;
  int actual_block = 0;
  int block_size;
  int counter_1;
  p_intList * res;
  p_intList stack;
  p_intList copy_numbers;
  int column;

  /* Ist die Embedding leer? */
  if (!embedding)
    return (NULL);

  res =  GetBiconnectedComponents (& number_of_blocks, embedding);
  size = embedding->size;

  /* Besteht der Graph nur aus einer 2-fach-Zusammenhangskomponente? */
  /* Falls ja, dann actual_block = 0, node_s = 0; */
  if (number_of_blocks == 1) {
    node_s = 0;
    actual_block = 0;
  } else {
    /* Existiert ein Blatt? Falls ja, dann node_s = Blatt mit minimaler */
    /* Nummer. */
    for (node_s = 0; node_s < size; node_s++)
      if (embedding->aList[node_s]->size == 1)
        break;
    if (node_s != size) {
      for (actual_block = 0; actual_block < number_of_blocks; actual_block++)
        if (inList (res [actual_block], node_s))
          break;
    } else {
      /* Es existieren mindestens zwei Bloecke und kein Blatt.
         Finde node_s so, dass node_s in genau einem Block vorkommt. */
      node_s =0;
      while (1) {
        for (actual_block = 0; actual_block < number_of_blocks; actual_block++)
          if (inList (res [actual_block], node_s))
            break;
        for (counter_1 = actual_block + 1; counter_1 < number_of_blocks;
             counter_1 ++)
          if (inList (res [counter_1], node_s))
            break;
        if (counter_1 != number_of_blocks)
          node_s++;
        else
          break;
      }
    }
  }
  /* In node_s ist jetzt ein passender Knoten ausgewaehlt, in actual_block
     ist gespeichert, in welchem Block er sich befindet. */

  stack = copyIntList (res [actual_block]);
  delVal (stack, node_s);

  while (stack->first) {
    st_numbers =
      st_numbering_with_source (embedding, node_s, res [actual_block]);
    clearIntList (res [actual_block]);
    res [actual_block] = (p_intList) NULL;

    {
      int       st_of_node [size];
      int       node_of_st [size];
      p_intList copy_numbers;

      copy_numbers = copyIntList (st_numbers);
      node_1 = 0;
      while (copy_numbers->first) {
        node_2 = popFirst (copy_numbers);
        st_of_node [node_2] = node_1;
        node_of_st [node_1 ++] = node_2;
      }
      block_size = st_numbers->size;
      clearIntList (copy_numbers);

      faces = faces_of_embedding (embedding, node_of_st [0],
                                  node_of_st [block_size - 1], st_numbers);
      tmp_faces = faces;
      number_faces = 0;
      while (tmp_faces) {
        tmp_faces = tmp_faces->next;
        number_faces++;
      }

      {
        edgelistptr up_edges     [number_faces];
        edgelistptr tmp_up_edges = (edgelistptr) NULL;
        edgelistptr down_edges   [number_faces];
        edgelistptr tmp_down_edges = (edgelistptr) NULL;
        edgelistptr dummy_edge;
        edgelistptr inserted_edges;

        tmp_faces = faces;

        for (face_1 = 0; face_1 < number_faces; face_1 ++) {
          face_edges = tmp_faces->face;
          up_edges [face_1] = (edgelistptr) NULL;
          down_edges [face_1] = (edgelistptr) NULL;

          while (face_edges) {
            node_1 = face_edges->edge.from;
            node_2 = face_edges->edge.to;
            if (st_of_node [node_1] < st_of_node [node_2])
              if (down_edges [face_1]) {
                tmp_down_edges->next = make_edge ("", node_1, node_2, VISIBLE);
                tmp_down_edges = tmp_down_edges->next;
              }
              else {
                down_edges [face_1] = make_edge ("", node_1, node_2, VISIBLE);
                tmp_down_edges = down_edges [face_1];
              }
            else
              if (up_edges [face_1]) {
                tmp_up_edges->next = make_edge ("", node_2, node_1, VISIBLE);
                tmp_up_edges = tmp_up_edges->next;
              }
              else {
                up_edges [face_1] = make_edge ("", node_2, node_1, VISIBLE);
                tmp_up_edges = up_edges [face_1];
              }
            face_edges = face_edges->next;
          }
          tmp_faces = tmp_faces->next;
        }

        /* Jetzt sind zu jeder Flaeche in up_edges und down_edges jeweils
           die Kanten gespeichert, die gemaess der st-Nummerierung
           vorwaerts bzw. rueckwaerts gerichtet sind. */

        /* Erzeugung der eigentlichen Visibility Representation */
        if (!vr)
          vr = new_visibility_representation (st_numbers);
        else {
          copy_numbers = copyIntList (st_numbers);
          node_1 = popFirst (copy_numbers);
          while (copy_numbers->first)
            append_new_row_after (vr, node_1, popLast (copy_numbers));
        }

        column = find_column_in_visibility (vr, node_of_st [0]);

        dummy_edge = make_edge ("", 0, 0, VISIBLE);
        inserted_edges = make_edge ("", 0, 0, VISIBLE);

        /* Die down_edges der ersten Flaeche werden in die Visibility
           Representation eingefuegt. */
        tmp_down_edges = down_edges [0];
        while (tmp_down_edges) {
          node_1 = tmp_down_edges->edge.from;
          node_2 = tmp_down_edges->edge.to;
          add_edge_to_visibility (vr, node_1, node_2, column);
          tmp_down_edges = tmp_down_edges->next;
        }
        for (face_1 = 0; face_1 < number_faces; face_1 ++) {
          dummy_edge->next = up_edges [face_1];
          del_edges_in_edgelist (dummy_edge, down_edges [0]);
          up_edges [face_1] = dummy_edge->next;
          dummy_edge->next = (edgelistptr) NULL;
        }
        del_edgelistptr (down_edges [0]);
        down_edges [0] = (edgelistptr) NULL;
        ready = 0;

        while (!ready) {
          /* Falls noch nicht repraesentierte Kanten existieren, wird eine
             neue Spalte in die Visibility Representation eingefuegt. */
          ready = 1;
          for (face_1 = 0; face_1 < number_faces; face_1 ++)
            if (up_edges [face_1])
              ready = 0;
          if (!ready) {
            insert_column_after (vr, column++);

            for (face_1 = 0; face_1 < number_faces; face_1 ++)
              /* Es koennen die up_edges einer Flaeche genau dann
                 eingefuegt werden, wenn alle down_edges bereits eingefuegt
                 worden sind. */
              if ((!down_edges [face_1]) && (up_edges [face_1])) {
                tmp_up_edges = up_edges [face_1];
                append_edgelist_to_edgelist
                  (up_edges [face_1], inserted_edges);
                while (tmp_up_edges) {
                  node_1 = tmp_up_edges->edge.from;
                  node_2 = tmp_up_edges->edge.to;
                  add_edge_to_visibility (vr, node_1, node_2, column);
                  tmp_up_edges = tmp_up_edges->next;
                }
                del_edgelistptr (up_edges [face_1]);
                up_edges [face_1] = (edgelistptr) NULL;
              }

            for (face_1 = 0; face_1 < number_faces; face_1 ++) {
              /* Die jetzt eingefuegten Kanten muessen aus den down_edges
                 der verbliebenen Flaechen entfernt werden. */
              if (down_edges [face_1]) {
                dummy_edge->next = down_edges [face_1];
                del_edges_in_edgelist (dummy_edge, inserted_edges->next);
                down_edges [face_1] = dummy_edge->next;
                dummy_edge->next = (edgelistptr) NULL;
              }
            }
            del_edgelistptr (inserted_edges->next);
            inserted_edges->next = (edgelistptr) NULL;
          }
        }
        del_edgelistptr (dummy_edge);
        del_edgelistptr (inserted_edges);
      }
      del_facelist (faces);
    }

    /* Im Stack stehen Kandidaten fuer Artikulations-Punkte. */
    while (stack->first) {
      node_s = popFirst (stack);
      /* Falls node_s Artikulations-Punkt ist, ist er in einem weiteren
         Block enthalten. */
      for (actual_block = 0; actual_block < number_of_blocks; actual_block++)
        if (res [actual_block])
          if (inList (res [actual_block], node_s))
            break;
      /* Falls node_s Artikulations-Punkt ist, sind die anderen Knoten des
         Kandidaten fuer weitere Punkte. */
      if (actual_block < number_of_blocks) {
        copy_numbers = copyIntList (res [actual_block]);
        while (copy_numbers->first) {
          node_1 = popFirst (copy_numbers);
          if ((!inList (stack, node_1)) && (node_1 != node_s))
            addLast (stack, node_1);
        }
        clearIntList (copy_numbers);
        addFirst (stack, node_s);
        break;
      }
    }
  }
  clearIntList (stack);
  return (vr);
}





/****************************************************************************/
/* NAME : del_visibility_representation                                     */
/* FUNKTION : Freigabe des Speicherplatzes einer Visibility Representation  */
/* UEBERGABEPARAMETER : Zeiger auf eine Visibility Representation           */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void del_visibility_representation (visibilityrepptr vr)
{
  if (vr)
    del_numberarray (vr->top_left);
  free (vr);
}





/****************************************************************************/
/* NAME : orthogonal_embedding                                              */
/* FUNKTION : Erzeugung einer orthogonalen Einbettung                       */
/* UEBERGABEPARAMETER : Zeiger auf Graph-Komponente                         */
/* VORAUSSETZUNG: Der repraesentierte Graph ist zusammenhaengend und        */
/*                planar (wird nicht geprueft);                             */
/* RUECKGABEWERT : Zeiger auf eine Orthogonal Representation                */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 03.02.1999                                         */
/****************************************************************************/

orthogonalrepptr orthogonal_embedding (visibilityrepptr vr,
                                       p_adjList embedding)
{
  orthogonalrepptr resultat;
  orthogonalrepptr actual_node;
  orthogonalrepptr new_node;
  p_intList        order;
  numberarrayptr   row;
  numberarrayptr   tmp_row;
  int              node_1;
  int              node_2;
  int              pos_x;
  int              pos_y = 0;
  unsigned int     positions [4];
  unsigned int     adjazent_node [4];
  unsigned int     edge_counter;
  unsigned int     situation_counter;
  unsigned int     situation [4];
  unsigned int     encoding;

  if ((!vr) || (!embedding))
    return (orthogonalrepptr) NULL;

  resultat = new_orthogonal_representation (embedding->size);
  row = vr->top_left;

  while (row) {
    node_1 = row->inhalt;
    actual_node = resultat;
    while (actual_node->number != node_1)
      actual_node = actual_node->next;
    tmp_row = row->p_right;
    situation_counter = 0;
    pos_x = 1;
    pos_y++;
    edge_counter = 0;
    while (tmp_row) {
      if (tmp_row->inhalt >= 0) {
        situation [situation_counter] = 0;
        if (tmp_row->up >= 0) {
          node_2 = tmp_row->up;
          positions [edge_counter] = pos_x;
          adjazent_node [edge_counter++] = node_2;
          situation [situation_counter] += 1;
        }
        if (tmp_row->down >= 0) {
          node_2 = tmp_row->down;
          positions [edge_counter] = pos_x;
          adjazent_node [edge_counter++] = node_2;
          situation [situation_counter] += 2;
          append_edge_to_orthogonal_representation (resultat, node_1,
                                                    node_2, embedding);
        }
        if (situation [situation_counter])
          situation_counter++;
      }
      tmp_row = tmp_row->p_right;
      pos_x += 2;
    }

    /* In der Liste situation steht jetzt verschluesselt, welcher Fall im
       Step 2 des Algorithmus GRID-EMBEDDING von Tamassia und Tollis
       angewendet werden muss. In dem Feld Positionen stehen die
       relativen Positionen der Hilfs- und des Originalknotens. */
    switch (situation_counter) {

    case 0:
      /* Es existiert keine adjazente Kante. Dieser Fall darf eigentlich
         nicht auftreten. */
      break;

    case 1:
      /* Eine Position */
      switch (situation [0]) {

      case 1:
        /* | */
        /* + */
        set_angle (actual_node, adjazent_node [0], 4, 360);
        actual_node->pos_x = positions [0];
        actual_node->pos_y = pos_y;
        break;

      case 2:
        /* + */
        /* | */
        set_angle (actual_node, adjazent_node [0], 4, 180);
        actual_node->pos_x = positions [0];
        actual_node->pos_y = pos_y;
        break;

      case 3:
        /* | */
        /* + */
        /* | */
        set_angle (actual_node, adjazent_node [0], 2, 360);
        set_angle (actual_node, adjazent_node [1], 2, 180);
        actual_node->pos_x = positions [0];
        actual_node->pos_y = pos_y;
        break;
      }
      break;

    case 2:
      /* Zwei Positionen */
      encoding = 3 * situation [0] + situation [1] - 4;

      switch (encoding) {
      case 0:
        /* | | */
        /* +-+ */
        set_angle (actual_node, adjazent_node [0], 1, 360);
        set_angle (actual_node, adjazent_node [1], 3, 90);
        actual_node->pos_x = positions [0];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, node_1, adjazent_node [1]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [1], 1);
        new_node->pos_x = positions [1];
        new_node->pos_y = pos_y;
        break;

      case 4:
        /* +-+ */
        /* | | */
        set_angle (actual_node, adjazent_node [0], 3, 180);
        set_angle (actual_node, adjazent_node [1], 1, 90);
        actual_node->pos_x = positions [0];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [1], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [1], 0);
        new_node->pos_x = positions [1];
        new_node->pos_y = pos_y;
        break;

      case 6:
        /* | | */
        /* +-+ */
        /* |   */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [2]);
        addLast (order, adjazent_node [1]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 1, 360);
        set_angle (actual_node, adjazent_node [2], 1, 90);
        set_angle (actual_node, adjazent_node [1], 2, 180);
        actual_node->pos_x = positions [0];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, node_1, adjazent_node [2]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [2], 1);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y;
        break;

      case 7:
        /* |   */
        /* +-+ */
        /* | | */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [2]);
        addLast (order, adjazent_node [1]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 1, 360);
        set_angle (actual_node, adjazent_node [2], 1, 90);
        set_angle (actual_node, adjazent_node [1], 2, 180);
        actual_node->pos_x = positions [0];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [2], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [2], 0);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y;
        break;

      case 8:
        /* | | */
        /* +-+ */
        /* | | */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [2]);
        addLast (order, adjazent_node [3]);
        addLast (order, adjazent_node [1]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 1, 360);
        set_angle (actual_node, adjazent_node [2], 1, 90);
        set_angle (actual_node, adjazent_node [3], 1, 180);
        set_angle (actual_node, adjazent_node [1], 1, 270);
        increase_bends (resultat, node_1, adjazent_node [0]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [0], 1);
        new_node->pos_x = ((positions [0] + positions [2]) / 2);
        new_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [0], node_1);
        new_node =
          insert_node_in_orthogonal_edge (new_node, adjazent_node [0], 0);
        new_node->pos_x = positions [0];
        new_node->pos_y = pos_y++;
        increase_bends (resultat, node_1, adjazent_node [1]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [1], 1);
        new_node->pos_x = positions [0];
        new_node->pos_y = pos_y;
        actual_node->pos_x = ((positions [0] + positions [2]) / 2);
        actual_node->pos_y = pos_y;
        increase_bends (resultat, node_1, adjazent_node [2]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [2], 1);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y++;
        increase_bends (resultat, node_1, adjazent_node [3]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [3], 1);
        new_node->pos_x = ((positions [0] + positions [2]) / 2);
        new_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [3], node_1);
        new_node =
          insert_node_in_orthogonal_edge (new_node, adjazent_node [3], 0);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y;
        break;
      }
      break;

    case 3:
      /* Drei Positionen */
      encoding = 9 * situation [0] + 3 * situation [1] + situation [2] - 13;

      /* Setzen der Kanten-Reihenfolge um den Knoten herum */
      switch (encoding) {
      case 0 :
        /* | | | */
        /* +-+-+ */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [1]);
        addLast (order, adjazent_node [2]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 1, 270);
        set_angle (actual_node, adjazent_node [1], 1, 360);
        set_angle (actual_node, adjazent_node [2], 2, 90);
        increase_bends (resultat, adjazent_node [0], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [0], 0);
        new_node->pos_x = positions [0];
        new_node->pos_y = pos_y;
        actual_node->pos_x = positions [1];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, node_1, adjazent_node [2]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [2], 1);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y;
        break;

      case 13:
        /* +-+-+ */
        /* | | | */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [2]);
        addLast (order, adjazent_node [1]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 2, 270);
        set_angle (actual_node, adjazent_node [2], 1, 90);
        set_angle (actual_node, adjazent_node [1], 1, 180);
        increase_bends (resultat, node_1, adjazent_node [0]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [0], 1);
        new_node->pos_x = positions [0];
        new_node->pos_y = pos_y;
        actual_node->pos_x = positions [1];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [2], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [2], 0);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y;
        break;

      case 18:
        /* | | | */
        /* +-+-+ */
        /* |     */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [2]);
        addLast (order, adjazent_node [3]);
        addLast (order, adjazent_node [1]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 1, 270);
        set_angle (actual_node, adjazent_node [2], 1, 360);
        set_angle (actual_node, adjazent_node [3], 1, 90);
        set_angle (actual_node, adjazent_node [1], 1, 180);
        increase_bends (resultat, adjazent_node [0], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [0], 0);
        new_node->pos_x = positions [0];
        new_node->pos_y = pos_y;
        actual_node->pos_x = positions [2];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, node_1, adjazent_node [3]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [3], 1);
        new_node->pos_x = positions [3];
        new_node->pos_y = pos_y++;
        increase_bends (resultat, adjazent_node [1], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [1], 0);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y;
        increase_bends (resultat, node_1, adjazent_node [1]);
        new_node =
          insert_node_in_orthogonal_edge (new_node, adjazent_node [1], 1);
        new_node->pos_x = positions [1];
        new_node->pos_y = pos_y;
        break;

      case 19:
        /* | |   */
        /* +-+-+ */
        /* |   | */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [2]);
        addLast (order, adjazent_node [3]);
        addLast (order, adjazent_node [1]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 1, 270);
        set_angle (actual_node, adjazent_node [2], 1, 360);
        set_angle (actual_node, adjazent_node [3], 1, 90);
        set_angle (actual_node, adjazent_node [1], 1, 180);
        increase_bends (resultat, adjazent_node [0], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [0], 0);
        new_node->pos_x = positions [0];
        new_node->pos_y = pos_y;
        actual_node->pos_x = positions [2];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [3], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [3], 0);
        new_node->pos_x = positions [3];
        new_node->pos_y = pos_y++;
        increase_bends (resultat, adjazent_node [1], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [1], 0);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y;
        increase_bends (resultat, node_1, adjazent_node [1]);
        new_node =
          insert_node_in_orthogonal_edge (new_node, adjazent_node [1], 1);
        new_node->pos_x = positions [1];
        new_node->pos_y = pos_y;
        break;

      case 21:
        /* |   | */
        /* +-+-+ */
        /* | |   */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [3]);
        addLast (order, adjazent_node [2]);
        addLast (order, adjazent_node [1]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 1, 360);
        set_angle (actual_node, adjazent_node [3], 1, 90);
        set_angle (actual_node, adjazent_node [2], 1, 180);
        set_angle (actual_node, adjazent_node [1], 1, 270);
        increase_bends (resultat, node_1, adjazent_node [0]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [0], 1);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [0], node_1);
        new_node =
          insert_node_in_orthogonal_edge (new_node, adjazent_node [0], 0);
        new_node->pos_x = positions [0];
        new_node->pos_y = pos_y++;
        increase_bends (resultat, node_1, adjazent_node [1]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [1], 1);
        new_node->pos_x = positions [1];
        new_node->pos_y = pos_y;
        actual_node->pos_x = positions [2];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, node_1, adjazent_node [3]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [3], 1);
        new_node->pos_x = positions [3];
        new_node->pos_y = pos_y;
        break;

      case 22:
        /* |     */
        /* +-+-+ */
        /* | | | */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [3]);
        addLast (order, adjazent_node [2]);
        addLast (order, adjazent_node [1]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 1, 360);
        set_angle (actual_node, adjazent_node [3], 1, 90);
        set_angle (actual_node, adjazent_node [2], 1, 180);
        set_angle (actual_node, adjazent_node [1], 1, 270);
        increase_bends (resultat, node_1, adjazent_node [0]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [0], 1);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [0], node_1);
        new_node =
          insert_node_in_orthogonal_edge (new_node, adjazent_node [0], 0);
        new_node->pos_x = positions [0];
        new_node->pos_y = pos_y++;
        increase_bends (resultat, node_1, adjazent_node [1]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [1], 1);
        new_node->pos_x = positions [1];
        new_node->pos_y = pos_y;
        actual_node->pos_x = positions [2];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [3], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [3], 0);
        new_node->pos_x = positions [3];
        new_node->pos_y = pos_y;
        break;
      }
      break;

    case 4:
      /* Vier Positionen */
      /* Es gibt 16 Situationen, aber nur 8 Aktionen. Deshalb wird in
         encoding die aktuelle Situation binaer kodiert und die Aktionen
         ueber die Kodierung ausgewaehlt. */
      encoding = 8 * situation [0] + 4 * situation [1] + 2 * situation [2] +
        situation [3] - 15;

      /* Setzen der Kanten-Reihenfolge um den Knoten herum */
      switch (encoding) {
      case 0:
        /* | | | | */
        /* +-+-+-+ */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [1]);
        addLast (order, adjazent_node [2]);
        addLast (order, adjazent_node [3]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 1, 270);
        set_angle (actual_node, adjazent_node [1], 1, 360);
        set_angle (actual_node, adjazent_node [2], 1, 90);
        set_angle (actual_node, adjazent_node [3], 1, 180);
        increase_bends (resultat, adjazent_node [0], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [0], 0);
        new_node->pos_x = positions [0];
        new_node->pos_y = pos_y;
        actual_node->pos_x = positions [1];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, node_1, adjazent_node [2]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [2], 1);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y++;
        increase_bends (resultat, node_1, adjazent_node [3]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [3], 1);
        new_node->pos_x = positions [1];
        new_node->pos_y = pos_y;
        increase_bends (resultat, node_1, adjazent_node [3]);
        new_node =
          insert_node_in_orthogonal_edge (new_node, adjazent_node [3], 1);
        new_node->pos_x = positions [3];
        new_node->pos_y = pos_y;
        break;

      case 15:
        /* +-+-+-+ */
        /* | | | | */
        order = getNewIntList ();
        addFirst (order, adjazent_node [0]);
        addLast (order, adjazent_node [3]);
        addLast (order, adjazent_node [2]);
        addLast (order, adjazent_node [1]);
        set_node_order (actual_node, order);
        clearIntList (order);
        set_angle (actual_node, adjazent_node [0], 1, 270);
        set_angle (actual_node, adjazent_node [3], 1, 360);
        set_angle (actual_node, adjazent_node [2], 1, 90);
        set_angle (actual_node, adjazent_node [1], 1, 180);
        increase_bends (resultat, adjazent_node [3], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [3], 0);
        new_node->pos_x = positions [1];
        new_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [3], node_1);
        new_node =
          insert_node_in_orthogonal_edge (new_node, adjazent_node [3], 0);
        new_node->pos_x = positions [3];
        new_node->pos_y = pos_y++;
        increase_bends (resultat, node_1, adjazent_node [0]);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [0], 1);
        new_node->pos_x = positions [0];
        new_node->pos_y = pos_y;
        actual_node->pos_x = positions [1];
        actual_node->pos_y = pos_y;
        increase_bends (resultat, adjazent_node [2], node_1);
        new_node =
          insert_node_in_orthogonal_edge (actual_node, adjazent_node [2], 0);
        new_node->pos_x = positions [2];
        new_node->pos_y = pos_y;
        break;
      }
    }
    row = row->p_down;
  }
  return (resultat);
}



/****************************************************************************/
/* NAME : visibility_adjlist                                                */
/* FUNKTION : Erzeugung einer durch eine Visibility Representation          */
/*            induzierten Adjazenz-Liste.                                   */
/* UEBERGABEPARAMETER : Zeiger auf Visibility Representation                */
/* VORAUSSETZUNG: Der repraesentierte Graph ist zusammenhaengend und        */
/*                planar (wird nicht geprueft);                             */
/* RUECKGABEWERT : Zeiger auf eine Adjazenzliste                            */
/* ERSTELLT VON : Ulf Milanese (01.03.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

p_adjList visibility_adjlist (visibilityrepptr vr)
{
	p_adjList      resultat = (p_adjList) NULL;
	numberarrayptr array = (numberarrayptr) NULL;
	numberarrayptr tmp_array = (numberarrayptr) NULL;
	int            from;
	int            to;
	int            after = -1;
	int            backwards = 0;

	if (!vr)
		return (resultat);

	resultat = getNewAdjList (vr->zeilen);
	array = vr->top_left;
	while (array) {
		from = array->inhalt;
		backwards = 0;
		after = -1;
		tmp_array = array->p_right;
		while (tmp_array && (tmp_array != array)) {
			if (!backwards) {
				to = tmp_array->up;
				if ((tmp_array->inhalt == from) && (to != FIELD_FREE)) {
					if (after == -1)
						addNewEdge (resultat, from, to);
					else
						addNewEdgeAfter (resultat, from, to, after);
					after = to;
				}
				if (!tmp_array->p_right)
					backwards = 1;
				else
					if ((tmp_array->inhalt == from) &&
							(tmp_array->p_right->inhalt != from))
						backwards = 1;
					else
						tmp_array = tmp_array->p_right;
			}
			else {
				to = tmp_array->down;
				if ((tmp_array->inhalt == from) && (to != FIELD_FREE)) {
					if (after == -1)
						addNewEdge (resultat, from, to);
					else
						addNewEdgeAfter (resultat, from, to, after);
					after = to;
				}
				tmp_array = tmp_array->p_left;
			}
		}
		array = array->p_down;
	}
	return (resultat);
}



/****************************************************************************/
/* NAME : transform_orthogonal_representation                               */
/* FUNKTION : Erzeugung einer orthogonalen Representation                   */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonale Representation          */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keine                                                    */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void transform_orthogonal_representation (orthogonalrepptr or)
{
  /* In dieser Prozedur werden die Transformationen T1 bis T3 aus dem
     Paper 'Planar Grid Embedding in Linear Time' von Roberto Tamassia
     und Ioannis G. Tollis implementiert. */

  transformation_T1 (or);
  transformation_T2 (or);
  transformation_T3 (or);
  renumber_orthogonal_representation (or);
}



/****************************************************************************/
/* NAME : insert_nonplanar_edges_into_orthogonal                            */
/* FUNKTION : Fuegt heuristisch die Kanten in die Orthogonal Representation */
/*            ein, die die Planaritaet zerstoeren und fuegt ausserdem       */
/*            dafuer noetige Hilfsknoten ein                                */
/* UEBERGABEPARAMETER : Zeiger auf Orthogonal Representation or; Zeiger auf */
/*                      planare Relation planarRel; Zeiger auf (eventuell)  */
/*                      nicht-planare Relation nonplanarRel                 */
/* VORAUSSETZUNG : nonplanarRel ist Teilrelation von planarRel (wird nicht  */
/*                 geprueft); or wurde aus planarRel berechnet (wird nicht  */
/*                 geprueft)                                                */
/* RUECKGABEWERT : keiner (or wird direkt geaendert)                        */
/* ERSTELLT VON : Ulf Milanese (15.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/
void insert_nonplanar_edges_into_orthogonal (orthogonalrepptr or,
                                             p_adjList planarEmbedding,
                                             KureRel * nonplanarRel)
{
  edgelistptr new_edges = NULL;
  edgelistptr  tmp_edges;
  int    node_1;
  int    node_2;
  int    tmp_node_1;
  int    tmp_node_2;
  int    counter_1;
  int    counter_2;
  int    free_edges_1;
  int    free_edges_2;
  adjlistptr  prec_free_edges_1 [3];
  adjlistptr  prec_free_edges_2 [3];
  int    winkel_1 [3];
  int    winkel_2 [3];
  int    distance;
  int    tmp_distance;
  int    tmp_pos_x_1;
  int    tmp_pos_y_1;
  int    tmp_pos_x_2;
  int    tmp_pos_y_2;
  int    pos_x_1;
  int    pos_y_1;
  int    pos_x_2;
  int    pos_y_2;
  int    choice_1;
  int    choice_2;
  adjlistptr  tmp_al;
  orthogonalrepptr or_node_1;
  orthogonalrepptr or_node_2;
  orthogonalrepptr last_node;
  int       ready;
  int       vars_zeilen;
  int       vars_spalten;

  vars_zeilen = kure_rel_get_vars_rows (nonplanarRel);
  vars_spalten = kure_rel_get_vars_cols (nonplanarRel);

  /* Alle Kanten, die nicht in planarRel vorkommen, werden in der Liste
     new_edges abgespeichert. */
  for (node_1 = 0; node_1 < planarEmbedding->size - 1; node_1 ++)
    for (node_2 = node_1 + 1; node_2 < planarEmbedding->size; node_2 ++)
    	if ((kure_get_bit_fast_si (nonplanarRel, node_2, node_1, vars_zeilen, vars_spalten)
    			|| kure_get_bit_fast_si(nonplanarRel, node_1, node_2, vars_zeilen, vars_spalten))
      //if ((get_rel_bit (nonplanarRel, node_1, node_2,
        //                vars_zeilen, vars_spalten) ||
        //   get_rel_bit (nonplanarRel, node_2, node_1,
        //                vars_zeilen, vars_spalten))
          && !areNeighbours (planarEmbedding, node_1, node_2)) {
        if (!new_edges) {
          new_edges = make_edge ("", node_1, node_2, VISIBLE);
        }
        else {
          append_edge_to_edgelist (make_edge ("", node_1, node_2, VISIBLE),
                                   new_edges);
       }
      }

  /* Zum Anfuegen von neuen Hilfsknoten zeigt last_node auf das letzte
     Element der Orthogonal Representation. */
  last_node = or;
  while (last_node->next)
    last_node = last_node->next;

  tmp_edges = new_edges;
  while (tmp_edges) {
    node_1 = tmp_edges->edge.from;
    node_2 = tmp_edges->edge.to;
    tmp_node_1 = node_1;
    tmp_node_2 = node_2;

    ready = 0;
    while (!ready) {

      /* Es werden fuer beide Knoten Listen erstellt, welche Winkel noch
         keine inzidenten Kanten besitzen. */
      or_node_1 = or;
      while (or_node_1->number != tmp_node_1)
        or_node_1 = or_node_1->next;
      free_edges_1 = 0;
      tmp_al = or_node_1->adjazent;
      do {
        for (counter_1 = tmp_al->angle; counter_1 > 1; counter_1--)
          if ((!or_node_1->help_node) || (counter_1 != 3)) {
            prec_free_edges_1 [free_edges_1] = tmp_al;
            winkel_1 [free_edges_1] =
              (tmp_al->winkel + ((tmp_al->angle - counter_1 + 1) * 90));
            if (winkel_1 [free_edges_1] > 360)
              winkel_1 [free_edges_1] -= 360;
            free_edges_1 ++;
          }
        tmp_al = tmp_al->next;
      } while (tmp_al != or_node_1->adjazent);
      or_node_2 = or;
      while (or_node_2->number != tmp_node_2)
        or_node_2 = or_node_2->next;
      free_edges_2 = 0;
      tmp_al = or_node_2->adjazent;
      do {
        for (counter_1 = tmp_al->angle; counter_1 > 1; counter_1--){
          prec_free_edges_2 [free_edges_2] = tmp_al;
          winkel_2 [free_edges_2] =
            (tmp_al->winkel + ((tmp_al->angle - counter_1 + 1) * 90));
          if (winkel_2 [free_edges_2] > 360)
            winkel_2 [free_edges_2] -= 360;
          free_edges_2 ++;
        }
        tmp_al = tmp_al->next;
      } while (tmp_al != or_node_2->adjazent);

      /* 1. Fall: Die beiden Knoten lassen sich ohne Hilfsknoten verbinden. */
      for (counter_1 = 0; counter_1 < free_edges_1; counter_1 ++)
        for (counter_2 = 0; counter_2 < free_edges_2; counter_2 ++) {
          switch (winkel_1 [counter_1]) {
          case 90:
            if ((winkel_2 [counter_2] == 270) &&
                (or_node_1->pos_x < or_node_2->pos_x) &&
                (or_node_1->pos_y == or_node_2->pos_y)) {
              make_horizontal_space_in_orthogonal
                (or, or_node_1->pos_y, or_node_1->pos_x, or_node_2->pos_x);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 90, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 270, node_2, tmp_node_2);
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            break;
          case 180:
            if ((winkel_2 [counter_2] == 360) &&
                (or_node_1->pos_y < or_node_2->pos_y) &&
                (or_node_1->pos_x == or_node_2->pos_x)) {
              make_vertikal_space_in_orthogonal
                (or, or_node_1->pos_x, or_node_1->pos_y, or_node_2->pos_y);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 180, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 360, node_2, tmp_node_2);
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            break;
          case 270:
            if ((winkel_2 [counter_2] == 90) &&
                (or_node_1->pos_x > or_node_2->pos_x) &&
                (or_node_1->pos_y == or_node_2->pos_y)) {
              make_horizontal_space_in_orthogonal
                (or, or_node_1->pos_y, or_node_2->pos_x, or_node_1->pos_x);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 270, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 90, node_2, tmp_node_2);
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            break;
          case 360:
            if ((winkel_2 [counter_2] == 180) &&
                (or_node_1->pos_y > or_node_2->pos_y) &&
                (or_node_1->pos_x == or_node_2->pos_x)) {
              make_vertikal_space_in_orthogonal
                (or, or_node_1->pos_x, or_node_2->pos_y, or_node_1->pos_y);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 360, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 180, node_2, tmp_node_2);
              ready = 1;
            }
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
            break;
          }
        }
      if (ready)
        break;

      /* 2. Fall: Es existieren freie Winkel, die sich schneiden. Es muss
         nur noch ein Hilfsknoten am Schnittpunkt hinzugefuegt werden. */
      for (counter_1 = 0; counter_1 < free_edges_1; counter_1 ++)
        for (counter_2 = 0; counter_2 < free_edges_2; counter_2 ++) {
          switch (winkel_1 [counter_1]) {
          case 90:
            if ((winkel_2 [counter_2] == 180) &&
                (or_node_1->pos_x < or_node_2->pos_x) &&
                (or_node_1->pos_y > or_node_2->pos_y)) {
              make_horizontal_space_in_orthogonal
                (or, or_node_1->pos_y, or_node_1->pos_x, -1);
              make_vertikal_space_in_orthogonal
                (or, or_node_2->pos_x, or_node_2->pos_y, -1);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 90, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 180, node_2, tmp_node_2);
              last_node =
                insert_node_in_orthogonal_edge (or_node_1, node_2, 1);
              last_node->pos_x = or_node_2->pos_x;
              last_node->pos_y = or_node_1->pos_y;
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            if ((winkel_2 [counter_2] == 360) &&
                (or_node_1->pos_x < or_node_2->pos_x) &&
                (or_node_1->pos_y < or_node_2->pos_y)) {
              make_horizontal_space_in_orthogonal
                (or, or_node_1->pos_y, or_node_1->pos_x, -1);
              make_vertikal_space_in_orthogonal
                (or, or_node_2->pos_x, -1, or_node_2->pos_y);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 90, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 360, node_2, tmp_node_2);
              last_node =
                insert_node_in_orthogonal_edge (or_node_1, node_2, 0);
              last_node->pos_x = or_node_2->pos_x;
              last_node->pos_y = or_node_1->pos_y;
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            break;
          case 180:
            if ((winkel_2 [counter_2] == 90) &&
                (or_node_1->pos_x > or_node_2->pos_x) &&
                (or_node_1->pos_y < or_node_2->pos_y)) {
              make_horizontal_space_in_orthogonal
                (or, or_node_2->pos_y, or_node_2->pos_x, -1);
              make_vertikal_space_in_orthogonal
                (or, or_node_1->pos_x, or_node_1->pos_y, -1);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 180, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 90, node_2, tmp_node_2);
              last_node =
                insert_node_in_orthogonal_edge (or_node_1, node_2, 0);
              last_node->pos_x = or_node_1->pos_x;
              last_node->pos_y = or_node_2->pos_y;
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            if ((winkel_2 [counter_2] == 270) &&
                (or_node_1->pos_x < or_node_2->pos_x) &&
                (or_node_1->pos_y < or_node_2->pos_y)) {
              make_horizontal_space_in_orthogonal
                (or, or_node_2->pos_y, -1, or_node_2->pos_x);
              make_vertikal_space_in_orthogonal
                (or, or_node_1->pos_x, or_node_1->pos_y,-1);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 180, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 270, node_2, tmp_node_2);
              last_node =
                insert_node_in_orthogonal_edge (or_node_1, node_2, 1);
              last_node->pos_x = or_node_1->pos_x;
              last_node->pos_y = or_node_2->pos_y;
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            break;
          case 270:
            if ((winkel_2 [counter_2] == 180) &&
                (or_node_1->pos_x > or_node_2->pos_x) &&
                (or_node_1->pos_y > or_node_2->pos_y)) {
              make_horizontal_space_in_orthogonal
                (or, or_node_1->pos_y, -1, or_node_1->pos_x);
              make_vertikal_space_in_orthogonal
                (or, or_node_2->pos_x, or_node_2->pos_y, -1);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 270, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 180, node_2, tmp_node_2);
              last_node =
                insert_node_in_orthogonal_edge (or_node_1, node_2, 0);
              last_node->pos_x = or_node_2->pos_x;
              last_node->pos_y = or_node_1->pos_y;
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            if ((winkel_2 [counter_2] == 360) &&
                (or_node_1->pos_x > or_node_2->pos_x) &&
                (or_node_1->pos_y < or_node_2->pos_y)) {
              make_horizontal_space_in_orthogonal
                (or, or_node_1->pos_y, -1, or_node_1->pos_x);
              make_vertikal_space_in_orthogonal
                (or, or_node_2->pos_x, -1, or_node_2->pos_y);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 270, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 360, node_2, tmp_node_2);
              last_node =
                insert_node_in_orthogonal_edge (or_node_1, node_2, 1);
              last_node->pos_x = or_node_2->pos_x;
              last_node->pos_y = or_node_1->pos_y;
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            break;
          case 360:
            if ((winkel_2 [counter_2] == 90) &&
                (or_node_1->pos_x > or_node_2->pos_x) &&
                (or_node_1->pos_y > or_node_2->pos_y)) {
              make_horizontal_space_in_orthogonal
                (or, or_node_2->pos_y, or_node_2->pos_x, -1);
              make_vertikal_space_in_orthogonal
                (or, or_node_1->pos_x, -1, or_node_1->pos_y);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 360, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 90, node_2, tmp_node_2);
              last_node =
                insert_node_in_orthogonal_edge (or_node_1, node_2, 1);
              last_node->pos_x = or_node_1->pos_x;
              last_node->pos_y = or_node_2->pos_y;
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            if ((winkel_2 [counter_2] == 270) &&
                (or_node_1->pos_x < or_node_2->pos_x) &&
                (or_node_1->pos_y > or_node_2->pos_y)) {
              make_horizontal_space_in_orthogonal
                (or, or_node_2->pos_y, -1, or_node_2->pos_x);
              make_vertikal_space_in_orthogonal
                (or, or_node_1->pos_x, -1, or_node_1->pos_y);
              make_edge_in_orthogonal
                (prec_free_edges_1 [counter_1], 360, node_1, tmp_node_1,
                 prec_free_edges_2 [counter_2], 270, node_2, tmp_node_2);
              last_node =
                insert_node_in_orthogonal_edge (or_node_1, node_2, 0);
              last_node->pos_x = or_node_1->pos_x;
              last_node->pos_y = or_node_2->pos_y;
              counter_1 = free_edges_1;
              counter_2 = free_edges_2;
              ready = 1;
            }
            break;
          }
        }
      if (ready)
        break;


      /* 3. Fall: Auf jedem freien Winkel wird im Abstand 1 ein Hilfsknoten
         plaziert. Dann wird das Paar ausgewaehlt mit kleinstem Abstand.
         Danach wird die Laenge der Kante von node_1 zum Hilfsknoten
         berechnet, indem der Abstand zum zweiten Hilfsknoten minimiert
         wird. */

      /* In distance wird eine grosse Zahl gespeichert. */
      distance = 3 * manhattan_distance (or_node_1->pos_x, or_node_1->pos_y,
                                         or_node_2->pos_x, or_node_2->pos_y);
      choice_1 = 0;
      choice_2 = 0;
      pos_x_1 = or_node_1->pos_x;
      pos_y_1 = or_node_1->pos_y;
      pos_x_2 = or_node_2->pos_x;
      pos_y_2 = or_node_2->pos_y;
      for (counter_1 = 0; counter_1 < free_edges_1; counter_1 ++) {
        tmp_pos_x_1 = or_node_1->pos_x;
        tmp_pos_y_1 = or_node_1->pos_y;
        if (winkel_1 [counter_1] == 90)
          tmp_pos_x_1 ++;
        if (winkel_1 [counter_1] == 180)
          tmp_pos_y_1 ++;
        if (winkel_1 [counter_1] == 270)
          tmp_pos_x_1--;
        if (winkel_1 [counter_1] == 360)
          tmp_pos_y_1--;
        for (counter_2 = 0; counter_2 < free_edges_2; counter_2 ++) {
          tmp_pos_x_2 = or_node_2->pos_x;
          tmp_pos_y_2 = or_node_2->pos_y;
          if (winkel_2 [counter_2] == 90)
            tmp_pos_x_2 ++;
          if (winkel_2 [counter_2] == 180)
            tmp_pos_y_2 ++;
          if (winkel_2 [counter_2] == 270)
            tmp_pos_x_2--;
          if (winkel_2 [counter_2] == 360)
            tmp_pos_y_2--;
          tmp_distance = manhattan_distance (tmp_pos_x_1, tmp_pos_y_1,
                                             tmp_pos_x_2, tmp_pos_y_2);
          if (distance > tmp_distance) {
            distance = tmp_distance;
            choice_1 = counter_1;
            choice_2 = counter_2;
            pos_x_1 = tmp_pos_x_1;
            pos_y_1 = tmp_pos_y_1;
            pos_x_2 = tmp_pos_x_2;
            pos_y_2 = tmp_pos_y_2;
          }
        }
      }
      /* In choice_1 steht jetzt, welche Kante an den ersten Knoten
         angefuegt werden soll. */
      ready = 0;
      while (!ready && pos_x_1 && pos_y_1) {
        tmp_pos_x_1 = pos_x_1;
        tmp_pos_y_1 = pos_y_1;
        if (winkel_1 [choice_1] == 90)
          tmp_pos_x_1 ++;
        if (winkel_1 [choice_1] == 180)
          tmp_pos_y_1 ++;
        if (winkel_1 [choice_1] == 270)
          tmp_pos_x_1--;
        if (winkel_1 [choice_1] == 360)
          tmp_pos_y_1--;
        tmp_distance = manhattan_distance (tmp_pos_x_1, tmp_pos_y_1,
                                           pos_x_2, pos_y_2);
        if (distance > tmp_distance) {
          distance = tmp_distance;
            pos_x_1 = tmp_pos_x_1;
            pos_y_1 = tmp_pos_y_1;
        }
        else
          ready = 1;
      }
      ready = 0;
      last_node = or;
      while (last_node->next)
        last_node = last_node->next;
      last_node->next = new_orthogonal_representation (1);
      last_node->next->number = last_node->number + 1;
      last_node = last_node->next;
      last_node->help_node = 1;
      last_node->adjazent = new_adjlist (node_1);
      last_node->adjazent->ziel = tmp_node_1;
      last_node->adjazent->angle = 4;
      last_node->adjazent->sym = new_adjlist (node_2);
      last_node->adjazent->sym->ziel = last_node->number;
      last_node->adjazent->sym->sym = last_node->adjazent;
      last_node->adjazent->sym->next = prec_free_edges_1 [choice_1]->next;
      prec_free_edges_1 [choice_1]->next = last_node->adjazent->sym;
      last_node->adjazent->sym->winkel = winkel_1 [choice_1];

      switch (winkel_1 [choice_1]) {
      case 90:
        make_horizontal_space_in_orthogonal
          (or, or_node_1->pos_y, or_node_1->pos_x, -1);
        make_vertikal_space_in_orthogonal (or, pos_x_1, -1, -1);
        last_node->adjazent->winkel = 270;
        break;
      case 180:
        make_vertikal_space_in_orthogonal
          (or, or_node_1->pos_x, or_node_1->pos_y, -1);
        make_horizontal_space_in_orthogonal (or, pos_y_1, -1, -1);
        last_node->adjazent->winkel = 360;
        break;
      case 270:
        if (!pos_x_1)
          pos_x_1 = 1;
        make_horizontal_space_in_orthogonal
          (or, or_node_1->pos_y, -1, or_node_1->pos_x);
        make_vertikal_space_in_orthogonal (or, pos_x_1, -1, -1);
        last_node->adjazent->winkel = 90;
        break;
      case 360:
        if (!pos_y_1)
          pos_y_1 = 1;
        make_vertikal_space_in_orthogonal
          (or, or_node_1->pos_x, -1, or_node_1->pos_y);
        make_horizontal_space_in_orthogonal (or, pos_y_1, -1, -1);
        last_node->adjazent->winkel = 180;
        break;
      }
      last_node->pos_x = pos_x_1;
      last_node->pos_y = pos_y_1;
      last_node->adjazent->sym->angle =
        ((last_node->adjazent->sym->next->winkel -
          last_node->adjazent->sym->winkel + 360) / 90);
      if (last_node->adjazent->sym->angle > 4)
        last_node->adjazent->sym->angle -= 4;
      prec_free_edges_1 [choice_1]->angle -=
        last_node->adjazent->sym->angle;
      tmp_node_1 = last_node->number;
    }
    tmp_edges = tmp_edges->next;
  }
  del_edgelistptr (new_edges);
}


/****************************************************************************/
/* NAME : graph_create_orthogonal                                           */
/* FUNKTION : Erzeugung eines Graphen ausgehend von einer orthogonalen      */
/*            Repraesentation                                               */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonal Representation or;       */
/*                      Gitter-Abstaende grid_x, grid_y; Name des Graphen   */
/*                      name                                                */
/* VORAUSSETZUNG: or ist korrekt erzeugt worden (wird nicht geprueft)       */
/* RUECKGABEWERT : Zeiger auf einen Graphen                                 */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM : 09.02.1999                                         */
/****************************************************************************/

graphlistptr graph_create_orthogonal (orthogonalrepptr orp, unsigned int grid_x,
                                      unsigned int grid_y, char * name)
{
  orthogonalrepptr tmp_or;
  adjlistptr al;
  adjlistptr tmp_al;
  int new_node_number = 0;
  int number_of_original_nodes = 0;
  int first_node;
  int ready;
  int node_1;
  int node_pos_x;
  int node_pos_y;
  graphlistptr resultat;
  Graph * graph1;
  char number_name [64];
  int minimum_1;
  int maximum_1;
  int minimum_2;
  int maximum_2;
  int maximum;
  int new_pos;
  int changed;
  int number_of_block_x = 0;
  int number_of_block_y = 0;
  int number_of_alap_x = 0;
  int number_of_alap_y = 0;
  int in_degree;
  int out_degree;
  int counter_1;
  int counter_2;

  if (!orp)
    return ((graphlistptr) NULL);

  /* Enthaelt der erste Knoten eine Kante (Voraussetzung ist, dass der
     Graph zusammenhaengend ist und mindestens vier Knoten enthaelt)? */
  al = orp->adjazent;
  if (!al)
    return ((graphlistptr) NULL);

  tmp_or = orp;
  while (tmp_or) {
    if (!tmp_or->help_node)
      number_of_original_nodes++;
    new_node_number++;
    tmp_or = tmp_or->next;
  }

  /* Enthaelt die Orthogonale Representation Knoten? */
  if (!new_node_number)
    return ((graphlistptr) NULL);
  al = orp->adjazent;

  {
    int right   [new_node_number];
    int down    [new_node_number];
    int left    [new_node_number];
    int up      [new_node_number];
    /* right [i]: Knoten, der rechts von i steht,
       down  [i]: Knoten, der unterhalb von i steht,
       left  [i]: Knoten, der links von i steht,
       up    [i]: Knoten, der oberhalb von i steht,
       Ist einer der Werte gleich -1, besitzt der Knoten i keinen
       benachbarten Knoten in dieser Richtung. */
    int pos_x [new_node_number];
    int pos_y [new_node_number];
    int old_x [new_node_number];
    int old_y [new_node_number];
    /* old_pos [i] [0]: x-Position des Knoten i vor einem Kompaktionsschritt,
       old_pos [i] [1]: y-Position des Knoten i */
    int block_x [new_node_number] [2];
    /* block_x [i] [0]: Auf der y-Achse am hoechsten liegender Punkt
       des Blockes i auf der x-Achse,
       block_x [i] [1]: am weitesten unten liegender Punkt vom Block i */
    int block_y [new_node_number] [2];
    int alap_x [new_node_number] [2];
    int alap_y [new_node_number] [2];
    /* alap_x (alap_y) enthaelt die Bloecke, die moeglichst weit nach
       rechts (nach unten) geschoben werden sollen. */

    tmp_or = orp;
    while (tmp_or) {
      al = tmp_or->adjazent;
      /* al zeigt nach der While-Schleife auf die Kante mit dem groessten
         Winkel */
      while (al->winkel < al->next->winkel)
        al = al->next;
      al = al->next;
      /* al zeigt jetzt auf die Kante mit dem kleinsten Winkel */

      if (al->winkel == 90) {
        right [tmp_or->number] = al->ziel;
        al = al->next;
      }
      else
        right [tmp_or->number] = -1;
      if (al->winkel == 180) {
        down [tmp_or->number] = al->ziel;
        al = al->next;
      }
      else
        down [tmp_or->number] = -1;
      if (al->winkel == 270) {
        left [tmp_or->number] = al->ziel;
        al = al->next;
      }
      else
        left [tmp_or->number] = -1;
      if (al->winkel == 360)
        up [tmp_or->number] = al->ziel;
      else
        up [tmp_or->number] = -1;
      pos_x [tmp_or->number] = tmp_or->pos_x;
      old_x [tmp_or->number] = tmp_or->pos_x;
      pos_y [tmp_or->number] = tmp_or->pos_y;
      old_y [tmp_or->number] = tmp_or->pos_y;
      tmp_or = tmp_or->next;
    }

    /* Berechnung der Bloecke. */
    for (counter_1 = 0; counter_1 < new_node_number; counter_1 ++) {
      /* Bloecke, die auf der x-Achse die gleiche Position haben muessen.
         Der erste Knoten besitzt keine Kante nach oben. */
      if (up [counter_1] == -1) {
        in_degree = 0;
        out_degree = 0;
        if (right [counter_1] != -1)
          out_degree ++;
        if (left [counter_1] != -1)
          in_degree ++;
        node_1 = counter_1;
        while (down [node_1] != -1) {
          node_1 = down [node_1];
          if (right [node_1] != -1)
            out_degree ++;
          if (left [node_1] != -1)
            in_degree ++;
        }
        block_x [number_of_block_x] [0] = counter_1;
        block_x [number_of_block_x] [1] = node_1;
        number_of_block_x++;
        /* Falls mehr Kanten den Block nach rechts als nach links
           verlassen, muss dieser Block moeglichst weit nach rechts
           verschoben werden. */
        if (out_degree > in_degree) {
          alap_x [number_of_alap_x] [0] = counter_1;
          alap_x [number_of_alap_x] [1] = node_1;
          number_of_alap_x++;
        }
      }
      /* Bloecke, die auf der y-Achse die gleiche Position haben muessen.
         Der erste Knoten besitzt keine Kante nach links. */
      if (left [counter_1] == -1) {
        in_degree = 0;
        out_degree = 0;
        if (down [counter_1] != -1)
          out_degree ++;
        if (up [counter_1] != -1)
          in_degree ++;
        node_1 = counter_1;
        while (right [node_1] != -1) {
          node_1 = right [node_1];
          if (down [node_1] != -1)
            out_degree ++;
          if (up [node_1] != -1)
            in_degree ++;
        }
        block_y [number_of_block_y] [0] = counter_1;
        block_y [number_of_block_y] [1] = node_1;
        number_of_block_y++;
        /* Falls mehr Kanten den Block nach unten als nach 
           verlassen, muss dieser Block moeglichst weit nach unten
           verschoben werden. */
        if (out_degree > in_degree) {
          alap_y [number_of_alap_y] [0] = counter_1;
          alap_y [number_of_alap_y] [1] = node_1;
          number_of_alap_y++;
        }
      }
    }

    do {
      /* Einplanung der Bloecke auf der x-Achse nach der Methode As Soon
         As Possible. */
      do {
        changed = 0;
        maximum = 0;
        for (counter_1 = 0; counter_1 < number_of_block_x; counter_1 ++) {
          minimum_1 = pos_y [block_x [counter_1] [0]];
          maximum_1 = pos_y [block_x [counter_1] [1]];
          if (pos_x [block_x [counter_1] [1]] > maximum)
            maximum = pos_x [block_x [counter_1] [1]];
          new_pos = 1;
          for (counter_2 = 0; counter_2 < number_of_block_x; counter_2 ++)
            if ((pos_x [block_x [counter_2] [0]] <
                 pos_x [block_x [counter_1] [0]]) &&
                (new_pos <= pos_x [block_x [counter_2] [0]])) {
              minimum_2 = pos_y [block_x [counter_2] [0]];
              maximum_2 = pos_y [block_x [counter_2] [1]];
              if ((minimum_1 <= maximum_2) && (maximum_1 >= minimum_2))
                new_pos = pos_x [block_x [counter_2] [0]] + 1;
            }
          if (pos_x [block_x [counter_1] [0]] > new_pos) {
            changed = 1;
            pos_x [block_x [counter_1] [0]] = new_pos;
            node_1 = block_x [counter_1] [0];
            while (down [node_1] != -1) {
              node_1 = down [node_1];
              pos_x [node_1] = new_pos;
            }
          }
        }
      } while (changed);
      /* Einplanung der Bloecke auf der x-Achse, die nach nach der
         Methode As Late As Possible berechnet werden muessen. */
      do {
        changed = 0;
        for (counter_1 = 0; counter_1 < number_of_alap_x; counter_1 ++) {
          minimum_1 = pos_y [alap_x [counter_1] [0]];
          maximum_1 = pos_y [alap_x [counter_1] [1]];
          new_pos = maximum;
          for (counter_2 = 0; counter_2 < number_of_block_x; counter_2 ++)
            if ((pos_x [block_x [counter_2] [0]] >
                 pos_x [alap_x [counter_1] [0]]) &&
                (new_pos >= pos_x [block_x [counter_2] [0]])) {
              minimum_2 = pos_y [block_x [counter_2] [0]];
              maximum_2 = pos_y [block_x [counter_2] [1]];
              if ((minimum_1 <= maximum_2) && (maximum_1 >= minimum_2))
                new_pos = pos_x [block_x [counter_2] [0]] - 1;
            }
          if (pos_x [alap_x [counter_1] [0]] < new_pos) {
            changed = 1;
            pos_x [alap_x [counter_1] [0]] = new_pos;
            node_1 = alap_x [counter_1] [0];
            while (down [node_1] != -1) {
              node_1 = down [node_1];
              pos_x [node_1] = new_pos;
            }
          }
        }
      } while (changed);

      /* Einplanung der Bloecke auf der y-Achse nach der Methode As Soon
         As Possible. */
      do {
        changed = 0;
        maximum = 0;
        for (counter_1 = 0; counter_1 < number_of_block_y; counter_1 ++) {
          minimum_1 = pos_x [block_y [counter_1] [0]];
          maximum_1 = pos_x [block_y [counter_1] [1]];
          if (pos_y [block_y [counter_1] [1]] > maximum)
            maximum = pos_y [block_y [counter_1] [1]];
          new_pos = 1;
          for (counter_2 = 0; counter_2 < number_of_block_y; counter_2 ++)
            if ((pos_y [block_y [counter_2] [0]] <
                 pos_y [block_y [counter_1] [0]]) &&
                (new_pos <= pos_y [block_y [counter_2] [0]])) {
              minimum_2 = pos_x [block_y [counter_2] [0]];
              maximum_2 = pos_x [block_y [counter_2] [1]];
              if ((minimum_1 <= maximum_2) && (maximum_1 >= minimum_2))
                new_pos = pos_y [block_y [counter_2] [0]] + 1;
            }
          if (pos_y [block_y [counter_1] [0]] > new_pos) {
            changed = 1;
            pos_y [block_y [counter_1] [0]] = new_pos;
            node_1 = block_y [counter_1] [0];
            while (right [node_1] != -1) {
              node_1 = right [node_1];
              pos_y [node_1] = new_pos;
            }
          }
        }
      } while (changed);
      /* Einplanung der Bloecke auf der y-Achse, die nach nach der
         Methode As Late As Possible berechnet werden muessen. */
      do {
        changed = 0;
        for (counter_1 = 0; counter_1 < number_of_alap_y; counter_1 ++) {
          minimum_1 = pos_x [alap_y [counter_1] [0]];
          maximum_1 = pos_x [alap_y [counter_1] [1]];
          new_pos = maximum;
          for (counter_2 = 0; counter_2 < number_of_block_y; counter_2 ++)
            if ((pos_y [block_y [counter_2] [0]] >
                 pos_y [alap_y [counter_1] [0]]) &&
                (new_pos >= pos_y [block_y [counter_2] [0]])) {
              minimum_2 = pos_x [block_y [counter_2] [0]];
              maximum_2 = pos_x [block_y [counter_2] [1]];
              if ((minimum_1 <= maximum_2) && (maximum_1 >= minimum_2))
                new_pos = pos_y [block_y [counter_2] [0]] - 1;
            }
          if (pos_y [alap_y [counter_1] [0]] < new_pos) {
            changed = 1;
            pos_y [alap_y [counter_1] [0]] = new_pos;
            node_1 = alap_y [counter_1] [0];
            while (right [node_1] != -1) {
              node_1 = right [node_1];
              pos_y [node_1] = new_pos;
            }
          }
        }
      } while (changed);

      /* Die neuen Positionen werden mit den vorherigen verglichen. Falls */
      /* es Aenderungen gab, wird die Schleife noch mal durchgefuehrt. */
      for (counter_1 = 0; counter_1 < new_node_number; counter_1 ++) {
        if (old_x [counter_1] != pos_x [counter_1]) {
          changed = 1;
          old_x [counter_1] = pos_x [counter_1];
        }
        if (old_y [counter_1] != pos_y [counter_1]) {
          changed = 1;
          old_y [counter_1] = pos_y [counter_1];
        }
      }
    } while (changed);

    /* Der Resultat-Graph wird erzeugt. */
    resultat = mk_graph (name, NORMAL);
    graph1 = get_graph (resultat, name);
    for (counter_1 = 0; counter_1 < new_node_number; counter_1 ++) {
      sprintf (number_name, "%d", counter_1 + 1);
      node_pos_x = pos_x [counter_1] * grid_x;
      node_pos_y = pos_y [counter_1] * grid_y;
      if (counter_1 < number_of_original_nodes)
        append_node (graph1, make_node (number_name, node_pos_x, node_pos_y,
                                        DEFAULT_DIM, VISIBLE));
      else
        append_node (graph1, make_node (number_name, node_pos_x, node_pos_y,
                                        DEFAULT_DIM, HELP));
    }
    tmp_or = orp;
    for (counter_1 = 0; counter_1 < number_of_original_nodes; counter_1 ++) {
      al = tmp_or->adjazent;
      first_node = al->dest;
      ready = 0;
      while (!ready) {
        append_edge (graph1, make_edge ("", counter_1 + 1, al->dest + 1,
                                        VISIBLE));
        tmp_al = al;
        while (tmp_al->ziel != al->dest) {
          append_edge_pathnode (get_edge (graph1, counter_1 + 1,
                                          al->dest + 1),
                                tmp_al->ziel + 1);
          tmp_al = tmp_al->sym->next;
        }
        al = al->next;
        if (al->dest == first_node)
          ready = 1;
      }
      tmp_or = tmp_or->next;
    }
  }
  return (resultat);
}




/****************************************************************************/
/* NAME : new_component_list                                                */
/* FUNKTION : Reservierung des Speicherplatzes fuer eine                    */
/*            Graph-Komponenten-Liste                                       */
/* UEBERGABEPARAMETER : keiner                                              */
/* VORAUSSETZUNG: keiner                                                    */
/* RUECKGABEWERT : Zeiger auf eine Graph-Komponente-Liste                   */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

komponentenlistptr new_component_list (void)
{
  komponentenlistptr resultat;

  resultat = (komponentenlistptr) malloc (sizeof (komponentenlist));
  resultat->original_edges = (edgelistptr) NULL;
  resultat->number_of_original_nodes = 0;
  resultat->zusammenhangskomponenten = (komponentenptr) NULL;
  return (resultat);
}



/****************************************************************************/
/* NAME : delKomponentenListe                                               */
/* FUNKTION : Freigabe des Speicherplatzes einer Graph-Komponenten-Liste    */
/* UEBERGABEPARAMETER : Zeiger auf eine Graph-Komponenten-Liste             */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void delKomponentenListe (komponentenlistptr klp)
{
  if (klp) {
    if (klp->original_edges)
      del_edgelistptr (klp->original_edges);
    if (klp->zusammenhangskomponenten)
      del_component (klp->zusammenhangskomponenten);
    free (klp);
  }
}


/****************************************************************************/
/* NAME : new_component                                                     */
/* FUNKTION : Reservierung des Speicherplatzes fuer eine Graph-Komponente   */
/* UEBERGABEPARAMETER : keiner                                              */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : Zeiger auf eine Graph-Komponente                         */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

komponentenptr new_component (void)
{
  komponentenptr resultat;

  resultat = (komponentenptr) malloc (sizeof (komponente));
  resultat->teilRelation = NULL;
  resultat->original_node_numbers = getNewIntList ();
  resultat->teilGraph = (graphlistptr) NULL;
  resultat->next = (komponentenptr) NULL;

  return (resultat);
}




/****************************************************************************/
/* NAME : del_component                                                     */
/* FUNKTION : Freigabe des Speicherplatzes einer Graph-Komponente           */
/* UEBERGABEPARAMETER : Zeiger auf eine Graph-Komponente                    */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void del_component (komponentenptr kp)
{
  if (kp) {
    if (kp->teilRelation)
    	kure_rel_destroy(kp->teilRelation);
      //free_rellist (kp->teilRelation);
    if (kp->original_node_numbers)
      clearIntList (kp->original_node_numbers);
    if (kp->teilGraph)
      del_graph (kp->teilGraph, kp->teilGraph->graph.name);
    if (kp->next)
      del_component (kp->next);
    free (kp);
  }
}





/****************************************************************************/
/* NAME : splitRelationIntoComponents                                       */
/* FUNKTION : Aufsplittung einer Relation in ihre Zusammenhangskomponenten  */
/* UEBERGABEPARAMETER : Zeiger auf eine Relation                            */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : Zeiger auf eine Graph-Komponenten-Liste                  */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/* 15.05.2000 (Umstellung auf grosse Zahlen)                                */
/****************************************************************************/
komponentenlistptr splitRelationIntoComponents (KureRel * impl)
{
  komponentenlistptr resultat;
  int counter;
  p_intList done_nodes;
  p_intList stack_nodes;
  p_intList rest_nodes;
  p_intList tmp_rest_nodes;
  komponentenptr actual_component = NULL;
  int exists_forward_edge;
  int exists_backward_edge;
  int node_1;
  int node_2;
  int number_of_nodes;

  int breite = kure_rel_get_cols_si (impl);
  //int breite = Kure_mp_mint2int (relData->breite);

  int                node_used [breite];
  int                old_node_number [breite];
  //Kure_MINT               * NUMBER_OF_NODES;
  int                vars_zeilen;
  int                vars_spalten;

  if ( !kure_is_hom (impl, NULL))
	  return (komponentenlistptr) NULL;
  //if (Kure_mp_mcmp (relData->breite, relData->hoehe) != 0 )
    //return ((komponentenlistptr) NULL);

  resultat = new_component_list ();
  //resultat->number_of_original_nodes = Kure_mp_mint2int (relData->breite);
  resultat->number_of_original_nodes = breite;
  rest_nodes = getNewIntList ();
  stack_nodes = getNewIntList ();
  done_nodes = getNewIntList ();

  for (node_1 = 0; node_1 < breite; node_1 ++)
    addLast (rest_nodes, node_1);

  /* while rest_nodes \neq \emptyset do */
  while (rest_nodes->first) {

    for (node_1 = 0; node_1 < breite; node_1 ++)
      node_used [node_1] = 0;

    /* Es sind noch Knoten keiner Zusammenhangskomponente zugeordnet
       worden, es wird also eine neue Zusammenhangskomponente benoetigt. */
    number_of_nodes = 0;
    if (!resultat->zusammenhangskomponenten) {
      resultat->zusammenhangskomponenten = new_component ();
      actual_component = resultat->zusammenhangskomponenten;
    }
    else {
      actual_component->next = new_component ();
      actual_component = actual_component->next;
    }

    /* node_1 = head (rest_nodes); rest_nodes = tail (rest_nodes) */
    node_1 = popFirst (rest_nodes);
    addFirst (stack_nodes, node_1);
    number_of_nodes++;

    vars_zeilen = kure_rel_get_vars_rows (impl);
    vars_spalten = kure_rel_get_vars_cols (impl);
    //vars_zeilen = Kure_mp_number_of_vars (relData->hoehe);
    //vars_spalten = Kure_mp_number_of_vars (relData->breite);

    /* while stack_nodes \neq \emptyset do */
    while (stack_nodes->first) {
      node_1 = popFirst (stack_nodes);
      node_used [node_1] = 1;
      tmp_rest_nodes = copyIntList (rest_nodes);

      while (tmp_rest_nodes->first) {
        /* node_2 = head (tmp_rest_nodes),
           tmp_rest_nodes = tail (tmp_rest_nodes) */
        node_2 = popFirst (tmp_rest_nodes);
        exists_forward_edge = (int)kure_get_bit_fast_si(impl, node_2, node_1,vars_zeilen,vars_spalten);
        //exists_forward_edge = (int) get_rel_bit (relData, node_1, node_2,
        //                                         vars_zeilen, vars_spalten);
        if (!exists_forward_edge) {
        	exists_backward_edge = (int) kure_get_bit_fast_si (impl, node_1, node_2, vars_zeilen, vars_spalten);
          //exists_backward_edge = (int) get_rel_bit (relData, node_2, node_1,
            //                                        vars_zeilen, vars_spalten);
        }
        else
          exists_backward_edge = 0;

        /* if (node_1, node_2) \in E \or (node_2, node_1) \in E do */
        if (exists_forward_edge || exists_backward_edge) {

          /* stack_nodes = stack_nodes \cup {node_1} */
          addLast (stack_nodes, node_2);
          number_of_nodes++;

          /* rest_nodes = rest_nodes \ {node_2} */
          delVal (rest_nodes, node_2);
          node_used [node_2] = 1;
        }
      }
      clearIntList (tmp_rest_nodes);
    }
    /* Alle Knoten dieser Zusammenhangskomponente sind durchlaufen worden. */

    counter = 0;
    for (node_1 = 0; node_1 < breite; node_1 ++)
      if (node_used [node_1]) {
        addLast (actual_component->original_node_numbers, node_1 + 1);
        old_node_number [counter++] = node_1;
      }
    /* In old_node_number sind jetzt die Original-Knotennummern fuer die
       aktuelle Komponente gespeichert. */

#if 1
   	actual_component->teilRelation
   		= kure_rel_new_with_size_si(kure_rel_get_context(impl), number_of_nodes, number_of_nodes);
#else
    NUMBER_OF_NODES = Kure_mp_itom (number_of_nodes);
    actual_component->teilRelation =
      mk_rel (relData->name, NUMBER_OF_NODES, NUMBER_OF_NODES, NORMAL);
    Kure_mp_mfree (NUMBER_OF_NODES);
#endif

    for (node_1 = 0; node_1 < number_of_nodes; node_1 ++)
    	for (node_2 = 0; node_2 < number_of_nodes; node_2 ++) {
#if 1
    		if (kure_get_bit_fast_si (impl, old_node_number [node_1], old_node_number [node_2], vars_zeilen, vars_spalten))
    		{
    			kure_set_bit_si (actual_component->teilRelation, TRUE, node_1, node_2);

    			if (!resultat->original_edges)
    				resultat->original_edges =
    						make_edge ("", old_node_number [node_1] + 1,
    								old_node_number [node_2] + 1, NORMAL);
    			else
    				append_edge_to_edgelist
    				(make_edge ("", old_node_number [node_1] + 1,
    						old_node_number [node_2] + 1, NORMAL),
    						resultat->original_edges);
    		}
#else
    		if (get_rel_bit (relData, old_node_number [node_2],
    				old_node_number [node_1],
    				vars_zeilen, vars_spalten)) {
    			set_rel_bit
    			(& (actual_component->teilRelation->rel), node_2, node_1,
    					Kure_mp_mint2int ((& (actual_component->teilRelation->rel))->breite),
    					Kure_mp_mint2int ((& (actual_component->teilRelation->rel))->hoehe));
    			if (!resultat->original_edges)
    				resultat->original_edges =
    						make_edge ("", old_node_number [node_1] + 1,
    								old_node_number [node_2] + 1, NORMAL);
    			else
    				append_edge_to_edgelist
    				(make_edge ("", old_node_number [node_1] + 1,
    						old_node_number [node_2] + 1, NORMAL),
    						resultat->original_edges);
    		}
#endif
    	}
  }
  return (resultat);
}




/****************************************************************************/
/* NAME : print_componentlist                                               */
/* FUNKTION : Debug-Ausgabe einer Graph-Komponenten-Liste                   */
/* UEBERGABEPARAMETER : Zeiger auf eine Graph-Komponenten-Liste             */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

#if 0
void print_componentlist (komponentenlistptr kpl)
{
  komponentenptr kp;
  int            counter = 1;

  if (kpl) {
    puts ("Komponentenliste:");
    printf ("Anzahl Original Knoten: %d\n", kpl->number_of_original_nodes);
    if (kpl->original_edges) {
      puts ("\nKanten im Original-Graphen:");
      print_edgelist (kpl->original_edges);
    }
    kp = kpl->zusammenhangskomponenten;
    while (kp) {
      printf ("\n%d. Komponente:\n", counter++);
      print_component (kp);
      kp = kp->next;
    }
  }
}
#endif



/****************************************************************************/
/* NAME : print_component                                                   */
/* FUNKTION : Debug-Ausgabe einer Graph-Komponente                          */
/* UEBERGABEPARAMETER : Zeiger auf eine Graph-Komponente                    */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

#if 0
void print_component (komponentenptr kp)
{
  if (kp) {
    if (kp->teilRelation)
      if (& (kp->teilRelation->rel)) {
        puts ("\nTeil-Relation:");
        print_relation (& (kp->teilRelation->rel));
      }
    if (kp->original_node_numbers) {
      puts ("\nOriginal-Nummerierung der Knoten:");
      printIntList (kp->original_node_numbers);
      puts ("");
    }
  }
}
#endif




/****************************************************************************/
/* NAME : small_orthogonal_graph                                            */
/* FUNKTION : Berechnet eine orthogonale Einbettung fuer Graphen mit bis zu */
/*            vier Knoten                                                   */
/* UEBERGABEPARAMETER : Zeiger auf eine Zusammenhangskomponente; Gitter-    */
/*                      abstaende; Relationsname                            */
/* VORAUSSETZUNG: Graph hat hoechstens vier Knoten                          */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (10.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/* 15.05.2000 (Umstellung auf grosse Zahlen)                                */
/****************************************************************************/

graphlistptr small_orthogonal_graph (KureRel * impl, unsigned int grid_x,
                                     unsigned int grid_y, char * name)
{
  //Rel * relData = get_rel (rel, name);
	int breite = kure_rel_get_cols_si (impl);
  //int breite = Kure_mp_mint2int (relData->breite);
  int number_of_nodes = breite;
  int number_of_helpnodes = 0;
  graphlistptr graph;
  Graph * graphData;
  int node_1;
  int node_2 = 0;
  int node_3 = 0;
  int node_4 = 0;
  char number_name [64];
  int degrees [number_of_nodes];
  int number_of_degree_three = 0;
  int number_of_degree_two = 0;
  int number_of_degree_one = 0;
  int counter_1;
  int vars_zeilen = kure_rel_get_vars_rows (impl);
  int vars_spalten = kure_rel_get_vars_cols (impl);

  graph = mk_graph (name, NORMAL);
  graphData = get_graph (graph, name);

  for (node_1 = 0; node_1 < number_of_nodes; node_1 ++) {
    sprintf (number_name, "%d", node_1 + 1);
    append_node (graphData, make_node (number_name, grid_x, grid_y,
                                       DEFAULT_DIM, VISIBLE));
    degrees [node_1] = 0;
  }

  //vars_zeilen = Kure_mp_number_of_vars (relData->hoehe);
  //vars_spalten = Kure_mp_number_of_vars (relData->breite);

  for (node_1 = 1; node_1 <= number_of_nodes; node_1 ++)
    for (node_2 = 1; node_2 <= number_of_nodes; node_2 ++)
    	if (kure_get_bit_fast_si (impl, node_1-1, node_2-2, vars_zeilen, vars_spalten))
      //if (get_rel_bit (relData, node_2 - 1, node_1 - 1, vars_zeilen, vars_spalten))
        append_edge (graphData, make_edge ("", node_1, node_2, VISIBLE));

  for (node_1 = 0; node_1 < number_of_nodes - 1; node_1 ++)
    for (node_2 = node_1 + 1; node_2 < number_of_nodes; node_2 ++) {
    	if (kure_get_bit_fast_si (impl, node_2, node_1, vars_zeilen, vars_spalten)
    			|| kure_get_bit_fast_si (impl, node_1, node_2, vars_zeilen, vars_spalten)) {
      //if ((get_rel_bit (relData, node_1, node_2, vars_zeilen, vars_spalten)) ||
      //    (get_rel_bit (relData, node_2, node_1, vars_zeilen, vars_spalten))) {
        degrees [node_1] += 1;
        degrees [node_2] += 1;
      }
    }
  /* In degrees sind jetzt die Grade der Knoten gespeichert, wenn graph
     ungerichtet und ohne Schleifen waere. */

  switch (number_of_nodes) {
  case 1:
    /* Zusammenhangskomponente besteht nur aus einem Knoten. */
    break;

  case 2:
    /* Zusammenhangskomponente besteht aus zwei Knoten. */
    set_node_positions (graphData, 2, grid_x, 2 * grid_y);
    break;

  case 3:
    /* Zusammenhangskomponente besteht aus drei Knoten
       Erster Fall: Alle Knoten haben Grad 2. Dann muessen die Knoten in
       folgender Form angeordnet werden:
       o-+
       | |
       o-o */
    if ((degrees [0] == 2) && (degrees [1] == 2) && (degrees [2] == 2)) {
      set_node_positions (graphData, 2, grid_x, 2 * grid_y);
      set_node_positions (graphData, 3, 2 * grid_x, 2 * grid_y);
      sprintf (number_name, "%d", number_of_nodes + ++number_of_helpnodes);
      append_node (graphData, make_node (number_name, 2 * grid_x, grid_y,
                                         DEFAULT_DIM, HELP));
      if (test_if_edge_exist (graphData, 1, 3))
        append_edge_pathnode (get_edge (graphData, 1, 3), 4);
      if (test_if_edge_exist (graphData, 3, 1))
        append_edge_pathnode (get_edge (graphData, 3, 1), 4);
    } else {
      /* Zweiter Fall: Es existiert ein Blatt. Knotenanordnung:
         o
         |
         o
         |
         o */
      node_2 = -1;
      for (counter_1 = 0; counter_1 < 3; counter_1 ++) {
        if (degrees [counter_1] == 2)
          node_1 = counter_1 + 1;
        if (degrees [counter_1] == 1) {
          if (node_2 == -1) {
            node_2 = counter_1 + 1;
          }
          else {
            node_3 = counter_1 + 1;
          }
        }
      }

      set_node_positions (graphData, node_1, grid_x, 2 * grid_y);
      set_node_positions (graphData, node_3, grid_x, 3 * grid_y);
    }
    break;

  case 4:
    for (node_1 = 0; node_1 < 4; node_1 ++)
      if (degrees [node_1] == 1)
        number_of_degree_one ++;
      else if (degrees [node_1] == 2)
        number_of_degree_two++;
      else
        number_of_degree_three ++;

    /* Der Zusammenhangskomponente besteht aus vier Knoten.
       Erster Fall: Alle Knoten habe den Grad drei. Dann muessen die
       Knoten folgendermassen angeordnet werden:
       +-o-+
       | | |
       | o-o
       | | |
       +-o-+ */
    if (number_of_degree_three == 4) {
      set_node_positions (graphData, 1, 2 * grid_x, grid_y);
      set_node_positions (graphData, 2, 2 * grid_x, 2 * grid_y);
      set_node_positions (graphData, 3, 2 * grid_x, 3 * grid_y);
      set_node_positions (graphData, 4, 3 * grid_x, 2 * grid_y);
      sprintf (number_name, "%d", number_of_nodes + number_of_helpnodes++ + 1);
      append_node (graphData, make_node (number_name, grid_x, grid_y,
                                         DEFAULT_DIM, HELP));
      sprintf (number_name, "%d", number_of_nodes + number_of_helpnodes++ + 1);
      append_node (graphData, make_node (number_name, grid_x, 3 * grid_y,
                                         DEFAULT_DIM, HELP));
      sprintf (number_name, "%d", number_of_nodes + number_of_helpnodes++ + 1);
      append_node (graphData, make_node (number_name, 3 * grid_x, grid_y,
                                         DEFAULT_DIM, HELP));
      sprintf (number_name, "%d", number_of_nodes + number_of_helpnodes++ + 1);
      append_node (graphData, make_node (number_name, 3 * grid_x, 3 * grid_y,
                                         DEFAULT_DIM, HELP));
      if (test_if_edge_exist (graphData, 1, 3)) {
        append_edge_pathnode (get_edge (graphData, 1, 3), 5);
        append_edge_pathnode (get_edge (graphData, 1, 3), 6);
      }
      if (test_if_edge_exist (graphData, 3, 1)) {
        append_edge_pathnode (get_edge (graphData, 3, 1), 6);
        append_edge_pathnode (get_edge (graphData, 3, 1), 5);
      }
      if (test_if_edge_exist (graphData, 1, 4))
        append_edge_pathnode (get_edge (graphData, 1, 4), 7);
      if (test_if_edge_exist (graphData, 4, 1))
        append_edge_pathnode (get_edge (graphData, 4, 1), 7);
      if (test_if_edge_exist (graphData, 3, 4))
        append_edge_pathnode (get_edge (graphData, 3, 4), 8);
      if (test_if_edge_exist (graphData, 4, 3))
        append_edge_pathnode (get_edge (graphData, 4, 3), 8);
    }

    /* Zweiter Fall: Es existieren zwei Knoten vom Grad drei.
       o-+
       | |
       o-o
       | |
       o-+ */
    if (number_of_degree_three == 2) {
      sprintf (number_name, "%d", number_of_nodes + number_of_helpnodes++ + 1);
      append_node (graphData, make_node (number_name, 2 * grid_x, grid_y,
                                         DEFAULT_DIM, HELP));
      sprintf (number_name, "%d", number_of_nodes + number_of_helpnodes++ + 1);
      append_node (graphData, make_node (number_name, 2 *grid_x, 3 * grid_y,
                                         DEFAULT_DIM, HELP));
      node_1 = -1;
      node_3 = -1;
      for (counter_1 = 0; counter_1 < 4; counter_1 ++) {
        if (degrees [counter_1] == 3) {
          if (node_1 == -1) {
            node_1 = counter_1 + 1;
          }
          else {
            node_2 = counter_1 + 1;
          }
        }
        if (degrees [counter_1] == 2) {
          if (node_3 == -1) {
            node_3 = counter_1 + 1;
          }
          else {
            node_4 = counter_1 + 1;
          }
        }
      }

      set_node_positions (graphData, node_1, grid_x, 2 * grid_y);
      set_node_positions (graphData, node_2, 2 * grid_x, 2 * grid_y);
      set_node_positions (graphData, node_3, grid_x, grid_y);
      set_node_positions (graphData, node_4, grid_x, 3 * grid_y);
      if (test_if_edge_exist (graphData, node_2, node_3))
        append_edge_pathnode (get_edge (graphData, node_2, node_3), 5);
      if (test_if_edge_exist (graphData, node_3, node_2))
        append_edge_pathnode (get_edge (graphData, node_3, node_2), 5);
      if (test_if_edge_exist (graphData, node_2, node_4))
        append_edge_pathnode (get_edge (graphData, node_2, node_4), 6);
      if (test_if_edge_exist (graphData, node_4, node_2))
        append_edge_pathnode (get_edge (graphData, node_4, node_2), 6);
    }

    /* Dritter Fall: Ein Knoten mit Grad 3, zwei Knoten mit Grad 2.
       o-+
       | |
       o-o
       |
       o */
    if ((number_of_degree_three == 1) && (number_of_degree_two == 2)) {
      sprintf (number_name, "%d", number_of_nodes + number_of_helpnodes++ + 1);
      append_node (graphData, make_node (number_name, 2 * grid_x, grid_y,
                                         DEFAULT_DIM, HELP));
      node_2 = -1;
      for (counter_1 = 0; counter_1 < 4; counter_1 ++) {
        if (degrees [counter_1] == 3)
          node_1 = counter_1 + 1;
        if (degrees [counter_1] == 2) {
          if (node_2 == -1) {
            node_2 = counter_1 + 1;
          }
          else {
            node_3 = counter_1 + 1;
          }
        }
        if (degrees [counter_1] == 1)
          node_4 = counter_1 + 1;
      }

      set_node_positions (graphData, node_1, grid_x, 2 * grid_y);
      set_node_positions (graphData, node_4, grid_x, 3 * grid_y);
      set_node_positions (graphData, node_2, grid_x, grid_y);
      set_node_positions (graphData, node_3, 2 * grid_x, 2 * grid_y);
      if (test_if_edge_exist (graphData, node_2, node_3))
        append_edge_pathnode (get_edge (graphData, node_2, node_3), 5);
      if (test_if_edge_exist (graphData, node_3, node_2))
        append_edge_pathnode (get_edge (graphData, node_3, node_2), 5);
    }

    /* Vierter Fall: Ein Knoten hat Grad 3, alle anderen Grad 1.
       o
       |
       o-o
       |
       o */
    if ((number_of_degree_three == 1) && (number_of_degree_two == 0)) {
      node_2 = -1;
      node_3 = -1;
      for (counter_1 = 0; counter_1 < 4; counter_1 ++) {
        if (degrees [counter_1] == 3)
          node_1 = counter_1 + 1;
        if (degrees [counter_1] == 1) {
          if (node_2 == -1) {
            node_2 = counter_1 + 1;
          }
          else {
            if (node_3 == -1) {
              node_3 = counter_1 + 1;
            }
            else {
              node_4 = counter_1 + 1;
            }
          }
        }
      }

      set_node_positions (graphData, node_1, grid_x, 2 * grid_y);
      set_node_positions (graphData, node_2, grid_x, grid_y);
      set_node_positions (graphData, node_3, 2 * grid_x, 2 * grid_y);
      set_node_positions (graphData, node_4, grid_x, 3 * grid_y);
    }

    /* Fuenfter Fall: Alle Knoten haben Grad 2.
       o-o
       | |
       o-o */
    if (number_of_degree_two == 4) {
      set_node_positions (graphData, 1, grid_x, grid_y);
      if ((test_if_edge_exist (graphData, 1, 2)) ||
          (test_if_edge_exist (graphData, 2, 1))) {
        set_node_positions (graphData, 2, 2 * grid_x, grid_y);
        if ((test_if_edge_exist (graphData, 1, 3)) ||
            (test_if_edge_exist (graphData, 3, 1))) {
          set_node_positions (graphData, 3, grid_x, 2 * grid_y);
          set_node_positions (graphData, 4, 2 * grid_x, 2 * grid_y);
        }
        else {
          set_node_positions (graphData, 4, grid_x, 2 * grid_y);
          set_node_positions (graphData, 3, 2 * grid_x, 2 * grid_y);
        }
      }
      else {
        set_node_positions (graphData, 2, 2 * grid_x, 2 * grid_y);
        set_node_positions (graphData, 3, 2 * grid_x, grid_y);
        set_node_positions (graphData, 4, grid_x, 2 * grid_y);
      }
    }

    /* Sechster Fall: Je zwei Knoten mit Grad zwei und eins.
       o
       |
       o
       |
       o
       |
       o */
    if ((number_of_degree_two == 2) && (number_of_degree_one == 2)) {
      node_1 = -1;
      node_3 = -1;
      for (counter_1 = 0; counter_1 < 4; counter_1 ++) {
        if (degrees [counter_1] == 2) {
          if (node_1 == -1) {
            node_1 = counter_1 + 1;
          } else {
            node_2 = counter_1 + 1;
          }
        }
        if (degrees [counter_1] == 1) {
          if (node_3 == -1) {
            node_3 = counter_1 + 1;
          } else {
            node_4 = counter_1 + 1;
          }
        }
      }

      set_node_positions (graphData, node_3, grid_x, grid_y);
      set_node_positions (graphData, node_4, grid_x, 4 * grid_y);
      if ((test_if_edge_exist (graphData, node_3, node_1)) ||
          (test_if_edge_exist (graphData, node_1, node_3))) {
        set_node_positions (graphData, node_1, grid_x, 2 * grid_y);
        set_node_positions (graphData, node_2, grid_x, 3 * grid_y);
      } else {
        set_node_positions (graphData, node_2, grid_x, 2 * grid_y);
        set_node_positions (graphData, node_1, grid_x, 3 * grid_y);
      }
    }
  }
  return (graph);
}


/****************************************************************************/
/* NAME : MergeGraphsFromComponents                                         */
/* FUNKTION : Zusammenfuegen der Zusammenghangskomponenten eines Graphen    */
/* UEBERGABEPARAMETER : Relation und Komponentenliste                       */
/* VORAUSSETZUNG : Die Komponentenliste wurde aus der Relation erzeugt      */
/*                 (wird nicht geprueft); In jeder Komponente ist ein       */
/*                 erzeugter Graph vorhanden (wird nicht geprueft)          */
/* RUECKGABEWERT : Zeiger auf eine Liste von Graphen                        */
/* ERSTELLT VON : Ulf Milanese (11.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/
graphlistptr MergeGraphsFromComponents (KureRel * impl, komponentenlistptr klp)
{
	graphlistptr resultat;
	Graph * graphData;
	graphlistptr tmp_graph;
	Graph * tmp_graphData = NULL;
	//rellistptr tmp_rel;
	//Rel * tmp_relData = NULL;
	edgelistptr edge_list;
	Edge * new_edge_listData;
	nodelistptr tmp_node_list;
	edgelistptr tmp_edge_list;
	intlistptr path;
	unsigned int offset_x = 0;
	int maximum_x = 0;
	komponentenptr actual_component;
	int number_of_original_nodes;
	unsigned int new_node_number;
	int number_of_nodes_in_component;
	int highest_node_number;
	int node_1;
	int node_2;
	int pos_x;
	int pos_y;
	char number_name [64];
	p_intList original_node_numbers;

	if (!klp)
		return ((graphlistptr) NULL);

	edge_list = klp->original_edges;
	number_of_original_nodes = klp->number_of_original_nodes;
	resultat = mk_graph (UNKNOWN_GRAPH_NAME, NORMAL);
	graphData = get_graph (resultat, UNKNOWN_GRAPH_NAME);

	for (node_1 = 0; node_1 < number_of_original_nodes; node_1 ++) {
		sprintf (number_name, "%d", node_1 + 1);
		append_node	(graphData, make_node (number_name, 1, 1, DEFAULT_DIM, VISIBLE));
	}
	new_node_number = number_of_original_nodes + 1;

	if (edge_list)
		append_edge (graphData, copy_edgelist (edge_list));

	actual_component = klp->zusammenhangskomponenten;
	while (actual_component) {
		KureRel * tmp_rel = actual_component->teilRelation;
		tmp_graph = actual_component->teilGraph;
		number_of_nodes_in_component = 0;
		highest_node_number = 0;
		if (tmp_graph) {
			tmp_graphData = get_graph (tmp_graph, UNKNOWN_GRAPH_NAME);
			assert (tmp_graphData != NULL);
			tmp_node_list = tmp_graphData->node_root;
			while (tmp_node_list) {
				if (highest_node_number < tmp_node_list->node.number)
					highest_node_number = tmp_node_list->node.number;
				number_of_nodes_in_component++;
				tmp_node_list = tmp_node_list->next;
			}
		}

		if (tmp_rel && tmp_graphData) {
			int old_node_number [highest_node_number + 1];

			original_node_numbers = copyIntList (actual_component->original_node_numbers);
			tmp_node_list = tmp_graphData->node_root;

			/* Die Original-Nummern der sichtbaren Knoten werden bestimmt.
         Voraussetzung: Die sichtbaren Knoten stehen in der Knotenliste
         des Teilgraphen vor den Hilfsknoten! */
			while (original_node_numbers->first) {
				node_1 = popFirst (original_node_numbers);
				old_node_number [tmp_node_list->node.number] = node_1;
				tmp_node_list = tmp_node_list->next;
			}
			clearIntList (original_node_numbers);
			number_of_original_nodes = kure_rel_get_cols_si (tmp_rel);
			// ... = Kure_mp_mint2int (tmp_relData->breite);

			/* Die zusaetzlichen Hilfsknoten werden eingefuegt. */
			while (tmp_node_list) {
				sprintf (number_name, "%d", new_node_number);
				append_node (graphData, make_node (number_name, 1, 1, DEFAULT_DIM, HELP));
				old_node_number [tmp_node_list->node.number] = new_node_number++;
				tmp_node_list = tmp_node_list->next;
			}

			/* In old_node_number sind jetzt die Original-Knotennummern fuer die
         aktuelle Komponente gespeichert. */

			/* Positionierung der Knoten. */
			tmp_node_list = tmp_graphData->node_root;
			while (tmp_node_list) {
				node_1 = tmp_node_list->node.number;
				pos_x = get_node_xpos (tmp_graphData, node_1) + offset_x;
				pos_y = get_node_ypos (tmp_graphData, node_1);
				if (maximum_x < pos_x)
					maximum_x = pos_x;
				set_node_positions (graphData, old_node_number [node_1], pos_x, pos_y);
				tmp_node_list = tmp_node_list->next;
			}

			/* Setzen der edge_path_nodes. */
			tmp_edge_list = tmp_graphData->edge_root;
			while (tmp_edge_list) {
				node_1 = tmp_edge_list->edge.from;
				node_2 = tmp_edge_list->edge.to;
				path = tmp_edge_list->edge.path;
				new_edge_listData = get_edge (graphData, old_node_number [node_1],
											  old_node_number [node_2]);
				while (path) {
					append_edge_pathnode (new_edge_listData, old_node_number [path->number]);
					path = path->next;
				}
				tmp_edge_list = tmp_edge_list->next;
			}
		}
		offset_x = maximum_x;
		actual_component = actual_component->next;
	}
	return (resultat);
}




/****************************************************************************/
/* NAME : graph_orthogonal                                                  */
/* FUNKTION : Zeichnet einen Graphen orthogonal                             */
/* UEBERGABEPARAMETER : Zeiger auf eine Relation                            */
/* VORAUSSETZUNG : Relation laesst sich orthogonal darstellen (wird nicht   */
/*                 geprueft)                                                */
/* RUECKGABEWERT : Zeiger auf eine Liste von Graphen                        */
/* ERSTELLT VON : Ulf Milanese (02.03.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/* 15.05.2000 (Umstellung auf grosse Zahlen)                                */
/****************************************************************************/

graphlistptr graph_orthogonal (KureRel * impl)
{
	graphlistptr       resultat;
	komponentenlistptr klp;
	komponentenptr     kp;
	//Rel *              copyOfRel;
	unsigned int       gridx = 48;
	unsigned int       gridy = 48;
	//rellistptr         planarRelation;
	//Rel *              planarRelData;
	p_adjList          planarEmbedding;
	visibilityrepptr   visibilityRepresentation;
	orthogonalrepptr   orthogonalRepresentation;

	klp = splitRelationIntoComponents (impl);
	if (klp) {

		kp = klp->zusammenhangskomponenten;
		while (kp) {
			KureRel * copy = kp->teilRelation;
			//copyOfRel = get_rel (kp->teilRelation, rel->name);

			if (kure_rel_get_cols_si (copy) <= 4) {
				//if (Kure_mp_mint2int (copyOfRel->breite) <= 4) {
				/* Zeichenalgorithmus per Hand aufrufen */
				kp->teilGraph = small_orthogonal_graph (kp->teilRelation, gridx, gridy, UNKNOWN_GRAPH_NAME);
			}

			else {
				KureRel * planar = planar_subrelation (copy);
				//planarRelation = planar_subrelation (copyOfRel);
				//planarRelData = get_rel (planarRelation, rel->name);

				/* Hier folgt der Algorithmus von Sascha Ulbrand zum planaren
				 *  Testen und Berechnen der Einbettung */
				isPlanar (planar, 1);
				computeEmbedding ();
				stripEmbedding (copy);
				planarEmbedding = getEmbeddingInOrigNumbering ();
				/* Ende des Algorithmuses von Sascha Ulbrand */

				visibilityRepresentation = visibility_representation (planarEmbedding);

				orthogonalRepresentation = orthogonal_embedding (visibilityRepresentation, planarEmbedding);
				del_visibility_representation (visibilityRepresentation);

				transform_orthogonal_representation (orthogonalRepresentation);
				insert_nonplanar_edges_into_orthogonal (orthogonalRepresentation, planarEmbedding, copy);
				delAdjList (planarEmbedding);
				kp->teilGraph =	graph_create_orthogonal (orthogonalRepresentation, gridx, gridy, UNKNOWN_GRAPH_NAME);
				del_orthogonal_representation (orthogonalRepresentation);
			}
			kp = kp->next;
		}
	}
	resultat = MergeGraphsFromComponents (impl, klp);
	delKomponentenListe (klp);
	return (resultat);
}
