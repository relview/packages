#include <stdlib.h>
#include <stdio.h>

#include "global-sme.h"
#include "zerlegen.h"

/* modulglobale Variablen */

static int *vater;
static int *Menge;



/*****************************************************************************/
/* NAME: zerlegen_spring                                                     */
/* FUNKTION: zerlegt den Graphen in seine Zusammenhangskomponenten           */
/* UEBERGABEPARAMETER: n Knotenzahl, Kantenzahl, edges Kantenliste,          */
/*                     Komponentenptr array der Teilgraphen,                 */
/*                     countptr Anzahl der Zusammenhangskomponenten          */
/* RUECKGABEWERT: KEINER                                                     */
/* ERSTELLT VON: Stefan Meier                                                */
/* AM: 06-JUN-1995                                                           */
/* LETZTE AENDERUNG AM : 10-JUL-1995                                         */
/*****************************************************************************/
void zerlegen_spring (int n, int Kantenzahl, S_EDGE * edges,
                      S_GRAPH ** Komponentenptr, int * countptr)
{
  int i;
  int v;
  int Komp_1;
  int Komp_2;
  int count;
  int komp;
  int * temp;
  S_GRAPH * Komponenten;
  int * surj;
  int ** inj;
  int * akt;
  int * edge_count;
  int * node_count;

  vater = (int *) calloc (n, sizeof (int));
  Menge = (int *) calloc (n, sizeof (int));
  temp = (int *) calloc (n, sizeof (int));
  if ((!vater) || (!Menge) || (!temp)) {
    printf("Fehler zerlegen (Zeile 46)\n");
    exit (0);
  }
  for (i = 0; i < n; i ++) {
    vater [i] = -1;
    Menge [i] = TRUE;
  }
  for (i=0;i<Kantenzahl;i++)
    {
    Komp_1 = Finde(edges[i].tail);
    Komp_2 = Finde(edges[i].head);
    if (Komp_1 != Komp_2)
      Vereinige(Komp_1, Komp_2);
    }
  count = 0;
  for (i=0;i<n;i++)
    if (Menge[i] == TRUE)
      temp[i] = count++;

  edge_count = (int *) calloc(count,sizeof(int));
  node_count = (int *) calloc(count,sizeof(int));
  if (edge_count == (int *) NULL || node_count == (int *) NULL)
    {
    printf("Fehler zerlegen (Zeile 69) \n");
    exit(0);
    }

  for (i=0;i<n;i++)
    {
    v = Finde(i);
    Menge[i] = temp[v];
    node_count[temp[v]]++;
    }
  free(temp);

  for (i=0;i<Kantenzahl;i++)
    edge_count[Menge[edges[i].tail]]++;
  Komponenten = (S_GRAPH *) calloc(count,sizeof(S_GRAPH));
  inj = (int **) calloc(count,sizeof(int *));
  surj = (int *) calloc(n,sizeof(int));
  akt = (int *) calloc(count,sizeof(int));
  if (Komponenten == (S_GRAPH *) NULL || inj == (int **) NULL 
       || surj == (int *) NULL || akt == (int *) NULL)
    {
    printf("Fehler zerlegen (Zeile 90)\n");
    exit(0);
    }

  for (i=0;i<count;i++)
    {
    inj[i] = (int *) calloc(node_count[i],sizeof(int));
    Komponenten[i].edges = (S_EDGE *) calloc(edge_count[i],sizeof(S_EDGE));
    if (inj[i] == (int *) NULL || Komponenten[i].edges == (S_EDGE *) NULL)
      {
      printf("Fehler zerlegen (Zeile 100)\n");
      exit(0);
      }
    }
  for (i=0;i<n;i++)
    {
    inj[Menge[i]][akt[Menge[i]]] = i;
    surj[i] = akt[Menge[i]]++;
    }
  for (i=0;i<count;i++)
    akt[i] = 0;
  for (i=0;i<Kantenzahl;i++)
    {
    komp = Menge[edges[i].head];
    Komponenten[komp].edges[akt[komp]].tail = surj[edges[i].tail];
    Komponenten[komp].edges[akt[komp]].head = surj[edges[i].head];
    Komponenten[komp].edges[akt[komp]++].back_and_forth = 
                                              edges[i].back_and_forth;
    }
  for (i=0;i<count;i++)
    {
    Komponenten[i].node_count = node_count[i];
    Komponenten[i].edge_count = edge_count[i];
    Komponenten[i].inj = inj[i];
    }

  *countptr = count;
  *Komponentenptr = Komponenten;
  free(surj);
  free(akt);
  free(vater);
  free(Menge);
  free(edge_count);
  free(node_count);
  free(inj);
}

/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* */
/* NAME : zerlegen_dag */
/* FUNKTION : zerlegt den Graphen in seine Zus.-komponenten */
/* UEBERGABEPARAMETER : n Knotenzahl, Kantenzahl, edges Kantenliste */
/*                      Komponentenptr array der Teilgraphen, countptr Anzahl der */
/*                      Zsh.-komp. */
/* RUECKGABEWERT :  */
/* ERSTELLT VON : Stefan Meier */
/* AM : 6.6.95 */
/* LETZTE AENDERUNG AM : 10.7.95 */
/* */
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

void zerlegen_dag(int n, int Kantenzahl, EDGE *edges, GRAPH **Komponentenptr, 
              int *countptr)
{
  int i, v, Komp_1, Komp_2, count, komp;
  int *temp;
  GRAPH *Komponenten;
  int *surj, **inj, *akt;
  int *edge_count, *node_count;

  vater = (int *) calloc(n, sizeof(int));
  Menge = (int *) calloc(n, sizeof(int));
  temp = (int *) calloc(n, sizeof(int));
  if (vater == (int *) NULL || Menge == (int *) NULL || temp == (int *) NULL)
    {
    printf("Fehler zerlegen (Zeile 165)\n");
    exit(0);
    }
  for (i=0;i<n;i++)
    {
    vater[i] = -1;
    Menge[i] = TRUE;
    }
  for (i=0;i<Kantenzahl;i++)
    {
    Komp_1 = Finde(edges[i].tail);
    Komp_2 = Finde(edges[i].head);
    if (Komp_1 != Komp_2)
      Vereinige(Komp_1, Komp_2);
    }
  count = 0;
  for (i=0;i<n;i++)
    if (Menge[i] == TRUE)
      temp[i] = count++;

  edge_count = (int *) calloc(count,sizeof(int));
  node_count = (int *) calloc(count,sizeof(int));
  if (edge_count == (int *) NULL || node_count == (int *) NULL)
    {
    printf("Fehler zerlegen (Zeile 189)\n");
    exit(0);
    }

  for (i=0;i<n;i++)
    {
    v = Finde(i);
    Menge[i] = temp[v];
    node_count[temp[v]]++;
    }
  free(temp);

  for (i=0;i<Kantenzahl;i++)
    edge_count[Menge[edges[i].tail]]++;
  Komponenten = (GRAPH *) calloc(count,sizeof(GRAPH));
  inj = (int **) calloc(count,sizeof(int *));
  surj = (int *) calloc(n,sizeof(int));
  akt = (int *) calloc(count,sizeof(int));
  if (Komponenten == (GRAPH *) NULL || inj == (int **) NULL 
       || surj == (int *) NULL || akt == (int *) NULL)
    {
    printf("Fehler zerlegen (Zeile 210)\n");
    exit(0);
    }

  for (i=0;i<count;i++)
    {
    inj[i] = (int *) calloc(node_count[i],sizeof(int));
    Komponenten[i].edges = (EDGE *) calloc(edge_count[i],sizeof(EDGE));
    if (inj[i] == (int *) NULL || Komponenten[i].edges == (EDGE *) NULL)
      {
      printf("Fehler zerlegen (Zeile 220)\n");
      exit(0);
      }
    }
  for (i=0;i<n;i++)
    {
    inj[Menge[i]][akt[Menge[i]]] = i;
    surj[i] = akt[Menge[i]]++;
    }
  for (i=0;i<count;i++)
    akt[i] = 0;
  for (i=0;i<Kantenzahl;i++)
    {
    komp = Menge[edges[i].head];
    Komponenten[komp].edges[akt[komp]].tail = surj[edges[i].tail];
    Komponenten[komp].edges[akt[komp]].head = surj[edges[i].head];
    Komponenten[komp].edges[akt[komp]++].back_and_forth = 
                                              edges[i].back_and_forth;
    }
  for (i=0;i<count;i++)
    {
    Komponenten[i].node_count = node_count[i];
    Komponenten[i].edge_count = edge_count[i];
    Komponenten[i].inj = inj[i];
    }

  *countptr = count;
  *Komponentenptr = Komponenten;
  free(surj);
  free(akt);
  free(vater);
  free(Menge);
  free(edge_count);
  free(node_count);
  free(inj);
}

  
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* */
/* NAME : Vereinige */
/* FUNKTION : 2 Mengen, als Baum dargestellt, bekommen den gleichen Vater */
/*            zugewiesen, werden somit vereinigt  */
/* UEBERGABEPARAMETER : i, j Wurzeln der beiden Baeume */
/* RUECKGABEWERT : */
/* ERSTELLT VON : Stefan Meier */
/* AM : 6.6.95 */
/* LETZTE AENDERUNG AM : 6.6.95 */
/* */
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

void Vereinige(int i, int j)
{
  int m;

  m = vater[i] + vater[j];  /* der Vater der Wurzel gibt die negative */
  if (vater[i] < vater[j])  /* Maechtigkeit der Menge an */
    {
    vater[i] = j;
    vater[j] = m;
    Menge[i] = FALSE;
    }
  else
    {
    vater[j] = i;
    vater[i] = m;
    Menge[j] = FALSE;
    }
}

 
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* */
/* NAME : Finde */
/* FUNKTION : findet zu einem Knoten die Wurzel des Baumes in dem */
/*            der Knoten liegt */
/* UEBERGABEPARAMETER : i Knoten */
/* RUECKGABEWERT : Wurzel des Baumes und somit Name der Menge */
/* ERSTELLT VON : Stefan Meier */
/* AM : 6.6.95 */
/* LETZTE AENDERUNG AM : 6.6.95 */
/* */
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

int Finde(int i)
{
  int j, v, k;

  j = i;
  while (vater[j] >= 0)
    j = vater[j];
  k = i;
  while (k != j)
    {
    v = vater[k];
    vater[k] = j;
    k = v;
    }
  return j;
}


/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* */
/* NAME : */
/* FUNKTION : */
/* UEBERGABEPARAMETER : */
/* RUECKGABEWERT : */
/* ERSTELLT VON : Stefan Meier */
/* AM : .95 */
/* LETZTE AENDERUNG AM : .95 */
/* */
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

