/*
 * main.c
 *
 *  Copyright (C) 2010 Stefan Bolus, University of Kiel, Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "relview/plugin.h"

/*!
 * TODO: Currently, for each menu entry a separate test is executed, even if
 *       the result of a previous test for a previous menu entry could be
 *       used. This can create problems for for larger graphs.
 */

#include "createdrawing.h" // Planar graphs.
#include "orthogonal.h" // Orthogonal graphs.
/* spring_schnell.h and spring_langsam.h cannot be used at the same time due to
 * overlapping declarations. */
//#include "spring_schnell.h"
//#include "spring_langsam.h"
graphlistptr spring_schnell (KureRel *, int, int);
graphlistptr spring_langsam (KureRel *, int, int);

#include "baum.h" // Layer (function DAG), Forest (function Tree)

/* Some drawing routines like spring_schnell and spring_langsam depend on
 * the dimensions of the graph window. */
typedef graphelem * (*draw_graph_func_t) (KureRel*, GraphWindow*);

/*!
 * Some graph drawing algorithms can be applied to any non-empty graph and thus
 * always return TRUE.
 */
static gboolean _always_enabled (gpointer user_data, MenuEntry * entry, gpointer obj) {
	return TRUE;
}


static gboolean _is_forest_enabled (gpointer user_data, MenuEntry * entry, gpointer obj)
{
	GraphWindow * gw = (GraphWindow*) obj;
	XGraph * gr = graph_window_get_graph(gw);
	KureContext * context = rv_get_context(rv_get_instance());
	Rel * rel = rel_new_from_xgraph (context, (XGraph*) gr);
	if (rel) {
		gboolean ret = false;
		KureRel * impl = rel_get_impl(rel);
		if ( !kure_is_empty(impl, NULL)) {
			KureRel * is_forest = NULL;
			KureError * err = NULL;
			lua_State * L = kure_lua_new (context);
			const char * code = "incl(R*R^,I(R)) & incl(trans(R), -I(R))";
			kure_lua_set_rel_copy (L, "R", impl);
			is_forest = kure_lang_exec (L, code, &err);
			if ( !is_forest) {
				g_warning ("graph-drawing: Unable to execute '%s'. Exiting. Reason: %s\n", code, err->message);
				kure_error_destroy (err);
			}
			else {
				ret = !kure_is_empty (is_forest, NULL);
				kure_rel_destroy(is_forest);
			}

			kure_lua_destroy (L);
		}
		rel_destroy(rel);
		return ret;
	}
	else return FALSE;
}


static gboolean _is_planar_enabled (gpointer user_data, MenuEntry * entry, gpointer obj)
{
	GraphWindow * gw = (GraphWindow*) obj;
	XGraph * gr = graph_window_get_graph(gw);
	KureContext * context = rv_get_context(rv_get_instance());
	Rel * rel = rel_new_from_xgraph (context, (XGraph*) gr);
	if (rel) {
		gboolean ret = false;
		KureRel * impl = rel_get_impl(rel);
		if ( !kure_is_empty(impl, NULL)) {
			ret = isPlanar (impl, 0);
		}
		rel_destroy (rel);
		return ret;
	}
	else return FALSE;
}

static gboolean _is_orthogonal_enabled (gpointer user_data, MenuEntry * entry, gpointer obj)
{
	GraphWindow * gw = (GraphWindow*) obj;
	XGraph * gr = graph_window_get_graph(gw);
	KureContext * context = rv_get_context(rv_get_instance());
	Rel * rel = rel_new_from_xgraph (context, (XGraph*) gr);
	if (rel) {
		gboolean ret = false;
		KureRel * impl = rel_get_impl(rel);
		if ( !kure_is_empty(impl, NULL)) {
			ret = rel_orthogonal(impl);
		}
		rel_destroy(rel);
		return ret;
	}
	else return FALSE;
}


/*
 * Simple List with XGraphEdgepath, only needed for the Next Funktion.
 */
struct XGraphEdgePath_List {
    XGraphEdgePath * xpath;
    struct XGraphEdgePath_List *next;
};

// Returns an XPath to given nodes if exists, otherwise NULL
XGraphEdgePath * lookupXpath(gint from, gint to, const struct XGraphEdgePath_List *e) {
    for( ; e != NULL ; e = e->next )  {
        XGraphEdgePath * xpath = e->xpath;

        if(from == xgraph_edge_path_get_from(xpath) && to == xgraph_edge_path_get_to(xpath))
        	return xpath;
    }
    return NULL;
}

// Add a new Element to a given List
void insertXpath(struct XGraphEdgePath_List **lst, XGraphEdgePath * xpath) {
    struct XGraphEdgePath_List *newEdgepath;

    while( *lst != NULL ) {
        lst = &(*lst)->next;
    }

    newEdgepath = malloc(sizeof(*newEdgepath));
    newEdgepath->xpath = xpath;
    newEdgepath->next = NULL;
    *lst = newEdgepath;
}

// Concats to EdgePath Lists
void appendXpaths(struct XGraphEdgePath_List **lst1, struct XGraphEdgePath_List **lst2) {
    while( *lst1 != NULL ) {
        lst1 = &(*lst1)->next;
    }
		*lst1 = *lst2;
}

// Removes A list to avoid memoryleaks
void clearXpaths(struct XGraphEdgePath_List **lst) {
    while( *lst != NULL ) {
    	struct XGraphEdgePath_List * t = *lst;
        lst = &(*lst)->next;
        free(t);
    }
}


// Simple IntList, needed for Visited Nodes in the next function
struct element {
    gint value;
    struct element *next;
};

// Looks for an Element in a given List, returs Boolean
gboolean lookupElement(gint value, const struct element *e) {
    for( ; e != NULL ; e = e->next )  {
        if(e->value == value)
            return TRUE;
    }

    return FALSE;
}

// Add a new Element
void insertElement(struct element **lst, gint value) {
    struct element *newElement;

    while( *lst != NULL ) {
        lst = &(*lst)->next;
    }

    newElement = malloc(sizeof(*newElement));
    newElement->value = value;
    newElement->next = NULL;
    *lst = newElement;
}

// Removes A list to avoid memoryleaks
void clearElements(struct element **lst) {
    while( *lst != NULL ) {
    	struct element * t = *lst;
        lst = &(*lst)->next;
        free(t);
    }
}

/*
 *	Helperfunction for all _collect_all_xpaths
 *  Collects alle Edgepath for a given Node
 */
struct XGraphEdgePath_List * _get_all_xpaths_to_node (struct element ** visitedNodes, gint startNode, graphelem * gl, gint orgNodeCount) {

	// Node already visted, then we don't need to go further
    if(lookupElement(startNode, *visitedNodes))
    	return NULL;

    // Final Node found, add the Finalnode to the EdgePath an return it
    if(startNode <= orgNodeCount){
		XGraphEdgePath * xpath = NULL;
		xpath = xgraph_edge_path_new();

		xgraph_edge_path_set_to(xpath,startNode);

		// return List with Xpaths
		struct XGraphEdgePath_List * xpathList = NULL;
		insertXpath(&xpathList,xpath);

		return xpathList;
  	}

    // new Node visted
    insertElement(visitedNodes,startNode);

    // Prepare the Structure
    edgeelem * edge_iter = NULL;
	Graph * lgr = &gl->graph;
    struct XGraphEdgePath_List * xpathsList = NULL;

    // Walk through all Edges
    for (edge_iter = lgr->edge_root ; edge_iter ; edge_iter = edge_iter->next) {
			Edge * edge = &edge_iter->edge;

			// Current Edges
			int from = atoi(get_node (lgr, edge->from)->name);
			int to   = atoi(get_node (lgr, edge->to)->name);

			// Edge is not matching
			if(startNode != from)
				continue;

			// Get all Xpaths
			struct XGraphEdgePath_List * xpathListNew = _get_all_xpaths_to_node(visitedNodes, to, gl, orgNodeCount);

			// Prepare ReturnList with new Paths
			if(!xpathsList)
				xpathsList = xpathListNew;
			else {
				if (xpathListNew != NULL)
					appendXpaths(&xpathsList, &xpathListNew);
			}
	}

	// Add the current LayoutPoint to all matching Paths
	struct XGraphEdgePath_List * xpathsList2 = xpathsList;
	for( ; xpathsList != NULL ; xpathsList = xpathsList->next )  {
		XGraphEdgePath * xpath = xpathsList->xpath;
		GQueue/*<LayoutPoint*>*/ * pts = xgraph_edge_path_get_points (xpath);

		// Fetch the node to get the coordinates
		Node * helper = get_node(lgr, startNode);

		if (helper) {
			// Attach coordinates to EdgePath Layout
			LayoutPoint * pt = g_new0 (LayoutPoint, 1);
			pt->x = (gfloat) helper->x_pos;
			pt->y = (gfloat) helper->y_pos;
			g_queue_push_head(pts, (gpointer)pt);
		}
	}

	return xpathsList2;
}

/*
 * Calculates all Edgepathes to a given Graph.
 * Uses Depthsearch an writes the History backwards
 */
void _collect_all_xpaths(struct XGraphEdgePath_List **lst, graphelem * gl, gint orgNodeCount){
	edgeelem * edge_iter = NULL;
	Graph * lgr = &gl->graph;

	// Walk through all Nodes
    int actNode = 1;

	for (actNode = 1; actNode <= orgNodeCount; ++actNode) {
		struct element * visitedNodes = NULL;

		// current Node is visited
		insertElement(&visitedNodes, actNode);

		// Walk through all Edges belonging to a node
		for (edge_iter = lgr->edge_root ; edge_iter ; edge_iter = edge_iter->next) {
			Edge * edge = &edge_iter->edge;

			// Current Edges
			int from = atoi(get_node (lgr, edge->from)->name);
			int to   = atoi(get_node (lgr, edge->to)->name);

			// Edge is not matching
			if(actNode != from)
				continue;

			// Fetch all Edgepaths to the next node
			struct XGraphEdgePath_List * xpaths = _get_all_xpaths_to_node(&visitedNodes, to, gl, orgNodeCount);

			// Einfügen als From node
			if(xpaths == NULL)
				continue;

			// Save the current struct pointer
			struct XGraphEdgePath_List * xpaths2 = xpaths;

			// Add the startnode to all calculated Edgepaths
			for( ; xpaths != NULL ; xpaths = xpaths->next )  {
				XGraphEdgePath * xpath = xpaths->xpath;
				xgraph_edge_path_set_from(xpath,from);
			}

			// Prepare Result
			if(*lst == NULL)
				*lst = xpaths2;
			else {
				if(xpaths2 != NULL)
					appendXpaths(lst,&xpaths2);
			}

		}

		clearElements(&visitedNodes);

	}
}

/*!
 * Applies a legacy layout created by the graph drawing algorithms to the
 * Relview graph representation.
 */
static void _apply_legacy_layout (XGraph * gr, graphelem * gl)
{
	Graph * lgr = &gl->graph;
	nodeelem * node_iter = NULL;
	edgeelem * edge_iter = NULL;

	/* Avoid 'changed' events while the graph is laid out. */
	xgraph_block_notify (gr);

	/* Reset the graph layout. */
	xgraph_reset_layout (gr);

	// Place the nodes
	for (node_iter = lgr->node_root ; node_iter ; node_iter = node_iter->next) {
		Node * node = &node_iter->node;
		XGraphNode * xnode = xgraph_get_node_by_name (gr, atoi(node->name));
		// Place a normal Node
		if (xnode) {
			XGraphNodeLayout * layout = xgraph_node_get_layout(xnode);
			assert (xnode != NULL);
			assert (layout != NULL);
			xgraph_node_layout_set_pos (layout, (gfloat)node->x_pos, (gfloat)node->y_pos);
		} else {
			// We do not draw the Helpernodes
		}
	}

	// Collect all EdgePaths
	struct XGraphEdgePath_List * lst = NULL;
	_collect_all_xpaths(&lst, gl, xgraph_get_node_count(gr));

	// Walk through all original Edges an set the edgepaths
	XGRAPH_FOREACH_EDGE(gr,xedge,iter,{

		// Fetch Edgenodes
		XGraphNode * from = xgraph_edge_get_from_node(xedge);
        XGraphNode * to   = xgraph_edge_get_to_node(xedge);

        // Fetch the Edgepath if exists
		XGraphEdgePath * edgePath = lookupXpath(atoi(xgraph_node_get_name(from)), atoi(xgraph_node_get_name(to)), lst);

		if(edgePath == NULL)
			continue;

		// Apply edgepath to edge
		xgraph_edge_layout_set_path (xgraph_edge_get_layout(xedge), edgePath);
	});

	clearXpaths(&lst);

	// Release the Graph and notify the GraphwindowObserver
	xgraph_unblock_notify (gr);
	xgraph_changed (gr);
}

/* Some magical constants ... . */
#define DEFAULT_DIM   24
#define DEFAULT_SPANNING_WIDTH    1800
#define DEFAULT_SPANNING_HEIGHT   1800

static graphelem * _spring_slow (KureRel * rel, GraphWindow * gw)
{
	int width = graph_window_get_display_width (gw),
			height = graph_window_get_display_height (gw);
	int spanning_width = MAX((width - 2 * DEFAULT_DIM),DEFAULT_SPANNING_WIDTH),
			spanning_height = MAX((height - 2 * DEFAULT_DIM), DEFAULT_SPANNING_HEIGHT);
	return spring_langsam (rel, spanning_width, spanning_height);
}

static graphelem * _spring_fast (KureRel * rel, GraphWindow * gw)
{
	int width = graph_window_get_display_width (gw),
			height = graph_window_get_display_height (gw);
	int spanning_width = MAX((width - 2 * DEFAULT_DIM),DEFAULT_SPANNING_WIDTH),
			spanning_height = MAX((height - 2 * DEFAULT_DIM), DEFAULT_SPANNING_HEIGHT);
	return spring_schnell (rel, spanning_width, spanning_height);
}

/* More magical constants from the graph drawing algorithms. Don't know where
 * they come from. */
#define DEFAULT_MIN_RANK 30
#define DEFAULT_MIN_ORDER 50

int min_rank = DEFAULT_MIN_RANK;
int min_order = DEFAULT_MIN_ORDER;

static graphelem * _layer (KureRel * rel, GraphWindow * gw)
{
	return dag (rel, min_rank, min_order);
}

static graphelem * _forest (KureRel * rel, GraphWindow * gw)
{
	return tree (rel, min_rank, min_order);
}

#define DEFAULT_WRAPPER(wrapfun,fun) \
	static graphelem * wrapfun (KureRel * rel, GraphWindow * gw) { return fun(rel); }
DEFAULT_WRAPPER(_planar_triangular, DrawTriangulatedGraph)
DEFAULT_WRAPPER(_planar_trimix, DrawTriangluarMixedModelGraph)
DEFAULT_WRAPPER(_planar_mixmod, DrawMixedModelGraph)
DEFAULT_WRAPPER(_orthogonal, graph_orthogonal)
DEFAULT_WRAPPER(_orthogonal_fast, graph_orthogonal_fast)

/*!
 * Called when the user selected an entry in the popup menu.
 *
 * \param user_data Pointer to the function which is to be called.
 * \param entry The menu entry.
 * \param obj The GraphWindow object.
 */
static void _on_activate (gpointer user_data, MenuEntry * entry, gpointer obj)
{
	draw_graph_func_t func = (draw_graph_func_t) user_data;

	GraphWindow * gw = (GraphWindow*) obj;
	XGraph * gr = graph_window_get_graph(gw);
	KureContext * context = rv_get_context(rv_get_instance());
	Rel * rel = rel_new_from_xgraph (context, (XGraph*) gr);

	if (rel) {
		KureRel * impl = rel_get_impl(rel);
		graphlistptr gl = NULL;

		gl = func (impl, gw);
		rel_destroy (rel);

		if (gl) {
			/* Translate the legacy graph structure to a relview graph (XGraph). */
			_apply_legacy_layout (gr, gl);

			/* Is there another possibility to delete a graph? */
			del_graph (gl, gl->graph.name);
		}
	}
}


/*******************************************************************************
 *                              Plugin Interface                               *
 *                                                                             *
 ******************************************************************************/

/* Stores our menu entries so we can remove them when the plugin is
 * disabled. */
static GList/*<MenuEntry*>*/ * _menu_entries = NULL;

G_MODULE_EXPORT gboolean onInit (int * version, rvp_plugin_id_t id)
{
    return TRUE; /* don't ignore module. */
}

static const char _menu_path [] = "/graph-window";

G_MODULE_EXPORT void onEnable (const gchar * ignored)
{
	Relview * rv = rv_get_instance();

	MenuManager * manager = rv_get_menu_manager(rv);
	MenuDomain * domain = menu_manager_get_domain(manager, _menu_path);

	if ( NULL == domain) {
		g_warning ("graph-drawing: Unknown menu domain: %s", _menu_path);
	}
	else {
#define MENU_ENTRY_ADD(name, is_enabled_func, on_activate_func, user_data) { \
	MenuEntry * e = menu_entry_new (name, is_enabled_func, on_activate_func, (gpointer) user_data); \
	if (e) { \
		_menu_entries = g_list_prepend (_menu_entries, (gpointer)e); \
		menu_domain_add (domain, "drawings"/*subpath*/, e); } }

		MENU_ENTRY_ADD ("Spring (Fast)", _always_enabled, _on_activate, _spring_slow);
		MENU_ENTRY_ADD ("Spring (Slow)", _always_enabled, _on_activate, _spring_fast);
		MENU_ENTRY_ADD ("Layer", _always_enabled, _on_activate, _layer);
		MENU_ENTRY_ADD ("Forest", _is_forest_enabled, _on_activate, _forest);

		MENU_ENTRY_ADD ("Planar (Triangular)", _is_planar_enabled, _on_activate, _planar_triangular);
		MENU_ENTRY_ADD ("Planar (Trimix)", _is_planar_enabled, _on_activate, _planar_trimix);
		MENU_ENTRY_ADD ("Planar (Mixmod)", _is_planar_enabled, _on_activate, _planar_mixmod);
		MENU_ENTRY_ADD ("Orthogonal", _is_orthogonal_enabled, _on_activate, _orthogonal);
		MENU_ENTRY_ADD ("Orthogonal (Fast)", _is_orthogonal_enabled, _on_activate, _orthogonal_fast);
	}
}

G_MODULE_EXPORT void onDisable ()
{
	if (_menu_entries != NULL) {
		Relview * rv = rv_get_instance();
		MenuManager * manager = rv_get_menu_manager(rv);
		MenuDomain * domain = menu_manager_get_domain (manager, _menu_path);

		if (domain != NULL) {
			GList/*<MenuEntry*>*/ * iter = _menu_entries;
			for ( ; iter ; iter = iter->next) {
				MenuEntry * cur = (MenuEntry*) iter->data;
				menu_domain_steal (domain, cur);
				menu_entry_destroy (cur);
			}
		}

		g_list_free (_menu_entries);
		_menu_entries = NULL;
	}
}

RvPlugInInfo PLUG_IN_INFO = {
		onInit, NULL, onEnable, onDisable,
		(gchar*) "Graph Drawing",
		(gchar*) "Provides Spring, Layer, Forest, Planar and Orthogonal drawings."
};

RV_PLUGIN_MAIN()
