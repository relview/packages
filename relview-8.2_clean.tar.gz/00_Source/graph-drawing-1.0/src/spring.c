/* globale Variablen und Funktionen fuer den Springembedder- */
/* algorithmus, werden genutzt von :                         */
/*                    spring_langsam                         */ 
/*                    spring_schnell                         */


float k;
