/****************************************************************************/
/* Dateiname: ort_helpfun.c                                                 */
/* Enthaelt Hilfsfunktionen fuer die Darstellung von orthogonalen Graphen,  */
/* die nicht in helpfunc.c vorhanden sind.                                  */
/* Autor: Ulf Milanese (09.12.1998)                                         */
/* zuletzt geaendert am: 10.02.1999                                         */
/****************************************************************************/

#include <stdio.h>
#include <malloc.h>

//#include "global.h"
#include "graph.h"
#include "ort_helpfun.h"

/****************************************************************************/
/* NAME : new_numberarray                                                   */
/* FUNKTION : Erzeugung eines dynamischen Arrays fuer Integer-Quadrupel     */
/* UEBERGABEPARAMETER : keiner                                              */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : Zeiger auf dynamisches Zahlen-Quadrupel                  */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 21.01.1999                                         */
/****************************************************************************/
numberarrayptr new_numberarray (void)
{
  numberarrayptr resultat;

  resultat = (numberarrayptr) malloc (sizeof (numberarray));
  resultat->inhalt = FIELD_FREE;
  resultat->left = FIELD_FREE;
  resultat->down = FIELD_FREE;
  resultat->right = FIELD_FREE;
  resultat->up = FIELD_FREE;
  resultat->p_left = (numberarrayptr) NULL;
  resultat->p_down = (numberarrayptr) NULL;
  resultat->p_right = (numberarrayptr) NULL;
  resultat->p_up = (numberarrayptr) NULL;
  return (resultat);
}



/****************************************************************************/
/* NAME : print_visibility_representation                                   */
/* FUNKTION : Debug-Ausgabe einer Visibility Representation                 */
/* UEBERGABEPARAMETER : Zeiger auf eine Visibility Representation vr        */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 26.01.1999                                         */
/****************************************************************************/

void print_visibility_representation (visibilityrepptr vr)
{
  if (vr) {
    puts ("Visibility Representation:");
    printf ("Spalten: %d, Zeilen: %d\n", vr->spalten, vr->zeilen);
    if (vr->top_left)
      print_numberarray (vr->top_left);
  }
}


/****************************************************************************/
/* NAME : new_visibility_representation                                     */
/* FUNKTION : Erzeugung eines dynamischen, zwei-dimensionalen               */
/*            Integer-Arrays                                                */
/* UEBERGABEPARAMETER : Zeiger auf eine Integer-Liste st_numbers            */
/* VORAUSSETZUNG: st_numbers->size stimmt mit der Anzahl der Zahlen         */
/*                ueberein; die Zahlen laufen von 1 bis size (wird nicht    */
/*                geprueft)                                                 */
/* RUECKGABEWERT : Zeiger auf eine Visibility Representation                */
/* ERSTELLT VON : Ulf Milanese (21.01.1999)                                 */
/* LETZTE AENDERUNG AM : 02.02.1999                                         */
/****************************************************************************/

visibilityrepptr new_visibility_representation (p_intList st_numbers)
{
  visibilityrepptr resultat;
  numberarrayptr   array;
  int              size;
  p_intList        copy_numbers;

  if (!st_numbers)
    return ((visibilityrepptr) NULL);

  size = st_numbers->size;
  if (size <= 0)
    return ((visibilityrepptr) NULL);

  copy_numbers = copyIntList (st_numbers);
  resultat = (visibilityrepptr) malloc (sizeof (visibilityrep));
  resultat->spalten = 1;
  resultat->zeilen = size;
  resultat->top_left = new_numberarray ();
  resultat->top_right = resultat->top_left;
  array = resultat->top_left;
  size--;
  while (size > 0) {
    array->p_down = new_numberarray ();
    array->p_down->p_up = array;
    if (copy_numbers->first)
      array->inhalt = popFirst (copy_numbers);
    else {
      clearIntList (copy_numbers);
      del_visibility_representation (resultat);
      return ((visibilityrepptr) NULL);
    }
    array = array->p_down;
    size--;
  }
  if (copy_numbers->first)
    array->inhalt = popFirst (copy_numbers);
  else {
    clearIntList (copy_numbers);
    del_visibility_representation (resultat);
    return ((visibilityrepptr) NULL);
  }

  clearIntList (copy_numbers);
  resultat->bottom_left = array;
  return (resultat);
}



/****************************************************************************/
/* NAME : append_column                                                     */
/* FUNKTION : Fuegt an eine Visibility Representation eine Spalte hinzu.    */
/* UEBERGABEPARAMETER : Zeiger auf Visibility Representation vr             */
/* VORAUSSETZUNG: vr ist korrekt initialisiert (wird nicht geprueft)        */
/* RUECKGABEWERT : 0, falls Anfuegen gescheitert ist                        */
/*                 1, falls Anfuegen geklappt hat                           */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 27.01.1999                                         */
/****************************************************************************/

int append_column (visibilityrepptr vr)
{
  numberarrayptr last_column;
  numberarrayptr new_cell;
  numberarrayptr tmp_last_column;
  numberarrayptr tmp_new_cell;

  if (!vr)
    return (0);

  last_column = vr->top_right;
  /* last_column zeigt nun auf das oberste Element in der Spalte ganz       */
  /* rechts.                                                                */

  last_column->p_right = new_numberarray ();
  if (!last_column->p_right)
    return (0);

  new_cell = last_column->p_right;
  new_cell->p_left = last_column;
  vr->top_right = new_cell;
  while (last_column->p_down) {
    tmp_last_column = last_column->p_down;
    tmp_last_column->p_right = new_numberarray ();
    if (!tmp_last_column->p_right)
      return (0);
    tmp_new_cell = tmp_last_column->p_right;
    tmp_new_cell->p_left = tmp_last_column;
    new_cell->p_down = tmp_new_cell;
    tmp_new_cell->p_up = new_cell;
    last_column = tmp_last_column;
    new_cell = tmp_new_cell;
  }
  vr->spalten++;
  return (1);
}



/****************************************************************************/
/* NAME : append_new_row_after                                              */
/* FUNKTION : Fuegt in eine Visibility Representation eine Zeile an eine    */
/*            bestimmte Position ein                                        */
/* UEBERGABEPARAMETER : Zeiger auf eine Visibility Representation;          */
/*                      Einfuegeposition where, Bezeichner what             */
/* VORAUSSETZUNG : where ist vorhanden (wird geprueft)                      */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 19.02.1999                                         */
/****************************************************************************/

void append_new_row_after (visibilityrepptr vr, int where, int what)
{
  numberarrayptr na1;
  numberarrayptr na2;
  numberarrayptr na3;

  na1 = vr->top_left;
  while (na1) {
    if (na1->inhalt == where)
      break;
    na1 = na1->p_down;
  }
  if (na1) {
    na2 = new_numberarray ();
    na2->inhalt = what;
    na2->p_down = na1->p_down;
    na2->p_up = na1;
    na1->p_down = na2;
    if (na2->p_down)
      na2->p_down->p_up = na2;
    na1 = na1->p_right;
    na3 = na2;
    while (na1) {
      na2 = new_numberarray ();
      na3->p_right = na2;
      na2->p_left = na3;
      na3 = na2;
      na2->p_down = na1->p_down;
      na2->p_up = na1;
      if (na2->p_down)
        na2->p_down->p_up = na2;
      na1->p_down = na2;
      na2->down = na1->down;
      if (na2->p_down)
        na2->up = na2->p_down->up;
      if (na2->up != FIELD_FREE)
        na2->inhalt = FIELD_USED;
      na1 = na1->p_right;
    }
    na3->p_right = (numberarrayptr) NULL;
    vr->zeilen++;
  }
}




/****************************************************************************/
/* NAME : find_column_in_visibility                                         */
/* FUNKTION : Finden der Spalte in einer Visibility Representation, in der  */
/*            die naechste Kante eingefuegt werden kann.                    */
/* UEBERGABEPARAMETER : Zeiger auf eine Visibility Representation vr;       */
/*                      Knotennummer node                                   */
/* VORAUSSETZUNG : node ist in vr enthalten (wird geprueft)                 */
/* RUECKGABEWERT : Nummer der Spalte                                        */
/* ERSTELLT VON : Ulf Milanese (19.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

int find_column_in_visibility (visibilityrepptr vr, int node)
{
  numberarrayptr na1;
  numberarrayptr na2;
  int            resultat = 0;

  if (!vr)
    return (0);
  na1 = vr->top_left;
  if (!na1)
    return (0);
  while (na1)
    if (na1->inhalt != node)
      na1 = na1->p_down;
    else
      break;
  if (!na1)
    return (0);

  na2 = na1->p_right;
  resultat = 1;
  while (na2)
    if (na2->inhalt == node)
      break;
    else {
      na2 = na2->p_right;
      resultat++;
    }

  /* 1. Fall: Zu dem Knoten existiert noch keine Kante, dann wird eine neue */
  /*          Spalte hinzugefuegt.                                          */
  if (!na2) {
    append_column (vr);
    return (resultat);
  }

  /* 2. Fall: Der Knoten ist mit einer Kante nach oben repraesentiert,      */
  /*          besitzt in dieser Spalte aber keine Kante nach unten. Es wird */
  /*          die Nummer dieser Spalte zurueckgegeben.                      */
  if (na2->down == FIELD_FREE)
    return (resultat);

  /* 3. Fall: Der Knoten ist bereits mit einer Kante nach unten             */
  /*          repraesentiert. Es wird nach rechts gesucht, bis eine andere  */
  /*          Kante den Weg blockiert oder das Ende des Arrays erreicht     */
  /*          wird. Eine neue Spalte wird eingefuegt, der Knoten bis        */
  /*          hierhin verlaengert und die Nummer der Spalte zurueckgegeben. */
  while (1)
    if (na2->p_right) {
      if (na2->p_right->inhalt != FIELD_USED) {
        if (na2->p_right->inhalt != node) {
          na2->right = node;
          na2->p_right->left = node;
          na2->p_right->inhalt = node;
        }
        na2 = na2->p_right;
        resultat++;
      }
      else {
        insert_column_after (vr, resultat);
        resultat++;
        return (resultat);
      }
    }
    else {
      append_column (vr);
      resultat++;
      return (resultat);
    }
}




/****************************************************************************/
/* NAME : insert_column_after                                               */
/* FUNKTION : Erzeugt eine neue Spalte in einer Visibility Representation   */
/* UEBERGABEPARAMETER : Zeiger auf Visibility Representation vr; Integer,   */
/*                      where mit Angabe, welche Spalte                     */
/* VORAUSSETZUNG : keine                                                    */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 19.02.1999                                         */
/****************************************************************************/

void insert_column_after (visibilityrepptr vr, int where)
{
  printf("HI\n");
  numberarrayptr na1;
  numberarrayptr na2;

  na1 = vr->top_left;
  while (where && na1) {
    where--;
    na1 = na1->p_right;
  }
  if (!na1)
    append_column (vr);
  if (!na1->p_right)
    append_column (vr);
  else {
    na2 = new_numberarray ();
    na2->p_left = na1;
    na2->p_right = na1->p_right;
    na1->p_right = na2;
    na2->p_right->p_left = na2;
    if (na1->right != FIELD_FREE) {
      na2->right = na1->right;
      na2->inhalt = na1->right;
      na2->left = na1->right;
    }
    while (na1->p_down) {
      na1 = na1->p_down;
      na2->p_down = new_numberarray ();
      na2->p_down->p_up = na2;
      na2 = na2->p_down;
      na2->p_left = na1;
      na2->p_right = na1->p_right;
      na1->p_right = na2;
      na2->p_right->p_left = na2;
      if (na1->right != FIELD_FREE) {
        na2->right = na1->right;
        na2->inhalt = na1->right;
        na2->left = na1->right;
      }
    }
  }
  vr->spalten++;
}





/****************************************************************************/
/* NAME : print_numberarray                                                 */
/* FUNKTION : Debug-Ausgabe eines Zahlen-Arrays                             */
/* UEBERGABEPARAMETER : Zeiger auf Zahlen-Array                             */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void print_numberarray (numberarrayptr array)
{
  numberarrayptr tmp_row;

  tmp_row = array;
  printf ("%4d: ", tmp_row->inhalt);
  tmp_row = array->p_right;
  while (tmp_row) {
    if (tmp_row->inhalt == FIELD_FREE)
      printf ("  ");
    else
      if (tmp_row->inhalt == FIELD_USED)
        printf ("| ");
      else
        if ((tmp_row->up >= 0) || (tmp_row->down >= 0))
          if (tmp_row->right >= 0)
            printf ("+-");
          else
            printf ("+ ");
        else
          printf ("--");
    tmp_row = tmp_row->p_right;
  }
  printf ("\n");
  if (array->p_down) {
    printf ("      ");
    tmp_row = array->p_right;
    while (tmp_row) {
      if (tmp_row->down == FIELD_FREE)
        printf ("  ");
      else
        printf ("| ");
      tmp_row = tmp_row->p_right;
    }
    printf ("\n");
    print_numberarray (array->p_down);
  }
}





/****************************************************************************/
/* NAME : del_numberarray_down                                              */
/* FUNKTION : Gibt reservierten Speicher fuer eine Spalte eines             */
/* Zahlen-Arrays frei                                                       */
/* UEBERGABEPARAMETER : Zeiger auf Zahlen-Array                             */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void del_numberarray_down (numberarrayptr array)
{
  if (array)
    del_numberarray_down (array->p_down);
  free (array);
}




/****************************************************************************/
/* NAME : del_numberarray                                                   */
/* FUNKTION : Gibt reservierten Speicher eines Zahlen-Arrays frei           */
/* UEBERGABEPARAMETER : Zeiger auf Zahlen-Array                             */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void del_numberarray (numberarrayptr array)
{
  if (array) {
    del_numberarray (array->p_right);
    del_numberarray_down (array->p_down);
  }
  free (array);
}




/****************************************************************************/
/* NAME : add_edge_to_visibility                                            */
/* FUNKTION : Fuegt die Repraesentation einer Kante in eine Visibility      */
/*            Representation in einer vorgegenen Spalte ein                 */
/* UEBERGABEPARAMETER : Zeiger auf eine Visibility Representation;          */
/*                      inzidente Knoten from und to; Spaltennummer         */
/* VORAUSSETZUNG: from ist ungleich to (wird geprueft); from und to sind    */
/*                in array vorhanden (wird geprueft)                        */
/* RUECKGABEWERT : 0, falls Pruefung gescheitert oder Speicherplatzprobleme */
/*                 1, sonst                                                 */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 19.02.1999                                         */
/****************************************************************************/

int add_edge_to_visibility (visibilityrepptr vr, int from, int to, int column)
{
  numberarrayptr upper_row;
  numberarrayptr lower_row;
  numberarrayptr tmp_column;
  numberarrayptr tmp_row_1;
  numberarrayptr tmp_row_2;
  int            node_1;
  int            node_2;
  int            exists_x;
  int            exists_y;

  if (from == to)
    return (0);

  if (!vr)
    return (0);

  /* Pruefung, ob das Zahlen-Array leer ist                                 */
  upper_row = vr->top_left;
  if (!upper_row)
    return (0);

  /* Pruefung, ob eine der beiden Zahlen enthalten ist                      */
  while ((upper_row->inhalt != from) && (upper_row->inhalt != to)) {
    upper_row = upper_row->p_down;
    if (!upper_row)
      return (0);
  }

  /* Pruefung, ob die zweite Zahl enthalten ist                             */
  if (upper_row->p_down) {
    lower_row = upper_row->p_down;
    while ((lower_row->inhalt != from) && (lower_row->inhalt != to)) {
      lower_row = lower_row->p_down;
      if (!lower_row)
        return (0);
    }
  }
  else
    return (0);

  /* Jetzt ist gesichert, dass beide Knoten in der Visibility               */
  /* Representation bereits vorhanden sind                                  */
  node_1 = upper_row->inhalt;
  node_2 = lower_row->inhalt;

  /* Test, ob diese Kante bereits repraesentiert worden ist. Falls ja,      */
  /* keine Aenderung                                                        */
  tmp_row_1 = upper_row->p_right;
  tmp_row_2 = lower_row->p_right;
  while (tmp_row_1) {
    if ((tmp_row_1->down == node_2) && (tmp_row_2->up == node_1))
      return (1);
    tmp_row_1 = tmp_row_1->p_right;
    tmp_row_2 = tmp_row_2->p_right;
  }

  /* Positionierung der beiden Zeiger auf die gewuenschte Spalte.           */
  while (column && upper_row && lower_row) {
    column--;
    upper_row = upper_row->p_right;
    lower_row = lower_row->p_right;
  }

  /* Die Kante wird in der gewaehlten Spalte repraesentiert.                */
  upper_row->inhalt = node_1;
  upper_row->down = node_2;
  lower_row->inhalt = node_2;
  lower_row->up = node_1;
  tmp_column = upper_row->p_down;
  while (tmp_column->up == FIELD_FREE) {
    tmp_column->down = node_2;
    tmp_column->up = node_1;
    tmp_column->inhalt = FIELD_USED;
    tmp_column = tmp_column->p_down;
  }

  /* Zur besseren Debug-Ausgabe wird der horizontale Knoten erzeugt         */
  /* 1. Schritt: Haben die Knoten frueher schon Kanten bekommen?            */
  exists_x = 0;
  tmp_row_1 = upper_row->p_left;
  while (tmp_row_1) {
    if (tmp_row_1->inhalt == FIELD_USED)
      break;
    if (tmp_row_1->inhalt == node_1)
      if (tmp_row_1->p_left) {
        exists_x = 1;
        break;
      }
    tmp_row_1 = tmp_row_1->p_left;
  }
  exists_y = 0;
  tmp_row_2 = lower_row->p_left;
  while (tmp_row_2) {
    if (tmp_row_2->inhalt == FIELD_USED)
      break;
    if (tmp_row_2->inhalt == node_2)
      if (tmp_row_2->p_left) {
        exists_y = 1;
        break;
      }
    tmp_row_2 = tmp_row_2->p_left;
  }
  /* 2. Schritt: Falls vorhanden, wird der Knoten 'durchgezogen'.           */
  while (exists_x) {
    /* Links steht nichts mehr (darf eigentlich nicht vorkommen).           */
    if (!upper_row->p_left)
      exists_x = 0;
    else
      /* Links steht die Spalte mit den Knoten-Benennungen                  */
      if (!upper_row->p_left->p_left)
        exists_x = 0;
      else {
        upper_row->left = node_1;
        upper_row->p_left->right = node_1;
        if (upper_row->p_left->inhalt == node_1)
          exists_x = 0;
        else {
          upper_row = upper_row->p_left;
          upper_row->inhalt = node_1;
        }
      }
  }

  while (exists_y) {
    /* Links steht nichts mehr (darf eigentlich nicht vorkommen).           */
    if (!lower_row->p_left)
      exists_y = 0;
    else
      /* Links steht die Spalte mit den Knoten-Benennungen                  */
      if (!lower_row->p_left->p_left)
        exists_y = 0;
      else {
        lower_row->left = node_2;
        lower_row->p_left->right = node_2;
        if (lower_row->p_left->inhalt == node_2)
          exists_y = 0;
        else {
          lower_row = lower_row->p_left;
          lower_row->inhalt = node_2;
        }
      }
  }
  return (1);
}



/****************************************************************************/
/* NAME : del_edges_in_edgelist                                             */
/* FUNKTION : In der Kantenliste el1 werden alle in el2 vorhandenen Kanten  */
/*            geloescht                                                     */
/* UEBERGABEPARAMETER : Zeiger auf Kantenlisten el1 und el2                 */
/* VORAUSSETZUNG: Das erste Element von el1 kommt nicht in el2 vor (wird    */
/*                nicht geprueft)                                           */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void del_edges_in_edgelist (edgelistptr el1, edgelistptr el2)
{
  edgelistptr tmp_edgelist_1;
  edgelistptr del_edgelist;

  if (el1)
    while ((el2) && (el1->next)) {
      tmp_edgelist_1 = el1;
      del_edgelist = tmp_edgelist_1->next;
      while (del_edgelist) {
        if ((del_edgelist->edge.from == el2->edge.from) &&
            (del_edgelist->edge.to == el2->edge.to)) {
          tmp_edgelist_1->next = del_edgelist->next;
          free (del_edgelist);
          break;
        }
        tmp_edgelist_1 = tmp_edgelist_1->next;
        del_edgelist = tmp_edgelist_1->next;
      }
      el2 = el2->next;
    }
}




/****************************************************************************/
/* NAME : copy_edgelist                                                     */
/* FUNKTION : Erstellung einer Kopie einer Kantenliste                      */
/* UEBERGABEPARAMETER : Zeiger auf Kantenliste el                           */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : Zeiger auf Kantenliste                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

edgelistptr copy_edgelist (edgelistptr el)
{
  edgelistptr resultat;
  edgelistptr tmp_resultat;

  if (!el)
    return ((edgelistptr) NULL);

  resultat = make_edge (el->edge.name, el->edge.from, el->edge.to,
                        el->edge.state);
  el = el->next;
  tmp_resultat = resultat;
  while (el) {
    tmp_resultat->next = make_edge (el->edge.name, el->edge.from,
                                    el->edge.to, el->edge.state);
    el = el->next;
    tmp_resultat = tmp_resultat->next;
  }
  return (resultat);
}




/****************************************************************************/
/* NAME : print_face                                                        */
/* FUNKTION : Debug-Ausgabe einer Liste von Kanten, die eine Flaeche        */
/*            umschliessen                                                  */
/* UEBERGABEPARAMETER : Zeiger auf eine Liste von Kanten                    */
/* VORAUSSETZUNG: Kanten bilden einen Kreis (wird nicht geprueft)           */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 09.02.1999                                         */
/****************************************************************************/

void print_face (edgelistptr el)
{
  if (el)
    printf ("%d", el->edge.from);
  while (el) {
    printf (" - %d", el->edge.to);
    el = el->next;
  }
  printf ("\n");
}




/****************************************************************************/
/* NAME : print_edgelist                                                    */
/* FUNKTION : Debug-Ausgabe einer Liste von Kanten                          */
/* UEBERGABEPARAMETER : Zeiger auf Kantenliste el                           */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM : 09.02.1999                                         */
/****************************************************************************/

void print_edgelist (edgelistptr el)
{
  printf ("Kantenliste: ");
  while (el) {
    printf ("(%d, %d)", el->edge.from, el->edge.to);
    if (el->next)
      printf (", ");
    el = el->next;
  }
  printf ("\n");
}




/****************************************************************************/
/* NAME : del_edgelist                                                      */
/* FUNKTION : Gibt den Speicherplatz einer Kantenliste frei                 */
/* UEBERGABEPARAMETER : Zeiger auf Kantenliste                              */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void del_edgelistptr (edgelistptr el)
{
  edgelistptr elIter;

  while (el) {
    elIter = el->next;
    free (el);
    el = elIter;
  }
}




/****************************************************************************/
/* NAME : right_face_of_edge                                                */
/* FUNKTION : Gibt zu einer Kante in einer Einbettung die rechts neben der  */
/*            Kantenorientierung liegende Flaeche zurueck                   */
/* UEBERGABEPARAMETER : Zeiger auf eine Kante el, Zeiger auf eine Adjazenz- */
/*                      Liste embedding; Liste von Knoten                   */
/* VORAUSSETZUNG: Kante el ist in embedding vorhanden (wird nicht           */
/*                ueberprueft); nodes ist in embedding enthalten            */
/* RUECKGABEWERT : Zeiger auf eine Kantenliste                              */
/* ERSTELLT VON : Ulf Milanese (18.01.1999)                                 */
/* LETZTE AENDERUNG AM : 19.02.1999                                         */
/****************************************************************************/

edgelistptr right_face_of_edge (edgelistptr el, p_adjList embedding,
                                p_intList nodes)
{
  edgelistptr  resultat;
  edgelistptr  tmp_resultat;
  edgelistptr  el1;
  int          node_1;
  int          node_2;
  unsigned int node_3;

  node_1 = el->edge.from;
  node_2 = el->edge.to;
  resultat = make_edge (el->edge.name, node_1, node_2, el->edge.state);
  tmp_resultat = resultat;
  while (1) {
    node_3 = nextClockNode (embedding, node_2, node_1);
    while (!inList (nodes, node_3))
      node_3 = nextClockNode (embedding, node_2, node_3);
    node_1 = node_2;
    node_2 = node_3;
    if ((node_1 == resultat->edge.from) && (node_2 == resultat->edge.to))
      break;
    el1 = make_edge ("", node_1, node_2, VISIBLE);
    tmp_resultat->next = el1;
    tmp_resultat = tmp_resultat->next;
  }
  return (resultat);
}


/****************************************************************************/
/* NAME : edge_is_in                                                        */
/* FUNKTION : Ueberprueft, ob eine Kante in einer Kantenliste vorhanden ist */
/* UEBERGABEPARAMETER : Zeiger auf Kante kante, Zeiger auf Kantenliste      */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : 0, falls kante nicht in liste                            */
/*                 1, sonst                                                 */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

int edge_is_in (edgelistptr kante, edgelistptr liste)
{
  edgelistptr tmp_list;

  tmp_list = liste;
  while (tmp_list) {
    if ((kante->edge.from == tmp_list->edge.from) &&
        (kante->edge.to == tmp_list->edge.to))
      return (1);
    tmp_list = tmp_list->next;
  }
  return (0);
}



/****************************************************************************/
/* NAME : append_edge_to_edgelist                                           */
/* FUNKTION : Fuegt an eine Kantenliste die Kopie einer Kante hinzu, falls  */
/*            diese noch nicht in der Kantenliste vorhanden ist             */
/* UEBERGABEPARAMETER : Zeiger auf Kante kante, Zeiger auf Kantenliste      */
/* VORAUSSETZUNG: liste ist ungleich NULL                                   */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 26.01.1999                                         */
/****************************************************************************/

void append_edge_to_edgelist (edgelistptr kante, edgelistptr liste)
{
  /* liste darf nicht leer sein!                                            */
  if (liste)

    /* Falls die erste Kante gleich der neuen kante ist, muss nichts mehr   */
    /* getan werden.                                                        */
    if ((kante->edge.from != liste->edge.from) ||
        (kante->edge.to != liste->edge.to)) {

      /* Durchlaufe liste, bis entweder Ende erreicht worden ist oder eine  */
      /* Kopie von kante gefunden wurde.                                    */
      while (liste->next) {
        if ((kante->edge.from == liste->next->edge.from) &&
          (kante->edge.to == liste->next->edge.to))
        break;
        liste = liste->next;
      }

      /* Falls das Ende der Liste erreicht worden ist, fuege neue Kante     */
      /* hinzu.                                                             */
      if (!liste->next)
        liste->next = make_edge (kante->edge.name, kante->edge.from,
                                 kante->edge.to, kante->edge.state);
    }
}




/****************************************************************************/
/* NAME : append_edgelist_to_edgelist                                       */
/* FUNKTION : Fuegt an eine Kantenliste die Kopie einer Edgelist hinzu,     */
/*            falls diese noch nicht in der Kantenliste vorhanden sind      */
/* UEBERGABEPARAMETER : Zeiger auf Kantenliste source,                      */
/*                      Zeiger auf Kantenliste sink                         */
/* VORAUSSETZUNG: sink ist ungleich NULL                                    */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (26.01.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void append_edgelist_to_edgelist (edgelistptr source, edgelistptr sink)
{
  /* sink darf nicht leer sein.                                             */
  if (sink) {
    while (source) {
      append_edge_to_edgelist (source, sink);
      source = source->next;
    }
  }
}


/****************************************************************************/
/* NAME : new_facelist                                                      */
/* FUNKTION : Speicherplatz-Reservierung fuer eine leere Liste von Flaechen */
/* UEBERGABEPARAMETER : keiner                                              */
/* VORAUSSETZUNG : keine                                                    */
/* RUECKGABEWERT : Zeiger auf eine Liste von Flaechen                       */
/* ERSTELLT VON : Ulf Milanese (11.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/


facelistptr new_facelist (void)
{
  facelistptr new_face;

  new_face = (facelistptr) malloc (sizeof (facelist));
  new_face->face = (edgelistptr) NULL;
  new_face->next = (facelistptr) NULL;
  return (new_face);
}





/****************************************************************************/
/* NAME : print_faces                                                       */
/* FUNKTION : Debug-Ausgabe einer Liste von Flaechen                        */
/* UEBERGABEPARAMETER : Zeiger auf eine Liste von Flaechen                  */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void print_faces (facelistptr fl)
{
  if (fl) {
    print_face (fl->face);
    print_faces (fl->next);
  }
}


/****************************************************************************/
/* NAME : del_facelist                                                      */
/* FUNKTION : Freigabe des Speicherplatzes einer Liste von Flaechen         */
/* UEBERGABEPARAMETER : Zeiger auf eine Liste von Flaechen                  */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void del_facelist (facelistptr fl)
{
  if (fl) {
    del_edgelistptr (fl->face);
    del_facelist (fl->next);
  }
  free (fl);
}





/****************************************************************************/
/* NAME : new_adjlist                                                       */
/* FUNKTION : Reservierung des Speicherplatzes fuer eine Adjazenz-Liste     */
/* UEBERGABEPARAMETER : Integer-Wert (wird in destination eingetragen)      */
/* VORAUSSETZUNG : keine                                                    */
/* RUECKGABEWERT : Zeiger auf eine Adjazenz-Liste                           */
/* ERSTELLT VON : Ulf Milanese (11.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

adjlistptr new_adjlist (unsigned int to)
{
  adjlistptr new_list;

  new_list = (adjlistptr) malloc (sizeof (adjlist));
  new_list->dest = to;
  new_list->next = new_list;
  new_list->sym = (adjlistptr) NULL;
  new_list->angle = 0;
  new_list->bends = 0;
  new_list->winkel = 0;
  new_list->ziel = to;
  return (new_list);
}



/****************************************************************************/
/* NAME : del_adjlist                                                       */
/* FUNKTION : Freigabe des Speicherplatzes fuer eine Adjazenz-Liste         */
/* UEBERGABEPARAMETER : Zeiger auf eine Adjazenz-Liste                      */
/* VORAUSSETZUNG : keine                                                    */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (11.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void del_adjlist (adjlistptr al)
{
  int        dest;
  adjlistptr tmp_al;

  if (al) {
    dest = al->dest;
    al = al->next;
    while (al->dest != dest) {
      if (al->next) {
        tmp_al = al->next;
        free (al);
        al = tmp_al;
      }
      else
        dest = al->dest;
        /* Falls eine fehlerhafte Struktur geloescht werden soll!           */
    }
  }
  free (al);
}


/****************************************************************************/
/* NAME : print_adjlist                                                     */
/* FUNKTION : Debug-Ausgabe einer Adjazenz-Liste                            */
/* UEBERGABEPARAMETER : Zeiger auf eine Adjazenz-Liste                      */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void print_adjlist (adjlistptr al)
{
  int node_1;

  if (al) {
    node_1 = al->dest;
    printf (" %d (a: %d, b: %d, w: %d, z: %d)", al->dest,
            al->angle, al->bends, al->winkel, al->ziel);
    while (al->next->dest != node_1) {
      al = al->next;
      printf (" - %d (a: %d, b: %d, w: %d, z: %d)", al->dest,
              al->angle, al->bends, al->winkel, al->ziel);
    }
  }
  printf ("\n");
}



/****************************************************************************/
/* NAME : del_orthogonal_representation                                     */
/* FUNKTION : Freigabe des Speicherplatzes einer Orthogonalen               */
/*            Representation                                                */
/* UEBERGABEPARAMETER : Zeiger auf eine orthogonale Representation pr       */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 09.02.1999                                         */
/****************************************************************************/

void del_orthogonal_representation (orthogonalrepptr or)
{
  if (or) {
    del_adjlist (or->adjazent);
    del_orthogonal_representation (or->next);
  }
  free (or);
}





/****************************************************************************/
/* NAME : print_orthogonal_representation                                   */
/* FUNKTION : Debug-Ausgabe einer Orthogonalen Representation               */
/* UEBERGABEPARAMETER : Zeiger auf eine orthogonale Representation pr       */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void print_orthogonal_representation (orthogonalrepptr or)
{
  puts ("Orthogonal Representation:");
  while (or) {
    printf ("%d (%d, %d) %d:", or->number, or->pos_x, or->pos_y,
            or->help_node);
    print_adjlist (or->adjazent);
    or = or->next;
  }
  printf ("\n");
}



/****************************************************************************/
/* NAME : new_orthogonal_representation                                     */
/* FUNKTION : Erzeugung einer initialen Orthogonalen Represenatation        */
/* UEBERGABEPARAMETER : Anzahl der zu repraesentierenden Knoten             */
/* RUECKGABEWERT : Zeiger auf eine Orthogonale Representation               */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 03.02.1999                                         */
/****************************************************************************/

orthogonalrepptr new_orthogonal_representation (unsigned int number)
{
  orthogonalrepptr or;
  orthogonalrepptr tmp_or;
  unsigned int     counter_1;

  or = (orthogonalrepptr) NULL;
  if (number) {
    or = (orthogonalrepptr) malloc (sizeof (orthogonalrep));
    or->number = 0;
    or->pos_x = 0;
    or->pos_y = 0;
    or->help_node = 0;
    or->adjazent = (adjlistptr) NULL;
    tmp_or = or;
    for (counter_1 = 1; counter_1 < number; counter_1++) {
      tmp_or->next = (orthogonalrepptr) malloc (sizeof (orthogonalrep));
      tmp_or = tmp_or->next;
      tmp_or->number = counter_1;
      tmp_or->pos_x = 0;
      tmp_or->pos_y = 0;
      tmp_or->help_node = 0;
      tmp_or->adjazent = (adjlistptr) NULL;
    }
    tmp_or->next = (orthogonalrepptr) NULL;
  }
  return (or);
}




/****************************************************************************/
/* NAME : append_edge_to_orthogonal_representation                          */
/* FUNKTION : Hinzufuegen einer Kante in eine Orthogonale Representation    */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonale Representation or,      */
/*                      Kante (from -> to), Zeiger auf eine Adjazenzliste   */
/* VORAUSSETZUNG: from und to sind in pr bereits repraesentiert (wird       */
/*                geprueft); (from -> to) ist in embedding vorhanden (wird  */
/*                geprueft); from ist ungleich to (wird geprueft)           */
/* RUECKGABEWERT : 0, falls Pruefung erfolglos oder Speicher-Probleme       */
/*                 1, sonst                                                 */
/* ERSTELLT VON : Ulf Milanese (22.12.1998)                                 */
/* LETZTE AENDERUNG AM : 09.02.1999                                         */
/****************************************************************************/

int append_edge_to_orthogonal_representation (orthogonalrepptr or, int from,
                                              int to, p_adjList embedding)
{
  orthogonalrepptr or_from = (orthogonalrepptr) NULL;
  orthogonalrepptr or_to = (orthogonalrepptr) NULL;
  adjlistptr       al_from;
  adjlistptr       al_to;
  adjlistptr       new_list;
  int              ready;
  int              node_1;
  int              node_2;

  while (or) {
    if (or->number == from)
      or_from = or;
    if (or->number == to)
      or_to = or;
    or = or->next;
  }
  if (!or_from || !or_to)
    return (0);
  al_from = or_from->adjazent;
  if (!al_from) {
    new_list = new_adjlist (to);
    or_from->adjazent = new_list;
    al_from = new_list;
  }
  else {
    if (al_from == al_from->next) {
      al_from->next = new_adjlist (to);
      al_from->next->next = al_from;
      al_from = al_from->next;
    }
    else {
      ready = 0;
      node_1 = al_from->dest;
      while (!ready) {
        node_2 = nextClockNode (embedding, from, node_1);
        if (node_2 == to)
          ready = 1;
        else {
          node_1 = node_2;
          if (node_1 == al_from->next->dest)
            al_from = al_from->next;
        }
      }
      new_list = new_adjlist (to);
      new_list->next = al_from->next;
      al_from->next = new_list;
      al_from = new_list;
    }
  }

  al_to = or_to->adjazent;
  if (!al_to) {
    new_list = new_adjlist (from);
    or_to->adjazent = new_list;
    al_to = new_list;
  }
  else {
    if (al_to == al_to->next) {
      al_to->next = new_adjlist (from);
      al_to->next->next = al_to;
      al_to = al_to->next;
    }
    else {
      ready = 0;
      node_1 = al_to->dest;
      while (!ready) {
        node_2 = nextClockNode (embedding, to, node_1);
        if (node_2 == from)
          ready = 1;
        else {
          node_1 = node_2;
          if (node_1 == al_to->next->dest)
            al_to = al_to->next;
        }
      }
      new_list = new_adjlist (from);
      new_list->next = al_to->next;
      al_to->next = new_list;
      al_to = new_list;
    }
  }
  al_from->sym = al_to;
  al_to->sym = al_from;
  return (1);
}


/****************************************************************************/
/* NAME : set_angle                                                         */
/* FUNKTION : Setzen der Werte angle und winkel in der Adjazenzliste einer  */
/*            Orthogonal Representation                                     */
/* UEBERGABEPARAMETER : Zeiger auf den aktuellen Knoten der Orthogonal      */
/*                      Representation; Zielknoten; relativer Winkel zur    */
/*                      im Uhrzeigersinn vorherigen Kante geteilt durch     */
/*                      PI/2; tatsaechlicher Winkel (90 Grad = nach links)  */
/* VORAUSSETZUNG: Der aktuelle Knoten ist mit to adjazent (wird nicht       */
/*                geprueft)                                                 */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (09.09.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void set_angle (orthogonalrepptr actual_node, int to, int angle, int winkel)
{
  if (actual_node) {
    adjlistptr al;

    al = actual_node->adjazent;
    while (al->dest != to)
      al = al->next;
    al->angle = angle;
    al->winkel = winkel;
  }
}





/****************************************************************************/
/* NAME : insert_node_in_orthogonal_edge                                    */
/* FUNKTION : Einfuegen eines Hilfsknoten in eine Kante einer Orthogonal    */
/*            Representation                                                */
/* UEBERGABEPARAMETER : Zeiger auf den aktuellen Knoten der Orthogonal      */
/*                      Representation; Zielknoten; Boolscher Wert, ob der  */
/*                      der Hilfsknoten fuer einen linken Knick (vom        */
/*                      aktuellen Knoten aus gesehen) benoetigt wird.       */
/* VORAUSSETZUNG: Der aktuelle Knoten ist mit to adjazent (wird nicht       */
/*                geprueft)                                                 */
/* RUECKGABEWERT : Zeiger auf den neuen Hilfsknoten in der Orthogonal       */
/*                 Representation                                           */
/* ERSTELLT VON : Ulf Milanese (09.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

orthogonalrepptr insert_node_in_orthogonal_edge (orthogonalrepptr actual_node,
                                                 int to, int left_angle)
{
  if (actual_node) {
    adjlistptr       al;
    orthogonalrepptr new_node = actual_node;
    int              new_node_number;

    al = actual_node->adjazent;
    while (al->dest != to)
      al = al->next;
    while (new_node->next)
      new_node = new_node->next;
    new_node_number = new_node->number + 1;
    new_node->next = (orthogonalrepptr) malloc (sizeof (orthogonalrep));
    new_node = new_node->next;
    new_node->number = new_node_number;
    new_node->help_node = 1;
    new_node->adjazent = new_adjlist (al->sym->dest);
    new_node->next = (orthogonalrepptr) NULL;
    new_node->adjazent->next = new_adjlist (al->dest);
    new_node->adjazent->sym = al;
    new_node->adjazent->next->next = new_node->adjazent;
    new_node->adjazent->next->sym = al->sym;
    al->sym->sym = new_node->adjazent->next;
    al->sym = new_node->adjazent;
    new_node->adjazent->next->ziel = al->ziel;
    al->ziel = new_node_number;
    new_node->adjazent->ziel = new_node->adjazent->next->sym->ziel;
    new_node->adjazent->next->sym->ziel = new_node_number;
    new_node->adjazent->winkel = al->winkel + 180;
    if (new_node->adjazent->winkel > 360)
      new_node->adjazent->winkel -= 360;
    if (left_angle) {
      new_node->adjazent->angle = 1;
      new_node->adjazent->next->angle = 3;
      new_node->adjazent->next->winkel = new_node->adjazent->winkel + 90;
      if (new_node->adjazent->next->winkel > 360)
        new_node->adjazent->next->winkel -= 360;
    }
    else {
      new_node->adjazent->angle = 3;
      new_node->adjazent->next->angle = 1;
      new_node->adjazent->next->winkel = new_node->adjazent->winkel - 90;
      if (new_node->adjazent->next->winkel < 90)
        new_node->adjazent->next->winkel += 360;
    }
    return (new_node);
  }
  else
    return ((orthogonalrepptr) NULL);
}



/****************************************************************************/
/* NAME : increase_bends                                                    */
/* FUNKTION : Inkrementierung des Feldes bends in einer Kante einer         */
/*            Orthogonal Representation                                     */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonal Representation;          */
/*                      Kante (from, to)                                    */
/* VORAUSSETZUNG: from, to und (from, to) sind in or enthalten (wird nicht  */
/*                geprueft)                                                 */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (09.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void increase_bends (orthogonalrepptr or, int from, int to)
{
  if (or) {
    while (or) {
      if (or->number != from)
        or = or->next;
      else {
        adjlistptr al;

        al = or->adjazent;
        while (al->dest != to)
          al = al->next;
        al->bends++;
        break;
      }
    }
  }
}




/****************************************************************************/
/* NAME : set_node_order                                                    */
/* FUNKTION : Umsortierung der Kantenreihenfolge um einen Knoten in einer   */
/*            Orthogonal Representation                                     */
/* UEBERGABEPARAMETER : Zeiger auf den aktuellen Knoten in einer Orthogonal */
/*                      Representation; Zeiger auf eine Liste von Integers  */
/* VORAUSSETZUNG: Die Integers sind Nummern von adjazenten Knoten (wird     */
/*                nicht geprueft)                                           */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (09.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void set_node_order (orthogonalrepptr actual_node, p_intList order)
{
  if ((actual_node) && (order)) {
    p_intList  order_copy = copyIntList (order);
    adjlistptr al_1;
    adjlistptr al_2;
    adjlistptr al_3;
    adjlistptr al_4;
    int        node_1;

    al_1 = actual_node->adjazent;
    node_1 = popFirst (order_copy);
    while (al_1->dest != node_1)
      al_1 = al_1->next;
    al_2 = new_adjlist (node_1);
    al_2->angle = al_1->angle;
    al_2->bends = al_1->bends;
    al_2->winkel = al_1->winkel;
    al_2->ziel = al_1->ziel;
    al_2->sym = al_1->sym;
    al_2->sym->sym = al_2;
    al_3 = al_2;

    while (order_copy->first) {
      node_1 = popFirst (order_copy);
      while (al_1->dest != node_1)
        al_1 = al_1->next;
      al_4 = new_adjlist (node_1);
      al_4->angle = al_1->angle;
      al_4->bends = al_1->bends;
      al_4->winkel = al_1->winkel;
      al_4->ziel = al_1->ziel;
      al_4->sym = al_1->sym;
      al_4->sym->sym = al_4;
      al_3->next = al_4;
      al_3 = al_4;
    }
    al_3->next = al_2;
    actual_node->adjazent = al_2;
    del_adjlist (al_1);
    clearIntList (order_copy);
  }
}



/****************************************************************************/
/* NAME : transformation_T1                                                 */
/* FUNKTION : Durchfuehrung der Transformation T1 aus dem Paper "Planar     */
/*            Grid Embedding in Linear Time" von Tamassia und Tollis        */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonal Representation           */
/* VORAUSSETZUNG: or muss ordnungsgemaess entstanden sein (darf keinen Mist */
/*                enthalten)                                                */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (09.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void transformation_T1 (orthogonalrepptr or)
{
  adjlistptr       al;
  adjlistptr       al_sym;
  adjlistptr       al_tmp;
  orthogonalrepptr or_tmp;
  int              help_node_1;
  int              help_node_2;
  unsigned int     minimum;

  or_tmp = or;
  while (or_tmp) {
    al = or_tmp->adjazent;
    if (al)
      do {

        /* Die Prozedur muss fuer jede Kante nur einmal durchgefueht werden */
        /* (Der Graph wird ungerichtet repraesentiert!).                    */
        if (al->dest > or_tmp->number) {

          /* Da Hilfsknoten eingefuehrt worden sind, wird in al_sym der     */
          /* symmetrische Zeiger des Destination-Knotens abgespeichert.     */
          al_sym = al;
          while (al_sym->dest != al_sym->ziel)
            al_sym = al_sym->sym->next;
          al_sym = al_sym->sym;

          /* Befinden sich auf der Kante Knicke nach links und nach rechts? */
          if ((al->bends > 0) && (al_sym->bends > 0)) {
            minimum = al->bends;
            if (al_sym->bends < minimum)
              minimum = al_sym->bends;
            al->bends -= minimum;
            al_sym->bends -= minimum;

            /* minimum gibt an, wieviele Paare von Hilfsknoten entfernt     */
            /* werden muessen.                                              */
            while (minimum) {

              /* Es existieren zwei verbundene Hilfsknoten, die je einen    */
              /* Knick nach links und nach rechts darstellen.               */
              al_tmp = al;
              while (al_tmp->winkel != al_tmp->sym->next->sym->next->winkel)
                al_tmp = al_tmp->sym->next;
              help_node_1 = al_tmp->ziel;
              help_node_2 = al_tmp->sym->next->ziel;
              if (del_nodepair_from_orthogonal (or, help_node_1, help_node_2))
                minimum--;
            }

          }
        }
        al = al->next;
      } while (al != or_tmp->adjazent);
    or_tmp = or_tmp->next;
  }
}




/****************************************************************************/
/* NAME : transformation_T2                                                 */
/* FUNKTION : Durchfuehrung der Transformation T2 aus dem Paper "Planar     */
/*            Grid Embedding in Linear Time" von Tamassia und Tollis        */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonal Representation           */
/* VORAUSSETZUNG: or muss ordnungsgemaess entstanden sein (darf keinen Mist */
/*                enthalten)                                                */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (09.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void transformation_T2 (orthogonalrepptr or)
{
  orthogonalrepptr or_tmp;
  adjlistptr       al;
  adjlistptr       al_sym;
  unsigned int     minimum;

  or_tmp = or;
  while (or_tmp) {
    al = or_tmp->adjazent;
    if (al) {

      /* Case 1 */
      minimum = al->bends;
      al = al->next;
      while (al != or_tmp->adjazent) {
        if (al->bends < minimum)
          minimum = al->bends;
        al = al->next;
      }
      if (minimum) {
        al->bends -= minimum;
        al = al->next;
        while (al != or_tmp->adjazent) {
          al->bends -= minimum;
          al = al->next;
        }
        while (minimum) {
          del_help_nodes_around_node (or, or_tmp, 1);
          minimum--;
        }
      }

      /* Case 2 */
      al_sym = al;
      while (al_sym->dest != al_sym->ziel)
        al_sym = al_sym->sym->next;
      al_sym = al_sym->sym;
      minimum = al_sym->bends;
      al = al->next;
      while (al != or_tmp->adjazent) {
        al_sym = al;
        while (al_sym->dest != al_sym->ziel)
          al_sym = al_sym->sym->next;
        al_sym = al_sym->sym;
        if (al_sym->bends < minimum)
          minimum = al_sym->bends;
        al = al->next;
      }
      if (minimum) {
        al_sym = al;
        while (al_sym->dest != al_sym->ziel)
          al_sym = al_sym->sym->next;
        al_sym = al_sym->sym;
        al_sym->bends -= minimum;
        al = al->next;
        while (al != or_tmp->adjazent) {
          al_sym = al;
          while (al_sym->dest != al_sym->ziel)
            al_sym = al_sym->sym->next;
          al_sym = al_sym->sym;
          al_sym->bends -= minimum;
          al = al->next;
        }
        while (minimum) {
          del_help_nodes_around_node (or, or_tmp, 0);
          minimum--;
        }
      }
    }
    or_tmp = or_tmp->next;
  }
}






/****************************************************************************/
/* NAME : transformation_T3                                                 */
/* FUNKTION : Durchfuehrung der Transformation T3 aus dem Paper "Planar     */
/*            Grid Embedding in Linear Time" von Tamassia und Tollis        */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonal Representation           */
/* VORAUSSETZUNG: or muss ordnungsgemaess entstanden sein (darf keinen Mist */
/*                enthalten)                                                */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (09.02.1999)                                 */
/* LETZTE AENDERUNG AM : 10.02.1999                                         */
/****************************************************************************/

void transformation_T3 (orthogonalrepptr or)
{
  orthogonalrepptr tmp_or = or;
  adjlistptr       al;
  adjlistptr       al_next_sym;
  unsigned int     minimum;
  int              first_node;

  while (tmp_or) {
    al = tmp_or->adjazent;
    first_node = al->dest;
    if (al)
      do {
        /* Case 1 */
        if ((al->angle >= 2) && (al->next->bends >= 1)) {
          minimum = al->angle - 1;
          if (al->next->bends < minimum)
            minimum = al->next->bends;
          al->angle -= minimum;
          al->next->angle += minimum;
          al->next->bends -= minimum;
          first_node = al->dest;
          while (minimum) {
            del_help_node_from_orthogonal_edge (or, al->next);
            minimum--;
          }
        }
        /* Case 2 */
        al_next_sym = al->next;
        while (al_next_sym->dest != al_next_sym->ziel)
          al_next_sym = al_next_sym->sym->next;
        al_next_sym = al_next_sym->sym;
        if ((al->next->angle >= 2) && (al_next_sym->bends >= 1)) {
          minimum = al->next->angle - 1;
          if (al_next_sym->bends < minimum)
            minimum = al_next_sym->bends;
          al->angle += minimum;
          al->next->angle -= minimum;
          al_next_sym->bends -= minimum;
          first_node = al->dest;
          while (minimum) {
            del_help_node_from_orthogonal_edge (or, al->next);
            minimum--;
          }
        }
        al = al->next;
      } while (first_node != al->dest);
    tmp_or = tmp_or->next;
  }
}



/****************************************************************************/
/* NAME : del_nodepair_from_orthogonal                                      */
/* FUNKTION : Loeschen zweier Hilfsknoten aus einer Orthogonal              */
/*            Representation und Verschiebung bestimmter Knoten             */
/* UEBERGABEPARAMETER : Zeiger auf Orthogonal Representation; Knotennummern */
/* VORAUSSETZUNG: Die beiden Knoten sind in der Orthogonalen Representation */
/*                vorhanden und miteinander verbunden und haben Grad 2      */
/* RUECKGABEWERT : 0, falls etwas nicht in Ordnung ist; 1 sonst             */
/* ERSTELLT VON : Ulf Milanese (09.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

int del_nodepair_from_orthogonal (orthogonalrepptr or, int help_node_1,
                                  int help_node_2)
{
  orthogonalrepptr or_1;
  orthogonalrepptr or_2;
  orthogonalrepptr or_1_prec = (orthogonalrepptr) NULL;
  orthogonalrepptr or_2_prec= (orthogonalrepptr) NULL;
  orthogonalrepptr tmp_or;
  adjlistptr       al_1;
  adjlistptr       al_2;
  adjlistptr       al_3;
  adjlistptr       al_4;
  int              node_1 = help_node_1;
  int              node_2 = help_node_1;
  int              node_3;
  int              node_4;
  int              vertikal_edge = 1;
  int              top_left = 1;
  int              delta = 0;
  int              min_value = 0;
  int              max_value = 0;

  /* node_1 = minimum (help_node_1, help_node_2), node_2 = maximum          */
  if (help_node_1 < help_node_2)
    node_2 = help_node_2;
  else
    node_1 = help_node_2;

  or_1 = or;
  while (or_1)
    if (or_1->number != node_1)
      or_1 = or_1->next;
    else
      break;
  if (!or_1)
    return (0);
  /* Jetzt ist gesichert, dass node_1 in or vorhanden ist.                  */

  /* al_1 zeigt auf das Ziel node_2                                         */
  al_1 = or_1->adjazent;
  if (al_1->ziel != node_2)
    al_1 = al_1->next;

  or_2 = or_1->next;
  while (or_2)
    if (or_2->number != node_2)
      or_2 = or_2->next;
    else
      break;
  if (!or_2)
    return (0);
  /* Jetzt ist gesichert, dass node_2 in or vorhanden ist.                  */

  /* al_2 zeigt auf das Ziel node_1                                         */
  al_2 = or_2->adjazent;
  if (al_2->ziel != node_1)
    al_2 = al_2->next;

  /* al_3 und al_4 sind die beiden Kanten, die die Knoten ueberbruecken     */
  al_3 = al_1->next->sym;
  al_4 = al_2->next->sym;
  node_3 = al_1->next->ziel;
  node_4 = al_2->next->ziel;
  al_3->sym = al_4;
  al_4->sym = al_3;
  al_3->ziel = node_4;
  al_4->ziel = node_3;
  al_1->next->sym = (adjlistptr) NULL;
  al_2->next->sym = (adjlistptr) NULL;

  if (or_1->pos_x < or_2->pos_x) {
    min_value = or_1->pos_x;
    max_value = or_2->pos_x;
    vertikal_edge = 0;
    delta = or_2->pos_x - or_1->pos_x;
    if (al_2->next->winkel == 360)
      top_left = 0;
  }
  if (or_1->pos_x > or_2->pos_x) {
    min_value = or_2->pos_x;
    max_value = or_1->pos_x;
    delta = or_1->pos_x - or_2->pos_x;
    vertikal_edge = 0;
    if (al_2->next->winkel == 180)
      top_left = 0;
  }
  if (or_1->pos_y < or_2->pos_y) {
    min_value = or_1->pos_y;
    max_value = or_2->pos_y;
    delta = or_2->pos_y - or_1->pos_y;
    if (al_2->next->winkel == 270)
      top_left = 0;
  }
  if (or_1->pos_y > or_2->pos_y) {
    min_value = or_2->pos_y;
    max_value = or_1->pos_y;
    delta = or_1->pos_y - or_2->pos_y;
    if (al_2->next->winkel == 90)
      top_left = 0;
  }

  tmp_or = or;
  do {
    if (vertikal_edge)
      if (tmp_or->pos_y > max_value)
        tmp_or->pos_y += delta;
      else {
        if ((top_left) && (tmp_or->pos_y >= min_value) &&
            (tmp_or->pos_x < or_1->pos_x))
          tmp_or->pos_y += delta;
        if ((!top_left) && (tmp_or->pos_y >= min_value) &&
            (tmp_or->pos_x > or_1->pos_x))
          tmp_or->pos_y += delta;
      }
    else
      if (tmp_or->pos_x > max_value)
        tmp_or->pos_x += delta;
      else {
        if ((top_left) && (tmp_or->pos_x >= min_value) &&
            (tmp_or->pos_y < or_1->pos_y))
          tmp_or->pos_x += delta;
        if ((!top_left) && (tmp_or->pos_x >= min_value) &&
            (tmp_or->pos_y > or_1->pos_y))
          tmp_or->pos_x += delta;
      }
    if (tmp_or->next) {
      if (tmp_or->next->number == node_1)
        or_1_prec = tmp_or;
      if (tmp_or->next->number == node_2)
        or_2_prec = tmp_or;
    }
    tmp_or = tmp_or->next;
  } while (tmp_or);

  or_2_prec->next = or_2->next;
  or_2->next = (orthogonalrepptr) NULL;
  del_orthogonal_representation (or_2);
  or_1_prec->next = or_1->next;
  or_1->next = (orthogonalrepptr) NULL;
  del_orthogonal_representation (or_1);
  return (1);
}



/****************************************************************************/
/* NAME : del_help_nodes_around_node                                        */
/* FUNKTION : Loescht in einer Orthogonal Representation auf den inzidenten */
/*            Kanten eines Knotens den jeweils ersten Hilfsknoten           */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonal Representation; Zeiger   */
/*                      auf den aktuellen Knoten; Information, ob es sich   */
/*                      jeweils linke oder rechte Knicke handelt.           */
/* VORAUSSETZUNG: Die Orthogonal Representation muss korrekt sein.          */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (10.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void del_help_nodes_around_node (orthogonalrepptr or, orthogonalrepptr node,
                                 int left_bend)
{
  int              min_value_x = node->pos_x;
  int              max_value_x = node->pos_x;
  int              delta_x = 0;
  int              min_value_y = node->pos_y;
  int              max_value_y = node->pos_y;
  int              delta_y = 0;
  int              new_pos_x;
  int              new_pos_y;
  int              help_node;
  orthogonalrepptr tmp_or;
  orthogonalrepptr prec_or = (orthogonalrepptr) NULL;
  orthogonalrepptr help_or = (orthogonalrepptr) NULL;
  adjlistptr       al = node->adjazent;

  do {
    help_node = al->ziel;
    tmp_or = or;
    while (tmp_or->next) {
      if (tmp_or->next->number == help_node) {
        prec_or = tmp_or;
        help_or = tmp_or->next;
        break;
      }
      tmp_or = tmp_or->next;
    }
    prec_or->next = help_or->next;
    help_or->next = (orthogonalrepptr) NULL;
    al->ziel = al->sym->next->ziel;
    al->sym->next->sym->ziel = node->number;
    al->sym = al->sym->next->sym;
    al->sym->sym = al;
    help_or->adjazent->sym = (adjlistptr) NULL;
    help_or->adjazent->next->sym = (adjlistptr) NULL;

    switch (al->winkel) {
    case 90:
      max_value_x = help_or->pos_x;
      break;
    case 180:
      max_value_y = help_or->pos_y;
      break;
    case 270:
      min_value_x = help_or->pos_x;
      break;
    case 360:
      min_value_y = help_or->pos_y;
      break;
    }
    del_orthogonal_representation (help_or);

    if (left_bend)
      al->winkel -= 90;
    else
      al->winkel += 90;
    if (al->winkel == 0)
      al->winkel = 360;
    if (al->winkel == 450)
      al->winkel = 90;
    al = al->next;
  } while (al != node->adjazent);

  delta_x = max_value_x - min_value_x;
  delta_y = max_value_y - min_value_y;

  tmp_or = or;
  while (tmp_or) {
    new_pos_x = tmp_or->pos_x;
    new_pos_y = tmp_or->pos_y;
    if (tmp_or->pos_x > max_value_x)
      new_pos_x += delta_x;
    else {
      if (left_bend && (tmp_or->pos_x >= min_value_x) &&
          (tmp_or->pos_y > node->pos_y))
        new_pos_x += delta_x;
      if (!left_bend && (tmp_or->pos_x >= min_value_x) &&
          (tmp_or->pos_y < node->pos_y))
        new_pos_x += delta_x;
    }
    if (tmp_or->pos_y > max_value_y)
      new_pos_y += delta_y;
    else {
      if (left_bend && (tmp_or->pos_y >= min_value_y) &&
          (tmp_or->pos_x < node->pos_x))
        new_pos_y += delta_y;
      if (!left_bend && (tmp_or->pos_y >= min_value_y) &&
          (tmp_or->pos_x > node->pos_x))
        new_pos_y += delta_y;
    }
    tmp_or->pos_x = new_pos_x;
    tmp_or->pos_y = new_pos_y;
    tmp_or = tmp_or->next;
  }
  node->pos_x = max_value_x;
  node->pos_y = max_value_y;
}



/****************************************************************************/
/* NAME : del_help_node_from_orthogonal_edge                                */
/* FUNKTION : Loescht den ersten Hilfsknoten auf einer Kante in einer       */
/*            Orthogonal Representation                                     */
/* UEBERGABEPARAMETER : Zeiger auf Orthogonal Representation; Zeiger auf    */
/*                      die Kante in der Adjazenz-Liste                     */
/* VORAUSSETZUNG: or wurde korrekt erzeugt; Kante enthaelt Hilfsknoten      */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (10.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void del_help_node_from_orthogonal_edge (orthogonalrepptr or, adjlistptr al)
{
  orthogonalrepptr tmp_or;
  orthogonalrepptr prec_or = (orthogonalrepptr) NULL;
  orthogonalrepptr help_or = (orthogonalrepptr) NULL;
  orthogonalrepptr node_or = (orthogonalrepptr) NULL;
  int              help_node = al->ziel;
  int              min_value_x;
  int              max_value_x;
  int              min_value_y;
  int              max_value_y;
  int              delta_x = 0;
  int              delta_y = 0;
  int              top_left = 0;

  tmp_or = or;
  while (tmp_or) {
    if (tmp_or->number == al->sym->ziel)
      node_or = tmp_or;
    if (tmp_or->next->number == help_node){
      prec_or = tmp_or;
      help_or = tmp_or->next;
      break;
    }
    tmp_or = tmp_or->next;
  }

  min_value_x = max_value_x = node_or->pos_x;
  min_value_y = max_value_y = node_or->pos_y;

  switch (al->winkel) {
  case 90:
    max_value_x = node_or->pos_x = help_or->pos_x;
    delta_x = max_value_x - min_value_x;
    if (al->sym->next->winkel == 180)
      top_left = 1;
    break;
  case 180:
    max_value_y = node_or->pos_y = help_or->pos_y;
    delta_y = max_value_y - min_value_y;
    if (al->sym->next->winkel == 90)
      top_left = 1;
    break;
  case 270:
    min_value_x = help_or->pos_x;
    delta_x = max_value_x - min_value_x;
    if (al->sym->next->winkel == 360)
      top_left = 1;
    break;
  case 360:
    min_value_y = help_or->pos_y;
    delta_y = max_value_y - min_value_y;
    if (al->sym->next->winkel == 270)
      top_left = 1;
    break;
  }
  al->winkel = al->sym->next->winkel;

  al->ziel = al->sym->next->ziel;
  al->sym->next->sym->ziel = node_or->number;
  al->sym = al->sym->next->sym;
  al->sym->sym = al;
  help_or->adjazent->sym = (adjlistptr) NULL;
  help_or->adjazent->next->sym = (adjlistptr) NULL;
  prec_or->next = help_or->next;
  help_or->next = (orthogonalrepptr) NULL;
  del_orthogonal_representation (help_or);

  tmp_or = or;
  while (tmp_or) {
    if (tmp_or->pos_x > max_value_x)
      tmp_or->pos_x += delta_x;
    else {
      if ((top_left) && (tmp_or->pos_x >= min_value_x) &&
          (tmp_or->pos_y < max_value_y))
        tmp_or->pos_x += delta_x;
      if ((!top_left) && (tmp_or->pos_x >= min_value_x) &&
          (tmp_or->pos_y > max_value_y))
        tmp_or->pos_x += delta_x;
    }
    if (tmp_or->pos_y > max_value_y)
      tmp_or->pos_y += delta_y;
    else {
      if ((top_left) && (tmp_or->pos_y >= min_value_y) &&
          (tmp_or->pos_x < max_value_x))
        tmp_or->pos_y += delta_y;
      if ((!top_left) && (tmp_or->pos_y >= min_value_y) &&
          (tmp_or->pos_x > max_value_x))
        tmp_or->pos_y += delta_y;
    }
    tmp_or = tmp_or->next;
  }
}


/****************************************************************************/
/* NAME : renumber_orthogonal_representation                                */
/* FUNKTION : Vergibt den einzelnen Knoten der Orthogonal Representation    */
/*            eine fortlaufende Nummerierung                                */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonal Representation           */
/* VORAUSSETZUNG: Es duerfen nur Hilfsknoten umnummeriert werden.           */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (10.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/
void renumber_orthogonal_representation (orthogonalrepptr or)
{
  int node_number = 0;
  adjlistptr al;

  while (or) {
    if (or->help_node) {
      or->number = node_number;
      al = or->adjazent;
      if (al)
        do {
          al->sym->ziel = node_number;
          al = al->next;
        } while (al != or->adjazent);
    }
    or = or->next;
    node_number++;
  }
}



/****************************************************************************/
/* NAME : make_horizontal_space_in_orthogonal                               */
/* FUNKTION : Verschiebt Knoten aus dem Bereich, der fuer eine neue Kante   */
/*            vorgesehen ist                                                */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonale Represetation or;       */
/*                      y-Position der Kante und x-Positionen der Knoten    */
/* VORAUSSETZUNG : pos_x_1 < pos_x_2                                        */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (15.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void make_horizontal_space_in_orthogonal (orthogonalrepptr or, int pos_y,
                                          int pos_x_1, int pos_x_2)
{
  while (or) {
    if ((or->pos_y > pos_y) ||
        ((or->pos_y == pos_y) && (or->pos_x > pos_x_1) &&
         ((or->pos_x < pos_x_2) || (pos_x_2 == -1))))
      or->pos_y++;
    or = or->next;
  }
}



/****************************************************************************/
/* NAME : make_vertikal_space_in_orthogonal                                 */
/* FUNKTION : Verschiebt Knoten aus dem Bereich, der fuer eine neue Kante   */
/*            vorgesehen ist                                                */
/* UEBERGABEPARAMETER : Zeiger auf eine Orthogonale Represetation or;       */
/*                      x-Position der Kante und y-Positionen der Knoten    */
/* VORAUSSETZUNG : pos_y_1 < pos_y_2                                        */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (15.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void make_vertikal_space_in_orthogonal (orthogonalrepptr or, int pos_x,
                                        int pos_y_1, int pos_y_2)
{
  while (or) {
    if ((or->pos_x > pos_x) ||
        ((or->pos_x == pos_x) && (or->pos_y > pos_y_1) &&
         ((or->pos_y < pos_y_2) || (pos_y_2 == -1))))
      or->pos_x++;
    or = or->next;
  }
}



/****************************************************************************/
/* NAME : make_edge_in_orthogonal                                           */
/* FUNKTION : Fuegt in zwei Adjazenz-Listen eine weitere Kante hinzu        */
/* UEBERGABEPARAMETER : Zeiger auf die Adjazenz-Listen; die Ausgangs-       */
/*                      Winkel; die Nummern der Knoten                      */
/* VORAUSSETZUNG : keine                                                    */
/* RUECKGABEWERT :keiner                                                    */
/* ERSTELLT VON : Ulf Milanese (15.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

void make_edge_in_orthogonal (adjlistptr al_1, int winkel_1,
                              int dest_1, int ziel_1,
                              adjlistptr al_2, int winkel_2,
                              int dest_2, int ziel_2)
{
  adjlistptr new_1;
  adjlistptr new_2;

  new_1 = new_adjlist (dest_2);
  new_1->ziel = ziel_2;
  new_1->winkel = winkel_1;
  new_1->next = al_1->next;
  al_1->next = new_1;
  if (((unsigned int) winkel_1) < al_1->winkel)
    winkel_1 += 360;
  new_1->angle = al_1->angle - ((winkel_1 - al_1->winkel) / 90);
  al_1->angle = (winkel_1 - al_1->winkel) / 90;

  new_2 = new_adjlist (dest_1);
  new_2->ziel = ziel_1;
  new_2->winkel = winkel_2;
  new_2->next = al_2->next;
  al_2->next = new_2;
  if (((unsigned int) winkel_2) < al_2->winkel)
    winkel_2 += 360;
  new_2->angle = al_2->angle - ((winkel_2 - al_2->winkel) / 90);
  al_2->angle = (winkel_2 - al_2->winkel) / 90;

  new_1->sym = new_2;
  new_2->sym = new_1;
}



/****************************************************************************/
/* NAME : manhattan_distance                                                */
/* FUNKTION : Berechnet die L1-Distanz zweier Koordinaten im N x N          */
/* UEBERGABEPARAMETER : (x, y)-Koordinaten zweier Punkte                    */
/* VORAUSSETZUNG : keine                                                    */
/* RUECKGABEWERT : Integer                                                  */
/* ERSTELLT VON : Ulf Milanese (16.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/****************************************************************************/

unsigned int manhattan_distance (unsigned int x_1, unsigned int y_1,
                                 unsigned int x_2, unsigned int y_2)
{
  unsigned int resultat;

  if (x_1 > x_2)
    resultat = x_1 - x_2;
  else
    resultat = x_2 - x_1;
  if (y_1 > y_2)
    resultat += y_1 - y_2;
  else
    resultat += y_2 - y_1;
  return (resultat);
}



#if 0
/****************************************************************************/
/* NAME : print_relation                                                    */
/* FUNKTION : Debug-Ausgabe einer Relation                                  */
/* UEBERGABEPARAMETER : Zeiger auf eine Relation                            */
/* VORAUSSETZUNG: keine                                                     */
/* RUECKGABEWERT : keiner                                                   */
/* ERSTELLT VON : Ulf Milanese (10.02.1999)                                 */
/* LETZTE AENDERUNG AM :                                                    */
/* Umstellung auf grosse Zahlen: 15.05.2000                                 */
/****************************************************************************/
void print_relation (Rel * relData)
{
  Kure_MINT * COUNTER_1;
  Kure_MINT * COUNTER_2;
  Kure_MINT * ZERO;
  char * ausgabe_hoehe;
  char * ausgabe_breite;
  char * ausgabe_counter_1;
  char * ausgabe_string_1;
  int vars_zeilen;
  int vars_spalten;
  ZERO = Kure_mp_itom (0);
  COUNTER_1 = Kure_mp_itom (0);
  COUNTER_2 = Kure_mp_itom (0);

  ausgabe_hoehe = (char *) malloc (sizeof (char)
                                   * (Kure_mp_laenge ((relData->hoehe))));
  ausgabe_breite = (char *) malloc (sizeof (char)
                                    * (Kure_mp_laenge ((relData->breite))));
  ausgabe_counter_1 = (char *) malloc (sizeof (char)
                                       * (Kure_mp_laenge (COUNTER_1)));
  ausgabe_string_1 = (char *) malloc (sizeof (char)
                                       * (Kure_mp_laenge (COUNTER_1)));

  puts ("Relation");

  ausgabe_hoehe = Kure_mp_ausgabe (relData->hoehe, 1, 3);
  ausgabe_breite = Kure_mp_ausgabe (relData->breite, 1, 3);
  printf ("zeilen: %s, spalten: %s\n", ausgabe_hoehe, ausgabe_breite);

  printf ("   ");
  Kure_mp_copy (ZERO, COUNTER_1);
  while (Kure_mp_mcmp (COUNTER_1, relData->breite) < 0) {
    ausgabe_string_1 = Kure_mp_ausgabe (COUNTER_1, 1, 3);
    printf ("%s", ausgabe_counter_1);
    Kure_mp_incr (COUNTER_1);
  }
  printf ("\n");
  Kure_mp_copy (ZERO, COUNTER_1);

  vars_zeilen = Kure_mp_number_of_vars (relData->hoehe);
  vars_spalten = Kure_mp_number_of_vars (relData->breite);

  while (Kure_mp_mcmp (COUNTER_1, relData->hoehe) < 0) {
    ausgabe_counter_1 = Kure_mp_ausgabe (COUNTER_1, 1, 3);
    printf ("%s", ausgabe_counter_1);

    Kure_mp_copy (ZERO, COUNTER_2);
    while (Kure_mp_mcmp (COUNTER_2, relData->breite) < 0) {
      if (mp_get_rel_bit (relData, COUNTER_1, COUNTER_2,
                          vars_zeilen, vars_spalten))
        printf (" x ");
      else
        printf ("   ");
      Kure_mp_incr (COUNTER_2);
    }
    printf ("\n");
    Kure_mp_incr (COUNTER_1);
  }

  free (ausgabe_counter_1);
  free (ausgabe_hoehe);
  free (ausgabe_breite);
  Kure_mp_mfree (COUNTER_1);
  Kure_mp_mfree (COUNTER_2);
  Kure_mp_mfree (ZERO);
}
#endif

