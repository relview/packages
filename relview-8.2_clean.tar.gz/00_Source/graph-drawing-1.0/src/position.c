#define POSITION_FILE
#define PLANAR_DATA

#define _position_c_

#include "graph.h"
#include "position.h"
#include "embedding.h"
#include "planar.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <malloc.h>

/* NAME : computeBoundingBoxes 
 * FUNKTION : initialisiert Ausmasse der boundingBoxes 
 * VORAUSSETZUNG: Ranking auf der Partitionierung ist berechnet.
 * UEBERGABEPARAMETER : -
 * RUECKGABEWERT : Zeiger auf ein Array
 * ERSTELLT VON : Sascha Ulbrand (13.01.1999)
 * LETZTE AENDERUNG AM : 13.01.1999
 */
p_boundingBox *computeBoundingBoxes (void)
{
	p_adjList adj = planarData.embedding.embedding;
	int *ranking = planarData.embedding.ranking;
	p_intListNode pIter, gIter;
	int size = adj->size;
	int node;
	int i, in, out, count;

	int inl, inr, outl, outr, dl, dr;	/* described in [GM99] */

	p_boundingBox *result = (p_boundingBox *) malloc (sizeof (p_boundingBox) * size);

	p_intList order = getNewIntList ();

	count = 0;
	while (order->size < adj->size) {
		for (i = 0; i < adj->size; i++) {
			if (ranking[i] == count)
				addLast (order, i);
		}
		count++;
	}

	while (order->size) {
		node = popFirst (order);
		/* Anzahl der In und OutPoints berechen */
		in = out = 0;

		outl = outr = dl = dr = -1;

		pIter = adj->aList[node]->first;
		while (pIter) {
			if (ranking[node] < ranking[pIter->val]) {
				out++;
			} else {
				in++;
			}
			pIter = pIter->next;
		}

		result[node] = getNewBoundingBox (in, out);
		result[node]->nodeNum = node;

		/* Berechnung einiger Werte fuer Bestimmung der Outpoints */
		if (in >= 2) {
			outl = MAXIMUM (0, (out - 1) / 2);
			outr = out / 2;
			dl = 1;
			dr = 1;
		} else if (in == 1) {
			p_intListListNode lIter = planarData.embedding.ordpart->first;
			p_intListNode iIter;
			int pos;

			for (i = 0; i < ranking[node]; i++) {
				lIter = lIter->next;
				assert (lIter);		/* muss existieren */
				if (!lIter)
					assert (false);
			}

			assert (inList (lIter->data, node));

			pos = indexInList (lIter->data, node);

			if (pos == 0) {
				/* linker Knoten */
				if (lIter->data->size == 1) {
					/* Einzelknoten in V_k */
					gIter = adj->aList[node]->first;
					while (gIter && ranking[gIter->val] > ranking[node])
						gIter = gIter->next;
					assert (gIter);
					printf ("just one inpoint, ranking of inNeighbour = %i\n", ranking[gIter->val]);
					assert (false);
				} else {
					iIter = nodeInList (lIter->data, node);
					assert (iIter);
					assert (iIter->next);
					if (!areNeighbours (adj, node, iIter->next->val)) {
						outl = MAXIMUM (0, (out - 1) / 2);
						outr = out / 2;
						dl = 1;
						dr = 0;
					} else {
						outl = out / 2;
						outr = MAXIMUM (0, (out - 1) / 2);
						dl = 0;
						dr = 1;
					}
				}
			} else if (pos == lIter->data->size - 1) {
				/* rechter Knoten */
				iIter = nodeInList (lIter->data, node);
				assert (iIter);
				assert (iIter->prev);
				if (!areNeighbours (adj, node, iIter->prev->val)) {
					outl = out / 2;
					outr = MAXIMUM (0, (out - 1) / 2);
					dl = 0;
					dr = 1;
				} else {
					/* (node, right(V_k)) \not\in E, evtl. noch komplizierten assert einfuegen */
					outl = MAXIMUM (0, (out - 1) / 2);
					outr = out / 2;
					dl = 1;
					dr = 0;
				}
			} else {
				/* Knoten in der Mitte der Kette */
				iIter = nodeInList (lIter->data, node);
				assert (iIter);
				assert (iIter->prev && iIter->next);
				if (!areNeighbours (adj, node, iIter->prev->val)) {
					outl = out / 2;
					outr = MAXIMUM (0, (out - 1) / 2);
					dl = 0;
					dr = 1;
				} else {
					assert (areNeighbours (adj, node, iIter->next->val));
					outl = MAXIMUM (0, (out - 1) / 2);
					outr = out / 2;
					dl = 1;
					dr = 0;
				}
			}
		} else {
			assert (in == 0);
			outl = MAXIMUM (0, (out - 1) / 2);
			outr = out / 2;
			dl = 0;
			dr = 0;
		}

		assert (outl >= 0 && outr >= 0 && dl >= 0 && dr >= 0);	/* irgendein Fall muss eingetreten sein. */

		/* Berechnung der Outpoints */

		if (out) {
			count = 0;
			for (i = 0; i <= outl - 1; i++) {
				result[node]->outPoints[count]->xrel = -outl + i;
				result[node]->outPoints[count]->yrel = dl + i;
				count++;
			}

			result[node]->outPoints[count]->xrel = 0;
			result[node]->outPoints[count]->yrel = MAXIMUM (0, MAXIMUM (outl + dl - 1, outr + dr - 1));
			/* doppeltes MAXIMUM Nur zum abfangen des Sonderfalls mit in==out==1 */
			count++;

			for (i = 0; i < outr; i++) {
				result[node]->outPoints[count]->xrel = 1 + i;
				result[node]->outPoints[count]->yrel = outr + dr - 1 - i;
				count++;
			}
		}
		/* Berechnung der Inpoints */

		if (in <= 2) {
			for (i = 0; i < in; i++) {
				result[node]->inPoints[i]->xrel = 0;
				result[node]->inPoints[i]->yrel = 0;
			}
		} else if (in == 3) {
			result[node]->inPoints[0]->xrel = -1;
			result[node]->inPoints[0]->yrel = 0;

			result[node]->inPoints[1]->xrel = 0;
			result[node]->inPoints[1]->yrel = -1;

			result[node]->inPoints[2]->xrel = 1;
			result[node]->inPoints[2]->yrel = 0;
		} else {
			assert (in > 3);
			inl = MAXIMUM (0, (in - 3) / 2);
			inr = MAXIMUM (0, (in - 2) / 2);

			count = 0;
			result[node]->inPoints[count]->xrel = -inl - (in == 4);
			result[node]->inPoints[count]->yrel = 0;
			count++;

			for (i = 0; i < inl; i++) {
				result[node]->inPoints[count]->xrel = -inl + i;
				result[node]->inPoints[count]->yrel = -1 - i;
				count++;
			}

			result[node]->inPoints[count]->xrel = 0;
			result[node]->inPoints[count]->yrel = -inr ;
			/* Anders als in GM98 kann es sein, dass die Spitze unten nicht abgeflacht sein darf, wie sie es im Moment ist !
			 * in diesem Fall muss von diesem Wert noch einer abgezogen werden. Die korrekte Zeile lautet dann
			 * result[node]->inPoints[count]->yrel = -inr -1 ; */

			count++;

			for (i = 0; i < inr; i++) {
				result[node]->inPoints[count]->xrel = 1 + i;
				result[node]->inPoints[count]->yrel = -inr + i;
				count++;
			}

			result[node]->inPoints[count]->xrel = inr;
			result[node]->inPoints[count]->yrel = 0;
			count++;
		}

		/* Die Einbettung kann erst bei der Konstruktion der Positionen in die BoundingBoxes uebertragen werden */

	}
	delIntList (order);
	return (p_boundingBox *) result;
}

/* NAME : computeLevels
 * FUNKTION : Berechnet, wie viele Ebenen beim Anfuegen mehrerer Knoten benoetigt werden und traegt diese Informationen
 *            in die Bounding-Boxes ein.
 * UEBERGABEPARAMETER : Zeiger auf BoundingBoxes
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (22.01.1999)
 * LETZTE AENDERUNG AM : 08.02.1999
 */
void computeLevels (void)
{
	p_adjList adj = planarData.embedding.embedding;	/* just a shortcut as usual */
	p_ordpartition ord = planarData.embedding.ordpart;	/* just a shortcut */
	p_intListListNode mIter;
	p_intListNode cIter, sIter;
	p_intSet chainElems = getNewIntSet (adj->size);
	int neighbours;

	p_genList edgeStack = getNewGenList ();
	p_genList edgeNumbering = getNewGenList ();
	p_edge kante;
	p_weightedEdge newkante;
	int from, to, temp;
	int counter;
	p_ordpartition LevelMemory = getNewOrdPartition ();	/* ist keine ordPartition, aber die Struktur laesst sich missbrauchen */
	p_intList nodesToExamine = getNewIntList ();
	p_intList leftNodesToExamine = getNewIntList ();

	assert (planarData.mixedmodel.edgelevels == NULL);
	planarData.mixedmodel.edgelevels = getNewGenList ();

	mIter = ord->first;
	assert (mIter);
	assert (mIter->next);
	mIter = mIter->next;		/* erste Partition braucht nicht betrachtet zu werden,
	 * da keine inPoints echt nach unten existieren */

	while (mIter) {
		if (mIter->data->size > 1) {

			clearIntList (nodesToExamine);
			copyIntListToIntSet (chainElems, mIter->data);
			cIter = mIter->data->first;
			assert (cIter);
			while (cIter) {
				neighbours = countNeighboursIn (adj, cIter->val, chainElems);
				if ((neighbours == 2 && (cIter->prev == 0 || cIter->next == 0)) ||
						(neighbours > 2)) {
					addLast (nodesToExamine, cIter->val);
				}
				cIter = cIter->next;
			}

			if (nodesToExamine->size) {
				/* fuer die Kanten zwischen Knoten von mIter->data muessen Levels berechnet werden */

				clearIntList (leftNodesToExamine);

				cIter = mIter->data->first;
				while (nodesToExamine->size) {
					int node = nodesToExamine->first->val;

					addLast (leftNodesToExamine, node);
					while (cIter && cIter->val != node)
						cIter = cIter->next;
					assert (cIter);	/* es muss was gefunden werden */

					sIter = mIter->data->last;
					while (sIter && !areNeighbours (adj, node, sIter->val))
						sIter = sIter->prev;
					assert (sIter);

					while (cIter && cIter != sIter) {
						assert (nodesToExamine->first);
						if (cIter->val == nodesToExamine->first->val)
							delFirst (nodesToExamine);
						cIter = cIter->next;
					}
					assert (cIter);

					sIter = mIter->data->last;
					while (sIter && sIter->val != cIter->val && !areNeighbours (adj, sIter->val, cIter->val))
						sIter = sIter->prev;

					if ((cIter->next && (cIter->next->val == sIter->val) && (cIter->val == nodesToExamine->first->val)) ||
							(cIter->next == NULL && nodesToExamine->first != NULL))
						delFirst (nodesToExamine);
				}

				assert (leftNodesToExamine->size);

				while (leftNodesToExamine->size) {
					kante = (p_edge) malloc (sizeof (edge));

					kante->from = popFirst (leftNodesToExamine);

					cIter = mIter->data->last;
					while (cIter) {
						if (areNeighbours (adj, cIter->val, kante->from))
							break;
						cIter = cIter->prev;
					}
					assert (cIter);	/* es muss etwas gefunden werden */

					kante->to = cIter->val;

					while (edgeNumbering->size)
						free (popLastGen (edgeNumbering));
					clearOrdPartition (LevelMemory);
					counter = 0;

					addEdgeWeight (edgeNumbering, kante->from, kante->to, counter++);
					addLastGen (edgeStack, kante);
					kante = NULL;		/* for security reasons forget pointer ;-) */

					while (edgeStack->size) {
						/* weise der Kante eine Nummer zu */
						kante = (p_edge) popFirstGen (edgeStack);

						addLastOrdPart (LevelMemory, getNewIntList ());

						/* entlang der Flaeche wandern und ggf. Kanten auf den Stack legen */
						from = kante->from;
						to = kante->to;

						from = prevClockNode (adj, from, to);
						to = kante->from;

						while (from != kante->from) {
							/* ueberpruefen, ob from, to benachbart sind in Ck_1 == mIter->data */
							sIter = mIter->data->first;
							while (sIter && sIter->val != to)
								sIter = sIter->next;
							assert (sIter);	/* es muss was gefunden werden */
							assert (sIter->next);	/* und sIter darf nicht letzter Knoten der Partition sein */
							if (sIter->next->val != from) {
								/* diese Kante erhoeht den Level */
								p_edge kan = (p_edge) malloc (sizeof (edge));

								kan->from = to;
								kan->to = from;
								addLastGen (edgeStack, kan);
								addEdgeWeight (edgeNumbering, from, to, counter++);
								addToNthPartition (LevelMemory, getEdgeWeight (edgeNumbering, kante->from, kante->to), counter - 1);
							}
							temp = from;
							from = prevClockNode (adj, from, to);
							to = temp;
						}
						free (kante);
					}

					/* Levelmemory abarbeiten und Werte in die Boxes uebertragen */
					if (LevelMemory->size > 1) {
						int i;
						p_intListListNode lIter;
						int *heights = (int *) malloc (sizeof (int) * LevelMemory->size);

						initIntArr (heights, LevelMemory->size, -1);

						lIter = LevelMemory->last;
						for (i = LevelMemory->size - 1; i >= 0; i--, lIter = lIter->prev) {
							p_intListNode slIter = lIter->data->first;
							int max = 0;

							while (slIter) {
								assert (heights[slIter->val] != -1);	/* muss schon frueher gesetzt sein */
								max = MAXIMUM (max, heights[slIter->val]);
								slIter = slIter->next;
							}
							max += 1;		/* einen fuer den eigenen Level anfuegen */
							heights[i] = max;

							/* Wert in die Boxen uebertragen */
							newkante = cutEdgeWithWeight (edgeNumbering, i);
							assert (newkante);
							newkante->val = max;
							addLastGen (planarData.mixedmodel.edgelevels, newkante);
						}
						free (heights);
					} else if (LevelMemory->size == 1) {
						newkante = cutEdgeWithWeight (edgeNumbering, 0);
						newkante->val = 1;
						addLastGen (planarData.mixedmodel.edgelevels, newkante);
						assert (newkante);
					} else {
						/* nothing to do ;-) */
					}
				}

			}
		}
		mIter = mIter->next;
	}

	delGenList (edgeStack);
	delGenList (edgeNumbering);
	delIntSet (chainElems);
	delOrdPartition (LevelMemory);
	delIntList (nodesToExamine);
	delIntList (leftNodesToExamine);
}

/* NAME : overtakeEmbedding
 * FUNKTION : Einbettung in eine Boundingbox uebertragen
 * BEDINGUNG: Boundingbox mus In- und OutPoints haben
 * UEBERGABEPARAMETER : Einbettung (adj), Array von BoundingBoxes(boxes), Ranking (rank) und Node (node)
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (15.01.1999)
 * LETZTE AENDERUNG AM : 15.01.1999
 */
void overtakeEmbedding (p_adjList adj, p_boundingBox *boxes, int *rank, int node)
{
	p_intListNode gIter;
	int count;
	int maxlevel = -1;
	int currlevel;

	assert (adj && boxes && rank);
	assert (node >= 0);
	assert (boxes[node]->in > 0 && boxes[node]->out > 0);
	gIter = adj->aList[node]->first;
	assert (gIter);
	while (!(rank[gIter->val] <= rank[node] && rank[nextClock (gIter)->val] > rank[node]))
		gIter = nextClock (gIter);
	gIter = nextClock (gIter);

	for (count = 0; count < boxes[node]->out; count++, gIter = nextClock (gIter)) {
		boxes[node]->outPoints[count]->toNode = gIter->val;
		currlevel = getEdgeWeight (planarData.mixedmodel.edgelevels, node, gIter->val);
		assert (currlevel == NONE);	/* darf nicht sein, diese und die vorige Zeile koennen spaeter entfernt werden */
	}

	for (count = boxes[node]->in - 1; count >= 0; count--, gIter = nextClock (gIter)) {
		boxes[node]->inPoints[count]->toNode = gIter->val;
		currlevel = getEdgeWeight (planarData.mixedmodel.edgelevels, node, gIter->val);
		if (currlevel != NONE) {
			assert (currlevel >= 0);
			maxlevel = MAXIMUM (currlevel, maxlevel);
			boxes[node]->inPoints[count]->level = currlevel;
		}
	}

	boxes[node]->maxlevel = maxlevel;
}

/* NAME : overtakeEmbeddingWithKnownLeftmostInPoint
 * FUNKTION : Einbettung in eine Boundingbox uebertragen, Knoten hat nur Inpoints 
 * UEBERGABEPARAMETER : Einbettung (adj), Array von BoundingBoxes(boxes), Ranking (rank) und Node (node)
 *                      sowie Das Ziel von inPoints[0] (leftmost)
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (15.01.1999)
 * LETZTE AENDERUNG AM : 15.01.1999
 */
void overtakeEmbeddingWithKnownLeftmostInPoint (p_adjList adj, p_boundingBox *boxes, int node, int leftmost)
{
	p_intListNode gIter;
	int count;
	int maxlevel = -1;
	int currlevel;

	assert (adj && boxes);
	assert (node >= 0);
	assert (boxes[node]->in > 0 && boxes[node]->out == 0);

	gIter = adj->aList[node]->first;
	while (gIter && gIter->val != leftmost)
		gIter = gIter->next;
	assert (gIter);		/* sonst sind Parameter ungueltig */

	for (count = 0; count < boxes[node]->in; count++, gIter = prevClock (gIter)) {
		boxes[node]->inPoints[count]->toNode = gIter->val;
		currlevel = getEdgeWeight (planarData.mixedmodel.edgelevels, node, gIter->val);
		if (currlevel != NONE) {
			assert (currlevel >= 0);
			maxlevel = MAXIMUM (currlevel, maxlevel);
			boxes[node]->inPoints[count]->level = currlevel;
		}
	}
	boxes[node]->maxlevel = maxlevel;
}

/* NAME : computeMinimalHeight
 * FUNKTION : berechnet minimal notwendige Hoehe zwischen zwei Knoten auf einem Kreis
 * UEBERGABEPARAMETER : Zeiger auf Boxes (boxes), Kreis (Ck_1), Knotennummern (cl,cr)
 * BEDINGUNG : y-Positionen der Boxen auf Ck_1 sind gesetzt und Knoten cl und cr sind in Ck_1
 * RUECKGABEWERT : Hoehe
 * ERSTELLT VON : Sascha Ulbrand (28.01.1999)
 * LETZTE AENDERUNG AM : 28.01.1999
 */
int computeMinimalHeight (p_boundingBox *boxes, p_intList Ck_1, int cl, int cr)
{
	int maximalheight = 0;
	p_intListNode pIter;

	assert (boxes && Ck_1);
	assert (cl >= 0 && cr >= 0);

	pIter = Ck_1->first;
	while (pIter && pIter->val != cl)
		pIter = pIter->next;

	assert (pIter);		/* es muss was gefunden werden */

	do {
		assert (boxes[pIter->val]->y >= 0);		/* Position muss bereits gesetzt sein */
		maximalheight = MAXIMUM (maximalheight,
				boxes[pIter->val]->y + maximumToTop (boxes[pIter->val]));

		pIter = pIter->next;
	} while (pIter && pIter->prev->val != cr);

	assert (pIter || Ck_1->last->val == cr);	/* auch cr muss in Ck_1 sein */

	return maximalheight;
}

/* NAME : ShiftNodesInGraph  
 * FUNKTION : Funktion verschiebt Knoten im Graphen um einen Offset nach rechts
 * UEBERGABEPARAMETER : Zeiger auf BoundingBoxes (boxes), Referenzknoten (node) und Offset (offset), 
 *                      sowie (Gk_1Set) und (ranking) Raenge der Knoten, sowie (cl) bei Ketten
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (03.02.1999)
 * LETZTE AENDERUNG AM : 03.02.1999
 */
void ShiftNodesInGraph (p_boundingBox *boxes, int node, int offset, p_intSet Gk_1Set, int *ranking, int cl)
{
	p_intList queue;
	p_intList shiftnodes;
	p_intList taboo;
	p_intListNode sIter;
	int iindex;
	int v;

	assert (boxes && node >= 0 && offset > 0 && cl >= 0);

	/* printf ("call to ShiftNodesInGraph for RefNode %i by xoffset=%i, cl=%i \n", node, offset, cl); */

	if (offset == 0)
		return;

	queue = getNewIntList ();
	shiftnodes = getNewIntList ();
	taboo = getNewIntList ();

	addLast (queue, node);

	while (queue->size) {
		v = popFirst (queue);
		addLast (shiftnodes, v);
		iindex = 0;
		while (iindex < boxes[v]->in) {
			if (boxes[v]->inPoints[iindex]->xrel >= 0 &&
					!inList (shiftnodes, boxes[v]->inPoints[iindex]->toNode) &&
					!inList (queue, boxes[v]->inPoints[iindex]->toNode) &&
					(!boxes[v]->in == 2 || iindex != 0) &&
					ranking[v] > ranking[boxes[v]->inPoints[iindex]->toNode]
			)			/* alle nach rechts gehenden inEdges kleineren Rangs aufnehmen */
				addLast (queue, boxes[v]->inPoints[iindex]->toNode);
			iindex++;
		}
	}

	assert (queue->size == 0);

	if (boxes[node]->in) {
		v = boxes[node]->inPoints[0]->toNode;
		do {
			addLast (taboo, v);
			if (boxes[v]->in && (boxes[v]->inPoints[0]->xrel < 0 || boxes[v]->in == 2)) {
				v = boxes[v]->inPoints[0]->toNode;
			} else {
				v = -1;			/* Abbruchkriterium */
			}
		} while (v >= 0 && boxes[v]->x < boxes[node]->x);
		if (v >= 0)
			addLast (taboo, v);
	}

	v = Gk_1Set->firstElem;
	while (v != NONE) {
		if (boxes[v]->x >= 0 && boxes[v]->x > boxes[node]->x && !inList (shiftnodes, v) && !inList (taboo, v)) {
			addLast (shiftnodes, v);
		}
		v = Gk_1Set->nextElem[v];
	}

	delIntList (queue);
	queue = taboo;
	taboo = NULL;			/* safety first */

	addLast (queue, cl);
	while (queue->size) {
		v = popFirst (queue);
		delVal (shiftnodes, v);

		iindex = 0;
		while (iindex < boxes[v]->in) {
			if (boxes[v]->inPoints[iindex]->xrel >= 0 &&
					!inList (shiftnodes, boxes[v]->inPoints[iindex]->toNode) &&
					!inList (queue, boxes[v]->inPoints[iindex]->toNode) &&
					(!boxes[v]->in == 2 || iindex != 0) &&
					ranking[v] > ranking[boxes[v]->inPoints[iindex]->toNode]
			)			/* alle nach rechts gehenden inEdges kleineren Rangs aufnehmen */
				addLast (queue, boxes[v]->inPoints[iindex]->toNode);
			iindex++;
		}
	}

	sIter = shiftnodes->first;
	while (sIter) {
		assert (boxes[sIter->val]->x >= 0);		/* war Knoten schon vorher mal gesetzt? */
		boxes[sIter->val]->x += offset;
		sIter = sIter->next;
	}
	delIntList (shiftnodes);
	delIntList (queue);
}


/****************************************************************************/
/* NAME : computeMixModPositions                                            */
/* FUNKTION : berechnet die Positionen fuer Mixed-Model                     */
/* UEBERGABEPARAMETER : Zeiger auf ein Array mit initialisierten            */
/*                      BoundingBoxes                                       */
/* RUECKGABEWERT : -                                                        */
/* ERSTELLT VON : Sascha Ulbrand (08.01.1999)                               */
/* LETZTE AENDERUNG AM : 09.02.1999                                         */
/****************************************************************************/
void computeMixModPositions (p_boundingBox * boxes)
{
	p_adjList adj = planarData.embedding.embedding;
	int * rank = planarData.embedding.ranking;
	p_intList Ck_1 = getNewIntList ();	/* Front von C_{k-1} */
	p_intSet Ck_1Set = getNewIntSet (planarData.planar.adj->size);
	/* same as above, unordered with O(1)-access */
	p_intSet Gk_1Set = getNewIntSet (planarData.planar.adj->size);
	p_intListListNode mIter;
	int node;
	int v1;
	int vp;
	p_intListNode cl;
	p_intListNode cr;
	p_intListNode crl;
	p_intListNode crr;	/* fuer Fall von Faecher bei vp */
	p_intListNode vIter;
	p_intListNode gIter;
	int oindex;
	int offset;
	int totaloffset;
	int offset2;
	int iindex;
	int minimalX;
	int maxlevel;
	int i = 0;
	int ypos;
	int yoffset;
	int yoffset2;
	int yoffset3;
	int toNode;

	assert (planarData.connect.preorder->size > 4);
	/* sonst ist das was fuer die simplePositions-Spezialbehandlung
	 * von kleinen Graphen */
	assert (boxes);

	mIter = planarData.embedding.ordpart->first;
	assert (mIter);
	assert (mIter->data->size == 2);
	v1 = (mIter->data->first->val);
	vp = (mIter->data->last->val);

	/* printf ("v1=%i,vp=%i\n",v1,vp); */

	/* initialize Ck_1, Ck_1Set, Gk_1Set */
	addLast (Ck_1, v1);
	addLast (Ck_1, vp);
	intSetIncl (Ck_1Set, v1);
	intSetIncl (Ck_1Set, vp);
	intSetIncl (Gk_1Set, v1);
	intSetIncl (Gk_1Set, vp);

	boxes[v1]->y = 0;
	boxes[vp]->y = 0;

	assert (boxes[v1]->in && boxes[v1]->out);
	/* Knoten v1 muss in- und OutPoints haben */
	boxes[v1]->x = abs (MINIMUM (boxes[v1]->outPoints[0]->xrel,
			boxes[v1]->inPoints[0]->xrel));

	assert (boxes[vp]->in && boxes[vp]->out);
	/* Knoten vp muss in- und OutPoints haben */
	boxes[vp]->x =
			abs (minimumToLeft (boxes[v1])) + abs (maximumToRight (boxes[v1])) +
			abs (MINIMUM (boxes[vp]->outPoints[0]->xrel,
					boxes[vp]->inPoints[0]->xrel));

	if (boxes[vp]->x == 0)
		boxes[vp]->x = 1;

	if (boxes[v1]->x == boxes[vp]->x)
		boxes[vp]->x++;		/* durfen nicht aufeinanderliegen */

	/* Initialisation der Knoten v1 und vp */
	overtakeEmbedding (adj, boxes, rank, v1);
	overtakeEmbedding (adj, boxes, rank, vp);

	mIter = mIter->next;
	assert (mIter);

	while (mIter) {
		/* printf ("anfuegen einer weiteren Partition: ");
		 * printIntList (mIter->data);
		 * printf("\n"); */

		if (mIter->data->size == 1) {
			/* Einzelknoten anfuegen */
			node = mIter->data->first->val;
			/* printf ("Behandle Einzelknoten %i\n", node); */

			/* cl und cr berechnen */
			cl = Ck_1->first;
			while (cl && !areNeighbours (adj, cl->val, node))
				cl = cl->next;
			assert (cl);		/* es muss was gefunden werden */
			cr = Ck_1->last;
			while (cr && !areNeighbours (adj, cr->val, node))
				cr = cr->prev;
			assert (cr);		/* es muss was gefunden werden */

			/* printf ("cl = %i, cr = %i\n", cl->val, cr->val); */

			if (boxes[node]->out)
				overtakeEmbedding (adj, boxes, rank, node);
			else
				overtakeEmbeddingWithKnownLeftmostInPoint (adj, boxes, node, cl->val);

			if (boxes[node]->in == 2) {
				int toNode2, oindex2;

				/* Modifikation der BoundingBox notwendig */
				boxes[node]->inPoints[0]->xrel = -1;

				toNode = boxes[node]->inPoints[0]->toNode;

				/* Suche nach passendem OutPoint der Kante des inPoint[0] */
				oindex = 0;
				while (oindex < boxes[toNode]->out &&
						boxes[toNode]->outPoints[oindex]->toNode != node)
					oindex++;
				assert (oindex < boxes[toNode]->out);
				/* es muss was gefunden werden */

				boxes[node]->x = boxes[toNode]->x +
						boxes[toNode]->outPoints[oindex]->xrel +
						abs (minimumToLeft (boxes[node]));

				/* die +1 kommt von der relpos -1 des InPoints */

				toNode2 = boxes[node]->inPoints[1]->toNode;

				/* Suche nach passendem OutPoint der Kante des inPoint[1] */
				oindex2 = 0;
				while (oindex2 < boxes[toNode2]->out &&
						boxes[toNode2]->outPoints[oindex2]->toNode != node)
					oindex2++;
				assert (oindex2 < boxes[toNode2]->out);
				/* es muss was gefunden werden */

				offset = boxes[node]->x - boxes[toNode2]->x -
						boxes[toNode2]->outPoints[oindex2]->xrel;
				/* printf ("snode offset to node %i = %i\n",node,offset); */
				totaloffset = 0;

				if (offset > 0) {
					/* rechter Knoten (toNode2) muss weiter nach rechts */
					totaloffset += offset;
				}
				if (boxes[node]->out > 0) {
					offset = boxes[node]->outPoints[boxes[node]->out - 1]->xrel -
							boxes[node]->inPoints[1]->xrel;

					if (offset > 0) {
						/* rechter Knoten (toNode2) muss weiter nach rechts */
						totaloffset += offset;
					}
				}

				if (totaloffset > 0)
					ShiftNodesInGraph (boxes, toNode2, totaloffset, Gk_1Set, rank,
							cl->val);

				if (boxes[toNode]->x == boxes[toNode2]->x) {
					boxes[node]->y =
							MAXIMUM (boxes[toNode]->y +
									boxes[toNode]->outPoints[oindex]->yrel +
									(boxes[toNode]->outPoints[oindex]->yrel == 0 ? 1 : 0),
									boxes[toNode2]->y +
									boxes[toNode2]->outPoints[oindex2]->yrel +
									(boxes[toNode2]->outPoints[oindex2]->yrel == 0 ? 1 : 0));
					boxes[node]->inPoints[0]->xrel = 0;
					/* Modifikation rueckgaengig machen */
				} else {
					boxes[node]->y =
							computeMinimalHeight (boxes, Ck_1,
									boxes[node]->inPoints[0]->toNode,
									boxes[node]->inPoints[1]->toNode) +
									abs (minimumToBottom (boxes[node])) +
									(minimumToBottom (boxes[node]) == 0 ? 1 : 0) + 1;
				}

				/* Sonderbehandlung von Knoten 1 */
				if (boxes[node]->x > boxes[1]->x)
					boxes[1]->x = boxes[node]->x;

			} else {
				/* Einzelknoten anfuegen, Knoten hat mehr als 2 inPoints */
				/* Suche nach InPoint mit xrel == 0 */
				iindex = 0;
				while (iindex < boxes[node]->in &&
						boxes[node]->inPoints[iindex]->xrel != 0)
					iindex++;
				assert (iindex < boxes[node]->in);
				/* es muss was gefunden werden */

				toNode = boxes[node]->inPoints[iindex]->toNode;

				/* Suche nach passendem OutPoint des der gefundenen Kante */
				oindex = 0;
				while (oindex < boxes[toNode]->out &&
						boxes[toNode]->outPoints[oindex]->toNode != node)
					oindex++;
				assert (oindex < boxes[toNode]->out);
				/* es muss was gefunden werden */

				/* printf ("Setze Knoten %i ueber Knoten %i\n",
	   node,boxes[node]->inPoints[iindex]->toNode); */

				boxes[node]->x = boxes[toNode]->x +
						boxes[toNode]->outPoints[oindex]->xrel;
				boxes[node]->y =
						computeMinimalHeight
						(boxes, Ck_1,
								boxes[node]->inPoints[0]->toNode,
								boxes[node]->inPoints[boxes[node]->in - 1]->toNode) +
								abs (minimumToBottom (boxes[node])) +
								(minimumToBottom (boxes[node]) == 0 ? 1 : 0) + 1;

				/* Alle in-toNodes mit echt positivem xrel notfalls zurechtruecken */
				iindex = 0;
				while (iindex < boxes[node]->in) {
					if (boxes[node]->inPoints[iindex]->xrel > 0) {
						int toNode = boxes[node]->inPoints[iindex]->toNode;
						int diff;

						oindex = 0;
						while (oindex < boxes[toNode]->out &&
								boxes[toNode]->outPoints[oindex]->toNode != node)
							oindex++;
						assert (oindex < boxes[toNode]->out);
						/* es muss was gefunden werden */

						diff = boxes[toNode]->x + boxes[toNode]->outPoints[oindex]->xrel -
								(boxes[node]->x + boxes[node]->inPoints[iindex]->xrel);
						if (diff < 0) {
							/* Verschiebung notwendig */
							ShiftNodesInGraph (boxes, toNode, -diff, Gk_1Set, rank, cl->val);
						}
					}
					iindex++;
				}

			}

			/* Falls Faecher nach oben groesser als Faecher nach unten erneut   */
			/* shiften */
			/* zunaechst links nachsehen */
			if (boxes[node]->out && boxes[node]->in &&
					boxes[node]->outPoints[0]->xrel < boxes[node]->inPoints[0]->xrel) {
				ShiftNodesInGraph (boxes, node, -boxes[node]->outPoints[0]->xrel +
						boxes[node]->inPoints[0]->xrel,
						Gk_1Set, rank, cl->val);
			}
			/* dann rechts nachsehen */

			if (boxes[node]->out && boxes[node]->in) {
				int xAbs;
				int toNode;
				int xoffset;

				oindex = 0;
				toNode = boxes[node]->inPoints[boxes[node]->in - 1]->toNode;
				while (oindex < boxes[toNode]->out &&
						boxes[toNode]->outPoints[oindex]->toNode != node)
					oindex++;
				assert (oindex < boxes[toNode]->out);
				/* es muss was gefunden werden */
				xAbs = boxes[toNode]->x + boxes[toNode]->outPoints[oindex]->xrel;
				xoffset = (boxes[node]->x +
						boxes[node]->outPoints[boxes[node]->out - 1]->xrel) - xAbs;
				if (xoffset > 0)
					ShiftNodesInGraph (boxes, toNode, xoffset, Gk_1Set, rank, cl->val);
			}
			/* Ck_1, Ck_1Set und Gk_1 reparieren */
			gIter = mIter->data->first;
			while (gIter) {
				intSetIncl (Gk_1Set, gIter->val);
				intSetIncl (Ck_1Set, gIter->val);
				gIter = gIter->next;
			}

			replaceChain (cl, cr, mIter->data);

			gIter = mIter->data->first;
			while (gIter) {
				intSetExcl (Ck_1Set, gIter->val);
				gIter = gIter->next;
			}

			/* Ende des Anfuegens eines Einzelknotens */

		} else {
			/* mehrere Knoten anfuegen, zunaechst x-Positionen berechnen und     */
			/* Platz schaffen */
			v1 = mIter->data->first->val;
			vp = mIter->data->last->val;
			/* printf ("Behandele Kette, v1=%i, vp=%i\n",v1,vp); */

			/* zunaechst cl finden */
			cl = Ck_1->first;
			assert (cl);
			while (cl && !areNeighbours (adj, cl->val, v1))
				cl = cl->next;
			/* printf ("cl=%i\n",cl->val); */

			assert (cl);		/* muss was finden */
			assert (boxes[cl->val]->out > 0);
			for (oindex = 0; oindex < boxes[cl->val]->out; oindex++)
				if (boxes[cl->val]->outPoints[oindex]->toNode == v1)
					break;
			assert (oindex < boxes[cl->val]->out);
			/* sonst wurde nichts gefunden */

			/* printf ("oindex=%i\n",oindex); */

			assert (boxes[v1]->in > 0);
			boxes[v1]->x = boxes[cl->val]->x +
					boxes[cl->val]->outPoints[oindex]->xrel +
					abs (boxes[v1]->inPoints[0]->xrel);

			if (abs (boxes[v1]->inPoints[0]->xrel) == 0)
				boxes[v1]->x++;

			if (boxes[v1]->out &&
					boxes[v1]->outPoints[0]->xrel < boxes[v1]->inPoints[0]->xrel) {
				boxes[v1]->x +=
						abs (boxes[v1]->outPoints[0]->xrel - boxes[v1]->inPoints[0]->xrel);
				if (abs (boxes[v1]->inPoints[0]->xrel) == 0)
					boxes[v1]->x--;
			}
			/* printf ("x(v1)=%i\n", boxes[v1]->x); */

			if (boxes[v1]->out)
				overtakeEmbedding (adj, boxes, rank, v1);
			else
				overtakeEmbeddingWithKnownLeftmostInPoint (adj, boxes, v1, cl->val);

			/* Alle Knoten aus Vk zwischen v1 und vp in einer Reihe anordnen     */
			/* und Embedding uebernehmen */
			vIter = mIter->data->first;
			assert (vIter->next);
			vIter = vIter->next;	/* vIter zeigt auf v2 */
			while (vIter->next) {
				assert (vIter->prev && vIter->next);
				offset = maximumToRight (boxes[vIter->prev->val]) +
						abs (minimumToLeft (boxes[vIter->val])) + 1;
				boxes[vIter->val]->x = boxes[vIter->prev->val]->x + offset;
				/* printf ("Berechne x fuer v_%i: Result=%i\n",vIter->val,
	   boxes[vIter->val]->x); */

				if (boxes[vIter->val]->out)
					overtakeEmbedding (adj, boxes, rank, vIter->val);
				else
					overtakeEmbeddingWithKnownLeftmostInPoint
					(adj, boxes, vIter->val, vIter->prev->val);

				/* printBoundingBox (boxes[vIter->val]); */

				vIter = vIter->next;
			}

			/* Untersuchungen fuer vp starten */
			assert (vp == vIter->val);

			/* zunaechst die Einbettung fuer vp uebernehmen */
			if (boxes[vp]->out)
				overtakeEmbedding (adj, boxes, rank, vp);
			else
				overtakeEmbeddingWithKnownLeftmostInPoint
				(adj, boxes, vp, vIter->prev->val);

			/* ganz linken (crl) und ganz rechten (crr) Nachbarn von vp auf      */
			/* Ck_1 suchen */

			crl = Ck_1->first;
			while (crl && !areNeighbours (adj, crl->val, vp))
				crl = crl->next;
			assert (crl);		/* muss gefunden werden */

			crr = Ck_1->last;
			while (crr && !areNeighbours (adj, crr->val, vp))
				crr = crr->prev;
			assert (crr);		/* muss gefunden werden */

			/* printf ("crl = %i,    crr = %i\n", crl->val, crr->val); */

			assert (crl->val != cl->val);	/* sollte nicht passieren */

			if (crl->val == crr->val) {
				/* einfacher Fall */

				assert (boxes[crr->val]->out > 0);
				for (oindex = 0; oindex < boxes[crr->val]->out; oindex++)
					if (boxes[crr->val]->outPoints[oindex]->toNode == vIter->val)
						break;

				assert (oindex != boxes[crr->val]->out);
				/* es muss was gefunden werden */

				offset = abs (minimumToLeft (boxes[vIter->val])) +
						maximumToRight (boxes[vIter->prev->val]) + 1;

				offset2 = boxes[vp]->inPoints[boxes[vp]->in - 1]->xrel;
				if (boxes[vp]->out > 0) {
					offset2 = MAXIMUM (offset2,
							boxes[vp]->outPoints[boxes[vp]->out - 1]->xrel);
				}
				minimalX = boxes[vIter->prev->val]->x +
						offset + offset2 + 1;

				boxes[vp]->x = boxes[vIter->prev->val]->x + offset;

				offset = minimalX -
						boxes[crr->val]->outPoints[oindex]->xrel - boxes[crr->val]->x;

				if (offset > 0) {
					/* alle Knoten unter und rechts von crr um offset nach rechts    */
					/* verschieben */
					ShiftNodesInGraph (boxes, crr->val, offset, Gk_1Set, rank, cl->val);
				}
			} else {
				/* schwieriger Fall: Letzter Knoten hat mehrere Nachbarn auf Ck_1 */
				/* zwei Moeglichkeiten: a) Kante von vp zu vi wurde nicht umgebettet */
				/*                      b) Kante von vp zu vi wurde umgebettet */

				int crc = UNDEF;	/* circle right center */
				int leftinindex = -1;
				int centerinindex = -1;
				int rightinindex = -1;
				int leftoutindex = -1;
				int centeroutindex = -1;
				int rightoutindex = -1;

				int xAbsOutLeft, xAbsOutCenter, xAbsOutRight;
				int xAbsInLeft, xAbsInCenter, aAbsInRight;

				/* 1. Phase: den relativen Outpoint von vp zu crl->val auf eine     */
				/* x-Position bringen */
				/* Fall 1: crl->val liegt rechts von vp, dann vp einfach setzen   */
				/* Fall 2: crl->val liegt links von vp, dann den Graphen strecken */

				assert (boxes[vp]->in > 2);
				assert (vIter->val == vp);

				boxes[vp]->x = boxes[vIter->prev->val]->x +
						maximumToRight (boxes[vIter->prev->val]) +
						abs (minimumToLeft (boxes[vp])) + 1;

				for (i = 0; i < boxes[vp]->in; i++) {
					if (boxes[vp]->inPoints[i]->toNode == crl->val)
						leftinindex = i;
					if (boxes[vp]->inPoints[i]->toNode == crr->val)
						rightinindex = i;
					if (boxes[vp]->inPoints[i]->xrel == 0) {
						crc = boxes[vp]->inPoints[i]->toNode;
						centerinindex = i;
					}
				}

				for (i = 0; i < boxes[crl->val]->out; i++) {
					if (boxes[crl->val]->outPoints[i]->toNode == vp) {
						leftoutindex = i;
						break;
					}
				}
				for (i = 0; i < boxes[crc]->out; i++) {
					if (boxes[crc]->outPoints[i]->toNode == vp) {
						centeroutindex = i;
						break;
					}
				}
				for (i = 0; i < boxes[crr->val]->out; i++) {
					if (boxes[crr->val]->outPoints[i]->toNode == vp) {
						rightoutindex = i;
						break;
					}
				}

				assert (leftinindex != -1 && rightinindex != -1 &&
						centerinindex != -1 &&
						leftoutindex != -1 && rightoutindex != -1);
				/* jede Suche muss erfolgreich sein */

				xAbsInLeft = boxes[vp]->x + boxes[vp]->inPoints[leftinindex]->xrel;
				xAbsOutLeft = boxes[crl->val]->x +
						boxes[crl->val]->outPoints[leftoutindex]->xrel;

				if (centeroutindex == -1) {
					/* Sonderfall: Knoten vp kann nicht mit gerader Kante ueber      */
					/* einem Knoten auf Ck_1 positioniert werden */
					/* daher nur maximal 2 mal shiften erforderlich */
					if (xAbsOutLeft < xAbsInLeft)
						ShiftNodesInGraph (boxes, crl->val,
								abs (xAbsOutLeft - xAbsInLeft), Gk_1Set, rank,
								cl->val);
					/* hopefully no else needed */

					xAbsOutRight = boxes[crr->val]->x +
							boxes[crr->val]->outPoints[rightoutindex]->xrel;
					aAbsInRight = boxes[vp]->x + boxes[vp]->inPoints[rightinindex]->xrel;

					if (xAbsOutRight < aAbsInRight) {
						/* Streckung des Graphen notwendig, Knoten unter und rechts von  */
						/* crr um abs(xAbsOutRight-aAbsInRight) nach rechts */
						ShiftNodesInGraph (boxes, crr->val,
								abs (xAbsOutRight - aAbsInRight), Gk_1Set,
								rank, cl->val);
					}
				} else {
					/* Normalfall */

					if (xAbsOutLeft < xAbsInLeft) {
						/* Graph muss gestreckt werden, alle Knoten rechts und unter  */
						/*  crl->val um abs(xAbsOutLeft-xAbsInLeft) nach rechts */
						ShiftNodesInGraph (boxes, crl->val,
								abs (xAbsOutLeft - xAbsInLeft), Gk_1Set,
								rank, cl->val);
					} else if (xAbsOutLeft > xAbsInLeft) {
						/* vp muss versetzt werden */
						boxes[vp]->x += abs (xAbsOutLeft - xAbsInLeft);
					} else {
						assert (xAbsOutLeft == xAbsInLeft);
						/* sollte ja wohl so sein ;-) */
					}

					/* 2.Phase, den inPoint mit xrel==0 von vp auf eine x-Position */
					/* mit dem outPoint von crc bringen */

					xAbsOutCenter = boxes[crc]->x +
							boxes[crc]->outPoints[centeroutindex]->xrel;
					xAbsInCenter = boxes[vp]->x + boxes[vp]->inPoints[centerinindex]->xrel;

					if (xAbsOutCenter < xAbsInCenter) {
						/* Graph muss gestreckt werden, alle Knoten unter und
						 * rechts von crc um abs(xAbsOutCenter - xAbsInCenter)
						 * nach rechts */
						ShiftNodesInGraph (boxes, crc,
								abs (xAbsOutCenter - xAbsInCenter), Gk_1Set,
								rank, cl->val);
					} else if (xAbsOutCenter > xAbsInCenter) {
						/* vp muss versetzt werden */
						boxes[vp]->x += abs (xAbsOutCenter - xAbsInCenter);
					} else {
						assert (xAbsOutCenter == xAbsInCenter);
					}

					/* 3. Phase, abpruefen, ob inPoint zu crr->val links von dem
					 * outPoint von crr->val liegt */
					xAbsOutRight = boxes[crr->val]->x +
							boxes[crr->val]->outPoints[rightoutindex]->xrel;
					aAbsInRight = boxes[vp]->x + boxes[vp]->inPoints[rightinindex]->xrel;

					if (xAbsOutRight < aAbsInRight) {
						/* Streckung des Graphen notwendig, Knoten unter und
						 * rechts von crr um abs(xAbsOutRight-aAbsInRight) nach
						 * rechts */
						ShiftNodesInGraph (boxes, crr->val,
								abs (xAbsOutRight - aAbsInRight), Gk_1Set,
								rank, cl->val);
					}
					/* cl, crl und crr muessen korrekt sein */
				}
			}

			/* falls outdeg(vp) > indeg(vp) pruefen, ob crr rechts vom
			 * rechten Hilfsknoten von vp ist */

			if (boxes[vp]->out && boxes[vp]->in) {
				int xAbs;
				int toNode;
				int xoffset;

				oindex = 0;
				toNode = boxes[vp]->inPoints[boxes[vp]->in - 1]->toNode;
				while (oindex < boxes[toNode]->out &&
						boxes[toNode]->outPoints[oindex]->toNode != vp)
					oindex++;
				assert (oindex < boxes[toNode]->out);
				/* es muss was gefunden werden */
				xAbs = boxes[toNode]->x + boxes[toNode]->outPoints[oindex]->xrel;
				xoffset = (boxes[vp]->x +
						boxes[vp]->outPoints[boxes[vp]->out - 1]->xrel) - xAbs;
				if (xoffset > 0)
					ShiftNodesInGraph (boxes, toNode, xoffset, Gk_1Set, rank, cl->val);
			}
			/* nun y-Position berechnen und bei allen neuen Knoten setzen */

			/* v1 betrachten */
			yoffset = 0;
			if (boxes[v1]->in > 2) {
				iindex = 0;
				while (iindex < boxes[v1]->in &&
						boxes[v1]->inPoints[iindex]->toNode != cl->val)
					iindex++;
				assert (iindex < boxes[v1]->in);
				/* es muss was gefunden werden */

				iindex++;
				assert (iindex < boxes[v1]->in);
				/* es darf auch nicht der letzte gewesen sein */
				while (iindex < boxes[v1]->in - 1) {
					iindex++;
					yoffset++;
				}
			}
			if (mIter->data->size > 2) {
				/* Knoten zwischen v1 und vp betrachten */
				assert (mIter->data->first && mIter->data->first->next);
				gIter = mIter->data->first->next;
				while (gIter->next) {
					if ((boxes[gIter->val]->in - 2) > yoffset)
						yoffset = boxes[gIter->val]->in - 2;
					/* zwei abziehen, die waagerecht verlaufen */
					gIter = gIter->next;
				}
			}
			/* vp betrachten ist wohl nicht notwendig */

			yoffset2 =
					(abs (MINIMUM (minimumToBottom (boxes[v1]),
							minimumToBottom (boxes[vp]))) + yoffset) == 0 ? 1 : 0;

			/* aus den Leveln der Kanten zwischen Knoten der Kette mues noch ein */
			/* weiterer Offset berechnet werden */

			maxlevel = 0;

			vIter = mIter->data->first;
			while (vIter) {
				maxlevel = MAXIMUM (maxlevel, boxes[vIter->val]->maxlevel);
				vIter = vIter->next;
			}

			if (maxlevel > 0)
				yoffset3 = maxlevel;
			else
				yoffset3 = 0;

			ypos =
					computeMinimalHeight (boxes, Ck_1, boxes[v1]->inPoints[0]->toNode,
							boxes[vp]->inPoints[boxes[vp]->in - 1]->toNode) +
							abs (MINIMUM
									(minimumToBottom (boxes[v1]), minimumToBottom (boxes[vp]))) +
									yoffset +
									yoffset2 +
									yoffset3;

			/* Werte uebertragen */
			vIter = mIter->data->first;
			while (vIter) {
				boxes[vIter->val]->y = ypos;
				vIter = vIter->next;
			}

			/* Ck_1, Ck_1Set und Gk_1Set reparieren */
			/* printf ("cl = %i,   cr = %i\n", cl->val, crr->val); */

			gIter = mIter->data->first;
			while (gIter) {
				intSetIncl (Gk_1Set, gIter->val);
				intSetIncl (Ck_1Set, gIter->val);
				gIter = gIter->next;
			}

			replaceChain (cl, crr, mIter->data);

			gIter = mIter->data->first;
			while (gIter) {
				intSetExcl (Ck_1Set, gIter->val);
				gIter = gIter->next;
			}

		}

		mIter = mIter->next;
	}

	delIntList (Ck_1);
	delIntSet (Ck_1Set);
	delIntSet (Gk_1Set);

}
