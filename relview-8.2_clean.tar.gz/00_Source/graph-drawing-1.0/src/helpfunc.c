/* $Revision: 1.1.1.1.2.1 $
 * $Header: /home/cvsroot/relview/relview/sul/helpfunc.c,v 1.1.1.1.2.1 2008/03/18 12:42:14 stefan Exp $
 * $State: Exp $
 * $Log: helpfunc.c,v $
 * Revision 1.1.1.1.2.1  2008/03/18 12:42:14  stefan
 * Solved some compiler warnings in various modules.
 *
 * Revision 1.1.1.1  2008/03/14 11:33:24  stefan
 * Initial import to CVS.
 *
 *
 * Revision 1.27  1999/03/22 13:26:11  sul
 * Verbesserungsvorschlag von Jens Voege eingearbeitet
 *
 * Revision 1.26  1999/03/11 18:28:16  sul
 * Bugfix fuer Problem von Ulf
 *
 * Revision 1.25  1999/02/24 13:54:13  sul
 * Ausgabe von printIntArr verbessert
 *
 * Revision 1.24  1999/02/23 15:30:14  sul
 * einige Funktionen zur Ausgabe in ein File eingebunden
 *
 * Revision 1.23  1999/02/23 14:41:54  sul
 * wichtige Nebenbedingung kommentiert
 *
 * Revision 1.22  1999/02/18 14:52:05  sul
 * useless comments killed
 *
 * Revision 1.21  1999/02/18 09:21:48  sul
 * kleine Aenderung
 *
 * Revision 1.20  1999/02/13 15:23:13  sul
 * RCS-Information fuer Debuggingzwecke bereitgestellt
 * ein assert angefuegt
 *
 * Revision 1.19  1999/02/12 10:07:34  sul
 * fuer Projekt in der Physiologie angepasst, so dass dieses File ohne
 * Modifikationen auch unter CVI uebersetzt
 *
 * Revision 1.18  1999/02/11 17:08:56  sul
 * uebersetzt jetzt auch mit g++ ohne Warnungen
 *
 * Revision 1.17  1999/02/09 13:53:17  sul
 * neue Funktion printAdjListDebug
 *
 * Revision 1.16  1999/02/08 15:53:59  sul
 * width und height sind keine Member der BoundingBoxes mehr
 * neue Funktionen:
 * - delFirst
 * - delLast
 * - printWeightedEdges
 *
 */

char helpfunc_c_rcsid[] __attribute__((unused)) ="$Id: helpfunc.c,v 1.1.1.1.2.1 2008/03/18 12:42:14 stefan Exp $";
#define _helpfunc_c_

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

#ifndef _MAUSWERT_DEVELOPMENT_
#include <malloc.h>
#else
#include <ansi_c.h>
#endif /* _MAUSWERT_DEVELOPMENT_ */

#include "helpfunc.h"

#define true 1
#define false 0

/********************************************************************************/
/*                                                                              */
/* Funktionen zur Verwaltung von Integerlisten                                  */
/*                                                                              */
/********************************************************************************/

/* NAME : getNewIntList
 * FUNKTION : erzeugt eine Liste von int's
 * UEBERGABEPARAMETER : int (maximale Anzahl)
 * RUECKGABEWERT : Zeiger auf eine Liste
 * ERSTELLT VON : Sascha Ulbrand (10.9.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
p_intList getNewIntList (void) {
  p_intList neu = (p_intList) malloc (sizeof (intList));
  neu->size = 0;
  neu->first = NULL;
  neu->last = NULL;
  return neu;
}

/* NAME : copyIntList
 * FUNKTION : kopiert IntList mit Inhalt
 * UEBERGABEPARAMETER : Zeiger auf IntList
 * RUECKGABEWERT : Zeiger auf kopierte Liste
 * ERSTELLT VON : Sascha Ulbrand (17.09.1998)
 * LETZTE AENDERUNG AM : 17.09.1998
 */
p_intList copyIntList (p_intList list) {
  p_intList neu;
  p_intListNode pIter;
  assert (list != NULL);
  pIter = list->first;
  neu = getNewIntList();
  while (pIter) {
    addLast (neu, pIter->val);
    pIter = pIter->next;
  }
  return neu;
}

/* NAME : delIntList
 * FUNKTION : loescht eine intList aus dem Speicher
 * UEBERGABEPARAMETER : p_intList (Zeiger auf die Liste)
 * RUECKGABEWERT : keiner
 * ERSTELLT VON : Sascha Ulbrand (10.9.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
void delIntList (p_intList old) {
  p_intListNode pIter;
  p_intListNode pDel;
  assert (old != NULL);
  pIter = old->first;
  while (pIter) {
    pDel = pIter;
    pIter = pIter->next;
    free (pDel);
  }
  free (old);
}

/* NAME : addLast
 * FUNKTION : Wert ans Ende der Liste anfuegen
 * UEBERGABEPARAMETER : p_intList (Liste, an die angefuegt wird)
                        int (Wert)
 * RUECKGABEWERT : Laenge der Liste nach Anhaengen des Nodes
 * ERSTELLT VON : Sascha Ulbrand (10.9.1998)
 * LETZTE AENDERUNG AM : 10.9.1998
 */
int addLast(p_intList list, int wert) {
  p_intListNode neu;

  assert (list != NULL);

  neu = (p_intListNode) malloc (sizeof (intListNode));
  assert (neu);
  neu->val = wert;
  neu->list = list;

  if (list->last) {
    list->last->next = neu;
    neu->prev = list->last;
    neu->next = NULL;
    list->last = neu;
  } else {
    neu->prev=NULL;
    neu->next=NULL;
    list->first = neu;
    list->last = neu;
  }
  return list->size++;
}

/* NAME : addFirst
 * FUNKTION : Wert ans Ende der Liste anfuegen
 * UEBERGABEPARAMETER : p_intList (Liste, an die angefuegt wird)
                        int (Wert)
 * RUECKGABEWERT : Laenge der Liste nach Anhaengen des Nodes
 * ERSTELLT VON : Sascha Ulbrand (14.9.1998)
 * LETZTE AENDERUNG AM : 14.9.1998
 */
int addFirst(p_intList list, int wert) {
  p_intListNode neu;

  assert (list != NULL);

  neu = (p_intListNode) malloc (sizeof (intListNode));
  assert (neu);
  neu->val = wert;
  neu->list = list;

  if (list->first) {
    list->first->prev = neu;
    neu->next = list->first;
    neu->prev = NULL;
    list->first = neu;
  } else {
    neu->prev=NULL;
    neu->next=NULL;
    list->first = neu;
    list->last = neu;
  }
  return list->size++;
}

/* NAME : addBefore
 * FUNKTION : Fuegt Wert vor angegebenem Element in die Liste ein
 * UEBERGABEPARAMETER : Zeiger auf Listenelement und Wert
 * RUECKGABEWERT : neue Laenge der Liste
 * ERSTELLT VON : Sascha Ulbrand (02.11.1998)
 * LETZTE AENDERUNG AM : 02.11.1998
 */
int addBefore (p_intListNode node, int wert) {
  p_intListNode neu = (p_intListNode) malloc (sizeof(intListNode));
  assert (node != NULL);
  if (node == node->list->first) {
    return addFirst (node->list, wert);
  } else {
    neu->prev = node->prev;
    neu->next = node;
    neu->list = node->list;
    neu->val = wert;

    node->prev->next = neu;
    node->prev = neu;

    return node->list->size++;
  }
}

/* NAME : addAfter
 * FUNKTION : Fuegt neuen Wert hinter dem angegebenen Node in die Liste an
 * UEBERGABEPARAMETER : Zeiger auf Listenelement und Wert
 * RUECKGABEWERT : neue Laenge der Liste
 * ERSTELLT VON : Sascha Ulbrand (02.11.1998)
 * LETZTE AENDERUNG AM : 02.11.1998
 */
int addAfter (p_intListNode node, int wert) {
  p_intListNode neu = (p_intListNode) malloc (sizeof(intListNode));
  assert (node != NULL);
  if (node == node->list->last) {
    return addLast (node->list, wert);
  } else {
    neu->prev = node;
    neu->next = node->next;
    neu->list = node->list;
    neu->val = wert;

    node->next->prev = neu;
    node->next = neu;
    return node->list->size++;
  }
}

/* NAME : delFirst
 * FUNKTION : loescht erstes Element einer IntList
 * UEBERGABEPARAMETER : Zeiger auf IntList (list)
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (08.02.1999)
 * LETZTE AENDERUNG AM : 08.02.1999
 */
void delFirst (p_intList list) {
  p_intListNode old;
  assert (list != NULL);
  assert (list->last);

  old = list->first;

  list->first = list->first->next;
  if (list->first)
    list->first->prev = NULL;
  else
    list->last = NULL;

  free (old);

  list->size--;
}

/* NAME : delLast
 * FUNKTION : loescht letztes Element einer IntList
 * UEBERGABEPARAMETER : Zeiger auf IntList (list)
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (08.02.1999)
 * LETZTE AENDERUNG AM : 08.02.1999
 */
void delLast (p_intList list){
  p_intListNode old;
  assert (list != NULL);
  assert (list->last);

  old = list->last;

  list->last = list->last->prev;
  if (list->last)
    list->last->next = NULL;
  else
    list->first = NULL;

  free (old);

  list->size--;
}

/* NAME : popLast
 * FUNKTION : loescht den letzten Eintrag einer Liste
 * UEBERGABEPARAMETER : Zeiger auf eine Liste
 * RUECKGABEWERT : geloeschter Wert
 * ERSTELLT VON : Sascha Ulbrand (14.09.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
int popLast (p_intList list) {
  int wert;
  p_intListNode old;
  assert (list != NULL);
  assert (list->last);

  old = list->last;
  wert = old->val;

  list->last = list->last->prev;
  if (list->last)
    list->last->next = NULL;
  else
    list->first = NULL;

  free (old);

  list->size--;

  return wert;
}

/* NAME : popFirst
 * FUNKTION : loescht den ersten Eintrag einer Liste
 * UEBERGABEPARAMETER : Zeiger auf eine Liste
 * RUECKGABEWERT : geloeschter Wert
 * ERSTELLT VON : Sascha Ulbrand (14.09.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
int popFirst (p_intList list) {
  int wert;
  p_intListNode old;
  assert (list != NULL);
  assert (list->last);

  old = list->first;
  wert = old->val;

  list->first = list->first->next;
  if (list->first)
    list->first->prev = NULL;
  else
    list->last = NULL;

  free (old);

  list->size--;

  return wert;
}

/* NAME : concIntList
 * FUNKTION : haengt eine Integerliste an die andere Liste an, app ist danach leer
 * UEBERGABEPARAMETER : Zeiger auf zwei IntLists
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (20.10.1998)
 * LETZTE AENDERUNG AM : 20.10.1998
 */
void concIntList (p_intList list, p_intList app) {
  p_intListNode pIter;
  assert (list != NULL && app != NULL);
  assert (list != app);
  if (list->size == 0) {
    assert (list->first == NULL);
    list->first = app->first;
    list->size = app->size;
    list->last = app->last;
  } else {
    assert (list->first != NULL);
    if (app->size != 0) {
      assert (app->first != NULL);
      list->last->next = app->first;
      app->first->prev = list->last;
      list->last = app->last;
      list->size += app->size;
    } else {
      assert (app->first == NULL);
    }
  }
  pIter = app->first;
  while (pIter) {
    pIter->list = list;
    pIter = pIter->next;
  }
  app->first = app->last = NULL;
  app->size = 0;
}

/* NAME : delNode
 * FUNKTION : loeschen eines beliebigen Eintrags einer Liste
 * UEBERGABEPARAMETER : Zeiger auf einen intListNode
 * RUECKGABEWERT : Wert des geloeschten Nodes
 * ERSTELLT VON : Sascha Ulbrand (17.09.1998)
 * LETZTE AENDERUNG AM : 17.09.1998
 */
int delNode (p_intListNode node) {
  int val;
  p_intList list;

  assert (node != NULL);

  list = node->list;

  if (node == list->first) {
    list->first = node->next;
    if (node->next) list->first->prev = NULL;
    else list->last = list->first;
  } else if (node == list->last) {
    list->last = list->last->prev;
    if (list->last) list->last->next = NULL;
    else list->first = list->last;
  } else {
    node->prev->next = node->next;
    node->next->prev = node->prev;
  }
  val = node->val;
  free (node);
  list->size--;
  return val;
}

/* NAME : delVal
 * FUNKTION : loescht erstes Auftreten eines Wertes aus der Liste
 * UEBERGABEPARAMETER : Liste (list) und Wert (val)
 * RUECKGABEWERT : Anzahl der geloeschten Nodes
 * ERSTELLT VON : Sascha Ulbrand (17.09.1998)
 * LETZTE AENDERUNG AM : 17.09.1998
 */
int delVal (p_intList list, int val) {
  p_intListNode pIter;
  assert (list != NULL);
  pIter = list->first;
  while (pIter) {
    if (pIter->val == val) {
      delNode (pIter);
      return 1;
    }
    pIter = pIter->next;
  }
  return 0;
}

/* NAME : inList
 * FUNKTION : ueberprueft Vorhandensein in einer Liste
 * UEBERGABEPARAMETER : (list) Liste
 *                      (val) zu suchender Wert
 * RUECKGABEWERT : 0 : Wert nicht gefunden
 *                 1 : Wert gefunden
 * ERSTELLT VON : Sascha Ulbrand (08.10.1998)
 * LETZTE AENDERUNG AM : 08.10.1998
 */
int inList (p_intList list, int val) {
  p_intListNode pIter;
  assert (list != NULL);
  pIter = list->first;
  while (pIter) {
    if (pIter->val == val) return true;
    pIter = pIter->next;
  }
  return false;
}

/* NAME : indexInList
 * FUNKTION : ueberprueft Vorhandensein in einer Liste
 * UEBERGABEPARAMETER : (list) Liste
 *                      (val) zu suchender Wert
 * RUECKGABEWERT : -1 falls Wert nicht gefunden
 *                 ansonsten Position des ersten Vorkommens (Zaehlung beginnt bei 0)
 * ERSTELLT VON : Sascha Ulbrand (14.01.1999)
 * LETZTE AENDERUNG AM : 14.01.1999
 */
int indexInList (p_intList list, int val) {
  p_intListNode pIter;
  int count = 0;
  assert (list != NULL);
  pIter = list->first;
  while (pIter) {
    if (pIter->val == val) return count;
    count++;
    pIter = pIter->next;
  }
  return -1;
}

/* NAME : nodeInList
 * FUNKTION : liefert Zeiger auf ersten Node mit Wert
 * UEBERGABEPARAMETER : (list) Liste
 *                      (val) zu suchender Wert
 * RUECKGABEWERT : Zeiger auf Node oder NULL
 * ERSTELLT VON : Sascha Ulbrand (14.01.1999)
 * LETZTE AENDERUNG AM : 14.01.1999
 */
p_intListNode nodeInList (p_intList list, int val) {
  p_intListNode pIter;
  assert (list != NULL);
  pIter = list->first;
  while (pIter) {
    if (pIter->val == val) return pIter;
    pIter = pIter->next;
  }
  return (p_intListNode) NULL;
}

/* NAME : nextClock
 * FUNKTION : betrachtet Liste als zyklische Liste und liefert naechtes Element
 * UEBERGABEPARAMETER : Zeiger auf Listeneintrag
 * RUECKGABEWERT : Zeiger auf Listeneintrag
 * ERSTELLT VON : Sascha Ulbrand (02.11.1998)
 * LETZTE AENDERUNG AM : 02.11.1998
 */
p_intListNode nextClock (p_intListNode node) {
  if (node->next)
    return node->next;
  else
    return node->list->first;
}

/* NAME : prevClock
 * FUNKTION : betrachtet Liste als zyklische Liste und liefert vorhergehendes Element
 * UEBERGABEPARAMETER : Zeiger auf Listeneintrag
 * RUECKGABEWERT : Zeiger auf Listeneintrag
 * ERSTELLT VON : Sascha Ulbrand (02.11.1998)
 * LETZTE AENDERUNG AM : 02.11.1998
 */
p_intListNode prevClock (p_intListNode node) {
  if (node->prev)
    return node->prev;
  else
    return node->list->last;
}

/* NAME : replaceChain
 * FUNKTION : ersetzt Teilstueck in der Liste
 * UEBERGABEPARAMETER : (from) (to) begrenzen das Teilstueck und werden nicht ersetzt
 *                      (by) ist das ersetzte Stueck, herausgeloestes Stueck wird in diese Liste geschrieben
 * NEBENBEDINGUNG: jeder Wert ist nur einmal in der Liste
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 04.01.1999
 */
void replaceChain (p_intListNode from, p_intListNode to, p_intList by) {
  p_intList list;
  p_intListNode bIter,lIter;

  assert (from && to && by);
  assert (from->list == to->list);
  assert (from->list != by); /* avoid replacing of same lists */

  list = from->list;
  bIter = by->first;
  lIter = from;

  while (bIter) {
    addAfter (lIter, bIter->val);
    bIter = bIter->next;
    lIter = lIter->next;
  }

  lIter = lIter->next;
  assert (lIter);

  clearIntList (by);

  while (lIter && lIter != to) {
    bIter = lIter->next;
    addLast (by, delNode (lIter));
    lIter = bIter;
  }

  assert (lIter); /* sonst war (to) vor (from) in der Liste, unsinniger Aufruf der Funktion */
}


/* NAME : clearIntList
 * FUNKTION : loescht alle Eintraege einer Liste
 * UEBERGABEPARAMETER : Zeiger auf eine Liste
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (22.10.1998)
 * LETZTE AENDERUNG AM : 22.10.1998
 */
void clearIntList (p_intList list) {
  p_intListNode iter;
  p_intListNode iter2 = NULL;
  assert (list != NULL);
  iter = list->first;

  while (iter) {
    iter2 = iter->next;
    free (iter);
    iter = iter2;
  }

  list->first = list->last = NULL;
  list->size = 0;
}

/* NAME : printIntList
 * FUNKTION : Ausgabe einer IntList
 * UEBERGABEPARAMETER : p_intList (Liste)
 * RUECKGABEWERT : keiner
 * ERSTELLT VON : Sascha Ulbrand (10.09.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
void printIntList (p_intList list) {
  p_intListNode pIter = list->first;
  int komma=0;

  assert (list != NULL);

  printf ("(");
  while (pIter) {
    if (komma) printf (", ");
    else komma=1;
    printf ("%i", pIter->val);
    pIter = pIter->next;
  }
  printf (")");
}

/* NAME : fprintIntList
 * FUNKTION : Ausgabe einer IntList
 * UEBERGABEPARAMETER : FILE* und p_intList (Liste)
 * RUECKGABEWERT : keiner
 * ERSTELLT VON : Sascha Ulbrand (10.09.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
void fprintIntList (FILE* out, p_intList list) {
  p_intListNode pIter = list->first;
  int komma=0;

  assert (list != NULL);

  fprintf (out,"(");
  while (pIter) {
    if (komma) fprintf (out,", ");
    else komma=1;
    fprintf (out,"%i", pIter->val);
    pIter = pIter->next;
  }
  fprintf (out,")");
}

/********************************************************************************/
/*                                                                              */
/* Funktionen zur Verwaltung von Adjazenzlisten                                 */
/*                                                                              */
/********************************************************************************/
/* NAME : getNewAdjList
 * FUNKTION : neue Adjazenzliste erstellen
 * UEBERGABEPARAMETER : Anzahl der Knoten
 * RUECKGABEWERT : Zeiger auf die Liste
 * ERSTELLT VON : Sascha Ulbrand (14.09.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
p_adjList getNewAdjList (int size) {
  p_adjList neu;
  p_intList* aList;
  int i;

  neu = (p_adjList) malloc (sizeof(adjList));
  neu->size = size;
  aList= (neu->aList = (p_intList*) malloc (size * sizeof(p_intList)));
  for (i=0; i<size; i++)
    aList[i] = getNewIntList();
  return neu;
}

/* NAME : copyAdjList
 * FUNKTION : kopiert eine Adjazenzliste
 * UEBERGABEPARAMETER : Zeiger auf AdjList
 * RUECKGABEWERT : Zeiger auf Adjlist
 * ERSTELLT VON : Sascha Ulbrand (17.09.1998)
 * LETZTE AENDERUNG AM : 17.09.1998
 */
p_adjList copyAdjList (p_adjList adj) {
  p_adjList neu;
  p_intListNode pIter;
  int i;
  assert (adj);
  neu = getNewAdjList (adj->size);
  for (i=0; i<adj->size; i++) {
    pIter = adj->aList[i]->first;
    while (pIter) {
      addNewEdge (neu, i, pIter->val);
      pIter = pIter->next;
    }
  }
  return neu;
}

/* NAME : addNewEdge
 * FUNKTION : Neue Kante in die Adjazenzliste einfuegen
 * UEBERGABEPARAMETER : Kante geht von Knoten (from) nach Knoten (to)
 * RUECKGABEWERT : neuer Grad des Knotens (from)
 * ERSTELLT VON : Sascha Ulbrand (14.09.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
int addNewEdge (p_adjList list, int from, int to) {
  assert (list);
  assert ( from>=0 && to>=0 );
  assert ( from < list->size && to < list->size );

  return addLast(list->aList[from],to);
}

/* NAME : delEdges
 * FUNKTION : loescht (ggf. beide) Vorkommen einer Kante in der Adjazenzliste
 * UEBERGABEPARAMETER : Zeiger auf Adjazenzliste (adj), 2 Knoten (node1) (node2)
 * RUECKGABEWERT : Anzahl der geloeschten Kanten (0,1 oder 2)
 * ERSTELLT VON : Sascha Ulbrand (06.01.1999)
 * LETZTE AENDERUNG AM : 06.01.1999
 */
int delEdges (p_adjList adj, int node1, int node2) {
  p_intListNode pIter;
  int count = 0;
  assert (adj);
  assert (node1 >=0 && node2 >=0 && node1<adj->size && node2<adj->size);

  pIter = adj->aList[node1]->first;
  while (pIter) {
    if (pIter->val == node2) {
      delNode (pIter);
      count++;
      break;
    }
    pIter = pIter->next;
  }

  pIter = adj->aList[node2]->first;
  while (pIter) {
    if (pIter->val == node1) {
      delNode (pIter);
      count++;
      break;
    }
    pIter = pIter->next;
  }

  return count;
}

/* NAME : degNode
 * FUNKTION : liefert Grad eines Knotens
 * UEBERGABEPARAMETER : (adj) Adjazenzliste, (node) Knoten
 * RUECKGABEWERT : Grad
 * ERSTELLT VON : Sascha Ulbrand 07.01.1999
 * LETZTE AENDERUNG AM : 07.01.1999
 */
int degNode (p_adjList adj, int node) {
  assert (adj);
  assert (node>=0 && node<adj->size);
  return adj->aList[node]->size;
}

/* NAME : leftup
 * FUNKTION : liefert den rechten(!) zu (to) benachbarten Knoten von (from)
 * KOMMENTAR : Namensgebung der Funktion folgt der Notation aus [K93]
 * UEBERGABEPARAMETER : Zeiger auf Adjazenzliste (embedded)
 * RUECKGABEWERT : Nummer des Knotens
 * ERSTELLT VON : Sascha Ulbrand (02.11.1998)
 * LETZTE AENDERUNG AM : 02.11.1998
 */
int leftUp (p_adjList adj, int from, int to) {
  p_intListNode pIter;
  assert (adj != NULL);
  assert (from >=0 && to >= 0 && from < adj->size && to < adj->size);
  assert (from != to);
  pIter = adj->aList[from]->first;
  while (pIter->val != to) {
    pIter = pIter->next;
    assert (pIter); /* sonst war (to) nicht Nachbar von (from) */
  }
  return nextClock(pIter)->val;
}

/* NAME : rightup
 * FUNKTION : liefert den linken(!) zu (to) benachbarten Knoten von (from)
 * KOMMENTAR : Namensgebung der Funktion folgt der Notation aus [K93]
 * UEBERGABEPARAMETER : Zeiger auf Adjazenzliste (embedded)
 * RUECKGABEWERT : Nummer des Knotens
 * ERSTELLT VON : Sascha Ulbrand (02.11.1998)
 * LETZTE AENDERUNG AM : 02.11.1998
 */
int rightUp (p_adjList adj, int from, int to) {
  p_intListNode pIter;
  assert (adj != NULL);
  assert (from >=0 && to >= 0 && from < adj->size && to < adj->size);
  assert (from != to);
  pIter = adj->aList[from]->first;
  while (pIter->val != to) {
    pIter = pIter->next;
    assert (pIter); /* sonst war (to) nicht Nachbar von (from) */
  }
  return prevClock(pIter)->val;
}

/* NAME : prevClockNode
 * FUNKTION : Vorgaenger in der Einbettung
 * UEBERGABEPARAMETER : (adj) Einbettung, (base) (to) Knoten die durch Kante verbunden sind
 * RUECKGABEWERT : Knotennummer
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 04.01.1999
 */
int prevClockNode (p_adjList adj, int base, int to) {
  p_intListNode pIter;
  assert (adj != NULL);
  assert (base >=0 && to >= 0 && base < adj->size && to < adj->size);
  assert (base != to);
  pIter = adj->aList[base]->first;
  while (pIter->val != to) {
    pIter = pIter->next;
    assert (pIter); /* sonst war (to) nicht Nachbar von (base) */
  }
  return prevClock(pIter)->val;
}

/* NAME : nextClockNode
 * FUNKTION : Nachfolger in der Ordnung
 * UEBERGABEPARAMETER : (adj) Einbettung, (base) (to) Knoten die durch Kante verbunden sind
 * RUECKGABEWERT : Knotennummer
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 04.01.1999
 */
int nextClockNode (p_adjList adj, int base, int to) {
  p_intListNode pIter;
  assert (adj != NULL);
  assert (base >=0 && to >= 0 && base < adj->size && to < adj->size);
  assert (base != to);
  pIter = adj->aList[base]->first;
  while (pIter->val != to) {
    pIter = pIter->next;
    assert (pIter); /* sonst war (to) nicht Nachbar von (base) */
  }
  return nextClock(pIter)->val;
}

/* NAME : areNeighbours
 * FUNKTION : gibt zurueck, ob Knoten Nachbarn sind. (Richtung der Kanten egal !)
 * UEBERGABEPARAMETER : (adj) Adjazenzliste, (node1) (node2) Knoten
 * RUECKGABEWERT : wahr oder falsch
 * BEMERKUNG : Da es sich um Adjazenzlisten handelt, ist der Zugriff nicht sonderlich effizient
 * ERSTELLT VON : Sascha Ulbrand (06.01.1999)
 * LETZTE AENDERUNG AM : 06.01.1999
 */
int areNeighbours (p_adjList adj, int node1, int node2) {
  assert (adj);
  assert (node1 >=0 && node2 >=0 && node1<adj->size && node2<adj->size);
  if ( inList(adj->aList[node1],node2) || inList(adj->aList[node1],node2) )
    return true;
  else
    return false;
}

/* NAME : neighboursIn
 * FUNKTION : ueberprueft, ob der Knoten (node) Nachbarn in der Menge (set) hat
 * UEBERGABEPARAMETER : (adj) Adjazenzliste, (node) Knotennummer, (set) Menge
 * RUECKGABEWERT : wahr oder falsch
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 04.01.1999
 */
int neighboursIn (p_adjList adj, int node, p_intSet set) {
  p_intListNode gIter;
  assert (adj);
  assert (adj->size > node);
  gIter = adj->aList[node]->first;
  while (gIter) {
    if (isInIntSet (set, gIter->val))
      return true;
    gIter = gIter->next;
  }
  return false;
}

/* NAME : countNeighboursIn
 * FUNKTION : zaehlt Nachbarn von Knoten (node) in der Menge (set)
 * UEBERGABEPARAMETER : (adj) Adjazenzliste, (node) Knotennummer, (set) Menge
 * RUECKGABEWERT : Anzahl der Nachbarn
 * ERSTELLT VON : Sascha Ulbrand (05.01.1999)
 * LETZTE AENDERUNG AM : 05.01.1999
 */
int countNeighboursIn (p_adjList adj, int node, p_intSet set) {
  p_intListNode gIter;
  int count = 0;
  assert (adj);
  assert (adj->size > node);
  gIter = adj->aList[node]->first;
  while (gIter) {
    if (isInIntSet (set, gIter->val))
      count++;
    gIter = gIter->next;
  }
  return count;
}


/* NAME : addNewEdgeAfter
 * FUNKTION : Fuegt Kante in bestimmte Stelle in die Adjazenzliste
 * NEBENBEDINGUNG : jeder Wert kommt in der Liste nur einmal vor
 * UEBERGABEPARAMETER : Zeiger auf Adjazenzliste, Kante (from, to) und Stelle hinter der eingefuegt wird
 * RUECKGABEWERT : neue Laenge der Adjazenzliste von (from)
 * ERSTELLT VON : Sascha Ulbrand (02.11.1998)
 * LETZTE AENDERUNG AM : 02.11.1998
 */
int addNewEdgeAfter (p_adjList adj, int from, int to, int after) {
  p_intListNode pIter;
  assert (adj != NULL);
  assert (from >=0 && to >= 0 && from < adj->size && to < adj->size);
  pIter = adj->aList[from]->first;
  while (pIter) {
    if (pIter->val == after) break;
    pIter = pIter->next;
  }
  assert (pIter != NULL); /* sonst war after nicht in der Liste */

  return addAfter (pIter, to);
}

/* NAME : addNewEdgeBefore
 * FUNKTION : Fuegt Kante in bestimmte Stelle in die Adjazenzliste
 * NEBENBEDINGUNG : jeder Wert kommt in der Liste nur einmal vor
 * UEBERGABEPARAMETER : Zeiger auf Adjazenzliste, Kante (from, to) und Stelle vor der eingefuegt wird
 * RUECKGABEWERT : neue Laenge der Adjazenzliste von (from)
 * ERSTELLT VON : Sascha Ulbrand (02.11.1998)
 * LETZTE AENDERUNG AM : 02.11.1998
 */
int addNewEdgeBefore (p_adjList adj, int from, int to, int before) {
  p_intListNode pIter;
  assert (adj != NULL);
  assert (from >=0 && to >= 0 && from < adj->size && to < adj->size);
  pIter = adj->aList[from]->first;
  while (pIter) {
    if (pIter->val == before) break;
    pIter = pIter->next;
  }
  assert (pIter != NULL); /* sonst war before nicht in der Liste */
  return addBefore (pIter, to);
}

/* NAME : delAdjList
 * FUNKTION : loescht eine Adjazenzliste aus dem Speicher
 * UEBERGABEPARAMETER : die zu loeschende Liste
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (14.09.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
void delAdjList (p_adjList list) {
  int i;
  p_intList* aList;
  assert (list);
  aList = list->aList;
  for (i=0; i<list->size; i++)
    delIntList (aList[i]);
  free (list);
}

/* NAME : printAdjList
 * FUNKTION : Gibt die Adjazenzliste auf der Standardausgabe aus
 * UEBERGABEPARAMETER : die auszugebende Liste
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (14.09.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
void printAdjList (p_adjList list) {
  int i;
  int b=true;
  p_intListNode pIter;
  p_intList* aList=list->aList;
  assert (list);

  for (i=0; b&&i<list->size; i++) {
    pIter = aList[i]->first;
    while (b&&pIter) {
      if (!inList (aList[pIter->val], i))
	b=false;
      pIter = pIter->next;
    }
  }
  if (b)
    printf ("undirected adjecency follows\n");
  else
    printf ("directed adjecency follows\n");

  for (i=0; i<list->size; i++) {
    printf ("%i: ", i);
    printIntList (aList[i]);
    printf ("\n");
  }
}

/* NAME : fprintAdjList
 * FUNKTION : Gibt die Adjazenzliste auf der Standardausgabe aus
 * UEBERGABEPARAMETER : FILE* und die auszugebende Liste
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (14.09.1998)
 * LETZTE AENDERUNG AM : 14.09.1998
 */
void fprintAdjList (FILE* out, p_adjList list) {
  int i;
  p_intList* aList=list->aList;
  assert (list);
  for (i=0; i<list->size; i++) {
    fprintf (out, "%i: ", i);
    fprintIntList (out,aList[i]);
    fprintf (out, "\n");
  }
}

/********************************************************************************/
/*                                                                              */
/* Funktionen zur Verwaltung von reorders                                       */
/*                                                                              */
/********************************************************************************/

/* NAME : getNewReorder
 * FUNKTION : erzeugt eine neue Order
 * UEBERGABEPARAMETER : Groesse der Order
 * RUECKGABEWERT : Zeiger auf Struktur
 * ERSTELLT VON : Sascha Ulbrand (16.11.1998)
 * LETZTE AENDERUNG AM : 16.11.1998
 */
p_reorder getNewReorder (int size) {
  p_reorder neu = (p_reorder) malloc (sizeof(reorder));
  neu->size = size;
  neu->phi = (int*) malloc(sizeof(int)*size);
  neu->phi_1 = (int*) malloc(sizeof(int)*size);
  return neu;
}

/* NAME : delReorder
 * FUNKTION : loescht die Struktur
 * UEBERGABEPARAMETER : Zeiger auf Struktur
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (16.11.1998)
 * LETZTE AENDERUNG AM : 16.11.1998
 */
void delReorder (p_reorder old) {
  assert (old != NULL);
  free (old->phi);
  free (old->phi_1);
  free (old);
}

/* NAME : printReorder
 * FUNKTION : Ausgabe einer Preorder
 * UEBERGABEPARAMETER : Zeiger auf die Struktur
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (16.11.1998)
 * LETZTE AENDERUNG AM : 16.11.1998
 */
void printReorder (p_reorder p) {
  assert (p != NULL);
  printIntArr ("order phi  =",p->phi, p->size);
  printIntArr ("order phi_1=",p->phi_1, p->size);
}

/********************************************************************************/
/*                                                                              */
/* Funktionen zur Verwaltung von PalmTrees                                      */
/*                                                                              */
/********************************************************************************/

/* NAME : getNewPalmTree
 * FUNKTION : erzeugt neuen PalmTree
 * UEBERGABEPARAMETER : Groesse der Knotenmenge
 * RUECKGABEWERT : Zeiger auf neue Struktur
 * ERSTELLT VON : Sascha Ulbrand (17.09.1998)
 * LETZTE AENDERUNG AM : 30.09.1998
 */
p_palmTree getNewPalmTree (int size) {
  int i;
  int *p;
  p_palmTree neu= (p_palmTree) malloc(sizeof(palmTree));
  neu->size=size;
  neu->tree = getNewAdjList (size);
  neu->fronds = getNewAdjList (size);
  neu->roots = getNewIntList();
  neu->IndepVertex = getNewIntList();
  neu->VertSets = NULL;
  p = neu->preorder = (int*) malloc (size*sizeof(int));
  for (i=0; i<size; i++)
    *(p++) = -1;
  p = neu->preorder_1 = (int*) malloc (size*sizeof(int));
  for (i=0; i<size; i++)
    *(p++) = -1;
  p = neu->parent = (int*) malloc (size*sizeof(int));
  for (i=0; i<size; i++)
    *(p++) = -1;
  p = neu->low = (int*) malloc (size*sizeof(int));
  for (i=0; i<size; i++)
    *(p++) = -1;
  p = neu->low2 = (int*) malloc (size*sizeof(int));
  for (i=0; i<size; i++)
    *(p++) = -1;

  return neu;
}

/* NAME : delPalmTree
 * FUNKTION : entfernt alten PalmTree aus dem Speicher
 * UEBERGABEPARAMETER : Zeiger auf alten PalmTree
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (17.09.1998)
 * LETZTE AENDERUNG AM : 30.09.1998
 */
void delPalmTree (p_palmTree old) {
  int i;
  assert (old);
  assert (old->tree);
  assert (old->fronds);
  assert (old->preorder);
  assert (old->preorder_1);
  assert (old->parent);
  assert (old->roots);
  assert (old->low);
  assert (old->low2);
  assert (old->IndepVertex);
  free (old->tree);
  free (old->fronds);
  free (old->preorder);
  free (old->preorder_1);
  free (old->parent);
  delIntList (old->roots);
  free (old->low);
  free (old->low2);
  if (old->VertSets) {
    for (i=0; i<old->IndepVertex->size; i++)
      delIntList (old->VertSets[i]);
    free (old->VertSets);
  }
  delIntList (old->IndepVertex);
  free (old);
}

/* NAME : printPalmTree
 * FUNKTION : teilweise textuelle Ausgabe eines PalmTrees
 * UEBERGABEPARAMETER : Zeiger auf eine PalmTree-Struktur
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand 17.09.1998
 * LETZTE AENDERUNG AM : (17.09.1998)
 */
void printPalmTree (p_palmTree out) {
  int i;
  assert (out);
  printf ("PalmTree size=%i\nTree-Adjazenzliste:\n",out->size);
  printAdjList (out->tree);
  printf ("Frond->Adjazenzliste:\n");
  printAdjList (out->fronds);
  printf ("(node/preorder/parent)\n");
  for (i=0; i<out->size; i++)
    printf ("(%i, %i, %i)\n", i, out->preorder[i], out->parent[i]);
  printf ("Wurzeln:");
  printIntList (out->roots);
  printf ("\n");
}

/********************************************************************************/
/*                                                                              */
/* Funktionen zur Verwaltung von generischen Listen                             */
/*                                                                              */
/********************************************************************************/

/* NAME : getNewGenList
 * FUNKTION : erzeugt eine in der Liste von int's
 * UEBERGABEPARAMETER : int (maximale Anzahl)
 * RUECKGABEWERT : Zeiger auf eine Liste
 * ERSTELLT VON : Sascha Ulbrand (08.10.1998)
 * LETZTE AENDERUNG AM : 08.10.1998
 */
p_genList getNewGenList (void) {
  p_genList neu;
  neu = (p_genList) malloc (sizeof (genList));
  neu->size = 0;
  neu->first = NULL;
  neu->last = NULL;
  return neu;
}

/* NAME : delGenList
 * FUNKTION : loescht eine genList aus dem Speicher
 * VORAUSSETZUNG: Zeiger in den Nodes muessen auf ein mit malloc alloziertes Objekt zeigen !
 * UEBERGABEPARAMETER : p_genList (Zeiger auf die Liste)
 * RUECKGABEWERT : keiner
 * ERSTELLT VON : Sascha Ulbrand (08.10.1998)
 * LETZTE AENDERUNG AM : 08.10.1998
 */
void delGenList (p_genList old) {
  p_genListNode pIter;
  p_genListNode pDel;
  assert (old != NULL);
  pIter = old->first;
  while (pIter) {
    pDel = pIter;
    pIter = pIter->next;
    free (pDel->data); /* Data muss anstaendig initialisiert sein und mit malloc alloziert worden sein */
    free (pDel);
  }
  free (old);
}

/* NAME : addLastGen
 * FUNKTION : Wert ans Ende der Liste anfuegen
 * UEBERGABEPARAMETER : p_genList (Liste, an die angefuegt wird)
                        void* (data) Zeiger auf ein mit malloc alloziertes Objekt, Verantwortung obliegt nun der Liste
 * RUECKGABEWERT : Laenge der Liste nach Anhaengen des Nodes
 * ERSTELLT VON : Sascha Ulbrand (08.10.1998)
 * LETZTE AENDERUNG AM : 08.10.1998
 */
int addLastGen(p_genList list, void* data) {
  p_genListNode neu;

  assert (list != NULL);

  neu = (p_genListNode) malloc (sizeof (genListNode));
  assert (neu);
  neu->data = data;
  neu->list = list;

  if (list->last) {
    list->last->next = neu;
    neu->prev = list->last;
    neu->next = NULL;
    list->last = neu;
  } else {
    neu->prev=NULL;
    neu->next=NULL;
    list->first = neu;
    list->last = neu;
  }
  return list->size++;
}

/* NAME : addFirstGen
 * FUNKTION : Wert ans Ende der Liste anfuegen
 * UEBERGABEPARAMETER : p_genList (Liste, an die angefuegt wird)
                        void* (data) Zeiger auf ein mit malloc alloziertes Objekt, Verantwortung obliegt nun der Liste
 * RUECKGABEWERT : Laenge der Liste nach Anhaengen des Nodes
 * ERSTELLT VON : Sascha Ulbrand (08.10.1998)
 * LETZTE AENDERUNG AM : 08.10.1998
 */
int addFirstGen(p_genList list, void* data) {
  p_genListNode neu;

  assert (list != NULL);

  neu = (p_genListNode) malloc (sizeof (genListNode));
  assert (neu);
  neu->data=data;
  neu->list = list;

  if (list->first) {
    list->first->prev = neu;
    neu->next = list->first;
    neu->prev = NULL;
    list->first = neu;
  } else {
    neu->prev=NULL;
    neu->next=NULL;
    list->first = neu;
    list->last = neu;
  }
  return list->size++;
}

/* NAME : popLastGen
 * FUNKTION : loescht den letzten Eintrag einer Liste
 * UEBERGABEPARAMETER : Zeiger auf eine Liste
 * RUECKGABEWERT : Zeiger auf Daten, Verantwortung fuer Speicher nicht mehr bei der Liste
 * ERSTELLT VON : Sascha Ulbrand (08.10.1998)
 * LETZTE AENDERUNG AM : 08.10.1998
 */
void* popLastGen (p_genList list) {
  void* wert;
  p_genListNode old;
  assert (list != NULL);
  assert (list->last);

  old = list->last;
  wert = old->data;

  list->last = list->last->prev;
  if (list->last)
    list->last->next = NULL;
  else
    list->first = NULL;

  free (old);

  list->size--;

  return wert;
}

/* NAME : popFirstGen
 * FUNKTION : loescht den ersten Eintrag einer Liste
 * UEBERGABEPARAMETER : Zeiger auf eine Liste
 * RUECKGABEWERT : Zeiger auf Daten, Verantwortung fuer Speicher nicht mehr bei der Liste
 * ERSTELLT VON : Sascha Ulbrand (08.10.1998)
 * LETZTE AENDERUNG AM : 08.10.1998
 */
void* popFirstGen (p_genList list) {
  void* wert;
  p_genListNode old;
  assert (list != NULL);
  assert (list->last);

  old = list->first;
  wert = old->data;

  list->first = list->first->next;
  if (list->first)
    list->first->prev = NULL;
  else
    list->last = NULL;

  free (old);

  list->size--;

  return wert;
}

/* NAME : concGenList
 * FUNKTION : haengt einer generischen Liste die andere Liste an, app ist danach leer
 * UEBERGABEPARAMETER : Zeiger auf zwei IntLists
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (20.10.1998)
 * LETZTE AENDERUNG AM : 20.10.1998
 */
void concGenList (p_genList list, p_genList app) {
  p_genListNode gIter;
  assert (list != NULL && app != NULL);
  assert (list != app);
  if (list->size == 0) {
    assert (list->first == NULL);
    list->first = app->first;
    list->size = app->size;
    list->last = app->last;
  } else {
    assert (list->first != NULL);
    if (app->size != 0) {
      assert (app->first != NULL);
      list->last->next = app->first;
      app->first->prev = list->last;
      list->last = app->last;
      list->size += app->size;
    } else {
      assert (app->first == NULL);
    }
  }
  gIter = app->first;
  while (gIter) {
    gIter->list = list;
    gIter = gIter->next;
  }
  app->first = app->last = NULL;
  app->size = 0;
}

/* NAME : delNodeGen
 * FUNKTION : loeschen eines beliebigen Eintrags einer Liste
 * UEBERGABEPARAMETER : Zeiger auf einen genListNode
 * RUECKGABEWERT : Zeiger auf Daten, Verantwortung fuer Speicher nicht mehr bei der Liste
 * ERSTELLT VON : Sascha Ulbrand (08.10.1998)
 * LETZTE AENDERUNG AM : 08.10.1998
 */
void* delNodeGen (p_genListNode node) {
  void* val;
  p_genList list;

  assert (node);

  list = node->list;

  if (node == list->first) {
    list->first = node->next;
    if (node->next) list->first->prev = NULL;
    else list->last = list->first;
  } else if (node == list->last) {
    list->last = list->last->prev;
    if (list->last) list->last->next = NULL;
    else list->first = list->last;
  } else {
    node->prev->next = node->next;
    node->next->prev = node->prev;
  }
  val = node->data;
  free (node);
  list->size--;
  return val;
}

/* NAME : clearGenList
 * FUNKTION : loescht Inhalt einer genList
 * UEBERGABEPARAMETER : Zeiger auf genList
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (28.10.1998)
 * LETZTE AENDERUNG AM : 28.10.1998
 */
void clearGenList (p_genList list) {
  p_genListNode pIter, next;
  assert (list != NULL);
  pIter = list->first;
  while (pIter) {
    free (pIter->data);
    next = pIter->next;
    free (pIter);
    pIter = next;
  }
  list->first = list->last = NULL;
  list->size = 0;
}

/********************************************************************************/
/*                                                                              */
/* Funktionen zur Bearbeitung von speziellen Instanzen generischer Listen       */
/*                                                                              */
/********************************************************************************/

/* NAME : addEdgeWeight
 * FUNKTION : fuegt ein tripel des typs weightedEdge an die Liste an
 * UEBERGABEPARAMETER : Zeiger auf initialisierte genList (list) und drei Werte (from,to,val)
 * BEMERKUNG : Es wird nicht ueberprueft, ob Kanten doppelt angefuegt werden (ist effizienter)
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (22.01.1999)
 * LETZTE AENDERUNG AM : 22.01.1999
 */
void addEdgeWeight (p_genList list, int from, int to, int val) {
  p_weightedEdge node = (p_weightedEdge) malloc (sizeof(weightedEdge));
  assert (from>=0 && to>=0 && val>=0);
  assert (list);
  node->from = from;
  node->to = to;
  node->val = val;
  addLastGen (list, node);
}

/* NAME : getEdgeWeight
 * FUNKTION : sucht in der genList nach dem Wert einer Kante
 * UEBERGABEPARAMETER : Zeiger auf genList (list) und Kante (ungerichtet)
 * RUECKGABEWERT : Wert der Kante
 * ERSTELLT VON : Sascha Ulbrand (22.01.1999)
 * LETZTE AENDERUNG AM : 22.01.1999
 */
int getEdgeWeight (p_genList list, int from, int to) {
  p_genListNode gIter;

  if (list == NULL)
    return NONE;

  assert (list);
  assert (from>=0 && to>=0);

  gIter = list->first;
  while (gIter) {
    if ( ( ( (p_weightedEdge)gIter->data)->from == from && ((p_weightedEdge)gIter->data)->to == to)  ||
	 ( ( (p_weightedEdge)gIter->data)->from == to && ((p_weightedEdge)gIter->data)->to == from) ) {
      return ((p_weightedEdge)gIter->data)->val;
    }
    gIter = gIter->next;
  }

  return NONE; /* keiner gefunden */
}

/* NAME : cutEdgeWithWeight
 * FUNKTION : loescht die erste Kante mit Wert (val) aus der Liste und gibt Zeiger auf die Kante zurueck
 * UEBERGABEPARAMETER : Zeiger auf GenList mit Zeigern auf gewichtete Kanten (list), und Wert (val)
 * RUECKGABEWERT : Zeiger auf Kante, Speicher muss von aufrufender Funktion freigegeben werden
 * ERSTELLT VON : Sascha Ulbrand (25.01.1999)
 * LETZTE AENDERUNG AM : 25.01.1999
 */
p_weightedEdge cutEdgeWithWeight (p_genList list, int val) {
  p_genListNode gIter;
  assert (list);
  gIter = list->first;
  while (gIter) {
    if (((p_weightedEdge)gIter->data)->val == val) {
      return (p_weightedEdge) delNodeGen (gIter);
    }
    gIter = gIter->next;
  }
  assert (false); /* nothing found, should not happen in my program (sul 26.01.1999) */
  return (p_weightedEdge) NULL;
}

/* NAME : printWeightedEdges
 * FUNKTION : Ausgabe einer gewichteten Eckenliste
 * UEBERGABEPARAMETER : Zeiger auf eine Genlist, Inhalt wird als p_edge interpretiert
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (08.02.1998)
 * LETZTE AENDERUNG AM : 08.02.1999
 */
void printWeightedEdges (p_genList list) {
  p_genListNode gIter = list->first;
  while (gIter) {
    printf ("(%i,%i (w=%i)), ", ((p_weightedEdge)gIter->data)->from, ((p_weightedEdge)gIter->data)->to, ((p_weightedEdge)gIter->data)->val);
    gIter = gIter->next;
  }
}

/* NAME : printGenEdges
 * FUNKTION : Ausgabe einer Eckenliste
 * UEBERGABEPARAMETER : Zeiger auf eine Genlist, Inhalt wird als p_edge interpretiert
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (??.10.1998)
 * LETZTE AENDERUNG AM : 22.01.1999
 */
void printGenEdges (p_genList list) {
  p_genListNode gIter = list->first;
  while (gIter) {
    printf ("(%i,%i), ", ((p_edge)gIter->data)->from, ((p_edge)gIter->data)->to);
    gIter = gIter->next;
  }
}


/********************************************************************************/
/*                                                                              */
/* Funktionen zur Verwaltung von ordered partitions                             */
/*                                                                              */
/********************************************************************************/

/* NAME : getNewOrdPartition
 * FUNKTION : erzeugt eine neue Liste
 * UEBERGABEPARAMETER : -
 * RUECKGABEWERT : Zeiger auf eine Liste
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 04.01.1999
 */
p_ordpartition getNewOrdPartition (void) {
  p_ordpartition neu;
  neu = (p_ordpartition) malloc (sizeof (ordpartition));
  neu->size = 0;
  neu->first = NULL;
  neu->last = NULL;
  return neu;
}

/* NAME : delOrdPartition
 * FUNKTION : loescht eine OrdPartition aus dem Speicher
 * UEBERGABEPARAMETER : p_ordpartition (Zeiger auf die Liste)
 * RUECKGABEWERT : keiner
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 04.01.1999
 */
void delOrdPartition (p_ordpartition old) {
  p_intListListNode pIter;
  p_intListListNode pDel;
  assert (old != NULL);
  pIter = old->first;
  while (pIter) {
    pDel = pIter;
    pIter = pIter->next;
    delIntList (pDel->data); /* Data muss auf eine initialisierte intList zeigen */
    free (pDel);
  }
  free (old);
}

/* NAME : addLastOrdPart
 * FUNKTION : Wert ans Ende der Liste anfuegen
 * UEBERGABEPARAMETER : p_ordpartition (Liste, an die angefuegt wird)
                        void* (data) Zeiger auf eine korrekt initialisierte intList, Verantwortung obliegt nun der Liste
 * RUECKGABEWERT : Laenge der Liste nach Anhaengen des Nodes
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 04.01.1999
 */
int addLastOrdPart(p_ordpartition list, p_intList data) {
  p_intListListNode neu;

  assert (list != NULL);

  neu = (p_intListListNode) malloc (sizeof (intListListNode));
  assert (neu);
  neu->data = data;
  neu->list = list;

  if (list->last) {
    list->last->next = neu;
    neu->prev = list->last;
    neu->next = NULL;
    list->last = neu;
  } else {
    neu->prev=NULL;
    neu->next=NULL;
    list->first = neu;
    list->last = neu;
  }
  return list->size++;
}

/* NAME : addFirstOrtPart
 * FUNKTION : Wert ans Ende der Liste anfuegen
 * UEBERGABEPARAMETER : p_ordpartition (Liste, an die angefuegt wird)
                        void* (data) Zeiger auf eine korrekt initialisierte intList, Verantwortung obliegt nun der Liste
 * RUECKGABEWERT : Laenge der Liste nach Anhaengen des Nodes
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 04.01.1999
 */
int addFirstOrtPart(p_ordpartition list, p_intList data) {
  p_intListListNode neu;

  assert (list != NULL);

  neu = (p_intListListNode) malloc (sizeof (intListListNode));
  assert (neu);
  neu->data=data;
  neu->list = list;

  if (list->first) {
    list->first->prev = neu;
    neu->next = list->first;
    neu->prev = NULL;
    list->first = neu;
  } else {
    neu->prev=NULL;
    neu->next=NULL;
    list->first = neu;
    list->last = neu;
  }
  return list->size++;
}

/* NAME : addToNthPartition
 * FUNKTION : fuegt Zahl an die n-te Partition(Liste) an
 * UEBERGABEPARAMETER : Zeiger auf Partitionsliste (list), n (n) und Wert (val)
 * RUECKGABEWERT : 0, falls Liste nicht groesser wurde, 1 falls die Liste um einen vergroessert wurde
 * ERSTELLT VON : Sascha Ulbrand (25.01.1999)
 * LETZTE AENDERUNG AM : 25.01.1999
 */
int addToNthPartition (p_ordpartition list, int n, int val) {
  p_intListListNode lIter;
  assert (list);
  assert (n>=0);

  lIter = list->first;
  while (lIter && n>0) {
    lIter = lIter->next;
    n--;
  }

  if (n==0) {
    addLast (lIter->data, val);
    return 0;
  } else if (n==1) {
    assert (lIter == NULL);
    addLastOrdPart (list, getNewIntList());
    addLast (list->last->data, val);
    return 1;
  } else
    assert (false); /* maximal eine Liste anhaengen */

  return -1;
}


/* NAME : clearOrdPartition
 * FUNKTION : loescht Inhalt einer OrdPartition
 * UEBERGABEPARAMETER : Zeiger auf OrdPartition
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 04.01.1999
 */
void clearOrdPartition (p_ordpartition list) {
  p_intListListNode pIter, next;
  assert (list != NULL);
  pIter = list->first;
  while (pIter) {
    delIntList (pIter->data);
    next = pIter->next;
    free (pIter);
    pIter = next;
  }
  list->first = list->last = NULL;
  list->size = 0;
}

/* NAME : printOrdPartition
 * FUNKTION : gibt ordered partition aus
 * UEBERGABEPARAMETER : Zeiger auf ordpartition
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (04.01.1999)
 * LETZTE AENDERUNG AM : 04.01.1999
 */
void printOrdPartition (p_ordpartition ord) {
  p_intListListNode oIter;
  assert (ord);
  oIter = ord->first;
  while (oIter) {
    printIntList (oIter->data);
    printf (" ");
    oIter = oIter->next;
  }
}

/********************************************************************************/
/*                                                                              */
/* Funktionen zur Verwaltung von blocks                                         */
/*                                                                              */
/********************************************************************************/

/* NAME : getNewBlock (entspricht dem Konstruktor)
 * FUNKTION : erzeuge neuen Block
 * UEBERGABEPARAMETER : (x,y) Ecke und (A) Liste von Attachments
 * RUECKGABEWERT : Zeiger auf initialisierte Struktur
 * ERSTELLT VON : Sascha Ulbrand (20.10.1998)
 * LETZTE AENDERUNG AM : 21.10.1998
 */
p_block getNewBlock (int x, int y, p_intList A) {
  p_edge Pecke = (p_edge) malloc (sizeof(edge));
  p_block blk = (p_block) malloc (sizeof(block));
  blk->Latt = getNewIntList();
  blk->Ratt = getNewIntList();
  blk->Lseg = getNewGenList();
  blk->Rseg = getNewGenList();
  Pecke->from = x;
  Pecke->to = y;
  addLastGen (blk->Lseg, Pecke);

  /* uebertrage die Liste A in Latt */
  blk->Latt->first = A->first;
  blk->Latt->last = A->last;
  blk->Latt->size = A->size;
  A->first = A->last = NULL;
  A->size = 0;

  return blk;
}

/* NAME : delBlock
 * FUNKTION : Loescht einen Block aus dem Speicher
 * UEBERGABEPARAMETER : Zeiger auf den alten Block
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (20.10.1998)
 * LETZTE AENDERUNG AM : 20.10.1998
 */
void delBlock (p_block old) {
  delIntList (old->Latt);
  delIntList (old->Ratt);
  delGenList (old->Lseg);
  delGenList (old->Rseg);
}

/* NAME : flipBlock
 * FUNKTION : tauscht die Seiten eines Blocks aus
 * UEBERGABEPARAMETER : Zeiger auf einen Block
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (20.10.1998)
 * LETZTE AENDERUNG AM : 21.10.1998
 */
void flipBlock (p_block blk) {
  p_intList itemp;
  p_genList gtemp;
  itemp = blk->Ratt; blk->Ratt=blk->Latt; blk->Latt=itemp;
  gtemp = blk->Rseg; blk->Rseg=blk->Lseg; blk->Lseg=gtemp;
}

/* NAME : left_interlace_block
 * FUNKTION : Ueberpruefung von Blockierung auf der linken Seite des uebergebenen Stacks
 * UEBERGABEPARAMETER : (S) Stack von Blocks (vom Typ GenList)
 * RUECKGABEWERT : Wahrheitswert
 * ERSTELLT VON : Sascha Ulbrand (20.10.1998)
 * LETZTE AENDERUNG AM : 21.10.1998
 */
int left_interlace_block (p_block B, p_genList S) {
  assert (B != NULL && S != NULL);
  if (B->Latt->size == 0) {
    printf ("fatal error in planarity test, Block->Latt is never empty\n");
    assert (false);
    exit (1);
  }
  if ( ((S->size!=0) && (((p_block)S->last->data)->Latt->size!=0)) &&
       (B->Latt->last->val < (((p_block)S->last->data)->Latt->first->val)))
    return true;
  else
    return false;
}

/* NAME : right_interlace_block
 * FUNKTION : Ueberpruefung von Blockierung auf der rechten Seite des uebergebenen Stacks
 * UEBERGABEPARAMETER : (S) Stack von Blocks (vom Typ GenList)
 * RUECKGABEWERT : Wahrheitswert
 * ERSTELLT VON : Sascha Ulbrand (20.10.1998)
 * LETZTE AENDERUNG AM : 21.10.1998
 */
int right_interlace_block (p_block B, p_genList S) {
  assert (B != NULL && S != NULL);
  if (B->Latt->size == 0) {
    printf ("fatal error in planarity test, Block->Latt is never empty\n");
    assert (false);
    exit (1);
  }
  if ( ((S->size!=0) && (((p_block)S->last->data)->Ratt->size!=0)) &&
       (B->Latt->last->val < (((p_block)S->last->data)->Ratt->first->val)))
    return true;
  else
    return false;
}

/* NAME : combine_blocks
 * FUNKTION : Fuegt den zweiten Block an das Ende des ersten an
 * UEBERGABEPARAMETER : Zwei Blocks
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (20.10.1998)
 * LETZTE AENDERUNG AM : 21.10.1998
 */
void combine_blocks (p_block thisone, p_block other) {
  assert (thisone != NULL && other != NULL);

  concIntList (thisone->Latt, other->Latt);
  concIntList (thisone->Ratt, other->Ratt);
  concGenList (thisone->Lseg, other->Lseg);
  concGenList (thisone->Rseg, other->Rseg);

}

/* NAME : clean_block
 * FUNKTION : entfernt alle Attachments eines Blocks nach w, setzt alpha von Ecken
 * UEBERGABEPARAMETER : (thisone) Block (dfsnum_w) DFS-Nummer, (alpha) Seite, zu der eine Ecke geht
 * RUECKGABEWERT :
 * ERSTELLT VON : Sascha Ulbrand (20.10.1998)
 * LETZTE AENDERUNG AM : 21.10.1998
 */
int clean_block (p_block thisone, int dfsnum_w, char** alpha) {
  p_genListNode gIter;

  assert (thisone != NULL);

  while (thisone->Latt->size != 0 && thisone->Latt->first->val == dfsnum_w)
    popFirst (thisone->Latt);
  while (thisone->Ratt->size != 0 && thisone->Ratt->first->val == dfsnum_w)
    popFirst (thisone->Ratt);

  if (thisone->Latt->size || thisone->Ratt->size)
    return false;

  /* Latt und Ratt sind leer */
  gIter = thisone->Lseg->first;
  while (gIter) {
    if (alpha)
      alpha [((p_edge) gIter->data)->from][((p_edge) gIter->data)->to] = left;
    gIter = gIter->next;
  }

  gIter = thisone->Rseg->first;
  while (gIter) {
    if (alpha)
      alpha [((p_edge) gIter->data)->from][((p_edge) gIter->data)->to] = right;
    gIter = gIter->next;
  }
  return true;
}

/* NAME : add_to_att_block
 * FUNKTION : Fuegt einen Block ans Ende von Att an, flip(ped) falls notwendig
 * UEBERGABEPARAMETER : (thisone) Zeiger auf einen Block ,
 *                      (att) Attachment,
 *                      (dfsnum_w0) Rechte Seite hat kein Attachment ueber w0,
 *                      (alpha) Seite zu der die Ecken gehen
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (21.10.1998)
 * LETZTE AENDERUNG AM : 21.10.1998
 */
void add_to_att_block (p_block thisone, p_intList Att, int dfsnum_w0, char** alpha) {

  p_genListNode gIter;

  assert (thisone != NULL);
  assert (Att != NULL);
  // assert (alpha != NULL);

  if (thisone->Ratt->size && thisone->Ratt->first->val > dfsnum_w0)
    flipBlock (thisone);

  concIntList (Att, thisone->Latt);
  concIntList (Att, thisone->Ratt);

  gIter = thisone->Lseg->first;
  while (gIter) {
    if (alpha)
      alpha [((p_edge) gIter->data)->from][((p_edge) gIter->data)->to] = left;
    gIter = gIter->next;
  }

  gIter = thisone->Rseg->first;
  while (gIter) {
    if (alpha)
      alpha [((p_edge) gIter->data)->from][((p_edge) gIter->data)->to] = right;
    gIter = gIter->next;
  }

}

/* NAME : printBlock
 * FUNKTION : gibt einen Block aus
 * UEBERGABEPARAMETER : Zeiger auf einen Block
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (23.10.1998)
 * LETZTE AENDERUNG AM : 23.10.1998
 */
void printBlock (p_block blk) {
  p_genListNode gIter;

  printf ("Block:\nLatt: ");
  printIntList (blk->Latt);
  printf ("\nRatt: ");
  printIntList (blk->Ratt);
  printf ("\nLseg: ");

  gIter = blk->Lseg->first;
  while (gIter) {
    printf ("(%i, %i),", ((p_edge)gIter->data)->from, ((p_edge)gIter->data)->to);
    gIter = gIter->next;
  }
  printf ("\nRseg: ");

  gIter = blk->Rseg->first;
  while (gIter) {
    printf ("(%i, %i),", ((p_edge)gIter->data)->from, ((p_edge)gIter->data)->to);
    gIter = gIter->next;
  }
  printf ("\n");
}

/********************************************************************************/
/*                                                                              */
/* Funktionen zur Verwaltung von intSets                                        */
/*                                                                              */
/********************************************************************************/

/* NAME : getNewIntSet
 * FUNKTION : belegt Speicher fuer einen intSet
 * UEBERGABEPARAMETER : maximales Element - 1
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (26.10.1998)
 * LETZTE AENDERUNG AM : 26.10.1998
 */
p_intSet getNewIntSet (int range) {
  int elem;
  p_intSet set = (p_intSet) malloc (sizeof(intSet));
  assert (range > 0);
  set->range = range;
  set->size = 0;
  set->firstElem = NONE;
  set->inSet = (int*) malloc(sizeof(int) * range);
  set->nextElem = (int*) malloc(sizeof(int) * range);
  set->prevElem = (int*) malloc(sizeof(int) * range);
  for (elem = 0; elem < set->range; elem++) {
    set->inSet[elem] = false;
    set->nextElem[elem] = set->prevElem[elem] = NONE;
  }
  return set;
}

/* NAME : delIntSet
 * FUNKTION : gibt Speicher fuer einen intSet frei
 * UEBERGABEPARAMETER : Zeiger auf intSet
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (26.10.1998)
 * LETZTE AENDERUNG AM : 26.10.1998
 */
void delIntSet (p_intSet set) {
  assert (set != NULL);
  free (set->inSet);
  free (set->nextElem);
  free (set->prevElem);
  free (set);
}

/* NAME : intSetIncl
 * FUNKTION : fuegt Element in die Menge ein
 * UEBERGABEPARAMETER : Zeiger auf intSet und ein Element
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (26.10.1998)
 * LETZTE AENDERUNG AM : 26.10.1998
 */
void intSetIncl (p_intSet set, int elem) {
  assert (set != NULL);
  assert (0 <= elem && elem < set->range);
  if (!set->inSet[elem]) {
    if (set->size == 0) {
      set->firstElem = elem;
      set->nextElem[elem] = NONE;
      set->prevElem[elem] = NONE;
    } else {
      set->nextElem[elem] = set->firstElem;
      set->prevElem[set->firstElem] = elem;
      set->firstElem = elem;
    }
    set->inSet[elem] = true;
    set->size++;
  }
}

/* NAME : intSetExcl
 * FUNKTION : loescht Element aus der Menge
 * UEBERGABEPARAMETER : Zeiger auf intSet und Element
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (26.10.1998)
 * LETZTE AENDERUNG AM : 26.10.1998
 */
void intSetExcl (p_intSet set, int elem) {
  assert (set != NULL);
  assert (elem >= 0 && elem < set->range);
  if (set->inSet[elem]) {
    if (elem == set->firstElem) {
      set->firstElem = set->nextElem[elem];
      if (set->firstElem != NONE) {
        set->prevElem[set->firstElem] = NONE;
      }
    } else {
      set->nextElem[set->prevElem[elem]] = set->nextElem[elem];
      if (set->nextElem[elem] != NONE)
	set->prevElem[set->nextElem[elem]] = set->prevElem[elem];
    }
    set->inSet[elem] = false;
    set->size--;
  }
}

/* NAME : intSetClear
 * FUNKTION : leert eine Menge
 * UEBERGABEPARAMETER : Zeiger auf intSet
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (27.10.1998)
 * LETZTE AENDERUNG AM : 27.10.1998
 */
void intSetClear (p_intSet set){
  int i;
  set->size = 0;
  set->firstElem = 0;
  for (i=0; i<set->range; i++) {
    set->inSet[i] = false;
    set->nextElem[i] = set->prevElem[i] = NONE;
  }
}

/* NAME : copyIntSet
 * FUNKTION : kopiert intSet
 * UEBERGABEPARAMETER : (dest) und (source)
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (10.11.1998)
 * LETZTE AENDERUNG AM : 10.11.1998
 */
void copyIntSet (p_intSet dest, p_intSet source) {
  int i;
  assert (source != NULL);
  assert (dest != NULL);
  dest->range = source->range;
  dest->size = source->size;
  dest->firstElem = source->firstElem;
  for (i=0; i<dest->range; i++) {
    dest->inSet[i] = source->inSet[i];
    dest->nextElem[i] = source->nextElem[i];
    dest->prevElem[i] = source->prevElem[i];
  }
}

/* NAME : isInIntSet
 * FUNKTION : ueberprueft, ob Element in der Menge ist
 * UEBERGABEPARAMETER : Zeiger auf intSet und zu ueberpruefendes Element
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (26.10.1998)
 * LETZTE AENDERUNG AM : 26.10.1998
 */
int isInIntSet (p_intSet set, int elem) {
  assert (set != NULL);
  assert (elem >= 0 && elem < set->range);
  return set->inSet[elem];
}

/* NAME : copyIntListToIntSet
 * FUNKTION : uebernimmt Werte einer Liste in eine bereits existierende intList
 * BEMERKUNG : Bereits im intSet befindliche Werte werden vorher geloescht
 * UEBERGABEPARAMETER : Zeiger auf intSet und Zeiger auf intList
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (22.01.1999)
 * LETZTE AENDERUNG AM : (22.01.1999)
 */
void copyIntListToIntSet (p_intSet set, p_intList list) {
  p_intListNode pIter;
  assert (set && list);
  intSetClear (set);
  pIter = list->first;
  while (pIter) {
    assert (pIter->val < set->range); /* sonst ist ein Element zu gross */
    intSetIncl (set, pIter->val);
    pIter = pIter->next;
  }
}

/* NAME : printIntSet
 * FUNKTION : gibt intSet aus
 * UEBERGABEPARAMETER : Zeiger auf intSet
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (26.10.1998)
 * LETZTE AENDERUNG AM : 26.10.1998
 */
void printIntSet (p_intSet set) {
  int elem;
  int separate = false;
  assert (set != NULL);
  printf ("{");
  for (elem=0; elem<set->range; elem++) {
    if (set->inSet[elem]) {
      if (separate)
	printf (", ");
      else
	separate = true;
      printf ("%i", elem);
    }
  }
  printf ("}");
}

/********************************************************************************/
/*                                                                              */
/* Funktionen zur Verwaltung von BoundingBoxes                                  */
/*                                                                              */
/********************************************************************************/

/* NAME : getNewBoundingBox
 * FUNKTION : initialisiert neue Bounding-Box
 * UEBERGABEPARAMETER : -
 * RUECKGABEWERT : Zeiger auf BoundingBox
 * ERSTELLT VON : Sascha Ulbrand (08.01.1999)
 * LETZTE AENDERUNG AM : 08.01.1999
 */
p_boundingBox getNewBoundingBox (int in, int out) {
  p_boundingBox neu = (p_boundingBox) malloc (sizeof(boundingBox));
  int i;
  assert (neu);
  assert (in>=0 && out>=0);
  neu->nodeNum = -1;
  neu->x = neu->y = -1;
  neu->in = in;
  neu->out = out;
  neu->maxlevel = -1;
  neu->inPoints = (p_relPoints*) malloc(sizeof (p_relPoints)*in);
  neu->outPoints = (p_relPoints*) malloc(sizeof (p_relPoints)*out);
  for (i=0; i<in; i++) {
    neu->inPoints[i] = (p_relPoints) malloc (sizeof(relPoints));
    neu->inPoints[i]->xrel = neu->inPoints[i]->yrel = neu->inPoints[i]->toNode = neu->inPoints[i]->level = NONE;
  }
  for (i=0; i<out; i++) {
    neu->outPoints[i] = (p_relPoints) malloc (sizeof(relPoints));
    neu->outPoints[i]->xrel = neu->outPoints[i]->yrel = neu->outPoints[i]->toNode = neu->outPoints[i]->level = NONE;
  }
  return neu;
}

/* NAME : delBoundingBox
 * FUNKTION : loescht boundingBox aus dem Speicher
 * UEBERGABEPARAMETER : Zeiger auf boundingBox
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (08.01.1999)
 * LETZTE AENDERUNG AM : 08.01.1999
 */
void delBoundingBox (p_boundingBox old) {
  assert (old);
  if (old->inPoints)
    free (old->inPoints);
  if (old->outPoints)
    free (old->outPoints);
  free (old);
}

/* NAME : minimumToLeft
 * FUNKTION : ermittelt minimale xrel-Position einer ordentlich(!) installierten BoundinBox
 * UEBERGABEPARAMETER : Zeiger auf Boundingbox (box)
 * RUECKGABEWERT : Minimale relative x-Position
 * ERSTELLT VON : Sascha Ulbrand (15.01.1999)
 * LETZTE AENDERUNG AM : 15.01.1999
 */
int minimumToLeft (p_boundingBox box) {
  int xo=0;
  int xi=0;
  assert (box);
  if (box->in) {
    xi = box->inPoints[0]->xrel;
  }
  if (box->out) {
    xo = box->outPoints[0]->xrel;
  }
  return MINIMUM (xi,xo);
}

/* NAME : maximumToRight
 * FUNKTION : ermittelt maximale xrel-Position einer ordentlich(!) installierten BoundinBox
 * UEBERGABEPARAMETER : Zeiger auf Boundingbox (box)
 * RUECKGABEWERT : maximale relative x-Position
 * ERSTELLT VON : Sascha Ulbrand (15.01.1999)
 * LETZTE AENDERUNG AM : 15.01.1999
 */
int maximumToRight (p_boundingBox box) {
  int xo=0;
  int xi=0;
  assert (box);
  if (box->in) {
    xi = box->inPoints[box->in-1]->xrel;
  }
  if (box->out) {
    xo = box->outPoints[box->out-1]->xrel;
  }
  return MAXIMUM (xi,xo);
}

/* NAME : minimumToBottom
 * FUNKTION : ermittelt minimale xrel-Position einer ordentlich(!) installierten BoundinBox
 * UEBERGABEPARAMETER : Zeiger auf Boundingbox (box)
 * RUECKGABEWERT : Minimale relative x-Position
 * ERSTELLT VON : Sascha Ulbrand (15.01.1999)
 * LETZTE AENDERUNG AM : 18.01.1999
 */
int minimumToBottom (p_boundingBox box) {
  int ymin=0;
  int i;
  assert (box);
  if (box->in) {
    for (i=0; i<box->in; i++)
      ymin = MINIMUM (ymin, box->inPoints[i]->yrel);
  }
  return ymin;
}

/* NAME : maximumToTop
 * FUNKTION : ermittelt minimale xrel-Position einer ordentlich(!) installierten BoundinBox
 * UEBERGABEPARAMETER : Zeiger auf Boundingbox (box)
 * RUECKGABEWERT : Minimale relative x-Position
 * ERSTELLT VON : Sascha Ulbrand (15.01.1999)
 * LETZTE AENDERUNG AM : 18.01.1999
 */
int maximumToTop (p_boundingBox box) {
  int ymax=0;
  int i;
  assert (box);
  if (box->out) {
    for (i=0; i<box->out; i++)
      ymax = MAXIMUM (ymax, box->outPoints[i]->yrel);
  }
  return ymax;
}

/* NAME : relPointPosition
 * FUNKTION : liefert Zeiger auf zum Knoten (node) fuehrenden Struktur p_relPoints
 * UEBERGABEPARAMETER : Zeiger auf BoundingBox (box) und Zielknoten (node)
 * RUECKGABEWERT : Zeiger auf p_relPoints
 * ERSTELLT VON : Sascha Ulbrand (18.01.1999)
 * LETZTE AENDERUNG AM : 18.01.1999
 */
p_relPoints relPointPosition (p_boundingBox box, int node) {
  int iter;
  assert (box && node>=0);
  if (box->in) {
    for (iter = 0; iter<box->in; iter++) {
      if (box->inPoints[iter]->toNode == node)
	return box->inPoints[iter];
    }
  }
  if (box->out) {
    for (iter = 0; iter<box->out; iter++) {
      if (box->outPoints[iter]->toNode == node)
	return box->outPoints[iter];
    }
  }
  assert (false); /* nothing found, should not happen in my program (sul, 26.01.1999) */
  return (p_relPoints) NULL;
}


/* NAME : printBoundingBox
 * FUNKTION : gibt BoundingBox aus
 * UEBERGABEPARAMETER : Zeiger auf BoundingBox
 * RUECKGABEWERT : -
 * ERSTELLT VON : Sascha Ulbrand (13.01.1999)
 * LETZTE AENDERUNG AM : 13.01.1999
 */
void printBoundingBox (p_boundingBox box) {
  int i;
  printf ("Bounding Box of node %i at position (x,y)=(%i,%i)\n",
	  box->nodeNum, box->x, box->y);
  printf ("inpoints  (#=%i)\n",box->in);
  for (i=0; i<box->in; i++)
    printf ("  %i: rel (%i, %i) to node %i (level %i)\n", i,
	    box->inPoints[i]->xrel,
	    box->inPoints[i]->yrel,
	    box->inPoints[i]->toNode,
	    box->inPoints[i]->level);
  printf ("outpoints (#=%i)\n",box->out);
  for (i=0; i<box->out; i++)
    printf ("  %i: rel (%i, %i) to node %i (level %i)\n", i,
	    box->outPoints[i]->xrel,
	    box->outPoints[i]->yrel,
	    box->outPoints[i]->toNode,
	    box->outPoints[i]->level);
  printf ("\n");
}



/********************************************************************************/
/*                                                                              */
/* allgemeine Funktionen                                                        */
/*                                                                              */
/********************************************************************************/

void printIntArr (char* title, int* arr, int size) {
  int i;
  printf ("%s",title);
  for (i=0; i<size; i++) {
    if ((i%10) == 0) printf ("| ");
    printf ("%i ", arr[i]);
  }
  printf ("\n");
}

void initIntArr (int* arr, int size, int init) {
  int i;
  assert (size>0);
  for (i=0; i<size; i++)
    arr[i] = init;
}

