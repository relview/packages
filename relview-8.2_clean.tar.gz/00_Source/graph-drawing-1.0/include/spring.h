#ifndef _SME_SPRING_H
#define _SME_SPRING_H

#define VERY_BIG 10000
#define VIRTUAL 1
#define VIRT_HEAD 2
#define VIRT_TAIL 3
#define ORIGINAL 0

typedef int * INT_POINTER;

/* Datenstrukturen fuer die Spring-Embedder */

typedef struct {
  int head;
  int tail;
  int back_and_forth;
} S_EDGE;

typedef struct {
  float x_pos;
  float y_pos;
  float displ_x;
  float displ_y;
} S_NODE;

typedef struct {
  int node_count;
  int edge_count;
  S_NODE * nodes;
  S_EDGE * edges;
  int * inj;
} S_GRAPH;

#endif
