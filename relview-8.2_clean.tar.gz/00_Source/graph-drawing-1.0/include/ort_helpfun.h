/****************************************************************************/
/* Dateiname: ort_helpfun.h                                                 */
/* Enthaelt Typ-Definitionen und Prozedur-Koepfe fuer die Hilfsfunktionen   */
/* fuer die Darstellung von orthogonalen Graphen.                           */
/* Autor: Ulf Milanese (09.12.1998)                                         */
/* zuletzt geaendert am: 10.02.1999                                         */
/****************************************************************************/

#ifndef _UMI_ort_helpfun_h_
#define _UMI_ort_helpfun_h_

#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <malloc.h>
#include <glib.h>

#include "helpfunc.h"

/* Zeiger auf ein zwei-dimensionales, dynamisches Array von Integern.       */

typedef struct numberarray * numberarrayptr;

/* Zahlen-Feld: Hilfsstruktur fuer die Darstellung einer Visibility         */
/* Representation. inhalt ist der repraesentierte Knoten, left (right)      */
/* enthalten die Knotennummer, falls der Knoten weiter nach links (rechts)  */
/* verlaeuft, down (up) gibt an, welcher Knoten an dieser Stelle durch eine */
/* inzidente Kante mit dem Knoten inhalt verbunden ist. Befindet sich kein  */
/* Knoten an dieser Stelle, sind left und right gleich FIELD_FREE, durch-   */
/* laeuft eine Kante diese Stelle ist inhalt gleich FIELD_USED, up der oben */
/* und down der unten liegende Knoten. Ist dies nicht der Fall, sind die    */
/* drei Felder gleich FIELD_FREE. p_left (p_right, p_up, p_down) sind       */
/* Zeiger auf die benachbarten Felder des Arrays.                           */

typedef struct numberarray {
  int inhalt;
  int left;
  int down;
  int right;
  int up;
  numberarrayptr p_left;
  numberarrayptr p_down;
  numberarrayptr p_right;
  numberarrayptr p_up;
} numberarray;

/* Zeiger auf eine Visibility Representation                                */

typedef struct visibilityrep * visibilityrepptr;

/* Visibility Representation : Ein (planarer) Graph wird dargestellt, indem */
/* jeder Knoten durch einen horizontal verlaufenden Strich repraesentiert   */
/* wird und eine Kante durch eine vertikal verlaufende Linie. Die Linien    */
/* schneiden sich genau dann, wenn eine Kante mit einem Knoten adjazent     */
/* ist. zeilen und spalten gibt die Groesse des dynamischen Integer-Arrays  */
/* an, das zur Darstellung verwendet wird, top_left (top_right,             */
/* bottom_left) ist ein Zeiger, der auf die obere linke (obere rechte,      */
/* untere linke) Ecke des zweidimensionalen Arrays zeigt.                   */
 
typedef struct visibilityrep {
  unsigned int zeilen;
  unsigned int spalten;
  numberarrayptr top_left;
  numberarrayptr top_right;
  numberarrayptr bottom_left;
} visibilityrep;

/* Zeiger auf eine Liste von Flaechen : Jede Flaeche wird durch eine Liste  */
/* der begrenzenden Kanten beschrieben.                                     */

typedef struct facelist * facelistptr;

struct edge_t
{
	int from, to;
};

typedef struct facelist {
  edgelistptr face;
  facelistptr next;
} facelist;

/* Zeiger auf eine Liste von adjazenten Kanten                              */

typedef struct adjlist * adjlistptr;

/* Adjazenz-Liste : dest ist der Endknoten einer Kante, next die im Uhr-    */
/* zeigersinn naechste mit dem Ursprungsknoten verbundene Kante, sym die    */
/* (symmetrische) Rueckkante, angle ist der Winkel zur naechsten Kante in   */
/* PI/2 (1, 2, 3 oder 4), in winkel steht der tatsaechliche Winkel (90, 180 */
/* 270 oder 360), bends gibt an, wieviele Links-Knicke sich auf dieser      */
/* Kante befinden und ziel ist der naechste Knoten auf dieser Kante         */
/* (eventuell ein Hilfsknoten).                                             */

typedef struct adjlist {
  int dest;
  adjlistptr next;
  adjlistptr sym;
  unsigned int angle;
  unsigned int bends;
  unsigned int winkel;
  int ziel;
} adjlist;

/* Zeiger auf eine Orthogonal Representation                                */

typedef struct orthogonalrep * orthogonalrepptr;

/* Orthogonale Repraesentation : number ist die Knotennummer, pos_x und     */
/* pos_y die vergebene Position, help_node ist gleich 1, falls number ein   */
/* Hilfsknoten ist, sonst 0, adjazent ist die Adjazenz-Liste und next ein   */
/* Zeiger auf den naechsten Knoten.                                         */

typedef struct orthogonalrep {
  int number;
  int pos_x;
  int pos_y;
  int help_node;
  adjlistptr adjazent;
  orthogonalrepptr next;
} orthogonalrep;


#define FIELD_FREE -2
#define FIELD_USED -1
#define FIELD_WAIT -3

/* ab hier die nach aussen bekanntgegebenen Funktionen des Moduls           */

orthogonalrepptr new_orthogonal_representation (unsigned int);
orthogonalrepptr insert_node_in_orthogonal_edge (orthogonalrepptr, int, int);
void del_orthogonal_representation (orthogonalrepptr);
void set_angle (orthogonalrepptr, int, int, int);
void increase_bends (orthogonalrepptr, int, int);
void set_node_order (orthogonalrepptr, p_intList);
void print_orthogonal_representation (orthogonalrepptr);
int append_edge_to_orthogonal_representation (orthogonalrepptr, int, int,
					      p_adjList);
int del_nodepair_from_orthogonal (orthogonalrepptr, int, int);
void del_help_nodes_around_node (orthogonalrepptr, orthogonalrepptr, int);
void del_help_node_from_orthogonal_edge (orthogonalrepptr, adjlistptr);
void transformation_T1 (orthogonalrepptr);
void transformation_T2 (orthogonalrepptr);
void transformation_T3 (orthogonalrepptr);
void renumber_orthogonal_representation (orthogonalrepptr);
void make_horizontal_space_in_orthogonal (orthogonalrepptr, int, int, int);
void make_vertikal_space_in_orthogonal (orthogonalrepptr, int, int, int);
void make_edge_in_orthogonal (adjlistptr, int, int, int,
			      adjlistptr, int, int, int);

visibilityrepptr new_visibility_representation (p_intList);
void del_visibility_representation (visibilityrepptr);
void print_visibility_representation (visibilityrepptr);
void append_new_row_after (visibilityrepptr, int, int);
void insert_column_after (visibilityrepptr, int);
int append_column (visibilityrepptr);
int add_edge_to_visibility (visibilityrepptr, int, int, int);
int find_column_in_visibility (visibilityrepptr, int);

numberarrayptr new_numberarray (void);
void del_numberarray (numberarrayptr);
void del_numberarray_down (numberarrayptr);
void print_numberarray (numberarrayptr);

edgelistptr copy_edgelist (edgelistptr);
edgelistptr right_face_of_edge (edgelistptr, p_adjList, p_intList);
void del_edgelistptr (edgelistptr);
void  del_edges_in_edgelist (edgelistptr, edgelistptr);
int edge_is_in (edgelistptr, edgelistptr);
void append_edge_to_edgelist (edgelistptr, edgelistptr);
void append_edgelist_to_edgelist (edgelistptr, edgelistptr);
void print_face (edgelistptr);
void print_edgelist (edgelistptr);

facelistptr new_facelist (void);
void print_faces (facelistptr);
void del_facelist (facelistptr);

adjlistptr new_adjlist (unsigned int);
void print_adjlist (adjlistptr);
void del_adjlist (adjlistptr);

unsigned int manhattan_distance (unsigned int, unsigned int,
				 unsigned int, unsigned int);

//void print_relation (Rel *);

#include "planar.h"
#endif
