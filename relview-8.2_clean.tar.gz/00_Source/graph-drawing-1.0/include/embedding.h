/* $Revision: 1.1.1.1 $ 
 * $Header: /home/cvsroot/relview/relview/include/embedding.h,v 1.1.1.1 2008/03/14 11:33:24 stefan Exp $ 
 * $State: Exp $
 * $Log: embedding.h,v $
 * Revision 1.1.1.1  2008/03/14 11:33:24  stefan
 * Initial import to CVS.
 *
 *
 * Revision 1.7  1999/02/24 16:26:56  sul
 * neuen MIXMOD-Algorithmus zusammengehackt ;-)
 *
 * Revision 1.6  1999/02/16 12:01:51  sul
 * minor changes
 *
 * Revision 1.5  1999/02/13 15:27:08  sul
 * RCS-Information fuer Debuggingzwecke bereitgestellt
 *
 * Revision 1.4  1999/02/11 14:53:04  sul
 * neue Funktion computeSTnumbering
 *
 * Revision 1.3  1999/01/07 13:14:01  sul
 * neue Funktionsdeklaration
 *
 * Revision 1.2  1998/11/05 14:48:12  sul
 * Funktion zur Berechnung der Triangulierung
 *
 * Revision 1.1  1998/10/29 16:36:20  sul
 * Initial revision
 *
 */

#ifndef _SUL_embedding_h_
#define _SUL_embedding_h_

#ifdef _embedding_c_
char embedding_h_rcsid[] __attribute__((unused)) ="$Id: embedding.h,v 1.1.1.1 2008/03/14 11:33:24 stefan Exp $";
#else
extern char embedding_h_rcsid[] __attribute__((unused));
#endif

void computeEmbedding(void);
void computeSimpleTriangulation(void);
void computeEnhacedOrdering(void);
void computeSTnumbering(void);
void ConvertTriangularOrdering2EnhacedOrdering(void);
#endif   /* embedding_h */
