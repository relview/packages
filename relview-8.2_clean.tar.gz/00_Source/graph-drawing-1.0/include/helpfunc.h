/* $Revision: 1.1.1.1 $ 
 * $Header: /home/cvsroot/relview/relview/include/helpfunc.h,v 1.1.1.1 2008/03/14 11:33:24 stefan Exp $ 
 * $State: Exp $
 * $Log: helpfunc.h,v $
 * Revision 1.1.1.1  2008/03/14 11:33:24  stefan
 * Initial import to CVS.
 *
 *
 * Revision 1.21  1999/03/18 10:11:32  sul
 * indent
 *
 * Revision 1.20  1999/02/25 18:18:00  sul
 * mehrere Warnungen behoben, die durch -O2 aufgetaucht sind
 * indent durchgfuehrt
 *
 * Revision 1.19  1999/02/23 15:30:14  sul
 * einige Funktionen zur Ausgabe in ein File eingebunden
 *
 * Revision 1.18  1999/02/13 15:27:08  sul
 * RCS-Information fuer Debuggingzwecke bereitgestellt
 *
 * Revision 1.17  1999/02/12 14:28:28  sul
 * Objectfile kann jetzt in C++-Programme gelinkt werden
 *
 * Revision 1.16  1999/02/11 17:08:43  sul
 * uebersetzt jetzt auch mit g++ ohne Warnungen
 *
 * Revision 1.15  1999/02/09 13:57:31  sul
 * Funktion zum Einlesen von Graphen zu Debuggingzwecken
 * eingefuehrt
 */

#ifndef _SUL_helpfunc_h_
#define _SUL_helpfunc_h_

// Must not exceed a very limited amount of characters.
#define UNKNOWN_GRAPH_NAME "SomeGraph"

#ifdef _helpfunc_c_
char helpfunc_h_rcsid[] __attribute__ ((unused)) = "$Id: helpfunc.h,v 1.1.1.1 2008/03/14 11:33:24 stefan Exp $";

#else
extern char helpfunc_h_rcsid[];

#endif

#include <stdio.h>

#define true 1
#define false 0

#define MINIMUM(a,b) ((a)<(b)?(a):(b))
#define MAXIMUM(a,b) ((a)>(b)?(a):(b))

#define UNDEF -16777216
#define NONE -16777216

/* Strukturen fuer Listen von ints */
typedef struct intListNode *p_intListNode;
typedef struct intList *p_intList;
typedef struct intListNode {
  p_intList list;
  p_intListNode next;
  p_intListNode prev;
  int val;
} intListNode;

typedef struct intList {
  int size;
  p_intListNode first;
  p_intListNode last;
} intList;

/* Strukturen fuer generische Listen */
typedef struct genListNode *p_genListNode;
typedef struct genList *p_genList;
typedef struct genListNode {
  p_genList list;
  p_genListNode next;
  p_genListNode prev;
  void *data;
} genListNode;

typedef struct genList {
  int size;
  p_genListNode first;
  p_genListNode last;
} genList;

/* Strukturen fuer Adjazenzlisten */
typedef struct adjList *p_adjList;
typedef struct adjList {
  int size;
  p_intList *aList;
} adjList;

/* Struktur fuer eine Ordnung */
typedef struct reorder *p_reorder;
typedef struct reorder {
  int size;
  int *phi;
  int *phi_1;
} reorder;

/* Struktur von intList-Listenknoten */
typedef struct ordpartition *p_ordpartition;
typedef struct intListListNode *p_intListListNode;
typedef struct intListListNode {
  p_intListListNode next;
  p_intListListNode prev;
  p_intList data;
  p_ordpartition list;
} intListListNode;

/* Struktur von ordered partitions (==Liste von Listen von ints) */
typedef struct ordpartition {
  p_intListListNode first;
  p_intListListNode last;
  int size;
} ordpartition;

/* Struktur fuer einen PalmTree */
typedef struct palmTree *p_palmTree;
typedef struct palmTree {
  /* von den Hilfsfunktionen verwaltete Felder */
  int size;
  p_adjList tree;
  p_adjList fronds;
  p_intList roots;
  int *preorder;		/* neue Nummerierung der Knoten */
  int *preorder_1;		/* Umkehrfunktion von preorder */
  int *parent;
  int *low;
  int *low2;			/* LOWPT2 aus HT74 u.a. */
  p_intList IndepVertex;

  p_intList *VertSets;		/* hier stehen dann die biconnected Components */
} palmTree;

/* Nachprogrammierung der Klasse block aus MMN93, S. 11-12 */
typedef struct block *p_block;
typedef struct block {
  p_intList Latt, Ratt;
  p_genList Lseg, Rseg;
} block;

/* Nachprogrammierung von Teilen der Klasse intSet aus ATUV97 */
typedef struct intSet *p_intSet;
typedef struct intSet {
  int range;
  int size;
  int firstElem;
  int *inSet;
  int *nextElem;
  int *prevElem;
} intSet;

/* Struktur fuer eine BoundingBox (aus [GM98]) */
typedef struct relPoints *p_relPoints;
typedef struct relPoints {
  int xrel, yrel;
  int toNode;
  int level;
} relPoints;

typedef struct boundingBox *p_boundingBox;
typedef struct boundingBox {
  int nodeNum;
  int x, y;
  int in, out;
  int maxlevel;
  p_relPoints *inPoints;
  p_relPoints *outPoints;
} boundingBox;

/* allgemeine Strukturen ohne Funktionen */
enum side {
  left, right
};

typedef struct edge *p_edge;
typedef struct edge {
  int from, to;
} edge;

typedef struct pair *p_pair;
typedef struct pair {
  int x, y;
} pair;

typedef struct weightedEdge *p_weightedEdge;
typedef struct weightedEdge {
  int from, to, val;
} weightedEdge;

#ifdef __cplusplus
extern "C" {
#endif

/* Funktionen zur Listenverwaltung (intList) */
  p_intList getNewIntList (void);
  p_intList copyIntList (p_intList);
  void delIntList (p_intList old);
  int addLast (p_intList list, int wert);
  int addFirst (p_intList list, int wert);
  int addBefore (p_intListNode, int wert);
  int addAfter (p_intListNode, int wert);
  void delFirst (p_intList list);
  void delLast (p_intList list);
  int popLast (p_intList list);
  int popFirst (p_intList list);
  void concIntList (p_intList list, p_intList app);
  int delNode (p_intListNode node);
  int delVal (p_intList list, int val);
  int inList (p_intList list, int val);
  int indexInList (p_intList list, int val);
  p_intListNode nodeInList (p_intList list, int val);
  p_intListNode nextClock (p_intListNode node);
  p_intListNode prevClock (p_intListNode node);
  void replaceChain (p_intListNode from, p_intListNode to, p_intList by);
  void clearIntList (p_intList list);
  void printIntList (p_intList list);
  void fprintIntList (FILE * out, p_intList list);

/* Funktionen zur Verwaltung von generischen Listen */
  p_genList getNewGenList (void);
  void delGenList (p_genList old);
  int addLastGen (p_genList list, void *data);
  int addFirstGen (p_genList list, void *data);
  void *popLastGen (p_genList list);
  void *popFirstGen (p_genList list);
  void delLastGen (p_genList list);
  void delFirstGen (p_genList list);
  void concGenList (p_genList list, p_genList app);
  void *delNodeGen (p_genListNode node);
  void clearGenList (p_genList list);

/* Funktionen zur Bearbeitung von speziellen Instanzen generischer Listen */
/* WICHTIG: hier muss man wirklich wissen, was man tut, da der Compiler keine 
 * Ahnung hat, welche Instanz der generischen Liste man da eigentlich an die  
 * Funktion gibt. Das kann richtig unschoene Fehler liefern ;-) */

/* Genlists mit Pointern auf Struktur edge (p_edge) */
  void printGenEdges (p_genList list);

/* Genlists mit Pointern auf Struktur weightedEdge (p_weightedEdge) */
  void addEdgeWeight (p_genList list, int from, int to, int val);
  int getEdgeWeight (p_genList list, int from, int to);
  p_weightedEdge cutEdgeWithWeight (p_genList list, int weight);
  void printWeightedEdges (p_genList list);

/* Funktionen zur Verwaltung von ordered partitions */
  p_ordpartition getNewOrdPartition (void);
  void delOrdPartition (p_ordpartition old);
  int addLastOrdPart (p_ordpartition list, p_intList data);
  int addFirstOrtPart (p_ordpartition list, p_intList data);
  int addToNthPartition (p_ordpartition list, int n, int val);
  void clearOrdPartition (p_ordpartition list);
  void printOrdPartition (p_ordpartition list);

/* Funktionen zur Adjazenzlistenverwaltung */
  p_adjList getNewAdjList (int size);
  p_adjList copyAdjList (p_adjList);
  int addNewEdge (p_adjList adj, int from, int to);
  int delEdges (p_adjList adj, int node1, int node2);
  int degNode (p_adjList adj, int node);
  int leftUp (p_adjList, int from, int to);
  int rightUp (p_adjList, int from, int to);
  int prevClockNode (p_adjList adj, int base, int to);
  int nextClockNode (p_adjList adj, int base, int to);
  int areNeighbours (p_adjList adj, int node1, int node2);
  int neighboursIn (p_adjList adj, int node, p_intSet set);
  int countNeighboursIn (p_adjList adj, int node, p_intSet set);
  int addNewEdgeAfter (p_adjList, int from, int to, int after);
  int addNewEdgeBefore (p_adjList, int from, int to, int before);
  void delAdjList (p_adjList);
  void printAdjList (p_adjList list);
  void fprintAdjList (FILE * out, p_adjList list);

/* Funktionen zur Verwaltung von reorders */
  p_reorder getNewReorder (int);
  void delReorder (p_reorder);
  void printReorder (p_reorder);

/* Funktionen zur Verwaltung von PalmTrees */
  p_palmTree getNewPalmTree (int size);
  void delPalmTree (p_palmTree old);
  void printPalmTree (p_palmTree out);

/* Funktionen zur Verwaltung von blocks */
  p_block getNewBlock (int x, int y, p_intList A);
  void delBlock (p_block old);
  void flipBlock (p_block blk);
  int left_interlace_block (p_block B, p_genList S);
  int right_interlace_block (p_block B, p_genList S);
  void combine_blocks (p_block thisone, p_block other);
  int clean_block (p_block thisone, int dfsnum_w, char **alpha);
  void add_to_att_block (p_block blk, p_intList Att, int dfsnum_w0, char **alpha);
  void printBlock (p_block blk);

/* Funktionen zur Verwaltung von intSets */
  p_intSet getNewIntSet (int range);
  void delIntSet (p_intSet set);
  void intSetIncl (p_intSet set, int elem);
  void intSetExcl (p_intSet set, int elem);
  void intSetClear (p_intSet set);
  void copyIntSet (p_intSet dest, p_intSet source);
  int isInIntSet (p_intSet set, int elem);
  void copyIntListToIntSet (p_intSet set, p_intList list);
  void printIntSet (p_intSet set);

/* Funktionen zur Verwaltung von BoundingBoxes */
  p_boundingBox getNewBoundingBox (int in, int out);
  void delBoundingBox (p_boundingBox);
  int minimumToLeft (p_boundingBox box);
  int maximumToRight (p_boundingBox box);
  int minimumToBottom (p_boundingBox box);
  int maximumToTop (p_boundingBox box);
  void setLevelOfEdge (p_boundingBox box, int from, int to, int level);
  p_relPoints relPointPosition (p_boundingBox box, int node);
  void printBoundingBox (p_boundingBox);

/* allgemeine Funktionen */
  void printIntArr (char *title, int *arr, int size);
  void initIntArr (int *, int, int);

#ifdef __cplusplus
};

#endif

#endif /* _helpfunc_h_ */
