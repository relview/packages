#ifndef _SRC_GRAPH_H
#define _SRC_GRAPH_H

#include <glib.h>
#include "relview/plugin.h" // KureRel*

#define MAXNAMELENGTH 2048


/* From lib/include/relation.h in an old RelView distribution. */
#define NORMAL         0 /* normal = sichtbar                               */
#define HIDDEN         1 /* hidden = nicht sichtbar aus startup-file        */
#define TEMP           2 /* temp = Zwischenergebnisse                       */
#define MODIFIED       4 /* modified = geaendert => kein Test auf = graph   */
#define CORRESPONDENCE 8 /* ist fuer den Spezialgraphen gedacht, der Ueber- */
/* sichtlichkeit allerdings bei den Relationen definiert                    */


/* Compiles testing code for managing edges not only in an unsorted singly-
 * linked list, but also in an balanced binary tree. *
 *
 * TODO: There is still an error with the drawing after multiple rel->graph
 *       operations with (e.g.) random graphs.
 *
 * WARNING: Don't use it! It's use would alter the size and structure of
 *          the ddd files. Thus, we would loose backward compatibility with
 *          ddd files created by previous versions of RelView without these
 *          changes to the Graph structure.
 */
//#define EDGES_TREE_LOOKUP

/* Compiled testing code for managing nodes not only in an unsorted singly-
 * linked list, but also in an balanced binary tree.
 *
 * WARNING: See above.
 */
//#define NODES_TREE_LOOKUP

typedef struct _NodeStyle
{
#define NodeStyle_toRGB(r,g,b) ((gint32)((((r)&0xff)<<24)  \
                                         | (((g)&0xff)<<16) \
                                         | (((b)&0xff)<<8) | 0xff))
#define NodeStyle_getRed(c) ((gint)(((c)>>24)&0xff))
#define NodeStyle_getGreen(c) ((gint)(((c)>>16)&0xff))
#define NodeStyle_getBlue(c) ((gint)(((c)>>8)&0xff))
  gint32 color; /*!< 0xrrggbbxx, where x=0xff */
} NodeStyle;

#define VISIBLE            0
#define SELECTED           1
#define HELP               2
#define SELECTED_FOR_EDGE  3
#define WEIGHT             4
#define SELECTED_HELP      5
#define SELECTED_SECOND    6
#define SELECTED_BOTH      7

/* this is not the same as above! */
typedef enum _NodeFlags
{
#define NODE_ADD_FLAG(flags,f) ((NodeFlags)((flags) |= (NodeFlags)(f)))
#define NODE_REMOVE_FLAG(flags,f) ((NodeFlags)((flags) &= ~((NodeFlags)(f))))
#define NODE_HAS_FLAG(flags,f) ((gboolean)((flags) & (NodeFlags)(f)))
#define NODE_HAS_ALL_FLAGS(flags,f) ((gboolean)(((flags) & (f)) == (f)))
  NODE_VISIBLE              = 0x1,
  NODE_SELECTED             = 0x2,
  NODE_HIGHLIGHTED          = 0x4,
  NODE_SELECTED_FOR_EDGE    = 0x8,
  NODE_MARKED_HELP          = 0x10,
  NODE_MARKED_FIRST         = 0x20,
  NODE_MARKED_SECOND        = 0x40,
  NODE_MARKED_THIRD         = 0x80
} NodeFlags;


typedef struct {
  char name [MAXNAMELENGTH + 1];
  int x_pos;
  int y_pos;
  int number;
  int dim;
  int state;

  NodeFlags flags;

  /* extended by stb */
  gboolean useStyle;
  NodeStyle style; /*!< information on how to draw the node */
} Node;

typedef struct nodelist * nodelistptr;
typedef struct nodelist {
  Node node;
  nodelistptr next;
} nodeelem;

typedef struct intlist * intlistptr;
typedef struct intlist {
  int number;
  intlistptr next;
} intelem;

typedef struct _EdgeStyle
{
#define EdgeStyle_toRGB(r,g,b) NodeStyle_toRGB(r,g,b)
#define EdgeStyle_getRed(c) NodeStyle_getRed(c)
#define EdgeStyle_getGreen(c) NodeStyle_getGreen(c)
#define EdgeStyle_getBlue(c) NodeStyle_getBlue(c)
  gint32 color; /*!< 0xrrggbbxx, where x=0xff */
} EdgeStyle;

typedef enum _EdgeFlags
{
#define EDGE_ADD_FLAG(flags,f) ((NodeFlags)((flags) |= (NodeFlags)(f)))
#define EDGE_REMOVE_FLAG(flags,f) ((NodeFlags)((flags) &= ~((NodeFlags)(f))))
#define EDGE_HAS_FLAG(flags,f) ((gboolean)((flags) & (NodeFlags)(f)))
#define EDGE_HAS_ALL_FLAGS(flags,f) ((gboolean)(((flags) & (f)) == (f)))
#define EDGE_HAS_ANY_FLAG(flags,f) ((gboolean)(((flags) & (f)) != 0))
  EDGE_VISIBLE              = 0x1,
  EDGE_SELECTED             = 0x2,
  EDGE_HIGHLIGHTED          = 0x4,
  EDGE_MARKED_FIRST         = 0x20,
  EDGE_MARKED_SECOND        = 0x40,
} EdgeFlags;

typedef struct {
  char name [MAXNAMELENGTH + 1];
  int from;
  int to;
  int state;
  intlistptr path;

  EdgeFlags flags;

  gboolean useStyle;
  EdgeStyle style;  /*!< information on how to draw the edge */
} Edge;

/* TODO: Should be replaced with GList (from GLib) in the future! */
typedef struct edgelist * edgelistptr;
typedef struct edgelist {
  Edge edge;
  edgelistptr next;
} edgeelem;

typedef struct _Graph Graph;

typedef void (*GraphObserver_onDeleteNodeFunc) (gpointer*, Graph*, Node*);
typedef void (*GraphObserver_onDeleteEdgeFunc) (gpointer*, Graph*, Edge*);

/*interface*/ typedef struct _GraphObserver
{
  /* the first argument is always the observer itself. */
  GraphObserver_onDeleteNodeFunc onDeleteNode;
  GraphObserver_onDeleteEdgeFunc onDeleteEdge;

  gpointer * object;
} GraphObserver;

#define graph_get_name(g) ((const gchar*)((g)->name))
#define graph_get_state(g) ((g)->state)
#define graph_get_nodes(g) ((g)->node_root)
#define graph_get_edges(g) ((g)->edge_root)


struct _Graph {
  char name [MAXNAMELENGTH + 1];
  int state;

  nodelistptr node_root;
#ifdef NODES_TREE_LOOKUP
  GTree/*<nodelistptr>*/ * node_tree; /*!< Keys are the node's internal numbers,
                                       * values are the nodelistptr objects. */
#endif

  edgelistptr edge_root;
#ifdef EDGES_TREE_LOOKUP
  GTree/*<edgelistptr>*/ * edge_tree; /*!< Keys are the edges itself,
                                       * values are the edgelistptr objects. */
#endif

  GSList * observers;
};

typedef struct graphlist * graphlistptr;
typedef struct graphlist {
  Graph graph;
  graphlistptr next;
} graphelem;


#define GRAPH_NULL     -2
#define NODELIST_NULL  -3
#define NODE_NOT_FOUND -4


#define EDGELIST_NULL  -2
#define EDGE_NOT_FOUND -3


#define FIRST_MARK_LEVEL   1
#define SECOND_MARK_LEVEL  2

#define MARK_NODE_ERROR    128

#define VISIBLE            0
#define SELECTED           1
#define HELP               2
#define SELECTED_FOR_EDGE  3
#define WEIGHT             4
#define SELECTED_HELP      5
#define SELECTED_SECOND    6
#define SELECTED_BOTH      7

#define SPRING_SLOW    0
#define SPRING_FAST    1
#define TREE           2
#define DAG            3
#define TRIANGLE       4
#define PLANAR         5
#define ORTHOGONAL     6
#define TRIMIX         7
#define ORTHOGONAL_FAST 8


int          graph_get_node_count        (Graph * graph);
void         graph_register_observer     (Graph * n, GraphObserver * observer);
void         graph_unregister_observer   (Graph * n, GraphObserver * observer);

nodelistptr  make_node                   (char *, int, int, int, int);
int          del_node                    (Graph *, int );
int          del_single_node             (Graph *, int );
void         del_help_nodes              (Graph *);
int          append_node                 (Graph *, nodelistptr);
Node *       get_node                    (Graph *, int);
int          get_last_node               (Graph *);
Node *       test_if_node_nearby         (Graph * , int, int);
int          set_node_positions          (Graph *, int, int, int);
int          set_node_state              (Graph *, int, int);
int          get_node_xpos               (Graph *, int);
int          get_node_ypos               (Graph *, int);
int          get_internal_node_nr        (Graph *, int);

edgelistptr  make_edge                   (char * , int, int ,int);
Edge *       get_edge                    (Graph *, int, int);
int          del_edge                    (Graph *, int, int);
int          append_edge                 (Graph *, edgelistptr);
void         append_edge_pathnode        (Edge *, int);
void         prepend_edge_pathnode       (Edge *, int);
int          del_marked_edges            (Graph *);
int          del_connected_edges         (Graph *, int);
nodelistptr  run_edge_path               (Graph *, int ,int);
int          test_if_edge_exist          (Graph *, int ,int);

Graph *      get_graph                   (graphlistptr, char *);
graphlistptr get_graphlistptr            (graphlistptr, char *);
int          graph_exist                 (graphlistptr, char *);
graphlistptr mk_graph                    (char *, int);
graphlistptr append_graph                (graphlistptr, graphlistptr);
int          save_graph                  (graphlistptr, char *);
graphlistptr load_graph                  (char *);
void         renumber_graph              (Graph *);
void         correct_graph               (Graph *);
void         rename_graph                (Graph * , char *);
graphlistptr concat_graph_lists          (graphlistptr, graphlistptr);
graphlistptr merge_graph_lists           (graphlistptr, graphlistptr);
graphlistptr del_graph                   (graphlistptr, char *);
graphlistptr copy_graph                  (Graph *, char *);

void         set_graph_state             (Graph *, int state);
int          get_graph_width             (Graph *);
int          get_graph_height            (Graph *);
int          get_graph_minx              (Graph *);
int          get_graph_miny              (Graph *);

void         unmark_graph_nodes_complete (Graph *);
void         unmark_graph_edges_complete (Graph *);
void         unmark_graph_nodes          (Graph *, int);
void         unmark_graph_edges          (Graph *, int);
int          get_edgemarked_nodes        (Graph *);

graphlistptr reorder_graph               (Graph *);
void         graph_info                  ();

char *       graph_name                  (graphlistptr);
graphlistptr graph_next                  (graphlistptr);
void         swap_graph_hori             (Graph *);

/* alle Module, die mit graphen arbeiten wollen, brauche diesen ListenAnfang */

extern graphlistptr graph_root;

Graph * graph_get_current ();
int graph_get_edge_count (Graph * gr);

void graph_prepend_edge (Graph * graph, edgelistptr edge);
void graph_prepend_node (Graph * gr, nodelistptr node, int number);
gboolean graph_edge_exists (Graph * gr, Node * from, Node * to);
gboolean graph_edge_exists_int (Graph * gr, int from, int to);

void graph_dump (Graph * gr);

/* ---------------------------------------------------------- GraphLayout --- */

typedef struct _GraphLayout GraphLayout;

typedef struct _NodeLayout
{
  gint id;
  gfloat x, y;
} NodeLayout;

typedef enum _EdgeLayoutType
{
  EDGE_LAYOUT_DEFAULT,
  EDGE_LAYOUT_SEGMENTS
} EdgeLayoutType;

#if 0
typedef struct _LayoutPoint
{
  gfloat x,y;
} LayoutPoint, GraphLayoutPoint;
#endif

typedef struct _EdgeLayout
{
  gint fromId, toId;
  EdgeLayoutType type;

  /*! Only used, if type == EDGE_LAYOUT_SEGMENTS. One may omit the
   * first and the last node, if they represent the node positions. */
  GQueue/*<LayoutPoint*>*/ * segs;
} EdgeLayout, GraphEdgeLayout;

struct _GraphLayout
{
  GQueue/*<NodeLayout>*/ * nodes;
  GQueue/*<EdgeLayout*>*/ * edges;
};

GraphEdgeLayout * graph_edge_layout_new (gint from, gint to);
void graph_edge_layout_destroy (GraphEdgeLayout * self);
void graph_edge_layout_add_segments (GraphEdgeLayout*, int, float*);
void graph_edge_layout_add_segments_with_list (GraphEdgeLayout * self,
                                               GList/*<GraphLayoutPoint>*/ * pts);
void graph_edge_apply_layout (Graph * gr, Edge * edge, GraphEdgeLayout * layout);
void graph_edge_layout_dump (GraphEdgeLayout * self);


gboolean graph_apply_layout (Graph * gr, GraphLayout * layout);
void graph_edge_remove_layout (Graph * gr, Edge * edge);

GraphLayout * graph_layout_new ();
void graph_layout_destroy (GraphLayout * obj);
void graph_layout_add_node (GraphLayout * self, gint id, gfloat x, gfloat y);
void graph_layout_add_edge_segments (GraphLayout * self, gint fromId, gint toId,
                                     gint ptsCount, gfloat * pts);

void graph_simplify_layout (Graph * gr);

graphlistptr graph_create_default (KureRel * impl, int radius, const char * name);

#endif /* graph.h? */
