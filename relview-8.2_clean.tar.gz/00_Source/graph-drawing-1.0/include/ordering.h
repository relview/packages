#ifndef _SME_ORDERING_H
#define _SME_ORDERING_H

#define SCANNED 0
#define UNSCANNED 1
#define BESSER 0
#define SCHLECHTER 1
#define DOWN 1
#define UP 0
#define MAX_ITERATIONS 24

/* eigene Funktionen */

static void mk_new_graph (EDGE *, NODE *, int, int);
static void mk_graph_list ();
static void mk_rank_count ();
static void posit (int, int *);
static void init_order ();
static int part_pos (int, int, int, int *);
static void quicksort_pos (int, int, int *);
static float piv_med (int, int, int *);
static int part_med (int, int, float, int *);
static void quicksort_med (int, int, int *);
static void sort (int);
static int *adj_position (int, int);
static float median_value (int, int);
static void wmedian (int);
static void exchange_nodes (int, int);
static int crossing (int, int);
static void transpose ();
static int tot_crossing ();
static void copy ();
static void free_temp_list ();
static void pos_setzen ();
static void rueckgabe (int **, int **, int **, int **, EDGE **, NODE **,
                       int *, int *, INT_POINTER **, int **, int *);
static void set_list ();

/* nach aussen bekannt gegebene Funktionen */

void ordering (int **, int **, int **, int **, EDGE **, NODE **,
               int *, int *, INT_POINTER **, int **, int *);

#endif
