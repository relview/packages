var struct__KureParserObserver =
[
    [ "onFunction", "struct__KureParserObserver.html#a9f1b38af574273d173da712c3a9366eb", null ],
    [ "onProgram", "struct__KureParserObserver.html#aaf80fcd08d4187dfb94824ab6c33e7c5", null ],
    [ "object", "struct__KureParserObserver.html#a28425f473264d2b766e1305e3db37391", null ]
];