var group__ResQuot =
[
    [ "kure_left_residue", "group__ResQuot.html#ga4b05d10998f741ff1930e7ba25ed2f12", null ],
    [ "kure_right_residue", "group__ResQuot.html#gaf9abad4b9f0a2be1d38dc513232888aa", null ],
    [ "kure_symm_quotient", "group__ResQuot.html#ga65749a318822a019bceec5172b7f2ab7", null ]
];