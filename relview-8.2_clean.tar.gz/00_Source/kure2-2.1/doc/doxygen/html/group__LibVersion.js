var group__LibVersion =
[
    [ "KURE_MAJOR_VERSION", "group__LibVersion.html#ga044494a71947089f8e3f358d3a98ab60", null ],
    [ "KURE_MINOR_VERSION", "group__LibVersion.html#ga711c424bc2f0633d520496a0b95e9767", null ],
    [ "KURE_MICRO_VERSION", "group__LibVersion.html#gac296fed69e00e190ce30c4fbe4bbfda9", null ],
    [ "KURE_CHECK_VERSION", "group__LibVersion.html#ga5a0ee23bf953908f2eb97faafe3976c3", null ],
    [ "kure_check_version", "group__LibVersion.html#ga13aa4bbfacbecb72f2e268ee63e4d642", null ]
];