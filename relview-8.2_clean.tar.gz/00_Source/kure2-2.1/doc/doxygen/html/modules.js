var modules =
[
    [ "Relations", "group__Relations.html", "group__Relations" ],
    [ "Domains and Types", "group__DomainsTypes.html", "group__DomainsTypes" ],
    [ "Error Handling", "group__ErrorHandling.html", "group__ErrorHandling" ],
    [ "Library Version", "group__LibVersion.html", "group__LibVersion" ],
    [ "Contexts", "group__Contexts.html", "group__Contexts" ],
    [ "Lua Binding and the RelView Programming Language", "group__LuaAndLanguage.html", "group__LuaAndLanguage" ]
];