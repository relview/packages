var struct__KureError =
[
    [ "message", "struct__KureError.html#a68a862f16802c1e5b29842116d2608e4", null ],
    [ "code", "struct__KureError.html#a1fea2b72143a116c888d386344f92b4b", null ]
];