var group__DomainsTypes =
[
    [ "KureDom", "group__DomainsTypes.html#ga6e4600081a1525f3e1829b1e60d75d5d", null ],
    [ "kure_direct_product_new", "group__DomainsTypes.html#ga2272301e1f7676d4014d19260df68403", null ],
    [ "kure_direct_product_new_si", "group__DomainsTypes.html#ga06d217ec59f480714d0da9a01c61b499", null ],
    [ "kure_direct_sum_new", "group__DomainsTypes.html#ga636032049cce5d444757df6a5c167bc4", null ],
    [ "kure_direct_sum_new_si", "group__DomainsTypes.html#ga1948d09122bad857e19365193c9a4a47", null ],
    [ "kure_dom_new_copy", "group__DomainsTypes.html#ga69e465d127b4c78249d69946eeb585af", null ],
    [ "kure_dom_destroy", "group__DomainsTypes.html#ga3e1b95a6d7089598d2a46fee216d878b", null ],
    [ "kure_dom_get_name", "group__DomainsTypes.html#gae679b9a458892bc401b99eb66a594cc8", null ],
    [ "kure_dom_get_comp_count", "group__DomainsTypes.html#gacfa3bd392858125b521662629cf1c8ec", null ],
    [ "kure_dom_get_comp", "group__DomainsTypes.html#gab9371f9df0a0088f77681a34fb792cfd", null ]
];