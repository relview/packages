var group__Entries =
[
    [ "kure_get_entries", "group__Entries.html#gaf81d0ce9c9a570a910be3271b25790bd", null ],
    [ "kure_get_entries_si", "group__Entries.html#ga2b9703810f6e1f8cdd4da695710dbc3a", null ],
    [ "kure_vec_get_entries", "group__Entries.html#ga6e27b9f5c5e0a8a68241a8ab89782ec3", null ],
    [ "kure_vec_get_entries_si", "group__Entries.html#ga9d422a8dbda64c52f06fc5d915a79a66", null ]
];