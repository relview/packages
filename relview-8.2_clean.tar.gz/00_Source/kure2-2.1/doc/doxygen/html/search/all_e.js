var searchData=
[
  ['special_20sets_20and_20relations',['Special Sets and Relations',['../group__SpecialSets.html',1,'']]]
];
