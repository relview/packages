var searchData=
[
  ['basic_20functions',['Basic Functions',['../group__BasicFuncs.html',1,'']]],
  ['bit_20level_20access',['Bit Level Access',['../group__BitAccess.html',1,'']]]
];
