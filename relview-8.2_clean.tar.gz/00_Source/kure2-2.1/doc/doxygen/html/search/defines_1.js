var searchData=
[
  ['kure_5fdollar_5fsubst',['KURE_DOLLAR_SUBST',['../Kure_8h.html#a9cf3f6c930598758a9b5c04cf9f29b8c',1,'Kure.h']]]
];
