var searchData=
[
  ['_5fkureerror',['_KureError',['../struct__KureError.html',1,'']]],
  ['_5fkureparserobserver',['_KureParserObserver',['../struct__KureParserObserver.html',1,'']]]
];
