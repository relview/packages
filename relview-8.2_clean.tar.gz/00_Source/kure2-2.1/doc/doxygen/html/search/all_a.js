var searchData=
[
  ['message',['message',['../struct__KureError.html#a68a862f16802c1e5b29842116d2608e4',1,'_KureError']]]
];
