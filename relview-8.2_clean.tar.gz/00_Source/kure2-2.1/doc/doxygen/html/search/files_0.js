var searchData=
[
  ['index_2etxt',['index.txt',['../index_8txt.html',1,'']]]
];
