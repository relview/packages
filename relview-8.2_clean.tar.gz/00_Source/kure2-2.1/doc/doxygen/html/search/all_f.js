var searchData=
[
  ['tests',['Tests',['../group__Tests.html',1,'']]],
  ['true',['TRUE',['../Kure_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'Kure.h']]]
];
