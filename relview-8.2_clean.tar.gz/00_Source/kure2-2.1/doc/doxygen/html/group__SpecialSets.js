var group__SpecialSets =
[
    [ "kure_membership", "group__SpecialSets.html#ga6cd951b941734dc101a75c18f897197f", null ],
    [ "kure_partial_funcs", "group__SpecialSets.html#ga78bd675301dd188b4f9a85d4e3be536b", null ],
    [ "kure_partial_funcs_si", "group__SpecialSets.html#ga88dd22cb2bd77bee6394624f824a50a8", null ],
    [ "kure_total_funcs", "group__SpecialSets.html#ga212ce7edfa0c57519efb975d1d1f2729", null ],
    [ "kure_total_funcs_si", "group__SpecialSets.html#ga4f8ebb507c6853fa1717002924231d63", null ],
    [ "kure_successors", "group__SpecialSets.html#ga62a1c1210b101488d3a22cc9b9807e52", null ],
    [ "kure_successors_si", "group__SpecialSets.html#ga64dfbd5da93e5b338c0dea068db10d67", null ],
    [ "kure_domain", "group__SpecialSets.html#gadf0caaa4e0e42d4bb681e101fab82a1a", null ]
];