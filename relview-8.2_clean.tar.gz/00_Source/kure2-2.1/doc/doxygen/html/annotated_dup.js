var annotated_dup =
[
    [ "_KureError", "struct__KureError.html", "struct__KureError" ],
    [ "_KureParserObserver", "struct__KureParserObserver.html", "struct__KureParserObserver" ]
];