var group__Hulls =
[
    [ "kure_trans_hull", "group__Hulls.html#gac4db149cfc58f86e9795cb6703825211", null ],
    [ "kure_symm_hull", "group__Hulls.html#gaca1815e520d447e528d3c5b9a043dac0", null ],
    [ "kure_refl_hull", "group__Hulls.html#ga261d0a5ce8b1fbb0f2b19495e157ebec", null ]
];