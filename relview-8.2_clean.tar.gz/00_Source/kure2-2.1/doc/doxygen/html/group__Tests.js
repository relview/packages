var group__Tests =
[
    [ "kure_is_row_complete_si", "group__Tests.html#ga1d0232a4d70bd9811766795a987ff466", null ],
    [ "kure_is_empty", "group__Tests.html#ga8115cdb9e78fe3e2482583b8e4031654", null ],
    [ "kure_is_univalent", "group__Tests.html#ga374a6e5f66d0221ee07bd7d4457b004d", null ],
    [ "kure_is_vector", "group__Tests.html#ga876035f35e2889d655ecc09d97dc61eb", null ],
    [ "kure_is_hom", "group__Tests.html#gaf299c00a97a51013a855130cbbb6a459", null ]
];