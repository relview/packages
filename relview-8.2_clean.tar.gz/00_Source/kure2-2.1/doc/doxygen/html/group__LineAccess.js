var group__LineAccess =
[
    [ "kure_set_row", "group__LineAccess.html#gaaf52f42d7afebff4f6213baaeb197f8b", null ],
    [ "kure_set_row_si", "group__LineAccess.html#gafd0efc3fb0dcebd5210d2ce39cafd79a", null ]
];