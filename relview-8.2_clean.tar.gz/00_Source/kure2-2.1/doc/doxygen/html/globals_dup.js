var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "f", "globals_f.html", null ],
    [ "k", "globals_k.html", null ],
    [ "t", "globals_t.html", null ]
];