var group__LuaAndLanguage =
[
    [ "_KureParserObserver", "struct__KureParserObserver.html", [
      [ "onFunction", "struct__KureParserObserver.html#a9f1b38af574273d173da712c3a9366eb", null ],
      [ "onProgram", "struct__KureParserObserver.html#aaf80fcd08d4187dfb94824ab6c33e7c5", null ],
      [ "object", "struct__KureParserObserver.html#a28425f473264d2b766e1305e3db37391", null ]
    ] ],
    [ "KureParserObserver", "group__LuaAndLanguage.html#gabffdc7586f193dc826a265b8417a6df1", null ],
    [ "kure_lua_new", "group__LuaAndLanguage.html#ga235e56782a4d71827b9ff92ee8d1d9af", null ],
    [ "kure_lua_destroy", "group__LuaAndLanguage.html#ga23affd3e2d5e4ac554631f6738d13dcf", null ],
    [ "kure_lua_exec", "group__LuaAndLanguage.html#gac5bc33d165f704d2657b0ec5240b1474", null ],
    [ "kure_lua_set_rel_copy", "group__LuaAndLanguage.html#gace9e5f6cc1d548f0a8ffe3030ef688da", null ],
    [ "kure_lua_get_rel_copy", "group__LuaAndLanguage.html#ga7f36f2310bfd303df4b1067551e09dd0", null ],
    [ "kure_lua_set_dom_copy", "group__LuaAndLanguage.html#ga569df68ca01bd1022da3679b30f9c019", null ],
    [ "kure_lua_get_context", "group__LuaAndLanguage.html#ga4f2ba612357b347b724862a96c0a4edc", null ],
    [ "kure_lua_torel", "group__LuaAndLanguage.html#ga39b9cd671ee536f5d310735a58d3d979", null ],
    [ "kure_lua_isrel", "group__LuaAndLanguage.html#ga931b0e8741caf39995b3c9b6d40f7599", null ],
    [ "kure_lua_todom", "group__LuaAndLanguage.html#ga2d8a52096742ef31ce9df77b67596961", null ],
    [ "kure_lua_isdom", "group__LuaAndLanguage.html#ga6044b5d4e1ae9ee3eebebcf937d4145e", null ],
    [ "kure_lua_set_global_context", "group__LuaAndLanguage.html#ga2c5453a3128cee9f27ec1d9d8978338e", null ],
    [ "kure_lang_to_lua", "group__LuaAndLanguage.html#gab37ff04f6de84245a3a7bfa42d96b45a", null ],
    [ "kure_lang_expr_to_lua", "group__LuaAndLanguage.html#ga862aa52c6495723614ec446e7f972a1f", null ],
    [ "kure_lang_exec", "group__LuaAndLanguage.html#gadfe27ab3c3092e9f9429fe1005ae32ba", null ],
    [ "kure_lang_assign", "group__LuaAndLanguage.html#ga3a46734ab88714dc287811214ba0ae34", null ],
    [ "kure_lang_parse", "group__LuaAndLanguage.html#ga2568a9b341f0ecef7b3253084280b1c8", null ],
    [ "kure_lang_parse_file", "group__LuaAndLanguage.html#gabea34a28f398162b13cd6a6e00c55949", null ],
    [ "kure_lang_load", "group__LuaAndLanguage.html#ga5b62af6fab3dc7644c90a98d6787c4fa", null ],
    [ "kure_lang_load_file", "group__LuaAndLanguage.html#gae18d5924ef47df74cacebb8668006ab4", null ],
    [ "kure_lang_set_assert_func", "group__LuaAndLanguage.html#ga18c1272ead971ea137158354f0187901", null ]
];