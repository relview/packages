var group__Contexts =
[
    [ "kure_context_new", "group__Contexts.html#ga8a68a66d2d8287e03d38f9a1392e4523", null ],
    [ "kure_context_new_with_manager", "group__Contexts.html#gaca5ab2b262059dbd6e7a429bba00353a", null ],
    [ "kure_context_destroy", "group__Contexts.html#ga9511db62dd2afff6008a5720f2a03248", null ],
    [ "kure_context_get_manager", "group__Contexts.html#gab465a014cdeb30265596e0ae2f1c1d62", null ],
    [ "kure_context_get_error", "group__Contexts.html#ga4ebb6874ea7fcf74a5690d22fcd94c21", null ],
    [ "kure_context_get_random_func", "group__Contexts.html#ga6fba6d096109be92b7f48bf6e0df6a07", null ],
    [ "kure_context_get_random_udata", "group__Contexts.html#ga7857f71f3469c9eb9022162601e4e9fa", null ],
    [ "kure_context_set_random_func", "group__Contexts.html#gae64b18d4604ba04a87db0683fe328a48", null ],
    [ "kure_context_random", "group__Contexts.html#gaa8d6c8161ca400c56c521d8ed2ee8e22", null ],
    [ "kure_context_ref", "group__Contexts.html#ga696de7c9060df168e6b53061462a6355", null ],
    [ "kure_context_deref", "group__Contexts.html#gabe0c024b30a54b83d6c8ab3d30d020d9", null ],
    [ "kure_context_get_refs", "group__Contexts.html#ga913dadbc5222e831bdc87c4c0c25928b", null ]
];