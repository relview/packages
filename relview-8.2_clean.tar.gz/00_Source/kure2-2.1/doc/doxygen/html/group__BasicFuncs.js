var group__BasicFuncs =
[
    [ "kure_and", "group__BasicFuncs.html#ga80837e5fd5dff13a20416a2cf20937c9", null ],
    [ "kure_or", "group__BasicFuncs.html#ga466ffd301cf2dd58f6f633c83edd2314", null ],
    [ "kure_transpose", "group__BasicFuncs.html#ga2f0b650f1133baf798910f303b06079a", null ],
    [ "kure_complement", "group__BasicFuncs.html#gaf3c12b66ed29229d5e5bc5cefe63e119", null ],
    [ "kure_mult", "group__BasicFuncs.html#ga7b703d4590f6560715bf96850bf0d637", null ],
    [ "kure_mult_transp_norm", "group__BasicFuncs.html#gabe4e90bd515726a8f6741c784935c5b7", null ],
    [ "kure_mult_norm_transp", "group__BasicFuncs.html#ga4e8acc0db01a10eb0981969812258d75", null ],
    [ "kure_mult_transp_transp", "group__BasicFuncs.html#gadc484bd2c8534fda098f6c725704ffec", null ]
];