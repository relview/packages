var group__ErrorHandling =
[
    [ "_KureError", "struct__KureError.html", [
      [ "message", "struct__KureError.html#a68a862f16802c1e5b29842116d2608e4", null ],
      [ "code", "struct__KureError.html#a1fea2b72143a116c888d386344f92b4b", null ]
    ] ],
    [ "Kure_success", "group__ErrorHandling.html#gaebc8721b6bf7f73c8f7717f645f6c502", null ],
    [ "KureErrorCode", "group__ErrorHandling.html#gaacf1595f6abd9bd216b2aa45db072404", null ],
    [ "KureError", "group__ErrorHandling.html#gaa299bb3521d177d2d0243d225021bf38", null ],
    [ "_KureErrorCode", "group__ErrorHandling.html#ga20bdcd463b5f341d6b464d195238d61d", [
      [ "KURE_ERR_INV_ARG", "group__ErrorHandling.html#gga20bdcd463b5f341d6b464d195238d61dacf33b70cc7fa5e8e9297bf940ff0731f", null ],
      [ "KURE_ERR_DIFF_CONTEXTS", "group__ErrorHandling.html#gga20bdcd463b5f341d6b464d195238d61da8a573dc225adbfc13ec48ec0aa5e8f63", null ],
      [ "KURE_ERR_NOT_SAME_DIM", "group__ErrorHandling.html#gga20bdcd463b5f341d6b464d195238d61dade092a75d2cb4a3a63b1eb1bd3aa1962", null ],
      [ "KURE_ERR_NOT_COMPAT_DIM", "group__ErrorHandling.html#gga20bdcd463b5f341d6b464d195238d61daa09282f3d4a76cffeb018f98b35ac55e", null ],
      [ "KURE_ERR_OUT_OF_BOUNDS", "group__ErrorHandling.html#gga20bdcd463b5f341d6b464d195238d61dad71f6ee0c0601f4e046367f31a24dddc", null ],
      [ "KURE_ERR_NUM_TOO_BIG", "group__ErrorHandling.html#gga20bdcd463b5f341d6b464d195238d61da467367495c28f73f6b426b7ebdbb7ce0", null ],
      [ "KURE_ERR_SUCCESS", "group__ErrorHandling.html#gga20bdcd463b5f341d6b464d195238d61dad3b589b255c03d4163ef97928cc15a4a", null ]
    ] ],
    [ "kure_error_new", "group__ErrorHandling.html#ga34e924a19006660ed0694672c86b2469", null ],
    [ "kure_error_destroy", "group__ErrorHandling.html#ga9edad1153167d760882b8735ccbd6db3", null ],
    [ "kure_set_error", "group__ErrorHandling.html#ga72406413bc648b83f969894e4b0382fd", null ],
    [ "kure_set_error_va", "group__ErrorHandling.html#gac483b7ce31b91020069fd9df2db9847c", null ]
];