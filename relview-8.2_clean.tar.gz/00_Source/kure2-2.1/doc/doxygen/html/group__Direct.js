var group__Direct =
[
    [ "kure_tupling", "group__Direct.html#gac4263aa04d2fe8efb12a407b4a804b8d", null ],
    [ "kure_direct_sum", "group__Direct.html#ga98fa0a215290ac3106178021c52b3827", null ],
    [ "kure_proj_1", "group__Direct.html#gad125a8bb3a9f7fd5b12c4968ba65f590", null ],
    [ "kure_proj_1_si", "group__Direct.html#ga241e4629a39aa41bce0cea34eb4a89a6", null ],
    [ "kure_proj_1_dom", "group__Direct.html#gad27e9c1ea8b20ee7c05458e1ca4b7ef4", null ],
    [ "kure_proj_2", "group__Direct.html#gaacc28eaf31a0a78efb655c3872e87a85", null ],
    [ "kure_proj_2_si", "group__Direct.html#ga014d6095cba9a8392d0dd9c0ab2f4dc9", null ],
    [ "kure_proj_2_dom", "group__Direct.html#ga07c1351cff882afd4c2ca500cbbf4028", null ],
    [ "kure_inj_1", "group__Direct.html#ga010807fb8377b3fd7d351843a243939f", null ],
    [ "kure_inj_1_si", "group__Direct.html#ga25118ad2203244d6ec4bb2c0dbebc1ad", null ],
    [ "kure_inj_1_dom", "group__Direct.html#ga18902ca63740dd90da3afd9f247c0fdf", null ],
    [ "kure_inj_2", "group__Direct.html#ga125d492e61fa9007cd8873a4772665c0", null ],
    [ "kure_inj_2_si", "group__Direct.html#ga4ad20887af34cd87ad3769f15955f346", null ],
    [ "kure_inj_2_dom", "group__Direct.html#ga16d3c52df434c28ec88fc1890544d6d8", null ],
    [ "kure_product_order", "group__Direct.html#ga36a685e75d7b79d5fc97a4587985b26a", null ],
    [ "kure_sum_order", "group__Direct.html#ga94e846207897b10c4a24d06a5c3c579c", null ],
    [ "kure_minsets_upset", "group__Direct.html#ga2b88b2b613be2c8d6582e7ef471b391f", null ],
    [ "kure_minsets", "group__Direct.html#gac9ad7adaabef2264d1c6a347c9344d30", null ],
    [ "kure_maxsets_downset", "group__Direct.html#ga50c6d7e7bfacad541768d9a9ed62a159", null ],
    [ "kure_maxsets", "group__Direct.html#ga793a5f568ca50120aa3212875796c443", null ]
];