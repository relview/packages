/*
 * main.c
 *
 *  Copyright (C) 2011 Stefan Bolus, University of Kiel, Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

# include "relview/plugin.h"

#define NDEBUG 1

#define MSG_PREFIX "simple-game-labels"

/* --------------------------------------------------------- ZeroOneLabel --- */

typedef enum _LabelAxis
{
	COLS, ROWS
} LabelAxis;


/* Used internally for the label function. */
typedef struct _ZeroOneLabel {
	/* We use a copy of the relation that was initially passed. */
	KureRel * impl;
	LabelAxis what;
} ZeroOneLabel;



/*!
 * Destroy the given object.
 *
 * \author stb
 * \date 07.02.2009
 *
 * \param self The object to destroy.
 */
static void _zero_one_label_destroy (ZeroOneLabel * self)
{
	kure_rel_destroy (self->impl);
	g_free (self);
}


/*!
 * Label function of type \ref LabelFunc. See label.h for details.
 *
 * \author stb
 * \date 07.02.2009
 *
 * \param n 1-indexed row or column number to generate a label for.
 * \param buf Buffer to store the label in.
 * \param buf_size Size for the label including the terminating nul-byte.
 * \param data The label function's user data. The \ref ZeroOneLabel object
 *             in our case.
 */
static const gchar * _zero_one_labelfunc (int n, GString * s, gpointer user_data)
{
	ZeroOneLabel * self = (ZeroOneLabel*) user_data;
	KureRel * impl = self->impl;

#ifndef NDEBUG
	fprintf (stderr, MSG_PREFIX": _zero_one_labelfunc(n=%d (1-indexed),_)\n", n);
#endif

	if ( ! kure_rel_fits_si(impl)) {
		g_string_printf (s, "too big");
	}
	else {
		int rowCount = kure_rel_get_rows_si(impl),
				colCount = kure_rel_get_cols_si(impl);

		int count = (ROWS == self->what) ? rowCount : colCount;

		if (n > 0 && n <= count) {
			int ones = 0;
			int row, col, row_step, col_step;
			int vars_rows = kure_rel_get_vars_rows(impl),
					vars_cols = kure_rel_get_vars_cols(impl);

			if (ROWS == self->what) /* n is a row number */ {
				row = n-1; col = 0;
				row_step = 0; col_step = 1;
			}
			else {
				row = 0; col = n-1;
				row_step = 1; col_step = 0;
			}

			/* Count the number of 1s in the rows or cols. */
			while (row < rowCount && col < colCount) {
				ones += kure_get_bit_fast_si (impl, row, col, vars_rows, vars_cols);

				row += row_step;
				col += col_step;
			}

			g_string_printf(s, "%d / %d", n, ones);
		}
		else {
			/* Out of bounds. Maybe the user uses the label to label another
			 * relation. */
			g_string_assign(s, "");
		}
	}

	return s->str;
}

static int _labelfunc_identify_maxlen (int first, int last, void * user_data)
{
	return (int)ceil(log10(last));
}

/*!
 * Create a ZeroOneLabel for the given relation's rows or columns.
 *
 * \author stb
 * \date 07.02.2009
 *
 * \param rel The relation to create the label for. Must not be NULL.
 * \param what ROWS or COLS. See the top of this file.
 */
static Label * _zero_one_label_new (Rel * rel, LabelAxis what)
{
	if (!rel) return NULL;
	else {
		gchar * name = g_strdup_printf ("01_%s_%s", (what==COLS)?"cols":"rows", rel_get_name(rel));
		ZeroOneLabel * self = g_new0 (ZeroOneLabel, 1);
		Relview * rv = rv_get_instance ();
		Label * label = NULL;

		self->impl = kure_rel_new_copy(rel_get_impl (rel));
		self->what = what;

		/* If the user previously created such a label, replace it. */
		if (rv_label_exists (rv, name))
			rv_label_remove_by_name (rv, name);

		label = (Label*)label_func_new (name, _zero_one_labelfunc, self,  _labelfunc_identify_maxlen,
				(GFreeFunc)_zero_one_label_destroy);
		rv_label_add (rv, label);

		g_free (name);
		return label;
	}
}

/*******************************************************************************
 *                         Relview Plugin Integration                          *
 ******************************************************************************/

/*!
 * Callback for the availability of a menu entry. Always returns TRUE
 * indicating that the menu entry is always available.
 */
static gboolean _always_enabled (gpointer user_data, MenuEntry * entry, gpointer obj) {
	return TRUE;
}



/*!
 * Called when the user selected and entry in the popup menu.
 *
 * Create a ZeroOneLabel for the given relation. The labels will be
 * set for the relation. Remark: We neither care on any update of
 * the relations contents. Thus, if the relation is changed, e.g.
 * by the user, the labels displayed may be out of date, until some
 * other routine feels responsible to update them.
 *
 * The labels will be available in the global label namespace. They
 * won't be deleted automatically, if the relation is removed.
 *
 * \param user_data Pointer to the function which is to be called.
 * \param entry The menu entry.
 * \param obj The RelationWindow object.
 */
static void _on_activate (gpointer user_data, MenuEntry * entry, gpointer obj)
{
	Relview * rv = rv_get_instance();
	RelationWindow * window = (RelationWindow*) obj;
	Rel * rel = relation_window_get_relation (window);

	if (rel) {
		RelationViewport * viewport = relation_window_get_viewport (window);
		Label * rowLabel = _zero_one_label_new (rel, ROWS),
				*colLabel = _zero_one_label_new (rel, COLS);

		LabelAssoc assoc = rv_label_assoc_get (rv, rel, viewport);
		assoc.labels[0] = rowLabel;
		assoc.labels[1] = colLabel;

		rv_label_assoc_set (rv, &assoc);
	}
	else { /* No relation. Ignore */ }
}



G_MODULE_EXPORT static gboolean onInit (int * version, rvp_plugin_id_t id)
{
    return TRUE; /* don't ignore module. */
}


static const char _menu_path [] = "/relation-window";
static MenuEntry * _menu_entry = NULL;


G_MODULE_EXPORT static void onEnable (const gchar * message)
{
	Relview * rv = rv_get_instance();
	MenuManager * manager = rv_get_menu_manager(rv);
	MenuDomain * domain = menu_manager_get_domain(manager, _menu_path);

	if ( NULL == domain) {
		g_warning (MSG_PREFIX": Unknown menu domain: %s", _menu_path);
	}
	else {
		gboolean success;

		_menu_entry = menu_entry_new ("Create 0/1 Labels", _always_enabled,
				_on_activate, NULL);
		if (_menu_entry) {
			success = menu_domain_add (domain, "actions" /*subpath*/, _menu_entry);
			if ( !success) {
				g_warning (MSG_PREFIX": Unable to add menu entry to %s/actions",	_menu_path);
				menu_entry_destroy (_menu_entry);
			}
		}
	}
}


G_MODULE_EXPORT static void onDisable ()
{
	if (_menu_entry) {
		Relview * rv = rv_get_instance();
		MenuManager * manager = rv_get_menu_manager(rv);
		MenuDomain * domain = menu_manager_get_domain(manager, _menu_path);
		if (menu_domain_steal (domain, _menu_entry)) {
			menu_entry_destroy (_menu_entry);
			_menu_entry = NULL;
		}
	}
}


RvPlugInInfo PLUG_IN_INFO = {
		onInit, NULL, onEnable, onDisable,
		(gchar*) "0/1 Labels",
		(gchar*) "Creates a pair of Labels for a Relation which show the Number of Bits set in the Rows and Columns, resp."
};


RV_PLUGIN_MAIN()

